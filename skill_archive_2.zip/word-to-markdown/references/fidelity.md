# Fidelity reference

## Preservation model

This skill targets semantic preservation and recoverability, not Word page-layout replication. The main output is GitHub-Flavored Markdown plus raw HTML; Word-only semantics are preserved in sidecars and archived OOXML when possible.

## Expected preservation

| Word feature | Preservation strategy |
| --- | --- |
| Headings, paragraphs, emphasis, links | Pandoc -> Markdown |
| Ordered/unordered/multilevel lists | Pandoc -> Markdown, with numbering OOXML retained for audit |
| Simple tables | GFM tables when representable |
| Merged-cell tables | Raw HTML fallback |
| Images | Pandoc-linked assets plus byte-identical `assets/original-media/` copies |
| Image alt/title metadata | Audited in `extras/drawings.json` and checked against main Markdown |
| Footnotes/endnotes | Main Markdown where Pandoc supports them, plus note sidecars |
| Office Math | TeX math where Pandoc can convert it; original OOXML remains archived |
| Comments | JSON + Markdown sidecars with metadata and anchored text when available |
| Tracked revisions | Main output according to mode plus independent revision sidecars |
| Headers/footers | Semantic Markdown sidecars plus archived OOXML |
| Word fields | Displayed content in main conversion where possible; instructions in `fields.json` |
| Document properties | `metadata.json` |
| Word-only semantic parts | `extras/ooxml/` according to archival mode |

## Unavoidable representation changes

Markdown has no native page model, so exact margins, page size, columns, line wrapping, page breaks, section geometry, repeated headers/footers, and floating-object placement cannot be recreated exactly.

Dynamic Word fields have evaluation behavior that Markdown does not implement. The pipeline preserves field instructions separately, but Markdown does not recalculate them.

SmartArt, charts, ActiveX/OLE objects, and embedded application packages can be archived as source parts, but their native editing behavior cannot become Markdown behavior.

Text boxes and floating shapes may contain visible text/media that can be recovered, while geometry, layering, rotation, and wrapping remain Word-specific.

## Report interpretation

`media_verification` checks the independent `assets/original-media/` archive. A true `all_source_media_byte_identical` means every payload under `word/media/` appears byte-for-byte in the output.

`pandoc_media_verification` separately reports which media Pandoc extracted for the main Markdown. It can legitimately be incomplete for media used only in headers, footers, or other Word-only parts.

`semantic_text_verification` compares normalized Pandoc plain-text views of the DOCX and generated Markdown. Differences are a review signal, not automatically a conversion failure, because raw HTML tables, notes, or tracked-change rendering can normalize differently.

`drawing_verification` checks whether main-document drawing alt/title text appears verbatim in the Markdown. Missing alt/title is reported for review while the original metadata remains in `drawings.json` and OOXML.

Warnings use:

- `info`: expected representation change or extra preservation sidecar.
- `warning`: manual review is recommended because Markdown cannot fully reproduce the source behavior or a verification check found a potential fidelity gap.

## Modes

`preserve` passes tracked changes through Pandoc with `--track-changes=all` and independently exports revision metadata.

`clean` uses `--track-changes=accept` for the main Markdown but still exports original revision sidecars before conversion.

## OOXML archival

`semantic` keeps important XML/relationship parts and complex object payloads needed for recoverability without duplicating normal Word media.

`all` archives every non-media DOCX package part.

`none` omits the OOXML archive and should only be chosen when a smaller output is more important than recoverability.
