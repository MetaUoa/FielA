# Conversion report schema v2

`conversion-report.json` is the machine-readable audit record for a conversion.

Key sections:

- `source`: source filename, size, and SHA-256.
- `conversion`: Pandoc version, tested minimum, mode, reader/writer, command, and atomic-output flag.
- `source_features`: main-body counts plus per-part and aggregate OOXML feature counts.
- `comments_summary`, `revisions_summary`, `notes_summary`, `fields_summary`: sidecar feature counts.
- `media_verification`: byte-identity check against `assets/original-media/`.
- `pandoc_media_verification`: media extracted by Pandoc for the main Markdown.
- `drawing_verification`: main-document alt/title audit.
- `semantic_text_verification`: normalized plain-text comparison signal.
- `ooxml_archive`: archival mode and archived-file hashes.
- `output_manifest`: output file sizes and SHA-256 hashes, excluding the report itself.
- `warnings`: structured fidelity findings with `code`, `severity`, and `message`.

Treat schema version 2 as the contract implemented by the bundled converter.
