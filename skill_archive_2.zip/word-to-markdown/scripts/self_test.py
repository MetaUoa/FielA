#!/usr/bin/env python3
"""Regression-oriented smoke test for the Word-to-Markdown preservation pipeline."""

from __future__ import annotations

import base64
import hashlib
import json
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

try:
    from docx import Document
    from docx.enum.text import WD_BREAK
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from lxml import etree
except ImportError:
    print("self-test requires python-docx>=1.2 and lxml", file=sys.stderr)
    raise SystemExit(2)

PNG_1X1 = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII="
)
W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def add_simple_field(paragraph, instruction: str, displayed: str) -> None:
    fld = OxmlElement("w:fldSimple")
    fld.set(qn("w:instr"), instruction)
    run = OxmlElement("w:r")
    text = OxmlElement("w:t")
    text.text = displayed
    run.append(text)
    fld.append(run)
    paragraph._p.append(fld)


def add_simple_math(paragraph) -> None:
    math = OxmlElement("m:oMath")
    run = OxmlElement("m:r")
    text = OxmlElement("m:t")
    text.text = "x+1"
    run.append(text)
    math.append(run)
    paragraph._p.append(math)


def patch_tracked_changes(path: Path) -> None:
    with zipfile.ZipFile(path, "r") as src:
        files = {name: src.read(name) for name in src.namelist()}

    root = etree.fromstring(files["word/document.xml"])
    ns = {"w": W_NS}
    target = None
    for node in root.xpath(".//w:t", namespaces=ns):
        if node.text == "Inserted revision":
            target = node
            break
    if target is None:
        raise RuntimeError("tracked-change fixture text not found")

    run = target.getparent()
    parent = run.getparent()
    idx = parent.index(run)
    parent.remove(run)

    ins = etree.Element(qn("w:ins"))
    ins.set(qn("w:id"), "42")
    ins.set(qn("w:author"), "QA Reviewer")
    ins.set(qn("w:date"), "2026-09-22T12:00:00Z")
    ins.append(run)

    deletion = etree.Element(qn("w:del"))
    deletion.set(qn("w:id"), "43")
    deletion.set(qn("w:author"), "QA Reviewer")
    deletion.set(qn("w:date"), "2026-09-22T12:01:00Z")
    del_run = etree.Element(qn("w:r"))
    del_text = etree.Element(qn("w:delText"))
    del_text.text = "Deleted revision"
    del_run.append(del_text)
    deletion.append(del_run)

    parent.insert(idx, deletion)
    parent.insert(idx + 1, ins)
    files["word/document.xml"] = etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone="yes")

    temp = path.with_suffix(".patched.docx")
    with zipfile.ZipFile(temp, "w", zipfile.ZIP_DEFLATED) as dst:
        for name, data in files.items():
            dst.writestr(name, data)
    temp.replace(path)


def build_fixture(path: Path) -> None:
    doc = Document()
    doc.core_properties.title = "Word to Markdown V2 Fidelity Test"
    doc.core_properties.author = "Self Test"

    doc.add_heading("High-fidelity conversion", level=1)
    p = doc.add_paragraph()
    p.add_run("Bold text").bold = True
    p.add_run(", ")
    p.add_run("italic text").italic = True

    doc.add_paragraph("Bullet one", style="List Bullet")
    doc.add_paragraph("Bullet nested", style="List Bullet 2")
    doc.add_paragraph("Number one", style="List Number")
    doc.add_paragraph("Number nested", style="List Number 2")

    table = doc.add_table(rows=2, cols=3)
    table.cell(0, 0).text = "Merged A"
    table.cell(0, 1).text = "Merged B"
    table.cell(0, 2).text = "C"
    table.cell(1, 0).text = "D"
    table.cell(1, 1).text = "E"
    table.cell(1, 2).text = "F"
    table.cell(0, 0).merge(table.cell(0, 1))

    image_path = path.with_suffix(".png")
    image_path.write_bytes(PNG_1X1)
    shape = doc.add_picture(str(image_path))
    shape._inline.docPr.set("descr", "Tiny fidelity pixel")
    shape._inline.docPr.set("title", "Self-test image")

    comment_p = doc.add_paragraph()
    comment_run = comment_p.add_run("Comment target text")
    doc.add_comment(comment_run, text="Review this wording", author="QA", initials="Q")

    tracked = doc.add_paragraph()
    tracked.add_run("Inserted revision")

    field_p = doc.add_paragraph("Field: ")
    add_simple_field(field_p, "DATE", "2026-09-22")

    math_p = doc.add_paragraph("Equation: ")
    add_simple_math(math_p)

    doc.sections[0].header.paragraphs[0].text = "Header content"
    doc.sections[0].footer.paragraphs[0].text = "Footer content"

    page_break = doc.add_paragraph().add_run()
    page_break.add_break(WD_BREAK.PAGE)
    doc.add_heading("Page two", level=2)
    doc.save(path)
    patch_tracked_changes(path)


def run_convert(script: Path, docx: Path, out: Path, mode: str = "preserve") -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [
            sys.executable, str(script), str(docx), "-o", str(out),
            "--mode", mode, "--ooxml-archive", "semantic", "--force",
        ],
        capture_output=True,
        text=True,
    )


def main() -> int:
    script = Path(__file__).with_name("convert_docx.py")
    with tempfile.TemporaryDirectory(prefix="word-to-markdown-v2-") as td:
        root = Path(td)
        docx = root / "fixture.docx"
        out = root / "out"
        clean_out = root / "clean-out"
        build_fixture(docx)
        source_before = sha256(docx)

        proc = run_convert(script, docx, out, "preserve")
        if proc.returncode != 0:
            print(proc.stdout)
            print(proc.stderr, file=sys.stderr)
            return proc.returncode

        md = (out / "document.md").read_text(encoding="utf-8")
        report = json.loads((out / "conversion-report.json").read_text(encoding="utf-8"))
        comments = json.loads((out / "extras/comments.json").read_text(encoding="utf-8"))
        revisions = json.loads((out / "extras/revisions.json").read_text(encoding="utf-8"))
        fields = json.loads((out / "extras/fields.json").read_text(encoding="utf-8"))
        headers = (out / "extras/headers.md").read_text(encoding="utf-8")
        footers = (out / "extras/footers.md").read_text(encoding="utf-8")
        archived_doc = out / "extras/ooxml/word/document.xml"
        archived_comments = out / "extras/ooxml/word/comments.xml"
        original_media = list((out / "assets/original-media").glob("*"))

        checks = {
            "source_unchanged": sha256(docx) == source_before,
            "heading": "# High-fidelity conversion" in md,
            "bold": "**Bold text**" in md,
            "complex_table_html": "<table" in md and "colspan" in md,
            "main_image_reference": "assets/media/" in md,
            "original_media_preserved": bool(original_media) and sha256(original_media[0]) == hashlib.sha256(PNG_1X1).hexdigest(),
            "media_hash_verified": report["media_verification"]["all_source_media_byte_identical"],
            "schema_v2": report["schema_version"] == 2,
            "atomic_output_flag": report["conversion"]["atomic_output"] is True,
            "pandoc_minimum_recorded": report["conversion"]["minimum_tested_pandoc"] == [3, 1, 0],
            "complex_table_detected": report["source_features"]["complex_table_colspans"] > 0,
            "header_sidecar": "Header content" in headers,
            "footer_sidecar": "Footer content" in footers,
            "comment_exported": comments and comments[0]["text"] == "Review this wording",
            "comment_anchor_exported": comments and any(a.get("text") == "Comment target text" for a in comments[0].get("anchors", [])),
            "insert_revision_exported": any(r["kind"] == "insert" and "Inserted revision" in r["text"] for r in revisions),
            "delete_revision_exported": any(r["kind"] == "delete" and "Deleted revision" in r["text"] for r in revisions),
            "field_exported": any("DATE" in f.get("instruction", "") for f in fields),
            "math_detected": report["source_features"]["math_objects"] > 0,
            "drawing_alt_audited": report["drawing_verification"]["drawings_with_alt_or_title"] > 0,
            "ooxml_document_archived": archived_doc.is_file(),
            "ooxml_comments_archived": archived_comments.is_file(),
            "package_manifest_written": (out / "extras/source-package-manifest.json").is_file(),
        }

        # Atomic replacement must remove stale files rather than leaving residues.
        (out / "stale.txt").write_text("must disappear", encoding="utf-8")
        proc2 = run_convert(script, docx, out, "preserve")
        checks["atomic_force_removes_stale"] = proc2.returncode == 0 and not (out / "stale.txt").exists()

        # Clean mode accepts tracked changes in the main Markdown but must retain revision sidecars.
        clean_proc = run_convert(script, docx, clean_out, "clean")
        if clean_proc.returncode == 0:
            clean_report = json.loads((clean_out / "conversion-report.json").read_text(encoding="utf-8"))
            checks["clean_mode_revision_sidecar"] = (clean_out / "extras/revisions.json").is_file()
            checks["clean_mode_accept_warning"] = any(w["code"] == "TRACK_CHANGES_ACCEPTED" for w in clean_report["warnings"])
        else:
            checks["clean_mode_revision_sidecar"] = False
            checks["clean_mode_accept_warning"] = False

        failed = [name for name, ok in checks.items() if not ok]
        print(json.dumps({"checks": checks, "failed": failed}, indent=2, ensure_ascii=False))
        if failed:
            print("preserve stdout:", proc.stdout)
            print("preserve stderr:", proc.stderr, file=sys.stderr)
            print("clean stdout:", clean_proc.stdout)
            print("clean stderr:", clean_proc.stderr, file=sys.stderr)
        return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
