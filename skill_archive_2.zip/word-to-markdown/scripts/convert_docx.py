#!/usr/bin/env python3
"""Production-oriented DOCX -> Markdown preservation pipeline.

Pandoc performs the primary semantic conversion. This wrapper adds:
- atomic output replacement;
- minimum Pandoc compatibility checks;
- whole-package OOXML auditing;
- byte-identical extraction of every source media payload;
- sidecars for headers, footers, comments, revisions, notes, and fields;
- selected OOXML archival for structures Markdown cannot faithfully model;
- media, drawing-alt-text, and plain-text parity checks;
- a machine-readable conversion report.

The source DOCX is never modified.
"""

from __future__ import annotations

import argparse
import hashlib
import html
import json
import mimetypes
import os
import posixpath
import re
import shutil
import subprocess
import sys
import tempfile
import unicodedata
import uuid
import zipfile
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, Optional
import xml.etree.ElementTree as ET

NS = {
    "w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "wp": "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "m": "http://schemas.openxmlformats.org/officeDocument/2006/math",
    "cp": "http://schemas.openxmlformats.org/package/2006/metadata/core-properties",
    "dc": "http://purl.org/dc/elements/1.1/",
    "dcterms": "http://purl.org/dc/terms/",
    "ep": "http://schemas.openxmlformats.org/officeDocument/2006/extended-properties",
    "rel": "http://schemas.openxmlformats.org/package/2006/relationships",
}

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
R = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
WP = "{http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing}"

CONTENT_TYPES = "[Content_Types].xml"
DOCUMENT_XML = "word/document.xml"
CORE_XML = "docProps/core.xml"
APP_XML = "docProps/app.xml"
CUSTOM_XML = "docProps/custom.xml"
MIN_PANDOC_VERSION = (3, 1, 0)
REPORT_SCHEMA_VERSION = 2


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _read_xml(zf: zipfile.ZipFile, name: str) -> Optional[ET.Element]:
    try:
        return ET.fromstring(zf.read(name))
    except KeyError:
        return None
    except ET.ParseError as exc:
        raise RuntimeError(f"Invalid XML in {name}: {exc}") from exc


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1] if "}" in tag else tag


def _text_content(elem: Optional[ET.Element]) -> str:
    if elem is None:
        return ""
    chunks: list[str] = []
    for node in elem.iter():
        name = _local(node.tag)
        if name in {"t", "delText"} and node.text:
            chunks.append(node.text)
        elif name == "tab":
            chunks.append("\t")
        elif name in {"br", "cr"}:
            chunks.append("\n")
    return "".join(chunks)


def _count(root: Optional[ET.Element], xpath: str) -> int:
    return 0 if root is None else len(root.findall(xpath, NS))


def _core_metadata(root: Optional[ET.Element]) -> Dict[str, Any]:
    if root is None:
        return {}
    mapping = {
        "title": "dc:title",
        "subject": "dc:subject",
        "creator": "dc:creator",
        "keywords": "cp:keywords",
        "description": "dc:description",
        "last_modified_by": "cp:lastModifiedBy",
        "revision": "cp:revision",
        "created": "dcterms:created",
        "modified": "dcterms:modified",
        "category": "cp:category",
        "content_status": "cp:contentStatus",
    }
    result: Dict[str, Any] = {}
    for key, xpath in mapping.items():
        node = root.find(xpath, NS)
        if node is not None and node.text is not None:
            result[key] = node.text
    return result


def _app_metadata(root: Optional[ET.Element]) -> Dict[str, Any]:
    if root is None:
        return {}
    wanted = [
        "Application", "AppVersion", "Company", "Manager", "Pages", "Words",
        "Characters", "Paragraphs", "Lines", "TotalTime",
    ]
    result: Dict[str, Any] = {}
    for key in wanted:
        node = root.find(f"ep:{key}", NS)
        if node is not None and node.text is not None:
            value: Any = node.text
            if key in {"Pages", "Words", "Characters", "Paragraphs", "Lines", "TotalTime"}:
                try:
                    value = int(value)
                except ValueError:
                    pass
            result[key] = value
    return result


def _custom_metadata(root: Optional[ET.Element]) -> Dict[str, Any]:
    if root is None:
        return {}
    result: Dict[str, Any] = {}
    for prop in list(root):
        name = prop.attrib.get("name")
        if not name:
            continue
        value_node = next(iter(prop), None)
        if value_node is not None:
            result[name] = value_node.text
    return result


def _rels_name_for_part(part_name: str) -> str:
    directory, filename = posixpath.split(part_name)
    return posixpath.join(directory, "_rels", filename + ".rels")


def _resolve_rel_target(part_name: str, target: str) -> str:
    if target.startswith("/"):
        return target.lstrip("/")
    return posixpath.normpath(posixpath.join(posixpath.dirname(part_name), target))


def _relationships_for_part(zf: zipfile.ZipFile, part_name: str) -> Dict[str, Dict[str, str]]:
    root = _read_xml(zf, _rels_name_for_part(part_name))
    result: Dict[str, Dict[str, str]] = {}
    if root is None:
        return result
    for rel in root.findall("rel:Relationship", NS):
        rid = rel.attrib.get("Id")
        if not rid:
            continue
        typ = rel.attrib.get("Type", "")
        target = rel.attrib.get("Target", "")
        mode = rel.attrib.get("TargetMode", "Internal")
        item = {
            "type": typ.rsplit("/", 1)[-1] if typ else "unknown",
            "target": target,
            "target_mode": mode,
        }
        if mode.lower() != "external":
            item["resolved_target"] = _resolve_rel_target(part_name, target)
        result[rid] = item
    return result


def _relationship_counts_all(zf: zipfile.ZipFile) -> Dict[str, int]:
    counts: Counter[str] = Counter()
    for name in zf.namelist():
        if not name.endswith(".rels"):
            continue
        root = _read_xml(zf, name)
        if root is None:
            continue
        for rel in root.findall("rel:Relationship", NS):
            typ = rel.attrib.get("Type", "")
            counts[typ.rsplit("/", 1)[-1] if typ else "unknown"] += 1
    return dict(sorted(counts.items()))


def _package_manifest(zf: zipfile.ZipFile) -> list[Dict[str, Any]]:
    items: list[Dict[str, Any]] = []
    for info in sorted(zf.infolist(), key=lambda x: x.filename):
        if info.is_dir():
            continue
        data = zf.read(info.filename)
        items.append({
            "path": info.filename,
            "bytes": len(data),
            "compressed_bytes": info.compress_size,
            "sha256": _sha256(data),
        })
    return items


def _source_media(zf: zipfile.ZipFile) -> list[Dict[str, Any]]:
    result: list[Dict[str, Any]] = []
    for name in sorted(n for n in zf.namelist() if n.startswith("word/media/") and not n.endswith("/")):
        data = zf.read(name)
        result.append({
            "source_path": name,
            "filename": Path(name).name,
            "bytes": len(data),
            "sha256": _sha256(data),
            "mime_guess": mimetypes.guess_type(name)[0],
        })
    return result


def _paragraph_style_counts(root: Optional[ET.Element]) -> Dict[str, int]:
    counts: Counter[str] = Counter()
    if root is None:
        return {}
    for pstyle in root.findall(".//w:pPr/w:pStyle", NS):
        counts[pstyle.attrib.get(W + "val", "(unknown)")] += 1
    return dict(sorted(counts.items()))


def _numbering_summary(zf: zipfile.ZipFile) -> Dict[str, int]:
    root = _read_xml(zf, "word/numbering.xml")
    if root is None:
        return {"abstract_numberings": 0, "numberings": 0, "levels": 0, "paragraph_num_properties": 0}
    doc = _read_xml(zf, DOCUMENT_XML)
    return {
        "abstract_numberings": _count(root, ".//w:abstractNum"),
        "numberings": _count(root, ".//w:num"),
        "levels": _count(root, ".//w:lvl"),
        "paragraph_num_properties": _count(doc, ".//w:numPr"),
    }


def _styles_summary(zf: zipfile.ZipFile) -> Dict[str, int]:
    root = _read_xml(zf, "word/styles.xml")
    return {
        "styles": _count(root, ".//w:style"),
        "based_on": _count(root, ".//w:basedOn"),
        "linked_styles": _count(root, ".//w:link"),
    }


def _feature_counts_for_root(root: Optional[ET.Element]) -> Dict[str, int]:
    if root is None:
        return {}
    counts = {
        "paragraphs": _count(root, ".//w:p"),
        "tables": _count(root, ".//w:tbl"),
        "table_cells": _count(root, ".//w:tc"),
        "complex_table_colspans": _count(root, ".//w:gridSpan"),
        "complex_table_vertical_merges": _count(root, ".//w:vMerge"),
        "hyperlinks": _count(root, ".//w:hyperlink"),
        "drawings": _count(root, ".//w:drawing"),
        "inline_drawings": _count(root, ".//wp:inline"),
        "floating_drawings": _count(root, ".//wp:anchor"),
        "legacy_pictures": _count(root, ".//w:pict"),
        "text_boxes": _count(root, ".//w:txbxContent"),
        "math_objects": _count(root, ".//m:oMath") + _count(root, ".//m:oMathPara"),
        "tracked_insertions": _count(root, ".//w:ins"),
        "tracked_deletions": _count(root, ".//w:del"),
        "tracked_moves_from": _count(root, ".//w:moveFrom"),
        "tracked_moves_to": _count(root, ".//w:moveTo"),
        "comment_range_starts": _count(root, ".//w:commentRangeStart"),
        "comment_references": _count(root, ".//w:commentReference"),
        "bookmarks": _count(root, ".//w:bookmarkStart"),
        "fields_simple": _count(root, ".//w:fldSimple"),
        "field_instructions": _count(root, ".//w:instrText"),
        "content_controls": _count(root, ".//w:sdt"),
        "section_properties": _count(root, ".//w:sectPr"),
        "alt_chunks": _count(root, ".//w:altChunk"),
        "footnote_references": _count(root, ".//w:footnoteReference"),
        "endnote_references": _count(root, ".//w:endnoteReference"),
        "manual_page_breaks": 0,
    }
    counts["manual_page_breaks"] = sum(
        1 for br in root.findall(".//w:br", NS) if br.attrib.get(W + "type") == "page"
    )
    return counts


def _semantic_xml_parts(zf: zipfile.ZipFile) -> list[str]:
    result = []
    for name in zf.namelist():
        if not name.startswith("word/") or not name.endswith(".xml"):
            continue
        if any(seg in name for seg in ("/theme/",)):
            continue
        result.append(name)
    return sorted(result)


def _drawing_manifest(zf: zipfile.ZipFile, xml_parts: Iterable[str]) -> list[Dict[str, Any]]:
    result: list[Dict[str, Any]] = []
    for part in xml_parts:
        root = _read_xml(zf, part)
        if root is None:
            continue
        rels = _relationships_for_part(zf, part)
        for drawing in root.findall(".//w:drawing", NS):
            doc_pr = drawing.find(".//wp:docPr", NS)
            blip = drawing.find(".//a:blip", NS)
            embed_id = blip.attrib.get(R + "embed") if blip is not None else None
            link_id = blip.attrib.get(R + "link") if blip is not None else None
            rel_id = embed_id or link_id
            rel = rels.get(rel_id, {}) if rel_id else {}
            result.append({
                "part": part,
                "name": doc_pr.attrib.get("name") if doc_pr is not None else None,
                "title": doc_pr.attrib.get("title") if doc_pr is not None else None,
                "alt_text": doc_pr.attrib.get("descr") if doc_pr is not None else None,
                "relationship_id": rel_id,
                "relationship_type": rel.get("type"),
                "target": rel.get("resolved_target") or rel.get("target"),
                "target_mode": rel.get("target_mode"),
            })
    return result


def _comment_anchors(root: Optional[ET.Element]) -> Dict[str, str]:
    captured: Dict[str, list[str]] = defaultdict(list)
    if root is None:
        return {}
    active: list[str] = []

    def walk(node: ET.Element) -> None:
        name = _local(node.tag)
        cid = node.attrib.get(W + "id")
        if name == "commentRangeStart" and cid is not None:
            active.append(cid)
        elif name == "commentRangeEnd" and cid is not None:
            for i in range(len(active) - 1, -1, -1):
                if active[i] == cid:
                    active.pop(i)
                    break
        elif name in {"t", "delText"} and node.text:
            for current in active:
                captured[current].append(node.text)
        elif name == "tab":
            for current in active:
                captured[current].append("\t")
        elif name in {"br", "cr"}:
            for current in active:
                captured[current].append("\n")
        for child in list(node):
            walk(child)

    walk(root)
    return {k: "".join(v) for k, v in captured.items()}


def _extract_comments(zf: zipfile.ZipFile, document_like_parts: Iterable[str]) -> list[Dict[str, Any]]:
    anchors: Dict[str, list[Dict[str, str]]] = defaultdict(list)
    for part in document_like_parts:
        root = _read_xml(zf, part)
        for cid, text in _comment_anchors(root).items():
            anchors[cid].append({"part": part, "text": text})

    comments: list[Dict[str, Any]] = []
    for name in sorted(n for n in zf.namelist() if re.fullmatch(r"word/comments\d*\.xml", n)):
        root = _read_xml(zf, name)
        if root is None:
            continue
        for comment in root.findall(".//w:comment", NS):
            cid = comment.attrib.get(W + "id", "")
            paragraphs = [_text_content(p).strip() for p in comment.findall(".//w:p", NS)]
            comments.append({
                "id": cid,
                "author": comment.attrib.get(W + "author"),
                "initials": comment.attrib.get(W + "initials"),
                "date": comment.attrib.get(W + "date"),
                "text": "\n".join(p for p in paragraphs if p),
                "anchors": anchors.get(cid, []),
                "source_part": name,
            })
    return comments


def _extract_revisions(zf: zipfile.ZipFile, document_like_parts: Iterable[str]) -> list[Dict[str, Any]]:
    result: list[Dict[str, Any]] = []
    tags = {
        W + "ins": "insert",
        W + "del": "delete",
        W + "moveFrom": "move_from",
        W + "moveTo": "move_to",
    }
    for part in document_like_parts:
        root = _read_xml(zf, part)
        if root is None:
            continue
        for elem in root.iter():
            kind = tags.get(elem.tag)
            if not kind:
                continue
            result.append({
                "kind": kind,
                "part": part,
                "id": elem.attrib.get(W + "id"),
                "author": elem.attrib.get(W + "author"),
                "date": elem.attrib.get(W + "date"),
                "text": _text_content(elem),
            })
    return result


def _extract_notes(zf: zipfile.ZipFile) -> Dict[str, list[Dict[str, Any]]]:
    result: Dict[str, list[Dict[str, Any]]] = {"footnotes": [], "endnotes": []}
    for kind, part, tag in (
        ("footnotes", "word/footnotes.xml", "footnote"),
        ("endnotes", "word/endnotes.xml", "endnote"),
    ):
        root = _read_xml(zf, part)
        if root is None:
            continue
        for note in root.findall(f".//w:{tag}", NS):
            result[kind].append({
                "id": note.attrib.get(W + "id"),
                "type": note.attrib.get(W + "type"),
                "text": _text_content(note).strip(),
            })
    return result


def _extract_fields(zf: zipfile.ZipFile, document_like_parts: Iterable[str]) -> list[Dict[str, Any]]:
    result: list[Dict[str, Any]] = []
    for part in document_like_parts:
        root = _read_xml(zf, part)
        if root is None:
            continue
        for elem in root.findall(".//w:fldSimple", NS):
            result.append({
                "kind": "simple",
                "part": part,
                "instruction": elem.attrib.get(W + "instr", ""),
                "display_text": _text_content(elem),
            })
        for elem in root.findall(".//w:instrText", NS):
            result.append({
                "kind": "instruction_text",
                "part": part,
                "instruction": elem.text or "",
            })
    return result


def inspect_docx(path: Path) -> Dict[str, Any]:
    if not zipfile.is_zipfile(path):
        raise ValueError(f"Not a valid DOCX/ZIP package: {path}")
    with zipfile.ZipFile(path) as zf:
        names = set(zf.namelist())
        if DOCUMENT_XML not in names or CONTENT_TYPES not in names:
            raise ValueError(f"ZIP package is not a valid Word .docx document: {path}")

        xml_parts = _semantic_xml_parts(zf)
        document_like_parts = [
            n for n in xml_parts
            if n == DOCUMENT_XML
            or re.fullmatch(r"word/header\d*\.xml", n)
            or re.fullmatch(r"word/footer\d*\.xml", n)
            or n in {"word/footnotes.xml", "word/endnotes.xml"}
        ]
        per_part: Dict[str, Dict[str, int]] = {}
        aggregate: Counter[str] = Counter()
        for part in document_like_parts:
            counts = _feature_counts_for_root(_read_xml(zf, part))
            per_part[part] = counts
            aggregate.update(counts)

        main_root = _read_xml(zf, DOCUMENT_XML)
        main_counts = _feature_counts_for_root(main_root)
        rel_counts = _relationship_counts_all(zf)
        header_parts = sorted(n for n in names if re.fullmatch(r"word/header\d*\.xml", n))
        footer_parts = sorted(n for n in names if re.fullmatch(r"word/footer\d*\.xml", n))

        source_features: Dict[str, Any] = dict(main_counts)
        source_features.update({
            "headers": len(header_parts),
            "footers": len(footer_parts),
            "footnotes_parts": 1 if "word/footnotes.xml" in names else 0,
            "endnotes_parts": 1 if "word/endnotes.xml" in names else 0,
            "comments_parts": len([n for n in names if re.fullmatch(r"word/comments\d*\.xml", n)]),
            "charts": len([n for n in names if n.startswith("word/charts/") and n.endswith(".xml")]),
            "smartart_related_parts": len([n for n in names if n.startswith("word/diagrams/")]),
            "embedded_objects": len([n for n in names if n.startswith("word/embeddings/") and not n.endswith("/")]),
            "paragraph_styles": _paragraph_style_counts(main_root),
            "numbering": _numbering_summary(zf),
            "styles": _styles_summary(zf),
            "relationships": rel_counts,
            "all_document_like_parts_aggregate": dict(sorted(aggregate.items())),
            "per_part": per_part,
        })

        metadata = {
            "core": _core_metadata(_read_xml(zf, CORE_XML)),
            "extended": _app_metadata(_read_xml(zf, APP_XML)),
            "custom": _custom_metadata(_read_xml(zf, CUSTOM_XML)),
        }
        source_media = _source_media(zf)
        drawings = _drawing_manifest(zf, document_like_parts)
        comments = _extract_comments(zf, document_like_parts)
        revisions = _extract_revisions(zf, document_like_parts)
        notes = _extract_notes(zf)
        fields = _extract_fields(zf, document_like_parts)
        package_manifest = _package_manifest(zf)

    return {
        "features": source_features,
        "metadata": metadata,
        "source_media": source_media,
        "drawings": drawings,
        "comments": comments,
        "revisions": revisions,
        "notes": notes,
        "fields": fields,
        "package_manifest": package_manifest,
        "document_like_parts": document_like_parts,
        "header_parts": header_parts,
        "footer_parts": footer_parts,
    }


def _find_pandoc(explicit: Optional[str]) -> str:
    if explicit:
        p = Path(explicit)
        if p.is_file():
            return str(p)
        found = shutil.which(explicit)
        if found:
            return found
        raise FileNotFoundError(f"Pandoc not found: {explicit}")
    found = shutil.which("pandoc")
    if not found:
        raise FileNotFoundError(
            "Pandoc is required for high-fidelity conversion but was not found in PATH. "
            "Install Pandoc 3.1 or newer and rerun the converter."
        )
    return found


def _pandoc_version(pandoc: str) -> tuple[str, tuple[int, int, int]]:
    proc = subprocess.run([pandoc, "--version"], capture_output=True, text=True, check=True)
    first = proc.stdout.splitlines()[0].strip()
    match = re.search(r"(\d+)\.(\d+)(?:\.(\d+))?", first)
    if not match:
        raise RuntimeError(f"Could not parse Pandoc version from: {first}")
    parsed = (int(match.group(1)), int(match.group(2)), int(match.group(3) or 0))
    return first, parsed


def _check_pandoc_version(version: tuple[int, int, int], allow_unsupported: bool) -> None:
    if version < MIN_PANDOC_VERSION and not allow_unsupported:
        required = ".".join(map(str, MIN_PANDOC_VERSION))
        actual = ".".join(map(str, version))
        raise RuntimeError(
            f"Pandoc {required}+ is required by the tested compatibility baseline; found {actual}. "
            "Upgrade Pandoc or rerun with --allow-unsupported-pandoc to proceed at your own risk."
        )


def _safe_write_zip_member(zf: zipfile.ZipFile, member: str, destination: Path) -> None:
    pure = Path(member)
    if pure.is_absolute() or ".." in pure.parts:
        raise RuntimeError(f"Unsafe path in DOCX package: {member}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(zf.read(member))


def _extract_original_media(src: Path, output_dir: Path) -> list[Dict[str, Any]]:
    target_root = output_dir / "assets" / "original-media"
    result: list[Dict[str, Any]] = []
    with zipfile.ZipFile(src) as zf:
        members = sorted(n for n in zf.namelist() if n.startswith("word/media/") and not n.endswith("/"))
        for member in members:
            filename = Path(member).name
            target = target_root / filename
            target.parent.mkdir(parents=True, exist_ok=True)
            data = zf.read(member)
            target.write_bytes(data)
            result.append({
                "source_path": member,
                "path": target.relative_to(output_dir).as_posix(),
                "bytes": len(data),
                "sha256": _sha256(data),
            })
    return result


def _archive_ooxml(src: Path, output_dir: Path, mode: str) -> list[Dict[str, Any]]:
    if mode == "none":
        return []
    target_root = output_dir / "extras" / "ooxml"
    archived: list[Dict[str, Any]] = []
    with zipfile.ZipFile(src) as zf:
        for member in sorted(zf.namelist()):
            if member.endswith("/") or member.startswith("word/media/"):
                continue
            include = False
            if mode == "all":
                include = True
            else:
                include = (
                    member == CONTENT_TYPES
                    or member == "_rels/.rels"
                    or member.startswith("docProps/")
                    or member.startswith("word/") and (
                        member.endswith(".xml")
                        or member.endswith(".rels")
                        or member.startswith("word/embeddings/")
                        or member.startswith("word/diagrams/")
                        or member.startswith("word/charts/")
                        or member.startswith("word/customXml/")
                    )
                )
            if not include:
                continue
            target = target_root / member
            _safe_write_zip_member(zf, member, target)
            data = target.read_bytes()
            archived.append({
                "source_path": member,
                "path": target.relative_to(output_dir).as_posix(),
                "bytes": len(data),
                "sha256": _sha256(data),
            })
    return archived


def _extracted_files(root: Path, relative_root: str) -> list[Dict[str, Any]]:
    base = root / relative_root
    if not base.exists():
        return []
    result: list[Dict[str, Any]] = []
    for path in sorted(p for p in base.rglob("*") if p.is_file()):
        data = path.read_bytes()
        result.append({
            "path": path.relative_to(root).as_posix(),
            "bytes": len(data),
            "sha256": _sha256(data),
            "mime_guess": mimetypes.guess_type(path.name)[0],
        })
    return result


def _media_verification(source: Iterable[Dict[str, Any]], extracted: Iterable[Dict[str, Any]]) -> Dict[str, Any]:
    source_items = list(source)
    extracted_items = list(extracted)
    src_hashes = Counter(item["sha256"] for item in source_items)
    out_hashes = Counter(item["sha256"] for item in extracted_items)
    missing = list((src_hashes - out_hashes).elements())
    extra = list((out_hashes - src_hashes).elements())
    return {
        "source_media_count": len(source_items),
        "extracted_media_count": len(extracted_items),
        "all_source_media_byte_identical": not missing,
        "missing_source_hashes": missing,
        "extra_output_hashes": extra,
    }


def _part_rel_media(zf: zipfile.ZipFile, part: str) -> list[Dict[str, str]]:
    result: list[Dict[str, str]] = []
    for rid, rel in sorted(_relationships_for_part(zf, part).items()):
        if rel.get("type") != "image":
            continue
        target = rel.get("resolved_target") or rel.get("target", "")
        result.append({"relationship_id": rid, "target": target, "target_mode": rel.get("target_mode", "")})
    return result


def _render_table_html(table: ET.Element) -> str:
    rows: list[str] = []
    for tr in table.findall("./w:tr", NS):
        cells: list[str] = []
        for tc in tr.findall("./w:tc", NS):
            tc_pr = tc.find("./w:tcPr", NS)
            attrs: list[str] = []
            if tc_pr is not None:
                span = tc_pr.find("./w:gridSpan", NS)
                if span is not None and span.attrib.get(W + "val"):
                    attrs.append(f' colspan="{html.escape(span.attrib[W + "val"])}"')
                vmerge = tc_pr.find("./w:vMerge", NS)
                if vmerge is not None:
                    attrs.append(' data-word-vmerge="true"')
            text = "<br>".join(
                html.escape(_text_content(p).strip())
                for p in tc.findall("./w:p", NS)
                if _text_content(p).strip()
            )
            cells.append(f"<td{''.join(attrs)}>{text}</td>")
        rows.append("<tr>" + "".join(cells) + "</tr>")
    return "<table>\n" + "\n".join(rows) + "\n</table>"


def _render_part_markdown(root: Optional[ET.Element]) -> str:
    if root is None:
        return ""
    lines: list[str] = []
    children = list(root)
    if len(children) == 1 and _local(children[0].tag) == "body":
        children = list(children[0])
    for child in children:
        name = _local(child.tag)
        if name == "p":
            text = _text_content(child).strip()
            if text:
                lines.append(text)
                lines.append("")
        elif name == "tbl":
            lines.append(_render_table_html(child))
            lines.append("")
    return "\n".join(lines).strip() + ("\n" if lines else "")


def _write_header_footer_sidecar(src: Path, output_dir: Path, kind: str, parts: Iterable[str]) -> Optional[str]:
    parts = list(parts)
    if not parts:
        return None
    out = output_dir / "extras" / f"{kind}.md"
    out.parent.mkdir(parents=True, exist_ok=True)
    chunks = [f"# {kind.capitalize()}", "", "These are semantic sidecars. Exact Word page placement is not representable in Markdown.", ""]
    with zipfile.ZipFile(src) as zf:
        for part in parts:
            chunks.extend([f"## `{part}`", ""])
            rendered = _render_part_markdown(_read_xml(zf, part)).strip()
            chunks.append(rendered or "_(No visible text extracted.)_")
            media = _part_rel_media(zf, part)
            if media:
                chunks.extend(["", "Related media:"])
                for item in media:
                    target = item["target"]
                    if target.startswith("word/media/"):
                        filename = Path(target).name
                        chunks.append(f"- `../assets/original-media/{filename}` ({item['relationship_id']})")
                    else:
                        chunks.append(f"- `{target}` ({item['relationship_id']})")
            chunks.append("")
    out.write_text("\n".join(chunks).rstrip() + "\n", encoding="utf-8")
    return out.relative_to(output_dir).as_posix()


def _write_json_sidecar(output_dir: Path, name: str, payload: Any) -> str:
    path = output_dir / "extras" / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return path.relative_to(output_dir).as_posix()


def _write_comments_md(output_dir: Path, comments: list[Dict[str, Any]]) -> Optional[str]:
    if not comments:
        return None
    path = output_dir / "extras" / "comments.md"
    lines = ["# Word comments", ""]
    for item in comments:
        label = item.get("id") or "?"
        lines.append(f"## Comment {label}")
        meta = [x for x in [item.get("author"), item.get("date")] if x]
        if meta:
            lines.append("_" + " — ".join(meta) + "_")
            lines.append("")
        if item.get("anchors"):
            lines.append("Anchored text:")
            for anchor in item["anchors"]:
                lines.append(f"> {anchor.get('text', '').replace(chr(10), ' ')}")
            lines.append("")
        lines.append(item.get("text") or "_(Empty comment)_")
        lines.append("")
    path.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")
    return path.relative_to(output_dir).as_posix()


def _write_revisions_md(output_dir: Path, revisions: list[Dict[str, Any]]) -> Optional[str]:
    if not revisions:
        return None
    path = output_dir / "extras" / "revisions.md"
    lines = ["# Tracked revisions", "", "This sidecar preserves revision metadata independently of Pandoc's Markdown rendering.", ""]
    for idx, item in enumerate(revisions, 1):
        lines.append(f"## {idx}. {item['kind']}")
        meta = [f"part={item['part']}"]
        for key in ("author", "date", "id"):
            if item.get(key):
                meta.append(f"{key}={item[key]}")
        lines.append("`" + " | ".join(meta) + "`")
        lines.append("")
        text = item.get("text", "")
        if item["kind"] in {"delete", "move_from"}:
            lines.append(f"<del>{html.escape(text)}</del>")
        else:
            lines.append(f"<ins>{html.escape(text)}</ins>")
        lines.append("")
    path.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")
    return path.relative_to(output_dir).as_posix()


def _write_notes_md(output_dir: Path, notes: Dict[str, list[Dict[str, Any]]]) -> Optional[str]:
    if not notes.get("footnotes") and not notes.get("endnotes"):
        return None
    path = output_dir / "extras" / "notes.md"
    lines = ["# Footnotes and endnotes", ""]
    for kind in ("footnotes", "endnotes"):
        if not notes.get(kind):
            continue
        lines.extend([f"## {kind.capitalize()}", ""])
        for note in notes[kind]:
            if note.get("type") in {"separator", "continuationSeparator"}:
                continue
            lines.append(f"- `{note.get('id')}`: {note.get('text', '')}")
        lines.append("")
    path.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")
    return path.relative_to(output_dir).as_posix()


def _normalize_plain(text: str) -> str:
    text = unicodedata.normalize("NFC", text)
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    return re.sub(r"\s+", " ", text).strip()


def _pandoc_plain(pandoc: str, input_path: Path, from_format: str, track_changes: Optional[str] = None) -> str:
    cmd = [pandoc, str(input_path), f"--from={from_format}", "--to=plain", "--wrap=none"]
    if track_changes:
        cmd.append(f"--track-changes={track_changes}")
    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        return ""
    return proc.stdout


def _text_verification(pandoc: str, src: Path, md: Path, track_changes: str, writer: str) -> Dict[str, Any]:
    source_plain = _pandoc_plain(pandoc, src, "docx+styles", track_changes)
    output_plain = _pandoc_plain(pandoc, md, writer)
    src_norm = _normalize_plain(source_plain)
    out_norm = _normalize_plain(output_plain)
    return {
        "source_plain_sha256": _sha256(src_norm.encode("utf-8")),
        "output_plain_sha256": _sha256(out_norm.encode("utf-8")),
        "normalized_equal": bool(src_norm) and src_norm == out_norm,
        "source_characters": len(src_norm),
        "output_characters": len(out_norm),
    }


def _drawing_verification(drawings: list[Dict[str, Any]], markdown: str) -> Dict[str, Any]:
    main = [d for d in drawings if d.get("part") == DOCUMENT_XML]
    with_alt = [d for d in main if d.get("alt_text") or d.get("title")]
    missing: list[Dict[str, Any]] = []
    for d in with_alt:
        candidates = [x for x in (d.get("alt_text"), d.get("title")) if x]
        if not any(c in markdown for c in candidates):
            missing.append({"name": d.get("name"), "alt_text": d.get("alt_text"), "title": d.get("title"), "target": d.get("target")})
    return {
        "main_document_drawings": len(main),
        "drawings_with_alt_or_title": len(with_alt),
        "alt_or_title_visible_in_markdown": len(with_alt) - len(missing),
        "missing_alt_or_title": missing,
    }


def _warnings(features: Dict[str, Any], media_check: Dict[str, Any], text_check: Dict[str, Any], drawing_check: Dict[str, Any], mode: str, comments: list[Dict[str, Any]], revisions: list[Dict[str, Any]]) -> list[Dict[str, str]]:
    warnings: list[Dict[str, str]] = []

    def add(code: str, severity: str, message: str) -> None:
        warnings.append({"code": code, "severity": severity, "message": message})

    if features.get("complex_table_colspans", 0) or features.get("complex_table_vertical_merges", 0):
        add("COMPLEX_TABLE_HTML", "info", "Complex table spans were detected. Raw HTML may be used because GFM cannot represent row/column spans faithfully.")
    if features.get("floating_drawings", 0):
        add("FLOATING_LAYOUT", "warning", "Floating drawing anchors were detected. Image payloads are preserved, but Word wrap/position geometry is not representable in Markdown.")
    if features.get("text_boxes", 0):
        add("TEXT_BOX_LAYOUT", "warning", "Word text boxes were detected. Their XML is archived, but exact geometry, layering, and text flow are not representable in Markdown.")
    if features.get("headers", 0) or features.get("footers", 0):
        add("HEADER_FOOTER_SIDECAR", "info", "Headers/footers were detected and exported to semantic sidecars; page-placement behavior remains Word-specific.")
    if comments:
        add("COMMENTS_SIDECAR", "info", "Word comments were exported with author/date/text and anchored text when available.")
    if revisions:
        add("REVISIONS_SIDECAR", "info", "Tracked revisions were exported to independent sidecars so revision metadata remains recoverable even if Markdown rendering differs.")
    if features.get("charts", 0):
        add("CHARTS", "warning", "Word chart parts were detected. Editable chart semantics are archived as OOXML but are not recreated as editable Markdown objects.")
    if features.get("smartart_related_parts", 0):
        add("SMARTART", "warning", "SmartArt/diagram parts were detected. Source parts are archived; editable SmartArt behavior is not representable directly in Markdown.")
    if features.get("embedded_objects", 0):
        add("EMBEDDED_OBJECTS", "warning", "Embedded application objects were detected. Payloads are archived when OOXML archival is enabled, but their native application behavior is outside Markdown.")
    if features.get("content_controls", 0):
        add("CONTENT_CONTROLS", "info", "Content controls were detected. Visible content can convert, but control behavior/metadata remains in the archived OOXML.")
    if features.get("fields_simple", 0) or features.get("field_instructions", 0):
        add("FIELDS_SIDECAR", "info", "Word field instructions were exported to extras/fields.json; Markdown generally preserves displayed values, not field evaluation behavior.")
    if revisions and mode == "clean":
        add("TRACK_CHANGES_ACCEPTED", "info", "Tracked changes existed and the main Markdown accepted them because --mode clean was selected; revision sidecars still preserve the original revision records.")
    if not media_check.get("all_source_media_byte_identical", True):
        add("MEDIA_HASH_MISMATCH", "warning", "At least one source media payload was not preserved byte-identically in assets/original-media.")
    if not text_check.get("normalized_equal", False):
        add("TEXT_PARITY_REVIEW", "info", "Pandoc plain-text normalization of source and generated Markdown differs. This can be expected for some tables, notes, revisions, or raw HTML, but merits review for archival migrations.")
    if drawing_check.get("missing_alt_or_title"):
        add("DRAWING_ALT_TEXT_REVIEW", "warning", "Some main-document drawing alt/title text was not found verbatim in the generated Markdown. See drawing_verification for details.")
    if features.get("manual_page_breaks", 0) or features.get("section_properties", 0) > 1:
        add("PAGINATION", "info", "Page/section layout was detected. Markdown does not preserve Word pagination, margins, columns, or section geometry.")
    return warnings


def _output_manifest(output_dir: Path, exclude: Iterable[str] = ()) -> list[Dict[str, Any]]:
    excluded = set(exclude)
    result: list[Dict[str, Any]] = []
    for path in sorted(p for p in output_dir.rglob("*") if p.is_file()):
        rel = path.relative_to(output_dir).as_posix()
        if rel in excluded:
            continue
        result.append({"path": rel, "bytes": path.stat().st_size, "sha256": _file_sha256(path)})
    return result


def _atomic_commit(staging: Path, destination: Path, force: bool) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists() and not force:
        raise FileExistsError(f"Output directory already exists: {destination} (use --force to replace it)")
    backup: Optional[Path] = None
    try:
        if destination.exists():
            backup = destination.parent / f".{destination.name}.backup-{uuid.uuid4().hex}"
            destination.rename(backup)
        staging.rename(destination)
        if backup is not None:
            shutil.rmtree(backup)
    except Exception:
        if destination.exists() and backup is not None:
            shutil.rmtree(destination, ignore_errors=True)
        if backup is not None and backup.exists():
            backup.rename(destination)
        raise


def _run_conversion(src: Path, staging: Path, args: argparse.Namespace, pandoc: str, version_string: str, version_tuple: tuple[int, int, int], audit: Dict[str, Any], source_sha: str) -> Dict[str, Any]:
    output_md = staging / args.output_name
    track_changes = "all" if args.mode == "preserve" else "accept"
    writer = "gfm+raw_html+footnotes+pipe_tables+strikeout+task_lists+tex_math_dollars"
    command = [
        pandoc, str(src), "--from=docx+styles", f"--to={writer}", "--wrap=none",
        "--markdown-headings=atx", "--eol=lf", f"--track-changes={track_changes}",
        "--extract-media=assets", f"--output={output_md.name}",
    ]
    proc = subprocess.run(command, cwd=staging, capture_output=True, text=True)
    if proc.returncode != 0:
        raise RuntimeError(
            "Pandoc conversion failed.\n"
            f"Command: {' '.join(command)}\nstdout:\n{proc.stdout}\nstderr:\n{proc.stderr}"
        )
    if not output_md.is_file() or output_md.stat().st_size == 0:
        raise RuntimeError("Pandoc completed but produced an empty Markdown file")

    original_media = _extract_original_media(src, staging)
    archived_ooxml = _archive_ooxml(src, staging, args.ooxml_archive)

    sidecars: Dict[str, Any] = {}
    headers_md = _write_header_footer_sidecar(src, staging, "headers", audit["header_parts"])
    footers_md = _write_header_footer_sidecar(src, staging, "footers", audit["footer_parts"])
    if headers_md:
        sidecars["headers_markdown"] = headers_md
    if footers_md:
        sidecars["footers_markdown"] = footers_md
    if audit["comments"]:
        sidecars["comments_json"] = _write_json_sidecar(staging, "comments.json", audit["comments"])
        sidecars["comments_markdown"] = _write_comments_md(staging, audit["comments"])
    if audit["revisions"]:
        sidecars["revisions_json"] = _write_json_sidecar(staging, "revisions.json", audit["revisions"])
        sidecars["revisions_markdown"] = _write_revisions_md(staging, audit["revisions"])
    if audit["notes"].get("footnotes") or audit["notes"].get("endnotes"):
        sidecars["notes_json"] = _write_json_sidecar(staging, "notes.json", audit["notes"])
        sidecars["notes_markdown"] = _write_notes_md(staging, audit["notes"])
    if audit["fields"]:
        sidecars["fields_json"] = _write_json_sidecar(staging, "fields.json", audit["fields"])
    if audit["drawings"]:
        sidecars["drawings_json"] = _write_json_sidecar(staging, "drawings.json", audit["drawings"])

    package_manifest_path = _write_json_sidecar(staging, "source-package-manifest.json", audit["package_manifest"])
    sidecars["source_package_manifest"] = package_manifest_path

    metadata_payload = {
        "schema_version": 2,
        "source_file": src.name,
        "source_sha256": source_sha,
        "properties": audit["metadata"],
    }
    (staging / "metadata.json").write_text(json.dumps(metadata_payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    pandoc_assets = [x for x in _extracted_files(staging, "assets") if not x["path"].startswith("assets/original-media/")]
    original_assets = _extracted_files(staging, "assets/original-media")
    media_check = _media_verification(audit["source_media"], original_assets)
    pandoc_media_check = _media_verification(audit["source_media"], pandoc_assets)
    markdown_text = output_md.read_text(encoding="utf-8")
    drawing_check = _drawing_verification(audit["drawings"], markdown_text)
    text_check = _text_verification(pandoc, src, output_md, track_changes, writer)
    warnings = _warnings(
        audit["features"], media_check, text_check, drawing_check, args.mode,
        audit["comments"], audit["revisions"],
    )

    report = {
        "schema_version": REPORT_SCHEMA_VERSION,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source": {"filename": src.name, "bytes": src.stat().st_size, "sha256": source_sha},
        "output": {
            "markdown": output_md.name,
            "assets_directory": "assets",
            "metadata": "metadata.json",
            "report": "conversion-report.json",
            "sidecars": sidecars,
            "ooxml_archive_mode": args.ooxml_archive,
        },
        "conversion": {
            "engine": "pandoc",
            "pandoc_version": version_string,
            "pandoc_version_parsed": list(version_tuple),
            "minimum_tested_pandoc": list(MIN_PANDOC_VERSION),
            "unsupported_pandoc_override": bool(args.allow_unsupported_pandoc),
            "mode": args.mode,
            "track_changes": track_changes,
            "reader": "docx+styles",
            "writer": writer,
            "command": command,
            "atomic_output": True,
        },
        "source_features": audit["features"],
        "source_media": audit["source_media"],
        "drawings": audit["drawings"],
        "comments_summary": {"count": len(audit["comments"])},
        "revisions_summary": dict(Counter(r["kind"] for r in audit["revisions"])),
        "notes_summary": {k: len(v) for k, v in audit["notes"].items()},
        "fields_summary": {"count": len(audit["fields"])},
        "original_media_extraction": original_media,
        "ooxml_archive": {"mode": args.ooxml_archive, "files": archived_ooxml},
        "media_verification": media_check,
        "pandoc_media_verification": pandoc_media_check,
        "drawing_verification": drawing_check,
        "semantic_text_verification": text_check,
        "warnings": warnings,
        "fidelity_note": (
            "The pipeline preserves semantic document content as far as Pandoc and Markdown/HTML allow, while exporting "
            "Word-only semantics to sidecars and archived OOXML. Exact pagination, floating geometry, dynamic field behavior, "
            "and native application behavior of embedded objects cannot be recreated losslessly in Markdown."
        ),
    }
    report["output_manifest"] = _output_manifest(staging, exclude={"conversion-report.json"})
    (staging / "conversion-report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return report


def convert(args: argparse.Namespace) -> int:
    src = Path(args.input).expanduser().resolve()
    if not src.is_file():
        raise FileNotFoundError(f"Input DOCX not found: {src}")
    if src.suffix.lower() != ".docx":
        raise ValueError("Input must be a .docx file")

    output_dir = Path(args.output_dir).expanduser().resolve() if args.output_dir else src.with_suffix("").with_name(src.stem + "-md")
    if output_dir.exists() and not args.force:
        raise FileExistsError(f"Output directory already exists: {output_dir} (use --force to replace it)")
    if output_dir == src.parent:
        raise ValueError("Output directory cannot be the source DOCX parent directory")

    source_sha = _file_sha256(src)
    audit = inspect_docx(src)
    pandoc = _find_pandoc(args.pandoc)
    version_string, version_tuple = _pandoc_version(pandoc)
    _check_pandoc_version(version_tuple, args.allow_unsupported_pandoc)

    output_dir.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix=f".{output_dir.name}.staging-", dir=output_dir.parent))
    committed = False
    try:
        report = _run_conversion(src, staging, args, pandoc, version_string, version_tuple, audit, source_sha)
        if _file_sha256(src) != source_sha:
            raise RuntimeError("Source DOCX changed during conversion; output was not committed")
        _atomic_commit(staging, output_dir, args.force)
        committed = True
    finally:
        if not committed and staging.exists():
            shutil.rmtree(staging, ignore_errors=True)

    summary = {
        "status": "ok",
        "output_dir": str(output_dir),
        "markdown": str(output_dir / args.output_name),
        "warnings": len(report["warnings"]),
        "media_verified": report["media_verification"]["all_source_media_byte_identical"],
        "comments": report["comments_summary"]["count"],
        "revisions": sum(report["revisions_summary"].values()),
        "schema_version": REPORT_SCHEMA_VERSION,
    }
    print(json.dumps(summary, ensure_ascii=False))
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Convert DOCX to preservation-oriented GitHub-Flavored Markdown with assets, sidecars, OOXML audit, and atomic output."
    )
    parser.add_argument("input", help="Path to input .docx")
    parser.add_argument("-o", "--output-dir", help="Output directory (default: <input-stem>-md beside the DOCX)")
    parser.add_argument("--output-name", default="document.md", help="Markdown filename inside output directory")
    parser.add_argument(
        "--mode", choices=("preserve", "clean"), default="preserve",
        help="preserve keeps tracked insertions/deletions in main Markdown; clean accepts them. Sidecars retain original revisions in both modes.",
    )
    parser.add_argument(
        "--ooxml-archive", choices=("none", "semantic", "all"), default="semantic",
        help="archive Word-only OOXML parts under extras/ooxml (default: semantic)",
    )
    parser.add_argument("--pandoc", help="Pandoc executable or path (default: discover in PATH)")
    parser.add_argument(
        "--allow-unsupported-pandoc", action="store_true",
        help="allow Pandoc older than the tested minimum; conversion report records the override",
    )
    parser.add_argument("--force", action="store_true", help="Atomically replace the entire existing output directory")
    return parser


def main() -> int:
    try:
        return convert(build_parser().parse_args())
    except (FileNotFoundError, FileExistsError, ValueError, RuntimeError, OSError, subprocess.SubprocessError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
