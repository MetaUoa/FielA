---
name: word-to-markdown
description: Convert Microsoft Word .docx files into preservation-oriented, high-fidelity Markdown for GitHub, knowledge bases, AI/RAG pipelines, Obsidian, and document migrations. Use when ChatGPT must convert DOCX to Markdown/MD, preserve images byte-identically, retain comments and tracked revisions, export headers/footers/notes/fields as sidecars, preserve complex tables with HTML fallback, archive Word-only OOXML semantics, or audit conversion fidelity. Produces Markdown, assets, sidecars, metadata, and a machine-readable conversion report. Requires Pandoc 3.1+.
---

# Word to Markdown

Convert `.docx` to GitHub-Flavored Markdown while preserving recoverable document semantics beyond what Markdown alone can express. Never claim pixel-level losslessness: Word pagination, floating geometry, dynamic fields, and native embedded-object behavior do not have direct Markdown equivalents.

## Workflow

1. Keep the source `.docx` unchanged.
2. Use `preserve` mode by default. Use `clean` only when the user explicitly wants the accepted/final document view.
3. Run:

```bash
python3 scripts/convert_docx.py INPUT.docx -o OUTPUT_DIR --mode preserve --ooxml-archive semantic --force
```

4. Inspect `conversion-report.json` before delivery.
5. Deliver the entire output directory, preferably zipped when multiple files are present.

## Output contract

Typical output:

```text
OUTPUT_DIR/
├── document.md
├── assets/
│   ├── media/...                  # Pandoc-linked media used by document.md
│   └── original-media/...         # byte-identical copies of every source media payload
├── extras/
│   ├── headers.md
│   ├── footers.md
│   ├── comments.json
│   ├── comments.md
│   ├── revisions.json
│   ├── revisions.md
│   ├── notes.json
│   ├── notes.md
│   ├── fields.json
│   ├── drawings.json
│   ├── source-package-manifest.json
│   └── ooxml/...                  # archived Word-only semantic parts
├── metadata.json
└── conversion-report.json
```

Only sidecars relevant to features present in the source are created.

## Preservation rules

- Use Pandoc for the main document because it handles Word styles, lists, tables, notes, formulas, links, tracked changes, and media better than ad-hoc extraction.
- Preserve complex merged tables with raw HTML when GFM cannot express row/column spans.
- Extract all source media independently to `assets/original-media/` and verify hashes byte-for-byte.
- Export Word comments with author/date/text and anchored text when available.
- Export tracked insertions, deletions, moves, author/date/id, and text to sidecars regardless of main conversion mode.
- Export headers and footers to semantic Markdown sidecars and preserve their underlying OOXML.
- Export Word field instructions so displayed values are not the only surviving representation.
- Audit all document-like OOXML parts, not only `word/document.xml`.
- Preserve selected OOXML by default so Word-only semantics remain recoverable even when Markdown cannot represent them.
- Use atomic output replacement. A failed conversion must not leave a partially updated destination.
- Never silently downgrade to a lower-fidelity parser if Pandoc is missing.

## Conversion modes

Preservation mode:

```bash
python3 scripts/convert_docx.py INPUT.docx -o OUTPUT_DIR --mode preserve --force
```

Accepted/final view:

```bash
python3 scripts/convert_docx.py INPUT.docx -o OUTPUT_DIR --mode clean --force
```

`clean` accepts tracked changes only in the main Markdown. Revision sidecars still preserve the original revision records.

OOXML archival:

```bash
--ooxml-archive semantic   # default; preserve important Word semantic parts
--ooxml-archive all        # archive every non-media DOCX package part
--ooxml-archive none       # smallest output; only use when the user prefers minimal files
```

## Dependency policy

Require Pandoc 3.1 or newer by default. Older Pandoc versions may differ in DOCX tracked-change, table, math, or Markdown behavior. Only use `--allow-unsupported-pandoc` when the user explicitly accepts that compatibility risk.

The core converter uses Python standard-library modules. `scripts/self_test.py` additionally requires `python-docx>=1.2` and `lxml` to construct regression fixtures.

## Quality gate

Before delivery, verify:

- `document.md` exists and is non-empty.
- The source DOCX SHA-256 is unchanged.
- `media_verification.all_source_media_byte_identical` is true, or disclose the mismatch.
- Comments/revisions/headers/footers/fields present in the source have corresponding sidecars.
- Complex tables detected in the source remain structurally represented, typically with raw HTML.
- `conversion-report.json` uses schema version 2 and records Pandoc version, warnings, output hashes, sidecars, and archival mode.
- Any `warning` severity items are summarized to the user.

Run the bundled regression test after modifying this skill:

```bash
python3 scripts/self_test.py
```

For fidelity interpretation and unavoidable Markdown limitations, read `references/fidelity.md`.
