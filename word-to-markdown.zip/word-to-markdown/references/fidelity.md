# Fidelity reference

## Purpose

This converter targets semantic fidelity, not Word page-layout replication. GitHub-Flavored Markdown plus raw HTML is the output model.

## Expected preservation

| Word feature | Expected output |
| --- | --- |
| Headings | ATX Markdown headings |
| Paragraphs | Markdown paragraphs |
| Bold / italic / strikeout | Markdown emphasis syntax where supported |
| Hyperlinks | Markdown links |
| Ordered / unordered lists | Markdown lists |
| Simple tables | GFM pipe tables where Pandoc can represent them |
| Merged-cell tables | Raw HTML tables when needed |
| Images | Extracted under `assets/media/` and linked from Markdown |
| Footnotes | Markdown footnotes |
| Equations | TeX math where Pandoc can convert Office Math |
| Tracked changes, preserve mode | Retained by Pandoc rather than silently accepted/rejected |
| Document properties | `metadata.json` |

## Inherently lossy or non-portable areas

Markdown does not provide a page model. Exact margins, page size, columns, line wrapping, page breaks, section geometry, headers, footers, and floating-object positioning cannot be represented faithfully as ordinary Markdown.

Word fields have behavior and codes beyond their displayed value. Markdown generally preserves visible results but not automatic field evaluation.

SmartArt, charts, OLE objects, and embedded application packages contain editable semantics that Markdown does not model. Review the source document when these are important.

Text boxes and floating shapes can have geometry, layering, and text-flow behavior that cannot be recreated in Markdown. Visible text or image content may survive while placement does not.

## Report interpretation

`source_features` counts OOXML constructs before conversion. A nonzero count is not automatically an error; it indicates structures worth reviewing.

`media_verification.all_source_media_byte_identical` checks whether every binary payload under `word/media/` in the DOCX appears byte-for-byte among extracted assets. A `true` value means the source media payloads were not re-encoded during extraction. It does not prove page-layout fidelity.

Warnings use these severities:

- `info`: expected representation change or a structure Markdown cannot model exactly.
- `warning`: manual review is recommended because semantic or visual information may not transfer fully.

## Conversion modes

`preserve` passes tracked changes through Pandoc with `--track-changes=all`. Use this for archival or migration work where discarding revisions would be undesirable.

`clean` uses `--track-changes=accept`. Use this only when the accepted/final document view is intended.
