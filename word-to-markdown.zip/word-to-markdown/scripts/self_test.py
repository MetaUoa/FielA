#!/usr/bin/env python3
"""Create a representative DOCX fixture and smoke-test convert_docx.py."""

from __future__ import annotations

import base64
import json
import subprocess
import sys
import tempfile
from pathlib import Path

try:
    from docx import Document
    from docx.enum.text import WD_BREAK
except ImportError:
    print("self-test requires python-docx", file=sys.stderr)
    raise SystemExit(2)

PNG_1X1 = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII="
)


def build_fixture(path: Path) -> None:
    doc = Document()
    doc.core_properties.title = "Word to Markdown Fidelity Test"
    doc.core_properties.author = "Self Test"
    doc.add_heading("High-fidelity conversion", level=1)
    p = doc.add_paragraph()
    p.add_run("Bold text").bold = True
    p.add_run(", ")
    p.add_run("italic text").italic = True
    doc.add_paragraph("First item", style="List Bullet")
    doc.add_paragraph("Second item", style="List Bullet")

    table = doc.add_table(rows=2, cols=3)
    table.cell(0, 0).text = "Merged A"
    table.cell(0, 1).text = "Merged B"
    table.cell(0, 2).text = "C"
    table.cell(1, 0).text = "D"
    table.cell(1, 1).text = "E"
    table.cell(1, 2).text = "F"
    table.cell(0, 0).merge(table.cell(0, 1))

    image_path = path.with_suffix(".png")
    image_path.write_bytes(PNG_1X1)
    doc.add_picture(str(image_path))
    doc.sections[0].header.paragraphs[0].text = "Header content"
    doc.sections[0].footer.paragraphs[0].text = "Footer content"
    page_break = doc.add_paragraph().add_run()
    page_break.add_break(WD_BREAK.PAGE)
    doc.add_heading("Page two", level=2)
    doc.save(path)


def main() -> int:
    script = Path(__file__).with_name("convert_docx.py")
    with tempfile.TemporaryDirectory(prefix="word-to-markdown-") as td:
        root = Path(td)
        docx = root / "fixture.docx"
        out = root / "out"
        build_fixture(docx)
        proc = subprocess.run(
            [sys.executable, str(script), str(docx), "-o", str(out), "--force"],
            capture_output=True,
            text=True,
        )
        if proc.returncode != 0:
            print(proc.stdout)
            print(proc.stderr, file=sys.stderr)
            return proc.returncode
        md = (out / "document.md").read_text(encoding="utf-8")
        report = json.loads((out / "conversion-report.json").read_text(encoding="utf-8"))
        checks = {
            "heading": "# High-fidelity conversion" in md,
            "bold": "**Bold text**" in md,
            "complex_table_html": "<table>" in md and "colspan" in md,
            "image_reference": "assets/media/" in md,
            "media_hash_verified": report["media_verification"]["all_source_media_byte_identical"],
            "complex_table_detected": report["source_features"]["complex_table_colspans"] > 0,
            "header_detected": report["source_features"]["headers"] > 0,
        }
        failed = [name for name, ok in checks.items() if not ok]
        print(json.dumps({"checks": checks, "failed": failed}, indent=2))
        return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
