#!/usr/bin/env python3
"""High-fidelity DOCX -> Markdown conversion with OOXML fidelity audit.

Primary conversion is delegated to Pandoc because it understands Word styles,
tracked changes, formulas, tables, notes, links, and embedded media better than
ad-hoc text extraction. This wrapper adds deterministic defaults, metadata
extraction, source-feature auditing, media hash verification, and a JSON report.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import mimetypes
import os
import shutil
import subprocess
import sys
import zipfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, Optional
import xml.etree.ElementTree as ET

NS = {
    "w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "wp": "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
    "m": "http://schemas.openxmlformats.org/officeDocument/2006/math",
    "cp": "http://schemas.openxmlformats.org/package/2006/metadata/core-properties",
    "dc": "http://purl.org/dc/elements/1.1/",
    "dcterms": "http://purl.org/dc/terms/",
    "dcmitype": "http://purl.org/dc/dcmitype/",
    "xsi": "http://www.w3.org/2001/XMLSchema-instance",
    "ep": "http://schemas.openxmlformats.org/officeDocument/2006/extended-properties",
    "vt": "http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes",
    "rel": "http://schemas.openxmlformats.org/package/2006/relationships",
}

CONTENT_TYPES = "[Content_Types].xml"
DOCUMENT_XML = "word/document.xml"
DOCUMENT_RELS = "word/_rels/document.xml.rels"
CORE_XML = "docProps/core.xml"
APP_XML = "docProps/app.xml"
CUSTOM_XML = "docProps/custom.xml"


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _read_xml(zf: zipfile.ZipFile, name: str) -> Optional[ET.Element]:
    try:
        return ET.fromstring(zf.read(name))
    except KeyError:
        return None
    except ET.ParseError as exc:
        raise RuntimeError(f"Invalid XML in {name}: {exc}") from exc


def _count(root: Optional[ET.Element], xpath: str) -> int:
    return 0 if root is None else len(root.findall(xpath, NS))


def _core_metadata(root: Optional[ET.Element]) -> Dict[str, Any]:
    if root is None:
        return {}
    mapping = {
        "title": "dc:title",
        "subject": "dc:subject",
        "creator": "dc:creator",
        "keywords": "cp:keywords",
        "description": "dc:description",
        "last_modified_by": "cp:lastModifiedBy",
        "revision": "cp:revision",
        "created": "dcterms:created",
        "modified": "dcterms:modified",
        "category": "cp:category",
        "content_status": "cp:contentStatus",
    }
    result: Dict[str, Any] = {}
    for key, xpath in mapping.items():
        node = root.find(xpath, NS)
        if node is not None and node.text is not None:
            result[key] = node.text
    return result


def _app_metadata(root: Optional[ET.Element]) -> Dict[str, Any]:
    if root is None:
        return {}
    wanted = [
        "Application",
        "AppVersion",
        "Company",
        "Manager",
        "Pages",
        "Words",
        "Characters",
        "Paragraphs",
        "Lines",
        "TotalTime",
    ]
    result: Dict[str, Any] = {}
    for key in wanted:
        node = root.find(f"ep:{key}", NS)
        if node is not None and node.text is not None:
            value: Any = node.text
            if key in {"Pages", "Words", "Characters", "Paragraphs", "Lines", "TotalTime"}:
                try:
                    value = int(value)
                except ValueError:
                    pass
            result[key] = value
    return result


def _custom_metadata(root: Optional[ET.Element]) -> Dict[str, Any]:
    if root is None:
        return {}
    result: Dict[str, Any] = {}
    for prop in list(root):
        name = prop.attrib.get("name")
        if not name:
            continue
        value_node = next(iter(prop), None)
        if value_node is not None:
            result[name] = value_node.text
    return result


def _relationship_counts(root: Optional[ET.Element]) -> Dict[str, int]:
    counts: Counter[str] = Counter()
    if root is None:
        return {}
    for rel in root.findall("rel:Relationship", NS):
        typ = rel.attrib.get("Type", "")
        leaf = typ.rsplit("/", 1)[-1] if typ else "unknown"
        counts[leaf] += 1
    return dict(sorted(counts.items()))


def _source_media(zf: zipfile.ZipFile) -> list[Dict[str, Any]]:
    result: list[Dict[str, Any]] = []
    for name in sorted(n for n in zf.namelist() if n.startswith("word/media/") and not n.endswith("/")):
        data = zf.read(name)
        result.append(
            {
                "source_path": name,
                "filename": Path(name).name,
                "bytes": len(data),
                "sha256": _sha256(data),
                "mime_guess": mimetypes.guess_type(name)[0],
            }
        )
    return result


def _paragraph_style_counts(root: Optional[ET.Element]) -> Dict[str, int]:
    counts: Counter[str] = Counter()
    if root is None:
        return {}
    val_key = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val"
    for pstyle in root.findall(".//w:pPr/w:pStyle", NS):
        counts[pstyle.attrib.get(val_key, "(unknown)")] += 1
    return dict(sorted(counts.items()))


def inspect_docx(path: Path) -> tuple[Dict[str, Any], Dict[str, Any], list[Dict[str, Any]]]:
    if not zipfile.is_zipfile(path):
        raise ValueError(f"Not a valid DOCX/ZIP package: {path}")
    with zipfile.ZipFile(path) as zf:
        if DOCUMENT_XML not in zf.namelist() or CONTENT_TYPES not in zf.namelist():
            raise ValueError(f"ZIP package is not a valid Word .docx document: {path}")

        doc = _read_xml(zf, DOCUMENT_XML)
        rels = _read_xml(zf, DOCUMENT_RELS)
        core = _read_xml(zf, CORE_XML)
        app = _read_xml(zf, APP_XML)
        custom = _read_xml(zf, CUSTOM_XML)

        feature_counts: Dict[str, Any] = {
            "paragraphs": _count(doc, ".//w:p"),
            "tables": _count(doc, ".//w:tbl"),
            "table_cells": _count(doc, ".//w:tc"),
            "complex_table_colspans": _count(doc, ".//w:gridSpan"),
            "complex_table_vertical_merges": _count(doc, ".//w:vMerge"),
            "hyperlinks": _count(doc, ".//w:hyperlink"),
            "drawings": _count(doc, ".//w:drawing"),
            "inline_drawings": _count(doc, ".//wp:inline"),
            "floating_drawings": _count(doc, ".//wp:anchor"),
            "legacy_pictures": _count(doc, ".//w:pict"),
            "text_boxes": _count(doc, ".//w:txbxContent"),
            "math_objects": _count(doc, ".//m:oMath") + _count(doc, ".//m:oMathPara"),
            "tracked_insertions": _count(doc, ".//w:ins"),
            "tracked_deletions": _count(doc, ".//w:del"),
            "tracked_moves_from": _count(doc, ".//w:moveFrom"),
            "tracked_moves_to": _count(doc, ".//w:moveTo"),
            "comment_range_starts": _count(doc, ".//w:commentRangeStart"),
            "comment_references": _count(doc, ".//w:commentReference"),
            "bookmarks": _count(doc, ".//w:bookmarkStart"),
            "fields_simple": _count(doc, ".//w:fldSimple"),
            "field_instructions": _count(doc, ".//w:instrText"),
            "content_controls": _count(doc, ".//w:sdt"),
            "manual_page_breaks": 0,
            "section_properties": _count(doc, ".//w:sectPr"),
        }

        if doc is not None:
            break_type_key = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}type"
            feature_counts["manual_page_breaks"] = sum(
                1 for br in doc.findall(".//w:br", NS) if br.attrib.get(break_type_key) == "page"
            )

        rel_counts = _relationship_counts(rels)
        feature_counts["relationships"] = rel_counts
        feature_counts["headers"] = rel_counts.get("header", 0)
        feature_counts["footers"] = rel_counts.get("footer", 0)
        feature_counts["footnotes_parts"] = rel_counts.get("footnotes", 0)
        feature_counts["endnotes_parts"] = rel_counts.get("endnotes", 0)
        feature_counts["comments_parts"] = rel_counts.get("comments", 0)
        feature_counts["charts"] = rel_counts.get("chart", 0)
        feature_counts["smartart_related_parts"] = sum(
            rel_counts.get(k, 0)
            for k in ("diagramData", "diagramLayout", "diagramQuickStyle", "diagramColors")
        )
        feature_counts["embedded_objects"] = rel_counts.get("oleObject", 0) + rel_counts.get("package", 0)
        feature_counts["paragraph_styles"] = _paragraph_style_counts(doc)

        metadata = {
            "core": _core_metadata(core),
            "extended": _app_metadata(app),
            "custom": _custom_metadata(custom),
        }
        media = _source_media(zf)

    return feature_counts, metadata, media


def _pandoc_version(pandoc: str) -> str:
    proc = subprocess.run([pandoc, "--version"], capture_output=True, text=True, check=True)
    return proc.stdout.splitlines()[0].strip()


def _find_pandoc(explicit: Optional[str]) -> str:
    if explicit:
        p = Path(explicit)
        if p.is_file():
            return str(p)
        found = shutil.which(explicit)
        if found:
            return found
        raise FileNotFoundError(f"Pandoc not found: {explicit}")
    found = shutil.which("pandoc")
    if not found:
        raise FileNotFoundError(
            "Pandoc is required for high-fidelity conversion but was not found in PATH. "
            "Install Pandoc and rerun the converter."
        )
    return found


def _extracted_media(output_dir: Path) -> list[Dict[str, Any]]:
    assets = output_dir / "assets"
    if not assets.exists():
        return []
    result: list[Dict[str, Any]] = []
    for path in sorted(p for p in assets.rglob("*") if p.is_file()):
        data = path.read_bytes()
        result.append(
            {
                "path": path.relative_to(output_dir).as_posix(),
                "bytes": len(data),
                "sha256": _sha256(data),
                "mime_guess": mimetypes.guess_type(path.name)[0],
            }
        )
    return result


def _media_verification(source: Iterable[Dict[str, Any]], extracted: Iterable[Dict[str, Any]]) -> Dict[str, Any]:
    source_items = list(source)
    extracted_items = list(extracted)
    src_hashes = Counter(item["sha256"] for item in source_items)
    out_hashes = Counter(item["sha256"] for item in extracted_items)
    missing = list((src_hashes - out_hashes).elements())
    extra = list((out_hashes - src_hashes).elements())
    return {
        "source_media_count": len(source_items),
        "extracted_media_count": len(extracted_items),
        "all_source_media_byte_identical": not missing,
        "missing_source_hashes": missing,
        "extra_output_hashes": extra,
    }


def _warnings(features: Dict[str, Any], media_check: Dict[str, Any], mode: str) -> list[Dict[str, str]]:
    warnings: list[Dict[str, str]] = []

    def add(code: str, severity: str, message: str) -> None:
        warnings.append({"code": code, "severity": severity, "message": message})

    if features.get("complex_table_colspans", 0) or features.get("complex_table_vertical_merges", 0):
        add(
            "COMPLEX_TABLE_HTML",
            "info",
            "Complex table spans were detected. Pandoc normally emits raw HTML tables because GFM cannot represent row/column spans losslessly.",
        )
    if features.get("floating_drawings", 0):
        add(
            "FLOATING_LAYOUT",
            "warning",
            "Floating drawing anchors were detected. Image content is preserved, but exact Word wrap/positioning is not representable in Markdown.",
        )
    if features.get("text_boxes", 0):
        add(
            "TEXT_BOX_LAYOUT",
            "warning",
            "Word text boxes were detected. Text may be preserved, but exact box geometry/flow is not representable in Markdown.",
        )
    if features.get("headers", 0) or features.get("footers", 0):
        add(
            "HEADER_FOOTER",
            "warning",
            "Headers/footers were detected. Standard Markdown has no page-header/footer model; review conversion-report.json and the source DOCX if those are semantically important.",
        )
    if features.get("charts", 0):
        add(
            "CHARTS",
            "warning",
            "Word chart parts were detected. Editable chart semantics are not guaranteed in Markdown; rendered/embedded representations should be reviewed.",
        )
    if features.get("smartart_related_parts", 0):
        add(
            "SMARTART",
            "warning",
            "SmartArt/diagram parts were detected. Editable SmartArt semantics cannot be represented directly in Markdown.",
        )
    if features.get("embedded_objects", 0):
        add(
            "EMBEDDED_OBJECTS",
            "warning",
            "Embedded OLE/package objects were detected. Their editable application semantics are not representable directly in Markdown.",
        )
    if features.get("content_controls", 0):
        add(
            "CONTENT_CONTROLS",
            "info",
            "Word content controls were detected. Their visible content can convert, but control behavior/metadata may not survive.",
        )
    if features.get("fields_simple", 0) or features.get("field_instructions", 0):
        add(
            "FIELDS",
            "info",
            "Word fields were detected. Markdown generally preserves displayed results, not Word field behavior/code.",
        )
    if (features.get("tracked_insertions", 0) or features.get("tracked_deletions", 0)) and mode == "clean":
        add(
            "TRACK_CHANGES_ACCEPTED",
            "info",
            "Tracked changes existed in the source and were accepted because --mode clean was selected.",
        )
    if not media_check.get("all_source_media_byte_identical", True):
        add(
            "MEDIA_HASH_MISMATCH",
            "warning",
            "At least one source media payload was not found byte-identically among extracted assets. Review the media verification section.",
        )
    if features.get("manual_page_breaks", 0) or features.get("section_properties", 0) > 1:
        add(
            "PAGINATION",
            "info",
            "Page/section layout was detected. Markdown does not preserve Word pagination, margins, columns, or section geometry.",
        )
    return warnings


def convert(args: argparse.Namespace) -> int:
    src = Path(args.input).expanduser().resolve()
    if not src.is_file():
        raise FileNotFoundError(f"Input DOCX not found: {src}")
    if src.suffix.lower() != ".docx":
        raise ValueError("Input must be a .docx file")

    output_dir = Path(args.output_dir).expanduser().resolve() if args.output_dir else src.with_suffix("").with_name(src.stem + "-md")
    output_dir.mkdir(parents=True, exist_ok=True)
    output_md = output_dir / args.output_name
    if output_md.exists() and not args.force:
        raise FileExistsError(f"Output already exists: {output_md} (use --force to overwrite)")

    features, metadata, source_media = inspect_docx(src)
    pandoc = _find_pandoc(args.pandoc)
    version = _pandoc_version(pandoc)

    track_changes = "all" if args.mode == "preserve" else "accept"
    writer = "gfm+raw_html+footnotes+pipe_tables+strikeout+task_lists+tex_math_dollars"
    command = [
        pandoc,
        str(src),
        "--from=docx+styles",
        f"--to={writer}",
        "--wrap=none",
        "--markdown-headings=atx",
        "--eol=lf",
        f"--track-changes={track_changes}",
        "--extract-media=assets",
        f"--output={output_md.name}",
    ]

    proc = subprocess.run(command, cwd=output_dir, capture_output=True, text=True)
    if proc.returncode != 0:
        raise RuntimeError(
            "Pandoc conversion failed.\n"
            f"Command: {' '.join(command)}\n"
            f"stdout:\n{proc.stdout}\n"
            f"stderr:\n{proc.stderr}"
        )

    extracted = _extracted_media(output_dir)
    media_check = _media_verification(source_media, extracted)
    warnings = _warnings(features, media_check, args.mode)

    metadata_payload = {
        "source_file": src.name,
        "source_sha256": _sha256(src.read_bytes()),
        "properties": metadata,
    }
    report = {
        "schema_version": 1,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source": {
            "filename": src.name,
            "bytes": src.stat().st_size,
            "sha256": metadata_payload["source_sha256"],
        },
        "output": {
            "markdown": output_md.name,
            "assets_directory": "assets",
            "metadata": "metadata.json",
            "report": "conversion-report.json",
        },
        "conversion": {
            "engine": "pandoc",
            "pandoc_version": version,
            "mode": args.mode,
            "track_changes": track_changes,
            "reader": "docx+styles",
            "writer": writer,
            "command": command,
        },
        "source_features": features,
        "source_media": source_media,
        "extracted_media": extracted,
        "media_verification": media_check,
        "warnings": warnings,
        "fidelity_note": (
            "The converter preserves semantic document content as far as Pandoc and Markdown/HTML allow. "
            "Exact Word pagination, floating layout, field behavior, and application-specific embedded-object semantics "
            "cannot be represented losslessly in Markdown. Complex tables may be preserved as raw HTML."
        ),
    }

    (output_dir / "metadata.json").write_text(
        json.dumps(metadata_payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    (output_dir / "conversion-report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )

    summary = {
        "status": "ok",
        "output_dir": str(output_dir),
        "markdown": str(output_md),
        "warnings": len(warnings),
        "media_verified": media_check["all_source_media_byte_identical"],
    }
    print(json.dumps(summary, ensure_ascii=False))
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Convert DOCX to high-fidelity GitHub-Flavored Markdown with assets and a fidelity audit."
    )
    parser.add_argument("input", help="Path to input .docx")
    parser.add_argument("-o", "--output-dir", help="Output directory (default: <input-stem>-md beside the DOCX)")
    parser.add_argument("--output-name", default="document.md", help="Markdown filename inside output directory")
    parser.add_argument(
        "--mode",
        choices=("preserve", "clean"),
        default="preserve",
        help="preserve keeps tracked insertions/deletions; clean accepts tracked changes",
    )
    parser.add_argument("--pandoc", help="Pandoc executable or path (default: discover in PATH)")
    parser.add_argument("--force", action="store_true", help="Overwrite an existing Markdown output")
    return parser


def main() -> int:
    try:
        return convert(build_parser().parse_args())
    except (FileNotFoundError, FileExistsError, ValueError, RuntimeError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
