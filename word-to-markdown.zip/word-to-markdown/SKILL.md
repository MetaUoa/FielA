---
name: word-to-markdown
description: Convert Microsoft Word .docx files into high-fidelity Markdown for GitHub, knowledge bases, AI/RAG pipelines, Obsidian, and documentation migrations. Use when ChatGPT is asked to convert Word/DOCX to Markdown/MD, extract Word content and images into a Markdown project, preserve complex tables via HTML fallback, keep tracked changes for archival conversion, or audit fidelity/loss during DOCX-to-Markdown migration. Produces Markdown, original media assets, document metadata, and a conversion report. Requires Pandoc for the conversion engine.
---

# Word to Markdown

Convert `.docx` to GitHub-Flavored Markdown while preserving semantic content as far as Markdown/HTML permits. Do not claim pixel-level or layout-level losslessness: Word pagination, floating geometry, field behavior, and embedded application objects do not have direct Markdown equivalents.

## Workflow

1. Confirm the input is an accessible `.docx` file. Never modify the source file.
2. Choose conversion mode:
   - Use `preserve` by default. It keeps tracked insertions/deletions so content is not silently discarded.
   - Use `clean` only when the user explicitly wants the accepted/final document view.
3. Run the bundled converter:

```bash
python3 scripts/convert_docx.py INPUT.docx -o OUTPUT_DIR --mode preserve --force
```

4. Inspect the generated `conversion-report.json` before presenting the result. Pay special attention to warnings for floating drawings, text boxes, headers/footers, charts, SmartArt, embedded objects, fields, and pagination.
5. Verify the output folder contains at least `document.md`, `metadata.json`, and `conversion-report.json`. If the source contains images or other extractable media, also expect `assets/`.
6. Deliver the entire output directory to the user, preferably as a ZIP when multiple files are present.

## Output contract

Use this default layout:

```text
OUTPUT_DIR/
├── document.md
├── assets/
│   └── media/...
├── metadata.json
└── conversion-report.json
```

`document.md` uses GitHub-Flavored Markdown with raw HTML enabled. This is intentional: Pandoc can emit HTML for structures such as merged-cell tables that GFM cannot represent faithfully.

`metadata.json` stores Word document properties separately so conversion does not inject synthetic metadata into the document body.

`conversion-report.json` records source feature counts, Pandoc settings/version, source and output hashes, media verification, and fidelity warnings.

## Fidelity rules

- Preserve text, headings, emphasis, links, lists, notes, math, and ordinary tables through Pandoc.
- Extract embedded media rather than re-encoding it. Check `media_verification.all_source_media_byte_identical` in the report.
- Allow raw HTML in Markdown when Markdown syntax would lose structure, especially merged tables.
- Preserve tracked changes with `--mode preserve` unless the user asks for a clean accepted view.
- Do not flatten complex document structures into screenshots merely to imitate Word layout unless the user explicitly requests visual snapshots.
- Do not silently omit unsupported Word features. Surface them through the conversion report.
- Never describe the result as "100% lossless" unless every relevant source feature is representable and verified. Prefer "high-fidelity semantic conversion".

## Commands

Default preservation-oriented conversion:

```bash
python3 scripts/convert_docx.py INPUT.docx -o OUTPUT_DIR --mode preserve --force
```

Accepted/final-view conversion:

```bash
python3 scripts/convert_docx.py INPUT.docx -o OUTPUT_DIR --mode clean --force
```

Environment smoke test:

```bash
python3 scripts/self_test.py
```

If Pandoc is not found, stop and report the missing dependency rather than falling back to a lower-fidelity ad-hoc parser without user consent.

## Quality check

Before delivery, confirm:

- Converter exited successfully.
- Markdown file is non-empty.
- All source media hashes are present byte-identically in extracted assets, or the mismatch is disclosed.
- Complex merged tables remain as HTML when necessary.
- Any fidelity warnings are summarized to the user in one concise note.
- The source `.docx` remains unchanged.

For feature-specific limitations and interpretation of report warnings, consult `references/fidelity.md`.
