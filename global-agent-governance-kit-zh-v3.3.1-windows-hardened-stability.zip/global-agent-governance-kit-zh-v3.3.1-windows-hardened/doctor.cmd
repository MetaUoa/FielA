@echo off
setlocal
chcp 65001 >nul
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS%" (echo Windows PowerShell 5.1 is required.&exit /b 1)
"%PS%" -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0scripts\doctor.ps1" %*
set "RC=%ERRORLEVEL%"
exit /b %RC%
