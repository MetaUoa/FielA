﻿param([switch]$SkipSyntheticProbe)
$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding -ArgumentList $false } catch {}
. (Join-Path $PSScriptRoot 'agentkit-common.ps1')
$utf = New-Object System.Text.UTF8Encoding -ArgumentList @($false, $true)
$homeDir = [Environment]::GetFolderPath('UserProfile')
$appData = [Environment]::GetFolderPath('LocalApplicationData')
if (-not $appData) { $appData = Join-Path $homeDir 'AppData\Local' }
$kit = Join-Path $appData 'AgentKit'
$statePath = Join-Path $kit 'state.json'
$hookState = Join-Path $kit 'hook-state.json'
$issues = 0
function Report([string]$Level,[string]$Topic,[string]$Detail) {
    Write-Host ("[{0}] {1}: {2}" -f $Level,$Topic,$Detail)
    if ($Level -eq 'FAIL') { $script:issues++ }
}
function Contains-Hook($Obj,[string]$Event) {
    if (-not $Obj -or -not $Obj.hooks) { return $false }
    foreach ($group in @($Obj.hooks.$Event | Where-Object { $null -ne $_ })) {
        foreach ($handler in @($group.hooks | Where-Object { $null -ne $_ })) {
            if ([string]$handler.command -match '(?i)AgentKit[\\/]+bin[\\/]+plan\.ps1.*-Action\s+Hook(Check|Stop)\b' -and
                [string]$handler.command -match '-AgentKitManaged') { return $true }
        }
    }
    return $false
}
if (-not (Test-Path -LiteralPath $statePath -PathType Leaf)) {
    Report 'FAIL' '安装状态' '缺少 state.json；请先运行 install-all.cmd。'
    exit 2
}
Assert-AgentKitPlainPath $statePath
$state = [System.IO.File]::ReadAllText($statePath,$utf) | ConvertFrom-Json
$registered = @()
if (Test-Path -LiteralPath $hookState -PathType Leaf) {
    Assert-AgentKitPlainPath $hookState
    $registered = @(([System.IO.File]::ReadAllText($hookState,$utf) | ConvertFrom-Json).platforms)
}
$roots = @{
    Pi = $(if ($state.roots.pi) { [string]$state.roots.pi } else { Join-Path $homeDir '.pi\agent' })
    Codex = $(if ($state.roots.codex) { [string]$state.roots.codex } else { Join-Path $homeDir '.codex' })
    Claude = $(if ($state.roots.claude) { [string]$state.roots.claude } else { Join-Path $homeDir '.claude' })
}
$bin = Join-Path $kit 'bin'
$plan = Join-Path $bin 'plan.ps1'
if (Test-Path -LiteralPath $plan -PathType Leaf) { Report 'PASS' '计划 CLI' $plan }
else { Report 'FAIL' '计划 CLI' 'plan.ps1 未安装' }
foreach ($platform in @('Pi','Codex','Claude')) {
    $root = [string]$roots[$platform]
    $enabledByState = $registered -contains $platform
    $status = if ($enabledByState) { '登记为已配置' } else { '登记为未配置' }
    if ($platform -eq 'Pi') {
        $hookFile = Join-Path $root 'extensions\agentkit-plan-guard.ts'
        if (Test-Path -LiteralPath $hookFile -PathType Leaf) {
            if ((Test-Path -LiteralPath (Join-Path $bin 'agentkit-plan-guard.ts') -PathType Leaf) -and
                (Get-FileHash -LiteralPath $hookFile -Algorithm SHA256).Hash -eq (Get-FileHash -LiteralPath (Join-Path $bin 'agentkit-plan-guard.ts') -Algorithm SHA256).Hash) {
                Report 'CONFIGURED' 'Pi' "$status；扩展文件与安装版匹配。"
            } else { Report 'WARN' 'Pi' "$status；扩展文件已修改或版本不匹配：$hookFile" }
        } else { Report $(if ($enabledByState) { 'FAIL' } else { 'OFF' }) 'Pi' "$status；找不到扩展文件。" }
    } else {
        $cfg = Join-Path $root $(if ($platform -eq 'Codex') { 'hooks.json' } else { 'settings.json' })
        if (-not (Test-Path -LiteralPath $cfg -PathType Leaf)) {
            Report $(if ($enabledByState) { 'FAIL' } else { 'OFF' }) $platform "$status；没有 Hook 配置文件。"
        } else {
            try {
                Assert-AgentKitPlainPath $cfg
                $json = ([System.IO.File]::ReadAllText($cfg,$utf)) | ConvertFrom-Json
                if ((Contains-Hook $json 'PreToolUse') -and (Contains-Hook $json 'Stop')) {
                    Report 'CONFIGURED' $platform "$status；PreToolUse/Stop 指令存在。"
                } else { Report $(if ($enabledByState) { 'FAIL' } else { 'OFF' }) $platform "$status；没有匹配到成对的托管 Hook。" }
            } catch { Report 'FAIL' $platform "配置无法解析：$($_.Exception.Message)" }
        }
    }
}
$toml = Join-Path $roots.Codex 'config.toml'
if (Test-Path -LiteralPath $toml -PathType Leaf) {
    $txt = [System.IO.File]::ReadAllText($toml,$utf)
    $section = [regex]::Match($txt, '(?ms)^\[features\]\s*(.*?)(?=^\[|\z)')
    if ($section.Success -and $section.Groups[1].Value -match '(?m)^\s*hooks\s*=\s*false\b') {
        Report 'WARN' 'Codex 功能' 'config.toml 设置 hooks=false，已配置 Hook 也不会运行。'
    }
    if ($txt -match '(?m)^\s*allow_managed_hooks_only\s*=\s*true\b') {
        Report 'WARN' 'Codex 策略' '仅允许托管 Hook，用户级 AgentKit Hook 可能被跳过。'
    }
}
if (-not $SkipSyntheticProbe -and (Test-Path -LiteralPath $plan -PathType Leaf)) {
    $probeRoot = Join-Path ([System.IO.Path]::GetTempPath()) ('AgentKit Doctor ' + [guid]::NewGuid().ToString('N'))
    $psExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    try {
        [void][System.IO.Directory]::CreateDirectory($probeRoot)
        $args = @('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',$plan,'-Action','HookCheck','-ProjectPath',$probeRoot)
        $prior = $ErrorActionPreference
        $ErrorActionPreference = 'Continue'
        try {
            $out = '{"tool_name":"Write","tool_input":{"file_path":"probe.tmp"}}' | & $psExe @args 2>&1
            $deny = $LASTEXITCODE
            $out = '{"tool_name":"Read","tool_input":{"file_path":"probe.tmp"}}' | & $psExe @args 2>&1
            $read = $LASTEXITCODE
        } finally { $ErrorActionPreference = $prior }
        if ($deny -eq 2 -and $read -eq 0) { Report 'PASS' 'Hook 模拟探针' '无计划写入被拒绝，只读工具正常。' }
        else { Report 'FAIL' 'Hook 模拟探针' "写入返回 $deny，读取返回 $read；应分别为 2、0。" }
    } catch { Report 'FAIL' 'Hook 模拟探针' $_.Exception.Message }
    finally { if (Test-Path -LiteralPath $probeRoot) { Remove-Item -LiteralPath $probeRoot -Recurse -Force } }
}
Report 'UNVERIFIED' '真实 Hook 激活' '未检测实际 Codex / Pi / Claude 宿主回调；需在各宿主信任、重启后测试真实工具调用。'
Report 'UNVERIFIED' 'Codex 信任' '使用 /hooks 查看并信任当前 Hook 哈希；doctor 不会代替用户信任。'
if ($issues -gt 0) { exit 2 }
exit 0
