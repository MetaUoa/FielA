﻿param([switch]$Check, [switch]$Write)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
. (Join-Path $root 'scripts\agentkit-common.ps1')
$utf = New-Object System.Text.UTF8Encoding -ArgumentList @($false, $true)
$policyPath = Join-Path $root 'policy\GLOBAL_POLICY.md'
$base = [System.IO.File]::ReadAllText($policyPath,$utf).TrimEnd([char[]]@([char]13,[char]10))
$base = $base -replace '\A# [^\r\n]+\r?\n', ''
if (-not $base.Contains('## 4.')) { throw 'Missing canonical planning section.' }
if (-not $Check -and -not $Write) { throw 'Specify -Check or -Write.' }
$spec = @(
    @{ name='Pi'; title='# Pi global rules'; target='platform\pi\AGENTS.md'; tail='policy\platform\pi.md'; project='`AGENTS.md` / `CLAUDE.md`' },
    @{ name='Codex'; title='# Codex global rules'; target='platform\codex\AGENTS.md'; tail='policy\platform\codex.md'; project='`AGENTS.md` / `AGENTS.override.md`' },
    @{ name='Claude'; title='# Claude Code global rules'; target='platform\claude\CLAUDE.md'; tail='policy\platform\claude.md'; project='`CLAUDE.md` / `.claude/rules/`' }
)
foreach ($item in $spec) {
    $section = $base.Replace('`AGENTS.md` / `CLAUDE.md`', $item.project)
    $tail = [System.IO.File]::ReadAllText((Join-Path $root $item.tail),$utf).Trim()
    $title = switch ($item.name) {
        'Pi' { '# Pi ' }
        'Codex' { '# Codex ' }
        'Claude' { '# Claude Code ' }
    }
    # Preserve the first line of the original platform entry as a localized, platform-specific title.
    $target = Join-Path $root $item.target
    $original = [System.IO.File]::ReadAllText($target,$utf)
    $localizedTitle = ($original -split '\r?\n',2)[0]
    $body = $localizedTitle + "`r`n`r`n" + $section.Trim() + "`r`n`r`n" + $tail + "`r`n"
    $current = $original.Replace("`r`n","`n").Trim()
    if ($Check) {
        if ($current -cne $body.Replace("`r`n","`n").Trim()) { throw "Generated policy drift: $($item.target)" }
    } else {
        Write-AgentKitAtomicText $target $body
        Write-Host "Updated policy entry: $($item.target)"
    }
}
if ($Check) { Write-Host 'Generated policy consistency: PASS' }
