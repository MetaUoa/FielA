﻿# Non-invasive Windows PowerShell 5.1 plan CLI smoke tests.
$ErrorActionPreference = 'Stop'
try { $consoleUtf8 = New-Object System.Text.UTF8Encoding -ArgumentList $false; [Console]::OutputEncoding = $consoleUtf8; $OutputEncoding = $consoleUtf8 } catch {}
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$plan = Join-Path $root 'scripts\plan.ps1'
. (Join-Path $root 'scripts\agentkit-common.ps1')
$project = Join-Path ([System.IO.Path]::GetTempPath()) ('AgentKit Regression 中文 ' + [guid]::NewGuid().ToString('N'))
[void][System.IO.Directory]::CreateDirectory($project)
# Invoke the child PowerShell with real argument boundaries, including paths containing spaces or Chinese.
function Run-Plan([string[]]$Params, [int]$Expected) {
    $originalPreference = $ErrorActionPreference
    try {
        # HookCheck intentionally writes stderr when denying; it must not short-circuit the test.
        $ErrorActionPreference = 'Continue'
        $output = & (Join-Path $PSHOME 'powershell.exe') -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $plan @Params 2>&1
        $code = $LASTEXITCODE
    } finally { $ErrorActionPreference = $originalPreference }
    if ($code -ne $Expected) {
        throw "Unexpected CLI exit $code, expected $Expected. Output: $($output | Out-String)"
    }
    return ($output | Out-String)
}
function Run-Hook([string]$EventJson, [int]$Expected) {
    $originalPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        $output = $EventJson | & (Join-Path $PSHOME 'powershell.exe') -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $plan -Action HookCheck -ProjectPath $project 2>&1
        $code = $LASTEXITCODE
    } finally { $ErrorActionPreference = $originalPreference }
    if ($code -ne $Expected) { throw "Unexpected HookCheck exit $code, expected $Expected. Output: $($output | Out-String)" }
}
try {
    # Nothing may modify files without a ready plan, except a standalone plan bootstrap command.
    Run-Hook '{"tool_name":"Write","tool_input":{"file_path":"x.txt"}}' 2
    Run-Hook '{"tool_name":"Read","tool_input":{"file_path":"x.txt"}}' 0
    Run-Hook '{"tool_name":"mcp__github__create_issue","tool_input":{"title":"test"}}' 2
    Run-Hook '{"tool_name":"Bash","tool_input":{"command":"plan.cmd -Action Init -Task example; del x.txt"}}' 2
    Run-Hook '{"tool_name":"Bash","tool_input":{"command":"plan.cmd -Action Init -Task example"}}' 0
    # A quoted -StepsText delimiter is data, not a shell pipe; an actual shell pipe must be denied.
    Run-Hook '{"tool_name":"Bash","tool_input":{"command":"plan.cmd -Action Init -Task example -StepsText \"implement|verify\""}}' 0
    Run-Hook '{"tool_name":"Bash","tool_input":{"command":"plan.cmd -Action Init -Task example | del x.txt"}}' 2
    Run-Hook '{"tool_name":"Bash","tool_input":{"command":"del x.txt plan.cmd -Action Init -Task example"}}' 2
    $result = Run-Plan @('-Action','Init','-ProjectPath',$project,'-Task','regression') 0
    if ($result -notmatch 'PLAN_CREATED id=([a-f0-9]{12}) ready=False path=(.+)') { throw 'Missing plan draft id.' }
    $id = $Matches[1]
    $path = $Matches[2].Trim().Split([char[]]@([char]13,[char]10))[0]
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw 'Plan document not created.' }
    [void](Run-Plan @('-Action','Check','-ProjectPath',$project,'-PlanId',$id) 2)
    Run-Hook '{"tool_name":"Write","tool_input":{"file_path":"x.txt"}}' 2
    $ready = Run-Plan @('-Action','Ready','-ProjectPath',$project,'-PlanId',$id,'-Goal','repair guard','-Acceptance','tests pass','-StepsText','implement|verify') 0
    if ($ready -notmatch 'PLAN_READY') { throw 'Ready transition missing.' }
    [void](Run-Plan @('-Action','Check','-ProjectPath',$project,'-PlanId',$id) 0)
    Run-Hook '{"tool_name":"Write","tool_input":{"file_path":"x.txt"}}' 0
    [void](Run-Plan @('-Action','Finish','-ProjectPath',$project,'-PlanId',$id,'-Result','Completed','-Evidence','test suite passed') 2)
    [void](Run-Plan @('-Action','Step','-ProjectPath',$project,'-PlanId',$id,'-Step','implement') 0)
    [void](Run-Plan @('-Action','Step','-ProjectPath',$project,'-PlanId',$id,'-Step','verify') 0)
    [void](Run-Plan @('-Action','Finish','-ProjectPath',$project,'-PlanId',$id,'-Result','Completed','-Evidence','CLI smoke tests passed') 0)
    [void](Run-Plan @('-Action','Check','-ProjectPath',$project,'-PlanId',$id) 2)
    $contents = [System.IO.File]::ReadAllText($path)
    if ($contents -notmatch 'status=completed' -or $contents -notmatch 'CLI smoke tests passed') { throw 'Plan completion not persisted.' }
    if ($contents -notmatch '- 状态：已完成' -or $contents -notmatch '- 最终状态：已完成') { throw 'Plan summary not finalized.' }
    if ($contents -match '(?m)^- \[ \] ') { throw 'Completed document retained unchecked step.' }

    # Concurrent session B must not borrow session A's plan.
    $created = Run-Plan @('-Action','Init','-ProjectPath',$project,'-Task','session scoped','-SessionId','session-A','-Goal','scoped run','-Acceptance','scope verified','-StepsText','verify scope') 0
    if ($created -notmatch 'PLAN_CREATED id=([a-f0-9]{12}) ready=True path=(.+)') { throw 'Missing ready plan creation identifier.' }
    $sessionPlan = $Matches[1]
    [void](Run-Plan @('-Action','Check','-ProjectPath',$project,'-SessionId','session-B') 2)
    [void](Run-Plan @('-Action','Check','-ProjectPath',$project,'-SessionId','session-B','-PlanId',$sessionPlan) 2)
    Run-Hook '{"tool_name":"Write","session_id":"session-B","tool_input":{"file_path":"x.txt"}}' 2
    Run-Hook '{"tool_name":"Write","session_id":"session-A","tool_input":{"file_path":"x.txt"}}' 0
    [void](Run-Plan @('-Action','Step','-ProjectPath',$project,'-SessionId','session-A','-Step','verify scope') 0)
    [void](Run-Plan @('-Action','Finish','-ProjectPath',$project,'-PlanId',$sessionPlan,'-SessionId','session-A','-Result','Completed','-Evidence','Session isolation PASS') 0)

    # A Stop event must report ALL unfinished plans, not just exactly one.
    [void](Run-Plan @('-Action','Init','-ProjectPath',$project,'-Task','unfinished 1') 0)
    [void](Run-Plan @('-Action','Init','-ProjectPath',$project,'-Task','unfinished 2') 0)
    $stopJson = '{"cwd":' + (ConvertTo-Json $project -Compress) + ',"session_id":"probe-A"}'
    $prior = $ErrorActionPreference
    $ErrorActionPreference='Continue'
    try {
        $out = $stopJson | & (Join-Path $PSHOME 'powershell.exe') -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $plan -Action HookStop 2>&1
        $code = $LASTEXITCODE
    } finally { $ErrorActionPreference=$prior }
    if ($code -ne 2) { throw 'Stop hook ignored two unfinished plans.' }

    $file = Join-Path $project 'atomic.txt'
    [System.IO.File]::WriteAllText($file,'before')
    Write-AgentKitAtomicText $file 'after'
    if ([System.IO.File]::ReadAllText($file) -ne 'after') { throw 'Atomic replacement failed.' }
    Write-Host 'WINDOWS_REGRESSION_PASS: draft/ready, evidence/steps, two-plan Stop, session isolation, unknown MCP, Chinese/space paths, atomic replace'

} finally {
    # Run-project index is separated by a stable hash; delete only this known temporary test key.
    $utf = New-Object System.Text.UTF8Encoding -ArgumentList @($false, $true)
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $bytes = $utf.GetBytes(([System.IO.Path]::GetFullPath($project)).TrimEnd([char[]]@('\','/')).ToLowerInvariant())
        $idHash = ([System.BitConverter]::ToString($sha.ComputeHash($bytes))).Replace('-','').ToLowerInvariant().Substring(0,24)
        $appData = [Environment]::GetFolderPath('LocalApplicationData')
        $index = Join-Path $appData ('AgentKit\plan-state\' + $idHash + '.json')
        if (Test-Path -LiteralPath $index -PathType Leaf) { Remove-Item -LiteralPath $index -Force }
    } finally { $sha.Dispose() }
    if (Test-Path -LiteralPath $project) { Remove-Item -LiteralPath $project -Recurse -Force }
}
