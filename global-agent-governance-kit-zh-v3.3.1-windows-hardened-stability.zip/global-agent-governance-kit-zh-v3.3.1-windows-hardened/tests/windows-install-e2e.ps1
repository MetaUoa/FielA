﻿# DESTRUCTIVE to the current Windows user's agent configuration. RUN ONLY INSIDE A FRESH WINDOWS SANDBOX.
param([switch]$ConfirmWindowsSandbox)
$ErrorActionPreference='Stop'
if (-not $ConfirmWindowsSandbox -or $env:USERNAME -ne 'WDAGUtilityAccount' -or $env:AGENTKIT_SANDBOX_E2E -ne 'YES') {
    throw 'This end-to-end test installs and restores global agent files. It runs only with -ConfirmWindowsSandbox, AGENTKIT_SANDBOX_E2E=YES, and the default Windows Sandbox user.'
}
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$psExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$utf = New-Object System.Text.UTF8Encoding -ArgumentList @($false, $true)
$local = [Environment]::GetFolderPath('LocalApplicationData')
$homeDir = [Environment]::GetFolderPath('UserProfile')
$legacy = Join-Path $homeDir '.agent-global'
$pointer = Join-Path $local 'AgentKit\last-backup.txt'
$legacyProof = Join-Path $legacy 'owned-by-user.txt'
function Run([string]$Script, [string[]]$Arguments, [int]$Expected) {
    $last = $ErrorActionPreference
    try {
        $ErrorActionPreference='Continue'
        $out = & $psExe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File (Join-Path $root $Script) @Arguments 2>&1
        $result = $LASTEXITCODE
    } finally { $ErrorActionPreference=$last }
    if ($result -ne $Expected) { throw "Unexpected exit $result (expected $Expected) from ${Script}: $($out | Out-String)" }
}
if (Test-Path -LiteralPath $pointer -PathType Leaf) { throw 'Not a clean Sandbox: AgentKit already installed.' }
[void][System.IO.Directory]::CreateDirectory($legacy)
[System.IO.File]::WriteAllText($legacyProof,'This folder belongs to a user and should not be migrated by default.', $utf)
Run 'preview.ps1' @() 0
Run 'install.ps1' @() 0
if (-not (Test-Path -LiteralPath $legacyProof -PathType Leaf)) { throw 'Unsafe: default install deleted unknown legacy data.' }
Run 'verify.ps1' @() 0
Run 'install.ps1' @() 0
Run 'verify.ps1' @() 0

# Drift must be rejected before any overwrite (safe content adjustment, then restore).
$codex = Join-Path $homeDir '.codex\AGENTS.md'
if (Test-Path -LiteralPath $codex -PathType Leaf) {
    $original = [System.IO.File]::ReadAllBytes($codex)
    try {
        [System.IO.File]::AppendAllText($codex,"`r`n# DRIFT_SENTINEL`r`n",$utf)
        Run 'preview.ps1' @() 2
        Run 'install.ps1' @() 1
    } finally { [System.IO.File]::WriteAllBytes($codex,$original) }
}

# A manipulated backup target must fail before touching the outside sentinel.
$backup = [System.IO.File]::ReadAllText($pointer,$utf).Trim()
$manifestPath = Join-Path $backup 'manifest.json'
$manifestOriginal = [System.IO.File]::ReadAllBytes($manifestPath)
$sentinel = Join-Path ([System.IO.Path]::GetTempPath()) 'AgentKit-restore-target-sentinel.txt'
[System.IO.File]::WriteAllText($sentinel,'KEEP',$utf)
try {
    $entries = @(([System.IO.File]::ReadAllText($manifestPath,$utf)) | ConvertFrom-Json)
    $entries[0].target = $sentinel
    [System.IO.File]::WriteAllText($manifestPath,(ConvertTo-Json -InputObject $entries -Depth 10),$utf)
    Run 'restore-latest.ps1' @() 1
    if ([System.IO.File]::ReadAllText($sentinel,$utf) -ne 'KEEP') { throw 'Restore touched an outside path.' }
} finally {
    [System.IO.File]::WriteAllBytes($manifestPath,$manifestOriginal)
    if (Test-Path -LiteralPath $sentinel) { Remove-Item -LiteralPath $sentinel -Force }
}
# Optional hooks are configured, then disabled, without replacing other host settings.
Run 'scripts\toggle-hooks.ps1' @('-Mode','Enable','-Platform','All') 0
Run 'scripts\doctor.ps1' @() 0
Run 'scripts\toggle-hooks.ps1' @('-Mode','Disable','-Platform','All') 0
Run 'restore-latest.ps1' @() 0
if (-not (Test-Path -LiteralPath $legacyProof -PathType Leaf)) { throw 'Rollback deleted a user legacy file.' }
Write-Host 'WINDOWS_SANDBOX_E2E_PASS: installs x2, verifies x2, drift refusal, restore allowlist, hook config/disable, rollback, legacy protection'
