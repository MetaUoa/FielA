"""Cross-platform static packaging tests. Runtime PowerShell tests are separate."""
from __future__ import annotations
import hashlib
import json
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def raw(rel: str) -> bytes:
    return (ROOT / rel).read_bytes()

def content(rel: str) -> str:
    return raw(rel).decode('utf-8-sig').replace('\r\n','\n')

class ReleaseTests(unittest.TestCase):
    def test_manifest_complete_and_exact(self):
        info = json.loads(content('PACKAGE_MANIFEST.json'))
        self.assertEqual(info['version'], content('VERSION.txt').strip())
        expected = {p.as_posix().removeprefix(ROOT.as_posix() + '/') for p in ROOT.rglob('*') if p.is_file() and p.name != 'PACKAGE_MANIFEST.json' and not ('__pycache__' in p.parts or p.suffix in ('.pyc','.pyo'))}
        tracked = [x['path'] for x in info['files']]
        self.assertEqual(set(tracked), expected)
        self.assertEqual(len(tracked), len(set(tracked)))
        self.assertGreater(len(tracked), 45)
        for entry in info['files']:
            path = entry['path']
            self.assertFalse(Path(path).is_absolute())
            self.assertFalse(any(part in ('..','.') for part in Path(path).parts))
            data = raw(path)
            self.assertEqual(hashlib.sha256(data).hexdigest(), entry['sha256'], path)
            self.assertEqual(len(data), entry['bytes'], path)

    def test_powershell_windows_compat_encoding(self):
        for p in ROOT.rglob('*.ps1'):
            data = p.read_bytes()
            self.assertTrue(data.startswith(b'\xef\xbb\xbf'), str(p))
            self.assertEqual(data.count(b'\n'), data.count(b'\r\n'), str(p))
            self.assertNotIn(b'\r\r\n', data)
            data.decode('utf-8-sig')

    def test_cmd_ascii_and_crlf(self):
        for p in ROOT.rglob('*.cmd'):
            data = p.read_bytes()
            self.assertTrue(all(n <= 127 for n in data), str(p))
            self.assertEqual(data.count(b'\n'), data.count(b'\r\n'), str(p))
            self.assertIn(b'%SystemRoot%\\System32\\WindowsPowerShell\\v1.0\\powershell.exe', data, str(p))
            self.assertIn(b'chcp 65001', data, str(p))

    def test_generated_platform_entries(self):
        base = content('policy/GLOBAL_POLICY.md')
        self.assertIn('## 4.', base)
        base = re.sub(r'^#[^\n]+\n','',base).strip()
        targets = {
            'pi': ('platform/pi/AGENTS.md', '`AGENTS.md` / `CLAUDE.md`'),
            'codex': ('platform/codex/AGENTS.md','`AGENTS.md` / `AGENTS.override.md`'),
            'claude': ('platform/claude/CLAUDE.md','`CLAUDE.md` / `.claude/rules/`'),
        }
        for key,(target,proj) in targets.items():
            found = content(target).strip()
            heading = found.splitlines()[0]
            tail = content(f'policy/platform/{key}.md').strip()
            expected = heading+'\n\n'+base.replace('`AGENTS.md` / `CLAUDE.md`',proj)+'\n\n'+tail
            self.assertEqual(found, expected, target)
            self.assertLessEqual(len(found.splitlines()), 125)
            self.assertIn('powershell.exe -NoProfile', found)

    def test_atomic_writes_and_restore_safety(self):
        common = content('scripts/agentkit-common.ps1')
        self.assertIn('[System.IO.File]::Replace($tmp, $Path, $null)',common)
        self.assertIn('Assert-AgentKitPlainPath', common)
        self.assertIn('AbandonedMutexException', common)
        for name in ('install.ps1','restore-latest.ps1'):
            src = content(name)
            body = re.search(r'function Write-Utf8NoBomAtomic\([^)]*\)\s*\{(.*?)\n\}', src, re.S)
            self.assertIsNotNone(body,name)
            self.assertIn('Write-AgentKitAtomicText',body.group(1))
            self.assertNotIn('Remove-Item',body.group(1))
            self.assertIn('Enter-AgentKitMutex',src)
            self.assertIn('Exit-AgentKitMutex',src)
        restore = content('restore-latest.ps1')
        self.assertIn('Assert-ApprovedRestoreTarget $target $kind',restore)
        self.assertLess(restore.index('Assert-ApprovedRestoreTarget $target $kind'),restore.index('for ($i = 0; $i -lt $entries.Count; $i++) { Snapshot-CurrentTarget'))
        self.assertIn('Assert-NoPostInstallDrift',restore)
        self.assertIn('RestoreSafetyRoot',restore)
        self.assertIn('RecoverPending',restore)
        installer=content('install.ps1')
        self.assertIn('Save-FinalFingerprints',installer)
        self.assertIn('Assert-DriftBeforeOverwrite',installer)
        self.assertIn('PI_CODING_AGENT_DIR',installer)
        self.assertIn('CLAUDE_CONFIG_DIR',installer)
        self.assertIn('$script:TransactionStarted = $true',installer)
        self.assertIn('if (-not $script:Committed -and $script:TransactionStarted)',installer)
        self.assertIn('if ($name -in @(', content('scripts/check-package.ps1'))

    def test_plan_cli_guards(self):
        plan=content('scripts/plan.ps1')
        for action in ('Init','Ready','Check','Step','Finish','Resume','Status','List','HookCheck','HookStop'):
            self.assertRegex(plan, r"'"+action+"'")
        self.assertIn('CreateNew',plan)
        self.assertIn('Completed plans require -Evidence',plan)
        self.assertIn('Assert-PlanReadyContent',plan)
        self.assertIn('ready=$ready',plan)
        self.assertIn('if ($active.Count -gt 0)',plan)
        self.assertIn('Assert-AgentKitPlainPath $script:PlanRoot',plan)
        self.assertLess(plan.index('Assert-AgentKitPlainPath $script:PlanRoot'), plan.index('CreateDirectory($script:PlanRoot)'))
        self.assertIn('Write-Output', plan)
        self.assertIn('Assert-AgentKitChild $path $script:PlanRoot',plan)
        self.assertIn('SessionId',plan)
        self.assertIn('Never borrow a different session',plan)
        self.assertIn(r"'templates\EXECUTION_PLAN.md'",plan)
        toggle=content('scripts/toggle-hooks.ps1')
        self.assertIn('Rollback-HookChanges',toggle)
        self.assertIn('Stage-Backup',toggle)
        self.assertIn('ReplaceCustomized',toggle)
        self.assertIn('-AgentKitManaged',toggle)
        self.assertIn("'Codex') { '.*' } else { '*' }", toggle)

    def test_bootstrap_quotes_and_data_safety(self):
        plan = content('scripts/plan.ps1')
        win = content('tests/windows-regression.ps1')
        self.assertIn('$withoutQuotes = [regex]::Replace($cmd', plan)
        self.assertIn('$withoutQuotes -notmatch $bareOperators', plan)
        self.assertIn('$direct -or $viaPowerShell', plan)
        self.assertIn('Protect-RegexReplacement', plan)
        self.assertIn('SingleLine', plan)
        self.assertIn('-StepsText \\"implement|verify\\"', win)
        self.assertIn('plan.cmd -Action Init -Task example | del x.txt', win)
        self.assertIn('del x.txt plan.cmd -Action Init -Task example', win)
        self.assertIn('from ${Script}', content('tests/windows-install-e2e.ps1'))

    def test_regression_for_legacy_migration_and_host_activation(self):
        installer = content('install.ps1')
        preview = content('preview.ps1')
        doctor = content('scripts/doctor.ps1')
        extension = content('platform/pi/extensions/agentkit-plan-guard.ts')
        self.assertIn('if ($MigrateLegacy) {', installer)
        self.assertIn('if ($MigrateLegacy) {', preview)
        self.assertIn('Legacy item left untouched by default', preview)
        self.assertIn('AGENTKIT_SESSION_ID', extension)
        self.assertIn('sessionManager.getSessionFile()', extension)
        self.assertIn('UNVERIFIED', doctor)
        self.assertIn('Hook 模拟探针', doctor)
        self.assertIn('hooks=false', doctor)

    def test_no_secret_files_or_missing_docs(self):
        for name in ('README.md','AUDIT_REPORT.md','RELEASE_NOTES.md','tests/windows-regression.ps1','preview.ps1','scripts/render-policy.ps1','scripts/doctor.ps1','doctor.cmd'):
            self.assertTrue((ROOT/name).is_file(),name)
        for p in ROOT.rglob('*'):
            if p.is_file():
                self.assertFalse(p.suffix in ('.env','.pfx','.key','.pem'),str(p))

if __name__ == '__main__':
    unittest.main()
