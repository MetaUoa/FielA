@echo off
setlocal
chcp 65001 >nul
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS%" (echo Windows PowerShell 5.1 is required.&exit /b 1)
"%PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\toggle-hooks.ps1" -Mode Disable %*
set "RC=%ERRORLEVEL%"
:END
exit /b %RC%
