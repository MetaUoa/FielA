## Pi 平台补充

- 用户级 AgentKit Skills 由 Pi 从 `~/.agents/skills/` 原生发现；不要预读全部 Skills。
- 项目级 `AGENTS.md` 只写项目差异；更新全局规则或 Skills 后可执行 `/reload` 或新开会话。

- Windows AgentKit executable plan utility: `%LOCALAPPDATA%\AgentKit\bin\plan.ps1`; hooks are optional and require explicit `enable-hooks.cmd`.
