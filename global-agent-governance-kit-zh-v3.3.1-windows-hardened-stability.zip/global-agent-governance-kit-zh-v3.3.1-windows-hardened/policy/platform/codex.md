## Codex 平台补充

- 用户级 AgentKit Skills 由 Codex 从 `$HOME/.agents/skills/` 原生发现；路由依赖每个 Skill 的简短 `description`。
- 项目级 `AGENTS.md` 只写项目差异；Skill 更新未立即出现时重启 Codex。

- Windows AgentKit executable plan utility: `%LOCALAPPDATA%\AgentKit\bin\plan.ps1`; hooks are optional and require explicit `enable-hooks.cmd`.
