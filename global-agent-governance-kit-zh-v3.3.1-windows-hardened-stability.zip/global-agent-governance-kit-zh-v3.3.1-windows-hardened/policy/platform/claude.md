## Claude Code 平台补充

- 用户级 AgentKit Skills 安装在 `~/.claude/skills/`，由 Claude Code 原生发现；不要通过 `CLAUDE.md` 维护重复 Skill 清单。
- 项目级 `CLAUDE.md` 只写项目差异。

- Windows AgentKit executable plan utility: `%LOCALAPPDATA%\AgentKit\bin\plan.ps1`; hooks are optional and require explicit `enable-hooks.cmd`.
