import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { spawnSync } from "node:child_process";
import { randomUUID } from "node:crypto";
import { join } from "node:path";

// This extension is a best-effort governance guard, not an OS security boundary.
let ephemeralSession = `pi-ephemeral:${randomUUID()}`;
function sessionId(ctx: { sessionManager: { getSessionFile(): string | undefined | null } }): string {
  return ctx.sessionManager.getSessionFile() || ephemeralSession;
}
function runCheck(action: "HookCheck" | "HookStop", payload: unknown) {
  const windows = process.env.SystemRoot || "C:\\Windows";
  const appData = process.env.LOCALAPPDATA || join(process.env.USERPROFILE || "", "AppData", "Local");
  const shell = join(windows, "System32", "WindowsPowerShell", "v1.0", "powershell.exe");
  const script = join(appData, "AgentKit", "bin", "plan.ps1");
  return spawnSync(shell, ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", script, "-Action", action, "-AgentKitManaged"], {
    input: JSON.stringify(payload), encoding: "utf8", timeout: 12000, windowsHide: true,
  });
}
export default function (pi: ExtensionAPI) {
  // Child shell commands inherit this session id. plan.ps1 uses it for Init/Ready/Finish by default.
  pi.on("session_start", async (_event, ctx) => {
    ephemeralSession = `pi-ephemeral:${randomUUID()}`;
    process.env.AGENTKIT_SESSION_ID = sessionId(ctx);
  });
  pi.on("tool_call", async (event, ctx) => {
    const id = sessionId(ctx);
    process.env.AGENTKIT_SESSION_ID = id;
    const details = { tool_name: event.toolName, tool_input: event.input, cwd: ctx.cwd, session_id: id };
    const result = runCheck("HookCheck", details);
    if (result.error || result.status !== 0) {
      return { block: true, reason: `AgentKit plan check failed: ${(result.stderr || result.error?.message || "missing / unready plan").trim()}` };
    }
  });
  pi.on("agent_end", async (_event, ctx) => {
    const id = sessionId(ctx);
    const result = runCheck("HookStop", { cwd: ctx.cwd, session_id: id });
    if ((result.error || result.status !== 0) && ctx.hasUI) {
      ctx.ui.notify(`AgentKit: finalize or mark Partial/Blocked all active plans. ${(result.stderr || "").trim()}`, "warning");
    }
    // Pi's agent_end is a notification event; it cannot cancel the completed turn.
  });
}
