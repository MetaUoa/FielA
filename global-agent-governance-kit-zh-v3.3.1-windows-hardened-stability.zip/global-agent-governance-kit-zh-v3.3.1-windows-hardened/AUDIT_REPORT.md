# AgentKit v3.3.1 独立缺陷修复审计

本版基于 v3.3.0 原 ZIP 做补丁。以下是源代码修复范围，不是实际 Windows 安装成功证明。

| 缺陷 | v3.3.1 处理 | 验证范围 |
|---|---|---|
| 假完成/占位符计划 | Init 草稿、Ready 显式验收、步骤勾选与实质证据，防止 Completed 未勾选 | 静态规则及 Windows 待运行回归 |
| 多活动计划停止漏报 | Stop 发现大于零份未结案计划即报错 | 静态规则及 Windows 待运行回归 |
| 计划会话错配 | Pi 传递 session ID；隔离其他会话已关联的计划 | Pi TS 语法检查，宿主待验收 |
| Hook 已配置但未实际启用 | doctor 单独报告 CONFIGURED/PASS 模拟/UNVERIFIED 宿主与信任 | 静态报告；真实宿主待验收 |
| Hook 工具覆盖/错误出口 | Codex/Claude 宽 matcher；未知工具需计划；成功回 `{}`，阻断用退出码 2 | 静态和 Windows 待运行回归 |
| 测试 `__pycache__` 自污染 | 忽略编译缓存，保持 payload 字节完整检查 | 静态可运行 |
| 计划路径符号链接 | 建档目录创建前验证祖先 reparse point | 源码检查；Windows 待测 |
| 旧版数据误删 | 默认保留，显式 `-MigrateLegacy` 才触发处理 | 源码检查；Windows Sandbox 待测 |
| 升级预演不完整 | 添加状态、指针、备份、待恢复日志与历史迁移可见条目 | 源码检查；Windows 待测 |
| 历史计划兼容与输入注入 | 补充 `ready` 属性、转义正则替换、拒绝单行字段控制符 | 源码检查；Windows 待测 |

**尚未解决的平台边界**：不能依靠仅有的 CLI 检查证明真正执行了测试；无法强制拦截宿主未报告的文件写入、外部程序修改或绕过 Hook 的远程工具；Pi 的 agent_end 不能阻止完成事件。

---

## 原 v3.3.0 审计报告（保留供历史追溯）

# AgentKit v3.3.0 implementation / audit report

Base: v3.1.4 Windows Hardened Plan First. Scope: installation/restore security, plan lifecycle, maintenance UX and rollback capabilities.

## Controls implemented

| Control | Concrete implementation | Coverage boundary |
|---|---|---|
| Restore allowlist | `Assert-ApprovedRestoreTarget` in `restore-latest.ps1` | Only named files and Skill directories; custom roots taken from installation state or environment |
| Atomic text/file writes | `Write-AgentKitAtomicBytes` in `scripts/agentkit-common.ps1` | Same-volume File.Replace; staged directory swap uses compensating backup |
| Drift detection | SHA-256 and managed-block fingerprint in backup manifest | First upgrade from v3.1.x has no previous fingerprints |
| Transaction coordination | Named Mutex for install/restore/hooks, project-scoped Mutex for plan | No cross-machine coordination |
| Crash recovery | `pending-install.json`, `recover-pending.cmd`, backup snapshots | Must invoke recovery explicitly after abrupt process termination |
| Config roots | Pi / Codex / Claude directory overrides saved in `state.json` | Does not attempt to migrate arbitrary historical roots |
| Plan lifecycle | `scripts/plan.ps1` plus project plan file and runtime index | Requires Windows PowerShell 5.1 or compatible |
| Agent integrations | Pi extension, Claude + Codex hook JSON opt-in | Hooks cannot intercept every custom executable/tool/client |
| Source consistency | `scripts/render-policy.ps1 -Check` / `-Write` | Canonical policy + platform tail sources |
| Upgrade preview | `preview.ps1` / `preview.cmd` | Read-only, summary-level managed-rule diff |
| Recovery guards | Post-install fingerprint check + restore-safety snapshot | Modified managed state requires explicit user override |

## Tests and limitations

Portable release tests: `python3 -m unittest discover -s tests -p test_release.py -v`.
TypeScript syntax: `typescript.transpileModule` (Node) for Pi extension.
Windows runtime tests: `powershell.exe -NoProfile -File tests/windows-regression.ps1` (requires a real Windows environment).

Results appear in the delivered validation report. No claim is made that Windows PowerShell 5.1 runtime tests ran inside a Linux-only build container.

## Important design choices

- The default install does not silently modify the user's existing Claude/Codex hook settings or Pi extensions. Hook enforcement can be explicitly enabled and disabled, with backups.
- Read-only preparation before making a plan remains allowed; writing/editing tasks require plan initialization. The optional shell classifier is deliberately conservative and fail-closed when unsure; the built-in agent instruction also covers tool cases a hook cannot observe.
- User-authored material outside managed AGENTKIT markers is kept intact. Any managed content drift is a conflict unless explicitly permitted after preview.
- Global policy remains concise, with platform differences in separate tails and all seven existing Skills retained.
