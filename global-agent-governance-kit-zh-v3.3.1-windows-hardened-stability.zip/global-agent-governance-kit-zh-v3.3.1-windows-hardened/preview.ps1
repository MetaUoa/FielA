﻿param([switch]$Json, [switch]$MigrateLegacy)
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $Root 'scripts\agentkit-common.ps1')
$Utf8 = New-Object System.Text.UTF8Encoding -ArgumentList @($false, $true)
& (Join-Path $Root 'scripts\check-package.ps1')

$homeDir = [Environment]::GetFolderPath('UserProfile')
$appData = [Environment]::GetFolderPath('LocalApplicationData')
if (-not $appData) { $appData = Join-Path $homeDir 'AppData\Local' }
$dataDir = Join-Path $appData 'AgentKit'
$pi = if ($env:PI_CODING_AGENT_DIR) { [System.IO.Path]::GetFullPath($env:PI_CODING_AGENT_DIR) } else { Join-Path $homeDir '.pi\agent' }
$codex = if ($env:CODEX_HOME) { [System.IO.Path]::GetFullPath($env:CODEX_HOME) } else { Join-Path $homeDir '.codex' }
$claude = if ($env:CLAUDE_CONFIG_DIR) { [System.IO.Path]::GetFullPath($env:CLAUDE_CONFIG_DIR) } else { Join-Path $homeDir '.claude' }
$pointer = Join-Path $dataDir 'last-backup.txt'
$previous = @{}
if (Test-Path -LiteralPath $pointer -PathType Leaf) {
    $backupRoot = [System.IO.File]::ReadAllText($pointer, $Utf8).Trim()
    if ($backupRoot) {
        Assert-AgentKitChild $backupRoot (Join-Path $dataDir 'backups')
        $manifest = Join-Path $backupRoot 'manifest.json'
        if (Test-Path -LiteralPath $manifest -PathType Leaf) {
            foreach ($e in @(([System.IO.File]::ReadAllText($manifest,$Utf8)) | ConvertFrom-Json)) {
                if ($e.after_hash -and [string]$e.after_hash -ne 'PENDING') { $previous[[string]$e.target] = $e }
            }
        }
    }
}
$legacyBodyHashes = @{
    'Pi'='3d7a335327c130fccb4bfa705219b98b4bdcc21de15cf6c2757f62f53bb6b1d8';
    'Codex'='54f6a5726ce79fa0b2f0213f3bbbfa9196a7f23627a777fcb0fc03e4017847d8';
    'Claude'='af4c81d5f6cec31411ec6a1a507c0997bb8bb47eda763539eac678039806c70d'
}
$targets = New-Object 'System.Collections.Generic.List[object]'
# Preview also discloses any state changes and optional destructive legacy migration.
function Add-Target([string]$Path, [string]$Source, [string]$Kind) {
    $status = 'NEW'
    $note = ''
    if (Test-Path -LiteralPath $Path) {
        Assert-AgentKitPlainPath $Path
        $status = 'UPDATE'
        if ($previous.ContainsKey($Path)) {
            $e = $previous[$Path]
            $fingerprint = Get-AgentKitFingerprint $Path ([string]$e.fingerprint_kind)
            if ($fingerprint -ne [string]$e.after_hash) { $status='CONFLICT'; $note='User modification since prior installation' }
        }
        if ($Kind -eq 'managed' -and (Test-Path -LiteralPath $Path -PathType Leaf)) {
            $text = [System.IO.File]::ReadAllText($Path, $Utf8)
            $beginCount = [regex]::Matches($text,'<!-- AGENTKIT:BEGIN -->').Count
            $endCount = [regex]::Matches($text,'<!-- AGENTKIT:END -->').Count
            if (($beginCount + $endCount) -gt 0 -and ($beginCount -ne 1 -or $endCount -ne 1)) { $status='CONFLICT'; $note='Broken managed markers' }
            if ($beginCount -eq 1 -and $endCount -eq 1 -and $status -ne 'CONFLICT') {
                $expected = ([System.IO.File]::ReadAllText($Source, $Utf8)).Trim()
                $match = [regex]::Match($text,'(?s)<!-- AGENTKIT:BEGIN -->\s*(.*?)\s*<!-- AGENTKIT:END -->')
                if ($match.Success) {
                    if ($match.Groups[1].Value.Trim() -ceq $expected) { $status='UNCHANGED' }
                    else {
                        if (-not $previous.ContainsKey($Path)) {
                            $platform = if ($Path.StartsWith($pi, [System.StringComparison]::OrdinalIgnoreCase)) { 'Pi' } elseif ($Path.StartsWith($codex, [System.StringComparison]::OrdinalIgnoreCase)) { 'Codex' } else { 'Claude' }
                            $bodyFingerprint = Get-AgentKitFingerprint $Path 'managed'
                            if ($bodyFingerprint -ne $legacyBodyHashes[$platform]) { $status='CONFLICT'; $note='Untracked managed rule differs from known v3.1.4 baseline' }
                        }
                        $before = @($match.Groups[1].Value.Trim() -split '\r?\n')
                        $after = @($expected -split '\r?\n')
                        $diff = @(Compare-Object -ReferenceObject $before -DifferenceObject $after -CaseSensitive)
                        $note = ('Managed-rule diff items: ' + $diff.Count)
                    }
                }
            }
        } elseif ($Kind -eq 'directory' -and $status -ne 'CONFLICT') {
            if ((Get-AgentKitFingerprint $Source 'directory') -eq (Get-AgentKitFingerprint $Path 'directory')) { $status='UNCHANGED' }
            elseif (-not $previous.ContainsKey($Path)) { $status='CONFLICT'; $note='Untracked existing directory differs from packaged payload' }
        } elseif ($Kind -eq 'file' -and $status -ne 'CONFLICT') {
            if ((Get-FileHash -LiteralPath $Source -Algorithm SHA256).Hash -eq (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash) { $status='UNCHANGED' }
            elseif (-not $previous.ContainsKey($Path)) { $status='CONFLICT'; $note='Untracked existing file differs from packaged payload' }
        }
    }
    $targets.Add([pscustomobject]@{ status=$status; kind=$Kind; path=$Path; note=$note })
}
$skills = @('agentkit-debug-root-cause','agentkit-test-verification','agentkit-safe-refactor','agentkit-dependency-upgrade','agentkit-git-change-hygiene','agentkit-schema-migration','agentkit-release-readiness')
Add-Target (Join-Path $pi 'AGENTS.md') (Join-Path $Root 'platform\pi\AGENTS.md') 'managed'
Add-Target (Join-Path $codex 'AGENTS.md') (Join-Path $Root 'platform\codex\AGENTS.md') 'managed'
Add-Target (Join-Path $claude 'CLAUDE.md') (Join-Path $Root 'platform\claude\CLAUDE.md') 'managed'
foreach ($item in @([pscustomobject]@{dir=$pi;src='platform\pi\AGENTS.md'},[pscustomobject]@{dir=$codex;src='platform\codex\AGENTS.md'})) {
    $override = Join-Path $item.dir 'AGENTS.override.md'
    if (Test-Path -LiteralPath $override) { Add-Target $override (Join-Path $Root $item.src) 'managed' }
}
foreach ($skill in $skills) {
    $source = Join-Path $Root ('skills\' + $skill)
    Add-Target (Join-Path $homeDir ('.agents\skills\' + $skill)) $source 'directory'
    Add-Target (Join-Path $claude ('skills\' + $skill)) $source 'directory'
}
foreach ($name in @('agentkit-task.md','agentkit-review.md')) {
    Add-Target (Join-Path $pi ('prompts\' + $name)) (Join-Path $Root ('platform\pi\prompts\' + $name)) 'file'
}
# Installer always writes state and backup metadata, even when all payload files are unchanged.
$targets.Add([pscustomobject]@{ status=$(if (Test-Path -LiteralPath (Join-Path $dataDir 'state.json')) { 'UPDATE' } else { 'NEW' }); kind='metadata'; path=(Join-Path $dataDir 'state.json'); note='State metadata written transactionally; prior content backed up' })
$targets.Add([pscustomobject]@{ status='CREATE'; kind='backup'; path=(Join-Path $dataDir 'backups/<run-id>'); note='New backup manifest and snapshots for overwritten files' })
$targets.Add([pscustomobject]@{ status='UPDATE'; kind='pointer'; path=(Join-Path $dataDir 'last-backup.txt'); note='Commit pointer updated last; preserved on preflight failures' })
$targets.Add([pscustomobject]@{ status='CREATE/REMOVE'; kind='journal'; path=(Join-Path $dataDir 'pending-install.json'); note='Created during install and removed on commit/recovery' })
$legacyPaths = @(
    [pscustomobject]@{path=(Join-Path $homeDir '.agent-global'); action='REMOVE'; kind='directory'},
    [pscustomobject]@{path=(Join-Path $homeDir '.agent-global-last-backup.txt'); action='REMOVE'; kind='file'},
    [pscustomobject]@{path=(Join-Path $homeDir '.agent-global-backups'); action='ARCHIVE+REMOVE'; kind='directory'}
)
foreach ($legacy in $legacyPaths) {
    if (Test-Path -LiteralPath $legacy.path) {
        $targets.Add([pscustomobject]@{
            status=$(if ($MigrateLegacy) { 'DESTRUCTIVE' } else { 'PRESERVED' });
            kind=$legacy.kind; path=$legacy.path;
            note=$(if ($MigrateLegacy) { 'Explicit legacy migration: ' + $legacy.action + '; review ownership and contents' } else { 'Legacy item left untouched by default' })
        })
    }
}
if ($MigrateLegacy) {
    $targets.Add([pscustomobject]@{ status='REVIEW'; kind='legacy'; path=(Join-Path $homeDir '.agents/skills'); note='Known legacy skills and Pi prompts may be removed only if matching exact known content and layout' })
}
$runtime = Join-Path $dataDir 'bin'
$files = @{'plan.ps1'='scripts\plan.ps1';'agentkit-common.ps1'='scripts\agentkit-common.ps1';'toggle-hooks.ps1'='scripts\toggle-hooks.ps1';'doctor.ps1'='scripts\doctor.ps1';'agentkit-plan-guard.ts'='platform\pi\extensions\agentkit-plan-guard.ts';'EXECUTION_PLAN.md'='templates\EXECUTION_PLAN.md'}
foreach ($key in @($files.Keys | Sort-Object)) { Add-Target (Join-Path $runtime $key) (Join-Path $Root $files[$key]) 'file' }
if ($Json) { ConvertTo-Json -InputObject @($targets.ToArray()) -Depth 5 }
else { $targets | Format-Table -AutoSize }
$conflicts = @($targets | Where-Object { $_.status -eq 'CONFLICT' })
if ($conflicts.Count -gt 0) { Write-Warning ("Upgrade preview found $($conflicts.Count) conflicts. Resolve or explicitly run install.ps1 -ForceDrift."); exit 2 }
if ($MigrateLegacy) { Write-Warning 'Legacy migration requested. Inspect all DESTRUCTIVE rows before running install.ps1 -MigrateLegacy.' }
Write-Host 'Preview finished. No files modified.'
exit 0
