# AgentKit v3.3.1 验证报告

日期：2026-10-08；构建环境：Linux（非 Windows）。

## 已实际执行

- 运行 `PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -p test_release.py -v`：**9/9 测试通过**。检查版本清单、52+ 文件哈希、平台规则、Windows PS BOM+CRLF、CMD ASCII+CRLF、回滚防护关键代码、计划 Hook 防绕过及测试脚本。
- TypeScript `transpileModule` 静态编译 Pi extension：**0 语法诊断**（不等于完整 TypeScript 类型检查或 Pi 运行时兼容性验证）。
- 运行打包后 ZIP CRC、全部文件大小与 SHA-256 校验：结果见独立包验证记录和下载文件。
- 静态安全审查：`-MigrateLegacy` 默认关闭；`doctor` 把 CONFIGURED 与 UNVERIFIED 分离；完成状态需要 Ready + 全部 checklist + 具体证据；计划路径创建前检查父目录。

## 未执行（绝不能误称通过）

- Windows PowerShell 5.1 的 `install-all.cmd`、`verify.cmd`、`restore-latest.cmd`、`plan.cmd` 和 `doctor.cmd` 实机运行。
- `tests/windows-regression.ps1` 内完整计划 CLI 生命周期与进程 Hook 的真实 ExitCode 检查。
- `tests/windows-install-e2e.ps1` 在 Windows Sandbox 内的安装、覆盖升级、冲突拒绝、恢复白名单、Hook 启用/禁用、恢复行为。
- 三平台 Codex / Claude Code / Pi 在各自受支持客户端中启用并信任 Hooks 后的真实工具调用、异常退出与并发行为。

## 发布边界

本发布是**代码与静态包已验证的修复候选版**。`doctor.cmd` 模拟通过不能证明各宿主已加载 Hook；Pi `agent_end` 不能停止完成回合，任何 Hook 都不替代 Windows ACL 或沙箱。请在 Windows Sandbox 完成实机测试后，再在主力电脑升级。
