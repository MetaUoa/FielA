@echo off
setlocal
chcp 65001 >nul
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS%" (echo Windows PowerShell 5.1 is required.&exit /b 1)
set "MIGRATE="
if /I "%~1"=="-MigrateLegacy" set "MIGRATE=-MigrateLegacy"
if /I "%~2"=="-MigrateLegacy" set "MIGRATE=-MigrateLegacy"
"%PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0preview.ps1" %MIGRATE%
set "RC=%ERRORLEVEL%"
if /I "%~1"=="/nopause" goto END
if "%AGENTKIT_NO_PAUSE%"=="1" goto END
pause
:END
exit /b %RC%
