# AgentKit v3.3.1 实施计划及执行记录

创建日期：2026-10-08；最终状态：**代码修复及静态验证完成，Windows 实机验收待执行**。

## 目标和验收

- 对 v3.3.0 的复审高优先级问题进行修复：防止计划假完成、会话混用和 Hook 误判；保留原有 7 个 Skills、先计划后执行及中文优先规则。
- 修复旧版目录默认误删、计划路径重解析点检查顺序和升级预演不完整问题。
- 提供启用前检查、可选 Hook、诊断报告、测试脚本及完整可下载 ZIP。
- 在可用环境实测静态和打包完整性；不得把 Linux 静态校验冒充 Windows PowerShell 5.1 端到端测试。

## 实际实施步骤

- [x] 确认基线 v3.3.0 的源码文件、原 7 Skills、安装及恢复脚本边界。
- [x] 更新 `scripts/plan.ps1`：Init/Ready/Check/Step/Finish 生命周期；完成清单和证据；修复 HookStop 多计划漏报；提供会话隔离；祖先路径验证与旧索引兼容；输入特殊字符安全。
- [x] 更新 Pi 扩展、Codex 和 Claude 的可选 Hook 配置/事件覆盖，补充真实加载与信任状态的限制说明。
- [x] 默认不执行历史目录迁移；增加 `-MigrateLegacy` 显式选项和完整预演条目。
- [x] 增加 `doctor.cmd`/`doctor.ps1` 模拟探针和配置状态检查。
- [x] 排除 Python `__pycache__` 自污染，新增 Windows 回归及有防误运行门槛的 Windows Sandbox E2E 脚本。
- [x] 修复 `-StepsText "实现|验证"` 引号内管道误判，保留真实 Shell 管道拒绝；新增防回归静态用例。
- [x] 同步公共策略、Pi/Codex/Claude 生成规则、README、版本和发布说明。
- [x] 运行静态测试 **9/9 通过**、Pi TypeScript 静态转译 **0 诊断**，重算 SHA-256 清单并准备 ZIP。
- [ ] Windows PowerShell 5.1 / Windows Sandbox 实机执行计划 CLI、完整安装与恢复、三平台真实 Hook 激活和信任测试（需 Windows 环境）。

## 验证证据与风险

- 已执行：`PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -p test_release.py -v`，**9 tests OK**。
- 已执行：Node TypeScript `transpileModule`，**0 syntax diagnostics**。
- 已实施：严格文本 BOM/CRLF 与清单哈希检验、文件一致性、ZIP CRC 完整性校验（详见 `VALIDATION_REPORT.md`）。
- 尚未执行：Windows PowerShell 5.1 以及 Pi/Codex/Claude 的真实宿主 Hook。这些功能仍可能受运行时版本、信任提示或平台差异影响，不宜直接在主力环境启用所有 Hooks。
- 下一步：先在 Windows Sandbox 跑 `tests/windows-regression.ps1` 和 `tests/windows-install-e2e.ps1`，然后逐平台实机测试，再标记稳定生产发布。
