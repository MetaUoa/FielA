# Troubleshooting

## Contents

- Source directory path is wrong
- Same FQN exists multiple times
- Class name is known but FQN is not
- Nested classes
- Generated sources
- Source not found
- Explicit Maven fallback
- Test generation after resolution

## Source directory path is wrong

If the resolver returns `SOURCE_ROOT_INVALID`, verify the path supplied by the user. Do not replace it with `.m2` or another guessed directory.

## Same FQN exists multiple times

`AMBIGUOUS_SOURCE` means more than one verified Java source file has the same package and top-level type declaration.

This commonly means the source directory contains multiple library versions or duplicate extracted trees.

Do not choose by:

- newest timestamp;
- shortest path;
- alphabetical order;
- first grep result.

Narrow `--source-root` to the intended version/module tree and run again.

## Class name is known but FQN is not

Resolve the FQN from the real project caller first:

1. read the caller's `package`;
2. inspect explicit imports;
3. inspect same-package types;
4. inspect wildcard imports only if necessary;
5. inspect inherited/nested types;
6. for Spring, resolve the actual injected implementation.

Do not search the source directory for a simple name and assume the first match is correct.

## Nested classes

For JVM binary names such as:

```text
com.example.Outer$Inner
```

the source file is normally:

```text
com/example/Outer.java
```

Use the binary-style FQN when necessary. Then inspect `Outer.java` for the nested declaration/member.

## Generated sources

The default lookup excludes `target`, `build`, and `out` to avoid stale generated output.

If generated source is intentionally authoritative for the task, rerun with:

```text
--include-generated
```

## Source not found

`SOURCE_NOT_FOUND` means the exact FQN could not be verified inside the source directory supplied by the user.

Stop by default. Do not silently expand the search boundary.

Useful checks:

- FQN is correct;
- source root points at the correct version/tree;
- source was actually included in the supplied source set;
- nested-class naming is correct;
- source is generated and intentionally excluded.

## Explicit Maven fallback

Only when the user explicitly allows lookup outside the supplied source directory, run:

```bash
node "<skill-directory>/scripts/resolve-maven-source.mjs" --fqn "com.example.Type" --project "<module>" --json
```

That resolver may inspect Maven classpath/source artifacts. If it returns `SOURCE_ARTIFACT_UNAVAILABLE`, decompile only when the user permits it and label conclusions `DECOMPILED_SOURCE`.

## Test generation after resolution

Before generating tests:

- read the actual resolved source file;
- locate the exact overloaded method/signature;
- follow relevant superclass/interface/default-method behavior;
- inspect collaborators that materially influence behavior;
- prefer contract/observable behavior over incidental private implementation details.
