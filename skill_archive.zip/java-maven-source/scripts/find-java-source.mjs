#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const EXCLUDED_DIRS = new Set([
  '.git', '.idea', '.gradle', '.mvn-cache', 'node_modules', 'target', 'build', 'out', '.pi-cache'
]);

function parseArgs(argv) {
  const out = { sourceRoots: [], json: false, includeGenerated: false, maxCandidates: 50 };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === '--source-root') out.sourceRoots.push(argv[++i]);
    else if (arg === '--fqn') out.fqn = argv[++i];
    else if (arg === '--member') out.member = argv[++i];
    else if (arg === '--max-candidates') out.maxCandidates = Number(argv[++i]);
    else if (arg === '--include-generated') out.includeGenerated = true;
    else if (arg === '--json') out.json = true;
    else if (arg === '--help' || arg === '-h') out.help = true;
    else throw new Error(`Unknown argument: ${arg}`);
  }
  return out;
}

function usage() {
  return `Usage:\n  node find-java-source.mjs --source-root <dir> --fqn <fully.qualified.Type> [options]\n\nOptions:\n  --source-root <dir>      Source directory to search. Repeat for multiple roots.\n  --fqn <name>             Fully qualified Java type name.\n  --member <name>          Optional method/field/member name to locate after resolving the file.\n  --include-generated      Include target/build/out directories.\n  --max-candidates <n>     Maximum candidates in output (default: 50).\n  --json                   Emit machine-readable JSON.\n`;
}

function commandExists(cmd) {
  const probe = process.platform === 'win32' ? 'where' : 'which';
  return spawnSync(probe, [cmd], { encoding: 'utf8', windowsHide: true }).status === 0;
}

function typeInfo(fqn) {
  const binaryTop = fqn.split('$')[0];
  const parts = binaryTop.split('.');
  return {
    topFqn: binaryTop,
    simpleName: parts.at(-1),
    packageName: parts.slice(0, -1).join('.'),
    relativePath: `${binaryTop.replaceAll('.', '/')}.java`,
  };
}

function escapeRegex(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function inspectSource(file, info, member) {
  let text;
  try { text = fs.readFileSync(file, 'utf8'); } catch { return null; }

  const pkg = text.match(/(?:^|\n)\s*package\s+([\w.]+)\s*;/)?.[1] ?? '';
  if (pkg !== info.packageName) return null;

  const declRe = new RegExp(`\\b(class|interface|enum|record|@interface)\\s+${escapeRegex(info.simpleName)}\\b`);
  const lines = text.split(/\r?\n/);
  let declarationLine = null;
  for (let i = 0; i < lines.length; i += 1) {
    if (declRe.test(lines[i])) { declarationLine = i + 1; break; }
  }
  if (!declarationLine) return null;

  const memberMatches = [];
  if (member) {
    const memberRe = new RegExp(`\\b${escapeRegex(member)}\\b`);
    for (let i = 0; i < lines.length; i += 1) {
      if (memberRe.test(lines[i])) {
        memberMatches.push({ line: i + 1, text: lines[i].trim().slice(0, 500) });
        if (memberMatches.length >= 30) break;
      }
    }
  }

  return { packageName: pkg, declarationLine, memberMatches };
}

function rgCandidates(root, fileName, includeGenerated) {
  const args = ['--files', root, '-g', fileName];
  if (!includeGenerated) {
    for (const dir of EXCLUDED_DIRS) args.push('-g', `!**/${dir}/**`);
  }
  const res = spawnSync('rg', args, { encoding: 'utf8', windowsHide: true, maxBuffer: 64 * 1024 * 1024 });
  if (res.status !== 0 && res.status !== 1) return null;
  return (res.stdout ?? '').split(/\r?\n/).map(s => s.trim()).filter(Boolean).map(p => path.resolve(p));
}

function walkCandidates(root, fileName, includeGenerated) {
  const results = [];
  const stack = [root];
  while (stack.length) {
    const dir = stack.pop();
    let entries;
    try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { continue; }
    for (const entry of entries) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        if (!includeGenerated && EXCLUDED_DIRS.has(entry.name)) continue;
        stack.push(full);
      } else if (entry.isFile() && entry.name === fileName) {
        results.push(path.resolve(full));
      }
    }
  }
  return results;
}

function normalizeForSuffix(p) {
  return p.replaceAll('\\', '/').toLowerCase();
}

function resolveInRoot(root, info, member, includeGenerated) {
  const direct = path.resolve(root, ...info.relativePath.split('/'));
  const candidates = [];
  const seen = new Set();

  function add(file, mode) {
    const abs = path.resolve(file);
    if (seen.has(abs) || !fs.existsSync(abs)) return;
    seen.add(abs);
    const inspected = inspectSource(abs, info, member);
    if (!inspected) return;
    candidates.push({
      sourceRoot: path.resolve(root),
      sourcePath: abs,
      relativePath: path.relative(path.resolve(root), abs),
      matchMode: mode,
      ...inspected,
    });
  }

  add(direct, 'direct-fqn-path');

  const fileName = `${info.simpleName}.java`;
  const found = commandExists('rg')
    ? rgCandidates(path.resolve(root), fileName, includeGenerated)
    : walkCandidates(path.resolve(root), fileName, includeGenerated);

  for (const file of found ?? []) {
    const normalized = normalizeForSuffix(file);
    const wanted = normalizeForSuffix(info.relativePath);
    if (normalized.endsWith(`/${wanted}`) || path.basename(file) === fileName) add(file, 'recursive-verified');
  }

  return candidates;
}

function emit(result, json) {
  if (json) {
    process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
    return;
  }
  const lines = [
    `Resolution: ${result.resolution}`,
    `FQN: ${result.fqn}`,
  ];
  if (result.sourcePath) lines.push(`Source: ${result.sourcePath}`);
  if (result.sourceRoot) lines.push(`Source root: ${result.sourceRoot}`);
  if (result.declarationLine) lines.push(`Declaration line: ${result.declarationLine}`);
  if (result.member) lines.push(`Member: ${result.member}`);
  if (result.memberMatches?.length) {
    lines.push('Member matches:');
    for (const m of result.memberMatches) lines.push(`  ${m.line}: ${m.text}`);
  }
  if (result.candidates?.length) {
    lines.push('Candidates:');
    for (const c of result.candidates) lines.push(`  - ${c.sourcePath}`);
  }
  if (result.message) lines.push(`Message: ${result.message}`);
  process.stdout.write(`${lines.join('\n')}\n`);
}

function main() {
  let args;
  try { args = parseArgs(process.argv.slice(2)); }
  catch (e) {
    process.stderr.write(`${e.message}\n${usage()}`);
    process.exit(2);
  }

  if (args.help) {
    process.stdout.write(usage());
    return;
  }
  if (!args.fqn || !args.sourceRoots.length) {
    process.stderr.write(usage());
    process.exit(2);
  }
  if (!Number.isFinite(args.maxCandidates) || args.maxCandidates < 1) args.maxCandidates = 50;

  const roots = [];
  for (const raw of args.sourceRoots) {
    const root = path.resolve(raw);
    if (!fs.existsSync(root) || !fs.statSync(root).isDirectory()) {
      emit({ resolution: 'SOURCE_ROOT_INVALID', fqn: args.fqn, sourceRoot: root, message: 'Source root does not exist or is not a directory.' }, args.json);
      process.exit(1);
    }
    roots.push(root);
  }

  const info = typeInfo(args.fqn);
  const all = [];
  for (const root of roots) all.push(...resolveInRoot(root, info, args.member, args.includeGenerated));

  const unique = [...new Map(all.map(c => [c.sourcePath, c])).values()];
  const direct = unique.filter(c => c.matchMode === 'direct-fqn-path');
  const preferred = direct.length === 1 ? direct : unique;

  if (preferred.length === 1) {
    const c = preferred[0];
    emit({
      resolution: 'SOURCE_DIRECTORY',
      confidence: 'confirmed',
      fqn: args.fqn,
      member: args.member ?? null,
      sourceRoot: c.sourceRoot,
      sourcePath: c.sourcePath,
      relativePath: c.relativePath,
      declarationLine: c.declarationLine,
      memberMatches: c.memberMatches,
      matchMode: c.matchMode,
    }, args.json);
    return;
  }

  if (preferred.length > 1) {
    emit({
      resolution: 'AMBIGUOUS_SOURCE',
      confidence: 'unresolved',
      fqn: args.fqn,
      member: args.member ?? null,
      message: 'Multiple verified source files match the same FQN. Do not guess; narrow the source root.',
      candidates: preferred.slice(0, args.maxCandidates),
      totalCandidates: preferred.length,
    }, args.json);
    process.exit(3);
  }

  emit({
    resolution: 'SOURCE_NOT_FOUND',
    confidence: 'unresolved',
    fqn: args.fqn,
    member: args.member ?? null,
    sourceRoots: roots,
    message: 'The requested FQN was not found in the provided source directory. Do not search Maven/JARs unless the user explicitly allows fallback.',
  }, args.json);
  process.exit(4);
}

main();
