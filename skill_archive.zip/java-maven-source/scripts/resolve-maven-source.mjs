#!/usr/bin/env node

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const EXCLUDED_DIRS = new Set([
  '.git', '.idea', '.gradle', '.mvn-cache', 'node_modules', 'target', 'build', 'out', '.pi-cache'
]);

function fail(message, extra = {}) {
  const result = { status: 'error', message, ...extra };
  emit(result, true);
  process.exit(1);
}

function parseArgs(argv) {
  const out = {
    project: process.cwd(),
    scope: 'test',
    json: false,
    offline: false,
    noDownload: false,
  };

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === '--json') out.json = true;
    else if (arg === '--offline') out.offline = true;
    else if (arg === '--no-download') out.noDownload = true;
    else if (arg === '--fqn') out.fqn = argv[++i];
    else if (arg === '--project') out.project = argv[++i];
    else if (arg === '--scope') out.scope = argv[++i];
    else if (arg === '--cache') out.cache = argv[++i];
    else if (arg === '--classpath-file') out.classpathFile = argv[++i];
    else if (arg === '--help' || arg === '-h') out.help = true;
    else throw new Error(`Unknown argument: ${arg}`);
  }
  return out;
}

function usage() {
  return `Usage:\n  node resolve-maven-source.mjs --fqn <fully.qualified.Type> [options]\n\nOptions:\n  --project <dir>           Maven module directory (default: cwd)\n  --scope <scope>           Maven dependency scope (default: test)\n  --cache <dir>             Extraction/cache directory\n  --classpath-file <file>   Existing Maven-style classpath file\n  --offline                 Do not contact remote repositories\n  --no-download             Do not run dependency:get for missing sources\n  --json                    JSON output only\n`;
}

let OUTPUT_JSON = false;
function emit(result, forceJson = false) {
  if (OUTPUT_JSON || forceJson) {
    process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
    return;
  }

  const lines = [];
  lines.push(`Resolution: ${result.resolution ?? result.status}`);
  if (result.fqn) lines.push(`FQN: ${result.fqn}`);
  if (result.moduleDir) lines.push(`Module: ${result.moduleDir}`);
  if (result.gav) lines.push(`GAV: ${result.gav.groupId}:${result.gav.artifactId}:${result.gav.version}`);
  if (result.binaryJar) lines.push(`Binary: ${result.binaryJar}`);
  if (result.sourceJar) lines.push(`Source JAR: ${result.sourceJar}`);
  if (result.sourceEntry) lines.push(`Source entry: ${result.sourceEntry}`);
  if (result.sourcePath) lines.push(`Source: ${result.sourcePath}`);
  if (result.message) lines.push(`Message: ${result.message}`);
  if (result.candidates?.length) {
    lines.push('Candidates:');
    for (const c of result.candidates) lines.push(`  - ${c}`);
  }
  process.stdout.write(`${lines.join('\n')}\n`);
}

function commandExists(cmd) {
  const probe = process.platform === 'win32' ? 'where' : 'which';
  return spawnSync(probe, [cmd], { encoding: 'utf8' }).status === 0;
}

function findUp(startDir, names) {
  let current = path.resolve(startDir);
  while (true) {
    for (const name of names) {
      const p = path.join(current, name);
      if (fs.existsSync(p)) return p;
    }
    const parent = path.dirname(current);
    if (parent === current) return null;
    current = parent;
  }
}

function resolveMavenCommand(projectDir) {
  const wrapperNames = process.platform === 'win32' ? ['mvnw.cmd', 'mvnw'] : ['mvnw', 'mvnw.cmd'];
  const wrapper = findUp(projectDir, wrapperNames);
  if (wrapper) return { command: wrapper, shell: process.platform === 'win32' };
  const fallback = process.platform === 'win32' ? 'mvn.cmd' : 'mvn';
  return { command: fallback, shell: process.platform === 'win32' };
}

function run(cmd, args, opts = {}) {
  const res = spawnSync(cmd, args, {
    cwd: opts.cwd,
    encoding: 'utf8',
    shell: opts.shell ?? false,
    windowsHide: true,
    maxBuffer: 32 * 1024 * 1024,
  });
  return {
    status: res.status,
    stdout: res.stdout ?? '',
    stderr: res.stderr ?? '',
    error: res.error,
  };
}

function candidateSourceRelativePath(fqn) {
  const topLevel = fqn.split('$')[0];
  return `${topLevel.replaceAll('.', '/')}.java`;
}

function packageAndSimpleName(fqn) {
  const topLevel = fqn.split('$')[0];
  const parts = topLevel.split('.');
  return {
    simpleName: parts.at(-1),
    packageName: parts.slice(0, -1).join('.'),
  };
}

function verifyJavaSource(file, fqn) {
  try {
    const text = fs.readFileSync(file, 'utf8');
    const { packageName, simpleName } = packageAndSimpleName(fqn);
    const pkgMatch = text.match(/(?:^|\n)\s*package\s+([\w.]+)\s*;/);
    if ((pkgMatch?.[1] ?? '') !== packageName) return false;
    const escaped = simpleName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const decl = new RegExp(`\\b(class|interface|enum|record|@interface)\\s+${escaped}\\b`);
    return decl.test(text);
  } catch {
    return false;
  }
}

function findProjectSources(projectDir, fqn) {
  const rel = candidateSourceRelativePath(fqn).split('/');
  const fileName = rel.at(-1);
  const candidates = [];

  function walk(dir) {
    let entries;
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry of entries) {
      if (entry.isDirectory()) {
        if (EXCLUDED_DIRS.has(entry.name)) continue;
        walk(path.join(dir, entry.name));
      } else if (entry.isFile() && entry.name === fileName) {
        const full = path.join(dir, entry.name);
        const normalized = full.replaceAll('\\', '/');
        const suffix = candidateSourceRelativePath(fqn);
        if (normalized.endsWith(`/${suffix}`) && verifyJavaSource(full, fqn)) candidates.push(path.resolve(full));
      }
    }
  }

  walk(projectDir);
  return [...new Set(candidates)];
}

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function buildClasspath(args, projectDir, cacheDir) {
  if (args.classpathFile) {
    const cpFile = path.resolve(args.classpathFile);
    if (!fs.existsSync(cpFile)) throw new Error(`Classpath file not found: ${cpFile}`);
    return { classpathFile: cpFile, source: 'provided' };
  }

  const pom = path.join(projectDir, 'pom.xml');
  if (!fs.existsSync(pom)) throw new Error(`pom.xml not found in module directory: ${projectDir}`);

  ensureDir(cacheDir);
  const cpFile = path.join(cacheDir, 'classpath.txt');
  try { fs.rmSync(cpFile, { force: true }); } catch {}

  const mvn = resolveMavenCommand(projectDir);
  const mvnArgs = [
    '-q',
    `-DincludeScope=${args.scope}`,
    `-Dmdep.outputFile=${cpFile}`,
    'dependency:build-classpath',
  ];
  if (args.offline) mvnArgs.unshift('-o');

  const res = run(mvn.command, mvnArgs, { cwd: projectDir, shell: mvn.shell });
  if (res.error) throw new Error(`Unable to start Maven: ${res.error.message}`);
  if (res.status !== 0 || !fs.existsSync(cpFile)) {
    throw new Error(`Maven dependency:build-classpath failed.\n${res.stderr || res.stdout}`.trim());
  }
  return { classpathFile: cpFile, source: 'maven', maven: mvn };
}

function readClasspath(cpFile) {
  const raw = fs.readFileSync(cpFile, 'utf8').trim();
  if (!raw) return [];
  return raw.split(path.delimiter).map(s => s.trim()).filter(Boolean);
}

function parseClassfileFromJavap(output) {
  const lines = output.split(/\r?\n/);
  for (const line of lines) {
    const jarMatch = line.match(/^\s*Classfile\s+jar:(file:[^!]+)!\/(.+)\s*$/);
    if (jarMatch) {
      return {
        binaryJar: fileURLToPath(new URL(jarMatch[1])),
        classEntry: jarMatch[2],
      };
    }
  }
  return null;
}

function locateBinaryJar(fqn, classpathEntries) {
  if (!commandExists('javap')) throw new Error('JDK tool javap is not available in PATH.');
  const classpath = classpathEntries.join(path.delimiter);
  const res = run('javap', ['-classpath', classpath, '-verbose', fqn]);
  if (res.error) throw new Error(`Unable to start javap: ${res.error.message}`);
  if (res.status !== 0) {
    throw new Error(`javap could not resolve ${fqn} from the selected classpath.\n${res.stderr || res.stdout}`.trim());
  }
  const found = parseClassfileFromJavap(res.stdout);
  if (!found?.binaryJar) {
    throw new Error(`javap resolved ${fqn}, but the providing JAR could not be parsed from its output.`);
  }
  return found;
}

function listJar(jarPath) {
  if (!commandExists('jar')) throw new Error('JDK tool jar is not available in PATH.');
  const res = run('jar', ['tf', jarPath]);
  if (res.error) throw new Error(`Unable to start jar tool: ${res.error.message}`);
  if (res.status !== 0) throw new Error(`Unable to list JAR: ${jarPath}\n${res.stderr || res.stdout}`.trim());
  return res.stdout.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
}

function parseProperties(text) {
  const out = {};
  for (const rawLine of text.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith('#') || line.startsWith('!')) continue;
    const idxEq = line.indexOf('=');
    const idxColon = line.indexOf(':');
    const indexes = [idxEq, idxColon].filter(i => i >= 0);
    if (!indexes.length) continue;
    const idx = Math.min(...indexes);
    out[line.slice(0, idx).trim()] = line.slice(idx + 1).trim();
  }
  return out;
}

function extractJarEntries(jarPath, entries, destination) {
  ensureDir(destination);
  const res = run('jar', ['xf', jarPath, ...entries], { cwd: destination });
  if (res.error) throw new Error(`Unable to start jar tool: ${res.error.message}`);
  if (res.status !== 0) throw new Error(`Unable to extract from JAR: ${jarPath}\n${res.stderr || res.stdout}`.trim());
}

function readMavenGav(binaryJar, scratchDir) {
  const entries = listJar(binaryJar).filter(e => /^META-INF\/maven\/[^/]+\/[^/]+\/pom\.properties$/.test(e));
  if (!entries.length) return { gav: null, metadataEntries: [] };

  const tmp = fs.mkdtempSync(path.join(scratchDir, 'gav-'));
  try {
    extractJarEntries(binaryJar, entries, tmp);
    const records = [];
    for (const entry of entries) {
      const p = path.join(tmp, ...entry.split('/'));
      if (!fs.existsSync(p)) continue;
      const props = parseProperties(fs.readFileSync(p, 'utf8'));
      if (props.groupId && props.artifactId && props.version) {
        records.push({
          groupId: props.groupId,
          artifactId: props.artifactId,
          version: props.version,
          entry,
        });
      }
    }
    if (!records.length) return { gav: null, metadataEntries: entries };

    const base = path.basename(binaryJar, '.jar');
    const exact = records.find(r => base === `${r.artifactId}-${r.version}`);
    if (exact) return { gav: exact, metadataEntries: entries };

    const prefix = records.find(r => base.startsWith(`${r.artifactId}-`));
    if (prefix) return { gav: prefix, metadataEntries: entries, ambiguous: records.length > 1 };

    return { gav: records.length === 1 ? records[0] : null, metadataEntries: entries, ambiguous: records.length > 1, candidates: records };
  } finally {
    fs.rmSync(tmp, { recursive: true, force: true });
  }
}

function siblingSourcesJar(binaryJar, gav) {
  const dir = path.dirname(binaryJar);
  if (gav) {
    const p = path.join(dir, `${gav.artifactId}-${gav.version}-sources.jar`);
    if (fs.existsSync(p)) return p;
  }
  const fallback = path.join(dir, `${path.basename(binaryJar, '.jar')}-sources.jar`);
  return fs.existsSync(fallback) ? fallback : null;
}

function downloadSources(gav, projectDir, offline) {
  const mvn = resolveMavenCommand(projectDir);
  const coordinate = `${gav.groupId}:${gav.artifactId}:${gav.version}:jar:sources`;
  const mvnArgs = ['-q', `-Dartifact=${coordinate}`, '-Dtransitive=false', 'dependency:get'];
  if (offline) mvnArgs.unshift('-o');
  const res = run(mvn.command, mvnArgs, { cwd: projectDir, shell: mvn.shell });
  return { ...res, coordinate };
}

function sourceEntryFromClassEntry(classEntry, fqn, sourceJar) {
  let candidate;
  if (classEntry?.endsWith('.class')) {
    candidate = classEntry.replace(/\$[^/]*\.class$/, '.java').replace(/\.class$/, '.java');
  } else {
    candidate = candidateSourceRelativePath(fqn);
  }

  const entries = new Set(listJar(sourceJar));
  if (entries.has(candidate)) return candidate;

  const fallback = candidateSourceRelativePath(fqn);
  if (entries.has(fallback)) return fallback;
  return null;
}

function sanitizeSegment(value) {
  return String(value).replace(/[^A-Za-z0-9._-]+/g, '_');
}

function extractSourceFile(sourceJar, sourceEntry, cacheDir, gav) {
  const gavRoot = gav
    ? path.join(cacheDir, sanitizeSegment(gav.groupId), sanitizeSegment(gav.artifactId), sanitizeSegment(gav.version))
    : path.join(cacheDir, 'unknown-artifact');
  ensureDir(gavRoot);
  extractJarEntries(sourceJar, [sourceEntry], gavRoot);
  return path.join(gavRoot, ...sourceEntry.split('/'));
}

async function main() {
  let args;
  try {
    args = parseArgs(process.argv.slice(2));
  } catch (e) {
    process.stderr.write(`${e.message}\n${usage()}`);
    process.exit(1);
  }

  OUTPUT_JSON = args.json;
  if (args.help) {
    process.stdout.write(usage());
    return;
  }
  if (!args.fqn) fail('--fqn is required');

  const projectDir = path.resolve(args.project);
  if (!fs.existsSync(projectDir) || !fs.statSync(projectDir).isDirectory()) {
    fail(`Project directory not found: ${projectDir}`);
  }

  const cacheDir = path.resolve(args.cache ?? path.join(projectDir, '.pi-cache', 'maven-sources'));
  ensureDir(cacheDir);

  const projectSources = findProjectSources(projectDir, args.fqn);
  if (projectSources.length === 1) {
    emit({
      status: 'resolved',
      resolution: 'PROJECT_SOURCE',
      fqn: args.fqn,
      moduleDir: projectDir,
      sourcePath: projectSources[0],
      confidence: 'confirmed',
    });
    return;
  }
  if (projectSources.length > 1) {
    emit({
      status: 'unresolved',
      resolution: 'AMBIGUOUS_PROJECT_SOURCE',
      fqn: args.fqn,
      moduleDir: projectDir,
      candidates: projectSources,
      message: 'Multiple matching project sources exist. Narrow --project to the actual Maven module.',
      confidence: 'unresolved',
    });
    return;
  }

  let cp;
  try {
    cp = buildClasspath(args, projectDir, cacheDir);
  } catch (e) {
    fail(e.message, { fqn: args.fqn, moduleDir: projectDir });
  }

  const classpathEntries = readClasspath(cp.classpathFile);
  if (!classpathEntries.length) fail('Resolved classpath is empty.', { fqn: args.fqn, moduleDir: projectDir });

  let located;
  try {
    located = locateBinaryJar(args.fqn, classpathEntries);
  } catch (e) {
    fail(e.message, { fqn: args.fqn, moduleDir: projectDir, classpathFile: cp.classpathFile });
  }

  const binaryJar = path.resolve(located.binaryJar);
  const scratchDir = path.join(cacheDir, '.tmp');
  ensureDir(scratchDir);

  let gavInfo;
  try {
    gavInfo = readMavenGav(binaryJar, scratchDir);
  } catch (e) {
    fail(e.message, { fqn: args.fqn, moduleDir: projectDir, binaryJar });
  }

  const gav = gavInfo.gav;
  let sourceJar = siblingSourcesJar(binaryJar, gav);
  let downloadAttempted = false;
  let downloadError = null;

  if (!sourceJar && gav && !args.noDownload && !args.offline) {
    downloadAttempted = true;
    const dl = downloadSources(gav, projectDir, false);
    if (dl.status !== 0) downloadError = (dl.stderr || dl.stdout || 'dependency:get failed').trim();
    sourceJar = siblingSourcesJar(binaryJar, gav);
  }

  if (!sourceJar) {
    emit({
      status: 'unavailable',
      resolution: 'SOURCE_ARTIFACT_UNAVAILABLE',
      fqn: args.fqn,
      moduleDir: projectDir,
      gav: gav ? { groupId: gav.groupId, artifactId: gav.artifactId, version: gav.version } : null,
      binaryJar,
      classEntry: located.classEntry,
      classpathFile: cp.classpathFile,
      downloadAttempted,
      downloadError,
      mavenMetadataAmbiguous: Boolean(gavInfo.ambiguous),
      message: gav
        ? 'Exact binary JAR was resolved, but a matching sources JAR is unavailable. Decompile this exact binary only as a last resort.'
        : 'Exact binary JAR was resolved, but Maven GAV metadata could not be established. Do not guess a sources coordinate.',
      confidence: gav ? 'confirmed-binary' : 'unresolved-gav',
    });
    return;
  }

  let sourceEntry;
  let sourcePath;
  try {
    sourceEntry = sourceEntryFromClassEntry(located.classEntry, args.fqn, sourceJar);
    if (!sourceEntry) {
      emit({
        status: 'unavailable',
        resolution: 'SOURCE_ENTRY_UNAVAILABLE',
        fqn: args.fqn,
        moduleDir: projectDir,
        gav: gav ? { groupId: gav.groupId, artifactId: gav.artifactId, version: gav.version } : null,
        binaryJar,
        sourceJar,
        classEntry: located.classEntry,
        message: 'The sources JAR exists, but the matching Java source entry was not found.',
        confidence: 'unresolved',
      });
      return;
    }
    sourcePath = extractSourceFile(sourceJar, sourceEntry, cacheDir, gav);
  } catch (e) {
    fail(e.message, { fqn: args.fqn, moduleDir: projectDir, binaryJar, sourceJar });
  }

  emit({
    status: 'resolved',
    resolution: 'MAVEN_SOURCE_JAR',
    fqn: args.fqn,
    moduleDir: projectDir,
    gav: gav ? { groupId: gav.groupId, artifactId: gav.artifactId, version: gav.version } : null,
    binaryJar,
    classEntry: located.classEntry,
    sourceJar,
    sourceEntry,
    sourcePath,
    classpathFile: cp.classpathFile,
    classpathSource: cp.source,
    downloadAttempted,
    mavenMetadataAmbiguous: Boolean(gavInfo.ambiguous),
    confidence: gav && !gavInfo.ambiguous ? 'confirmed' : 'confirmed-binary',
  });
}

main().catch((e) => fail(e?.stack || String(e)));
