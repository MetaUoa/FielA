param(
    [Parameter(Mandatory = $true)]
    [string]$Fqn,

    [string]$Project = ".",
    [string]$Scope = "test",
    [string]$Cache,
    [string]$ClasspathFile,
    [switch]$Offline,
    [switch]$NoDownload,
    [switch]$Json
)

$ErrorActionPreference = "Stop"
$scriptPath = Join-Path $PSScriptRoot "resolve-maven-source.mjs"

$argsList = @($scriptPath, "--fqn", $Fqn, "--project", $Project, "--scope", $Scope)

if ($Cache) {
    $argsList += @("--cache", $Cache)
}
if ($ClasspathFile) {
    $argsList += @("--classpath-file", $ClasspathFile)
}
if ($Offline) {
    $argsList += "--offline"
}
if ($NoDownload) {
    $argsList += "--no-download"
}
if ($Json) {
    $argsList += "--json"
}

& node @argsList
exit $LASTEXITCODE
