param(
    [Parameter(Mandatory=$true)][string]$SourceRoot,
    [Parameter(Mandatory=$true)][string]$Fqn,
    [string]$Member,
    [switch]$Json
)

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$argsList = @(
    (Join-Path $scriptDir 'find-java-source.mjs'),
    '--source-root', $SourceRoot,
    '--fqn', $Fqn
)
if ($Member) { $argsList += @('--member', $Member) }
if ($Json) { $argsList += '--json' }

& node @argsList
exit $LASTEXITCODE
