---
name: java-maven-source
description: Precisely locates and reads Java implementation source from a user-provided source directory, especially for large Maven projects, dependency source trees, and test generation. Use when the user provides a Java/Maven source directory and asks to inspect a class, method, implementation, dependency behavior, or generate tests from real source. Resolve the exact FQN first, search only the provided source root by default, verify package and declaration to avoid same-named classes, report ambiguity instead of guessing, and use Maven sources or decompilation only when the user explicitly allows fallback.
---

# Java Source Lookup for Pi Agent

Treat the user-provided source directory as the authoritative lookup boundary. Search that directory directly. Do not inspect `.m2`, download sources, search GitHub, or decompile JARs unless the user explicitly asks for fallback.

## Core contract

1. Start from the real Java call site and resolve the target symbol to an exact FQN.
2. Use the source directory supplied by the user as `sourceRoot`.
3. Search by FQN first, not simple class name.
4. Verify both:
   - `package` matches the FQN package;
   - the file declares the expected top-level `class`, `interface`, `enum`, `record`, or annotation type.
5. If multiple verified files match, return `AMBIGUOUS_SOURCE`; never select one by filename, modification time, or proximity.
6. Once the correct source file is resolved, read that file directly and inspect the requested method/member.
7. Stay inside the provided source root by default.
8. Only use the bundled Maven resolver when the user explicitly requests Maven/JAR fallback after `SOURCE_NOT_FOUND`.
9. Only decompile an exact binary JAR after source lookup and allowed Maven-source fallback both fail.

## Required workflow

### 1. Resolve the FQN from the project code

From the actual caller, inspect:

- current `package`;
- explicit imports;
- wildcard imports only when necessary;
- same-package types;
- nested classes;
- inheritance and interfaces;
- Spring injection metadata when implementation selection matters.

For Spring, inspect `@Qualifier`, `@Resource`, `@Primary`, bean names, `@Bean`, `@Service`, constructor injection, and configuration before choosing an implementation.

Do not search a large source tree for `UserService` and pick the first result. Resolve something like:

```text
com.company.account.service.UserService
```

first.

### 2. Search the provided source directory

Locate this skill directory from the loaded `SKILL.md`, then run:

```bash
node "<skill-directory>/scripts/find-java-source.mjs" \
  --source-root "<provided-source-directory>" \
  --fqn "com.example.Type" \
  --json
```

To locate a method/member at the same time:

```bash
node "<skill-directory>/scripts/find-java-source.mjs" \
  --source-root "<provided-source-directory>" \
  --fqn "com.example.Type" \
  --member "targetMethod" \
  --json
```

On Windows, the PowerShell wrapper is also available:

```powershell
& "<skill-directory>\scripts\find-java-source.ps1" `
  -SourceRoot "D:\JavaSources" `
  -Fqn "com.example.Type" `
  -Member "targetMethod" `
  -Json
```

The resolver uses `rg` when available for fast candidate enumeration and falls back to a built-in directory walk. It verifies Java package and declaration before confirming a result.

### 3. Interpret source-directory results

#### `SOURCE_DIRECTORY`

The source is confirmed inside the provided directory. Read `sourcePath` directly.

Use the returned `memberMatches` only as navigation hints; read the surrounding source before interpreting overloaded methods, overrides, generics, lambdas, or annotations.

#### `AMBIGUOUS_SOURCE`

Multiple verified files expose the same FQN. Do not guess. Narrow the supplied source root to the appropriate library/module/source tree, then resolve again.

#### `SOURCE_NOT_FOUND`

Stop. State that the FQN was not found in the provided source directory.

Do **not** automatically:

- search `.m2`;
- run Maven downloads;
- search the web;
- inspect arbitrary JARs;
- decompile.

Proceed beyond the source directory only when the user explicitly permits fallback.

## Optional Maven fallback

If and only if the user allows Maven/JAR fallback, use:

```bash
node "<skill-directory>/scripts/resolve-maven-source.mjs" \
  --fqn "com.example.Type" \
  --project "<maven-module-directory>" \
  --json
```

That resolver may inspect the actual module classpath, identify the providing binary JAR, locate/download the exact `*-sources.jar`, and extract the matching `.java` file.

Treat these results as:

- `PROJECT_SOURCE`: repository/reactor source found;
- `MAVEN_SOURCE_JAR`: exact Maven source artifact found;
- `SOURCE_ARTIFACT_UNAVAILABLE`: source artifact unavailable; decompilation may be considered only if allowed.

Read `references/TROUBLESHOOTING.md` only when source lookup or explicit fallback fails.

## Test-generation rules

When generating tests from implementation behavior:

1. Resolve the exact implementation source before writing implementation-dependent assertions.
2. Prefer public contract and observable behavior over private implementation details.
3. Read the actual method body and relevant collaborators, not just grep hits.
4. Follow inheritance/override chains when behavior is inherited.
5. For overloaded methods, verify the exact parameter types used by the caller.
6. If the source directory contains multiple versions of the same library, treat duplicate FQNs as ambiguous until the correct source root/version is identified.
7. Never use a nearby version merely because it is easier to locate.

## Output evidence

Before modifying or generating tests based on an implementation, summarize:

```text
Symbol: <simple name>
FQN: <fully qualified name>
Source root: <provided source directory>
Source: <resolved .java path>
Member: <method/member if relevant>
Resolution: SOURCE_DIRECTORY | AMBIGUOUS_SOURCE | SOURCE_NOT_FOUND
Confidence: confirmed | unresolved
```

When explicit Maven fallback is used, additionally report the Maven GAV and binary/source JAR evidence returned by the fallback resolver.

## Search boundaries

By default exclude common build/cache directories such as:

```text
.git
.idea
.gradle
node_modules
target
build
out
.pi-cache
```

Use `--include-generated` only when generated source is intentionally part of the task.
