# Java Maven Source for Pi Agent

这个版本按你的实际使用方式设计：**你提供源码目录，Pi 直接在该目录下精确查找源码。**

默认不会去 `.m2`、不会自动下载 Maven sources、不会自动反编译 JAR。

## 安装

把整个 `java-maven-source` 目录复制到：

```text
C:\Users\<用户名>\.pi\agent\skills\java-maven-source\
```

或项目级：

```text
<项目根目录>\.pi\skills\java-maven-source\
```

确保存在：

```text
...\java-maven-source\SKILL.md
```

重启 Pi 后可自动触发，也可显式调用：

```text
/skill:java-maven-source
```

## 推荐用法

例如你已经有第三方库源码目录：

```text
D:\MavenSources
```

直接告诉 Pi：

```text
源码目录是 D:\MavenSources。
从当前调用点确定真正的 FQN，然后只在这个源码目录内查找对应实现，
查看目标方法后生成测试；找不到时不要自动反编译。
```

也可以明确指定类：

```text
/skill:java-maven-source
源码目录 D:\MavenSources，查看
org.springframework.web.client.RestTemplate#doExecute 的实现。
```

## 手动查找

```powershell
node .\scripts\find-java-source.mjs `
  --source-root "D:\MavenSources" `
  --fqn "org.springframework.web.client.RestTemplate" `
  --member "doExecute" `
  --json
```

或者：

```powershell
.\scripts\find-java-source.ps1 `
  -SourceRoot "D:\MavenSources" `
  -Fqn "org.springframework.web.client.RestTemplate" `
  -Member "doExecute" `
  -Json
```

返回 `SOURCE_DIRECTORY` 后，Pi 直接读取 `sourcePath`。

## 查找策略

```text
当前 Java 调用点
      ↓
解析 import / package / Spring 注入
      ↓
确定精确 FQN
      ↓
用户提供的源码目录
      ↓
按 FQN 路径 + 文件名快速候选搜索
      ↓
验证 package + 类型声明
      ↓
唯一匹配 → 直接读取 .java
      ↓
查看指定 method/member
```

如果同一个 FQN 在源码目录里出现多个版本：

```text
AMBIGUOUS_SOURCE
```

Pi 必须停止猜测并缩小源码根目录。

如果找不到：

```text
SOURCE_NOT_FOUND
```

Pi 默认停止，不自动搜索 Maven/JAR。

## 可选 Maven fallback

原有 Maven resolver 仍保留在：

```text
scripts\resolve-maven-source.mjs
```

只有你明确说“源码目录找不到时允许查 Maven/JAR”时才使用它。

## 依赖

主查找脚本仅依赖 Node.js 标准库。

如果系统安装了 `rg` (ripgrep)，会自动用于超大源码目录的快速候选枚举；没有 `rg` 也能工作，只是会使用 Node.js 目录遍历。

Maven/JDK 只在你显式允许 Maven fallback 时才需要。
