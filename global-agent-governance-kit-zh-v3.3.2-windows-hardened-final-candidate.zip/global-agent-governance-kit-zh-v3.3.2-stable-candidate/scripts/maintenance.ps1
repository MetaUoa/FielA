﻿param(
    [switch]$Apply,
    [switch]$ConfirmPrune,
    [ValidateRange(1,200)][int]$KeepRecent = 12,
    [ValidateRange(7,3650)][int]$MinAgeDays = 60
)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'agentkit-common.ps1')
$guard = $null
$utf = New-Object System.Text.UTF8Encoding -ArgumentList @($false, $true)
$homeDir = [Environment]::GetFolderPath('UserProfile')
$appData = [Environment]::GetFolderPath('LocalApplicationData')
if (-not $appData) { $appData = Join-Path $homeDir 'AppData\Local' }
$kit = Join-Path $appData 'AgentKit'
if ($Apply -and -not $ConfirmPrune) { throw '-Apply requires explicit -ConfirmPrune (dry-run by default).' }
function Assert-SafeTree([string]$Path) {
    Assert-AgentKitPlainPath $Path
    $stack = New-Object System.Collections.Stack
    $stack.Push($Path)
    while ($stack.Count -gt 0) {
        $current = $stack.Pop()
        foreach ($child in @(Get-ChildItem -LiteralPath $current -Force)) {
            if (($child.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
                throw "Refusing to prune tree with junction or symbolic link: $($child.FullName)"
            }
            if ($child.PSIsContainer) { $stack.Push($child.FullName) }
        }
    }
}
try {
    $guard = Enter-AgentKitMutex 'install-restore'
    Assert-AgentKitPlainPath $kit
    if (Test-Path -LiteralPath (Join-Path $kit 'pending-install.json')) { throw 'Interrupted install exists: recover-pending.cmd first.' }
    $pointer = Join-Path $kit 'last-backup.txt'
    $protected = ''
    if (Test-Path -LiteralPath $pointer -PathType Leaf) {
        Assert-AgentKitPlainPath $pointer
        $protected = [System.IO.File]::ReadAllText($pointer,$utf).Trim()
        if ($protected) {
            $backupRoot = Join-Path $kit 'backups'
            Assert-AgentKitChild $protected $backupRoot
            Assert-AgentKitPlainPath $protected
        }
    } elseif ($Apply) { throw 'Cannot prune without a valid last-backup.txt pointer.' }
    if ($Apply -and -not $protected) { throw 'No active backup pointer; refusing cleanup.' }
    $limit = (Get-Date).AddDays(-$MinAgeDays)
    $count = 0
    $bytes = [int64]0
    foreach ($name in @('backups','hook-backups','restore-safety')) {
        $dir = Join-Path $kit $name
        if (-not (Test-Path -LiteralPath $dir -PathType Container)) { continue }
        Assert-AgentKitPlainPath $dir
        $items = @(Get-ChildItem -LiteralPath $dir -Directory -Force | Sort-Object LastWriteTime -Descending)
        foreach ($entry in @($items | Select-Object -Skip $KeepRecent)) {
            if ($entry.Name -notmatch '^[0-9]{8}-[0-9]{6}(?:-[0-9]{3})?(?:-[0-9]+)?-[a-f0-9]{8}$') { continue }
            if ($entry.LastWriteTime -ge $limit) { continue }
            if ($protected -and [System.IO.Path]::GetFullPath($entry.FullName).Equals([System.IO.Path]::GetFullPath($protected),[System.StringComparison]::OrdinalIgnoreCase)) { continue }
            Assert-SafeTree $entry.FullName
            $size = [int64]0
            foreach ($file in @(Get-ChildItem -LiteralPath $entry.FullName -Recurse -File -Force)) { $size += $file.Length }
            $count++; $bytes += $size
            Write-Host ("{0} {1} ({2} bytes)" -f $(if ($Apply) {'PRUNE'} else {'CANDIDATE'}),$entry.FullName,$size)
            if ($Apply) { Remove-Item -LiteralPath $entry.FullName -Recurse -Force }
        }
    }
    Write-Host ("MAINTENANCE_{0}: {1} archive folders; {2} bytes; minimum age {3} days; newest {4} per category preserved." -f $(if ($Apply) {'APPLIED'} else {'PREVIEW'}),$count,$bytes,$MinAgeDays,$KeepRecent)
} catch {
    [Console]::Error.WriteLine('AGENTKIT_MAINTENANCE_ERROR: ' + $_.Exception.Message)
    exit 1
} finally {
    Exit-AgentKitMutex $guard
}
