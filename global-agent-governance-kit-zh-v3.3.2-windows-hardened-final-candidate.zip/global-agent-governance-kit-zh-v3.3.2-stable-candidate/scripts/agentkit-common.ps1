﻿# AgentKit shared primitives - compatible with Windows PowerShell 5.1.
$script:AgentKitUtf8 = New-Object System.Text.UTF8Encoding -ArgumentList @($false, $true)

function Assert-AgentKitPlainPath([string]$Path) {
    if ([string]::IsNullOrWhiteSpace($Path)) { throw 'Empty path is not permitted.' }
    $full = [System.IO.Path]::GetFullPath($Path)
    $cursor = $full
    while (-not [string]::IsNullOrEmpty($cursor)) {
        if (Test-Path -LiteralPath $cursor) {
            $item = Get-Item -LiteralPath $cursor -Force
            if (($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
                throw "Reparse point in path (unsafe for AgentKit writes): $cursor"
            }
        }
        $parent = [System.IO.Path]::GetDirectoryName($cursor)
        if ([string]::IsNullOrEmpty($parent) -or $parent -eq $cursor) { break }
        $cursor = $parent
    }
}

function Write-AgentKitAtomicBytes([string]$Path, [byte[]]$Data) {
    Assert-AgentKitPlainPath $Path
    $parent = [System.IO.Path]::GetDirectoryName([System.IO.Path]::GetFullPath($Path))
    if (-not (Test-Path -LiteralPath $parent -PathType Container)) {
        [void][System.IO.Directory]::CreateDirectory($parent)
    }
    if (Test-Path -LiteralPath $Path -PathType Container) { throw "File target is a directory: $Path" }
    $tmp = [System.IO.Path]::Combine($parent, ('.agentkit-' + [guid]::NewGuid().ToString('N') + '.tmp'))
    try {
        $stream = [System.IO.File]::Open($tmp, [System.IO.FileMode]::CreateNew, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
        try {
            $stream.Write($Data, 0, $Data.Length)
            $stream.Flush($true)
        } finally { $stream.Dispose() }
        if (Test-Path -LiteralPath $Path -PathType Leaf) {
            # File.Replace is an in-place replacement on the same volume. Never delete the old destination first.
            [System.IO.File]::Replace($tmp, $Path, $null)
        } else {
            [System.IO.File]::Move($tmp, $Path)
        }
    } finally {
        if ([System.IO.File]::Exists($tmp)) { [System.IO.File]::Delete($tmp) }
    }
}

function Write-AgentKitAtomicText([string]$Path, [string]$Text) {
    $bytes = $script:AgentKitUtf8.GetBytes($Text)
    Write-AgentKitAtomicBytes $Path $bytes
}

function Get-AgentKitFingerprint([string]$Path, [string]$Kind = 'file') {
    if (-not (Test-Path -LiteralPath $Path)) { return 'ABSENT' }
    Assert-AgentKitPlainPath $Path
    if ($Kind -eq 'managed') {
        if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { throw "Managed target is not a file: $Path" }
        $raw = [System.IO.File]::ReadAllText($Path, $script:AgentKitUtf8)
        $begin = '<!-- AGENTKIT:BEGIN -->'
        $end = '<!-- AGENTKIT:END -->'
        if ([regex]::Matches($raw, [regex]::Escape($begin)).Count -ne 1 -or [regex]::Matches($raw, [regex]::Escape($end)).Count -ne 1) {
            return 'INVALID-MARKER'
        }
        $match = [regex]::Match($raw, '(?s)' + [regex]::Escape($begin) + '\s*(.*?)\s*' + [regex]::Escape($end))
        if (-not $match.Success) { return 'INVALID-MARKER' }
        $body = $match.Groups[1].Value.Trim()
        $data = $script:AgentKitUtf8.GetBytes($body)
        $sha = [System.Security.Cryptography.SHA256]::Create()
        try { return ([System.BitConverter]::ToString($sha.ComputeHash($data))).Replace('-','').ToLowerInvariant() }
        finally { $sha.Dispose() }
    }
    if (Test-Path -LiteralPath $Path -PathType Leaf) {
        return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
    }
    if ($Kind -ne 'directory') { throw "Expected file at path: $Path" }
    $lines = New-Object 'System.Collections.Generic.List[string]'
    $root = [System.IO.Path]::GetFullPath($Path).TrimEnd([char[]]@('\','/'))
    $stack = New-Object System.Collections.Stack
    $stack.Push($root)
    while ($stack.Count -gt 0) {
        $current = [string]$stack.Pop()
        foreach ($item in @(Get-ChildItem -LiteralPath $current -Force)) {
            Assert-AgentKitPlainPath $item.FullName
            $rel = $item.FullName.Substring($root.Length).TrimStart([char[]]@('\','/')).Replace('\','/')
            if ($item.PSIsContainer) { $lines.Add('D ' + $rel); $stack.Push($item.FullName) }
            else { $lines.Add('F ' + $rel + ' ' + (Get-FileHash -LiteralPath $item.FullName -Algorithm SHA256).Hash.ToLowerInvariant()) }
        }
    }
    $lines.Sort([System.StringComparer]::Ordinal)
    $inputBytes = $script:AgentKitUtf8.GetBytes(($lines -join "`n"))
    $hash = [System.Security.Cryptography.SHA256]::Create()
    try { return ([System.BitConverter]::ToString($hash.ComputeHash($inputBytes))).Replace('-','').ToLowerInvariant() }
    finally { $hash.Dispose() }
}

function Enter-AgentKitMutex([string]$Name, [int]$TimeoutMs = 15000) {
    $safe = [regex]::Replace($Name, '[^A-Za-z0-9_-]', '_')
    $mutex = New-Object -TypeName System.Threading.Mutex -ArgumentList @($false, ('Local\AgentKit_' + $safe))
    $acquired = $false
    try {
        try { $acquired = $mutex.WaitOne($TimeoutMs) }
        catch [System.Threading.AbandonedMutexException] { $acquired = $true }
        if (-not $acquired) { throw "Another AgentKit operation is running: $Name" }
        return $mutex
    } catch {
        if (-not $acquired) { $mutex.Dispose() }
        throw
    }
}

function Exit-AgentKitMutex($Mutex) {
    if ($null -ne $Mutex) { try { $Mutex.ReleaseMutex() } finally { $Mutex.Dispose() } }
}

function Assert-AgentKitChild([string]$Child, [string]$Parent, [bool]$AllowEqual = $false) {
    $fullChild = [System.IO.Path]::GetFullPath($Child).TrimEnd([char[]]@('\','/'))
    $fullParent = [System.IO.Path]::GetFullPath($Parent).TrimEnd([char[]]@('\','/'))
    if ($AllowEqual -and $fullChild.Equals($fullParent, [System.StringComparison]::OrdinalIgnoreCase)) { return }
    $prefix = $fullParent + [System.IO.Path]::DirectorySeparatorChar
    if (-not $fullChild.StartsWith($prefix, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Path is outside allowed directory: $Child"
    }
}

# Historical official Pi guard extension fingerprints. Never overwrite other Pi extensions.
function Get-AgentKitKnownPiExtensionHashes {
    return @(
        'aeeab9a60bb148270ebe633feb4f705328c0cd0366affee9bfd567313f268a61', # v3.3.0
        'aeac0dc8858f85ab4b9284381c75cba2a5a75cf0c406d21f14513b42ccfab92e'  # v3.3.1
    )
}
