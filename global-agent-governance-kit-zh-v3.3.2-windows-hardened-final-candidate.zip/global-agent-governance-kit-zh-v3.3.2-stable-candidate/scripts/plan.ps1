﻿param(
    [ValidateSet('Init','Ready','Check','Step','Finish','Resume','Bind','Repair','Status','List','HookCheck','HookStop')]
    [string]$Action = 'Status',
    [string]$ProjectPath = '.',
    [string]$Task = '',
    [string]$Goal = '',
    [string]$Acceptance = '',
    [string]$StepsText = '',
    [string]$PlanId = '',
    [string]$SessionId = '',
    [string]$Step = '',
    [ValidateSet('Completed','Partial','Blocked')]
    [string]$Result = 'Completed',
    [string]$Evidence = '',
    [string]$Notes = '',
    [switch]$AgentKitManaged
)
$ErrorActionPreference = 'Stop'
# Keep Chinese project/task paths intact when called by CMD, CLI, and hook subprocesses.
try {
    $consoleUtf8 = New-Object System.Text.UTF8Encoding -ArgumentList $false
    [Console]::InputEncoding = $consoleUtf8
    [Console]::OutputEncoding = $consoleUtf8
    $OutputEncoding = $consoleUtf8
} catch {}
. (Join-Path $PSScriptRoot 'agentkit-common.ps1')
$script:KitMutex = $null
$script:TxnActive = $false
$script:TxnData = $null
$utf = New-Object System.Text.UTF8Encoding -ArgumentList @($false, $true)

function Resolve-AgentKitProjectRoot([string]$InputPath) {
    $full = [System.IO.Path]::GetFullPath($InputPath)
    if (-not (Test-Path -LiteralPath $full -PathType Container)) { return $full }
    # Select the nearest Git repository root or nearest already-established plan root.
    # Never walk beyond the current volume's root. An explicit AGENTKIT_PROJECT_ROOT wins.
    if ($env:AGENTKIT_PROJECT_ROOT) {
        $explicit = [System.IO.Path]::GetFullPath($env:AGENTKIT_PROJECT_ROOT)
        Assert-AgentKitChild $full $explicit $true
        return $explicit
    }
    $cursor = $full
    while ($cursor) {
        Assert-AgentKitPlainPath $cursor
        if ((Test-Path -LiteralPath (Join-Path $cursor '.git')) -or
            (Test-Path -LiteralPath (Join-Path $cursor 'docs\plans') -PathType Container)) { return $cursor }
        $parent = [System.IO.Path]::GetDirectoryName($cursor)
        if (-not $parent -or $parent -eq $cursor) { break }
        $cursor = $parent
    }
    return $full
}

function Get-ProjectHash([string]$FullPath) {
    $hash = [System.Security.Cryptography.SHA256]::Create()
    try {
        $bytes = $utf.GetBytes($FullPath.TrimEnd([char[]]@('\','/')).ToLowerInvariant())
        return ([System.BitConverter]::ToString($hash.ComputeHash($bytes))).Replace('-','').ToLowerInvariant().Substring(0,24)
    } finally { $hash.Dispose() }
}
function Safe-TaskSlug([string]$Value) {
    $slug = [regex]::Replace($Value.ToLowerInvariant(), '[^a-z0-9-]+', '-')
    $slug = [regex]::Replace($slug, '-+', '-').Trim('-')
    if (-not $slug) { $slug = 'task' }
    if ($slug.Length -gt 45) { $slug = $slug.Substring(0,45).TrimEnd('-') }
    return $slug
}
# An initialized markdown skeleton is NOT approval to modify project code.
function Assert-PlanReadyContent([string]$Text) {
    foreach ($heading in @('## 目标与完成标准','## 实施步骤','## 执行结果')) {
        if (-not $Text.Contains($heading)) { throw "Plan missing section: $heading" }
    }
    foreach ($label in @('目标','验收标准')) {
        $m = [regex]::Match($Text, '(?m)^- ' + $label + '：([^\r\n]+)')
        if (-not $m.Success -or $m.Groups[1].Value.Trim() -match '^<.*>$|^待(填写|补充|定)|^TODO$') {
            throw "Plan field must contain a concrete value: $label"
        }
    }
    $steps = [regex]::Matches($Text, '(?m)^- \[([ xX])\] ([^\r\n]+)')
    if ($steps.Count -lt 1) { throw 'Plan requires at least one explicit checklist step.' }
    foreach ($stepMatch in $steps) {
        if ($stepMatch.Groups[2].Value.Trim() -match '^<.*>$|^待(填写|补充|定)') { throw 'Plan still contains placeholder steps.' }
    }
}
function Protect-RegexReplacement([string]$Value) {
    # .NET Regex.Replace treats $1 and ${name} as substitution tokens.
    # User-entered paths and evidence must be inserted as text, never regex backreferences.
    return $Value.Replace('$', '$$')
}
function SingleLine([string]$Value, [string]$Name) {
    if ($Value -match '[\r\n]' -or $Value -match '[\x00-\x08\x0b\x0c\x0e-\x1f]') { throw "$Name must be a single printable line." }
    return $Value.Trim()
}
function Set-PlanFields([string]$Text, [string]$NewGoal, [string]$NewAcceptance, [string]$NewSteps) {
    if ($NewGoal) { $Text = [regex]::Replace($Text,'(?m)^- 目标：[^\r\n]*$',(Protect-RegexReplacement ('- 目标：' + (SingleLine $NewGoal '-Goal')))) }
    if ($NewAcceptance) { $Text = [regex]::Replace($Text,'(?m)^- 验收标准：[^\r\n]*$',(Protect-RegexReplacement ('- 验收标准：' + (SingleLine $NewAcceptance '-Acceptance')))) }
    if ($NewSteps) {
        $values = @($NewSteps -split '\|' | ForEach-Object { SingleLine $_ '-StepsText' } | Where-Object { $_ })
        if ($values.Count -lt 1) { throw '-StepsText must include a step.' }
        foreach ($v in $values) { if ($v -match '[\r\n]') { throw 'Multiline steps are not accepted.' } }
        $checklist = ($values | ForEach-Object { '- [ ] ' + $_ }) -join "`r`n"
        $Text = [regex]::Replace($Text, '(?s)(## 实施步骤\s*\r?\n).*?(\r?\n## 执行结果)', ('$1' + (Protect-RegexReplacement $checklist) + '$2'))
    }
    return $Text
}
function Is-PlanDocumentEdit($Event, $Plan) {
    if ($null -eq $Plan) { return $false }
    $name = [string]$Event.tool_name
    $candidate = ''
    if ($name -match '(?i)^(Write|Edit|MultiEdit|NotebookEdit)$') {
        $candidate = [string]$Event.tool_input.file_path
        if (-not $candidate) { $candidate = [string]$Event.tool_input.path }
        if (-not $candidate) { return $false }
    } elseif ($name -eq 'apply_patch') {
        $command = [string]$Event.tool_input.command
        $matches = [regex]::Matches($command, '(?m)^\*\*\* (Update|Add|Delete|Move to) File: (.+)$')
        if ($matches.Count -ne 1 -or $matches[0].Groups[1].Value -ne 'Update') { return $false }
        $candidate = $matches[0].Groups[2].Value.Trim()
    } else { return $false }
    try {
        if (-not [System.IO.Path]::IsPathRooted($candidate)) { $candidate = Join-Path $script:ProjectRoot $candidate }
        $full = [System.IO.Path]::GetFullPath($candidate)
        return $full.Equals([string]$Plan.path, [System.StringComparison]::OrdinalIgnoreCase)
    } catch { return $false }
}

function Load-Index {
    if (-not (Test-Path -LiteralPath $script:IndexPath -PathType Leaf)) {
        return [pscustomobject]@{ schema=1; project=$script:ProjectRoot; tasks=@(); bindings=([pscustomobject]@{}) }
    }
    Assert-AgentKitPlainPath $script:IndexPath
    $index = [System.IO.File]::ReadAllText($script:IndexPath, $utf) | ConvertFrom-Json
    if ([string]$index.project -ne $script:ProjectRoot -or [int]$index.schema -ne 1) { throw 'Invalid plan index: project or schema mismatch.' }
    if (-not $index.PSObject.Properties['bindings']) { $index | Add-Member -NotePropertyName bindings -NotePropertyValue ([pscustomobject]@{}) }
    return $index
}
# The plan document and index cannot be atomically replaced as one file. A guarded,
# persisted undo journal permits crash recovery; all operations hold the project mutex.
function Get-BytesOrNull([string]$Path) {
    if (Test-Path -LiteralPath $Path -PathType Leaf) {
        Assert-AgentKitPlainPath $Path
        return ,([System.IO.File]::ReadAllBytes($Path))
    }
    if (Test-Path -LiteralPath $Path) { throw "Expected file at $Path" }
    return $null
}
function Get-ByteHash([byte[]]$Bytes) {
    if ($null -eq $Bytes) { return 'ABSENT' }
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try { return ([System.BitConverter]::ToString($sha.ComputeHash($Bytes))).Replace('-','').ToLowerInvariant() }
    finally { $sha.Dispose() }
}
function Save-TxnJournal {
    Assert-AgentKitPlainPath $script:JournalPath
    Write-AgentKitAtomicText $script:JournalPath (ConvertTo-Json -InputObject $script:TxnData -Depth 8)
}
function Begin-PlanTransaction([string]$DocumentPath) {
    if ($script:TxnActive) { throw 'A plan transaction is already active.' }
    Assert-AgentKitChild $DocumentPath $script:PlanRoot
    Assert-AgentKitPlainPath $DocumentPath
    if (Test-Path -LiteralPath $script:JournalPath) { throw 'Pending plan transaction requires Repair before a new modification.' }
    $oldDoc = Get-BytesOrNull $DocumentPath
    $oldIndex = Get-BytesOrNull $script:IndexPath
    $script:TxnData = [pscustomobject]@{
        schema=1; project=$script:ProjectRoot; phase='prepared';
        doc_path=[System.IO.Path]::GetFullPath($DocumentPath);
        doc_before=$(if ($null -eq $oldDoc) { $null } else { [System.Convert]::ToBase64String($oldDoc) });
        doc_oldhash=(Get-ByteHash $oldDoc); doc_newhash='';
        index_before=$(if ($null -eq $oldIndex) { $null } else { [System.Convert]::ToBase64String($oldIndex) });
        index_oldhash=(Get-ByteHash $oldIndex); index_newhash=''
    }
    Save-TxnJournal
    $script:TxnActive = $true
}
function Set-TxnExpected([string]$Kind, [byte[]]$Bytes) {
    if (-not $script:TxnActive) { return }
    if ($Kind -eq 'doc') { $script:TxnData.doc_newhash = Get-ByteHash $Bytes }
    elseif ($Kind -eq 'index') { $script:TxnData.index_newhash = Get-ByteHash $Bytes }
    else { throw 'Unexpected transaction file type.' }
    # Journal the intended content hash BEFORE the actual file replacement.
    Save-TxnJournal
}
function Write-PlanDocument([string]$Path, [string]$Content) {
    Set-TxnExpected 'doc' ($utf.GetBytes($Content))
    Write-AgentKitAtomicText $Path $Content
}
function Recover-PlanTransaction {
    if (-not (Test-Path -LiteralPath $script:JournalPath -PathType Leaf)) { return }
    Assert-AgentKitPlainPath $script:JournalPath
    $pending = [System.IO.File]::ReadAllText($script:JournalPath,$utf) | ConvertFrom-Json
    if ([int]$pending.schema -ne 1 -or [string]$pending.project -ne $script:ProjectRoot) { throw 'Unrecognized or cross-project transaction journal.' }
    $doc = [System.IO.Path]::GetFullPath([string]$pending.doc_path)
    Assert-AgentKitChild $doc $script:PlanRoot
    Assert-AgentKitPlainPath $doc
    Assert-AgentKitPlainPath $script:IndexPath
    if ([string]$pending.phase -eq 'committed') {
        Remove-Item -LiteralPath $script:JournalPath -Force
        return
    }
    if ([string]$pending.phase -ne 'prepared') { throw 'Unknown transaction phase; refusing repair.' }
    # If a user changed either file after the interrupted operation, fail closed and
    # preserve the journal instead of silently overwriting unrelated edits.
    foreach ($part in @(
        [pscustomobject]@{ path=$doc; oldhash=[string]$pending.doc_oldhash; newhash=[string]$pending.doc_newhash; old=$pending.doc_before },
        [pscustomobject]@{ path=$script:IndexPath; oldhash=[string]$pending.index_oldhash; newhash=[string]$pending.index_newhash; old=$pending.index_before }
    )) {
        $actualHash = Get-ByteHash (Get-BytesOrNull $part.path)
        if ($actualHash -ne $part.oldhash -and $actualHash -ne $part.newhash) {
            throw "Recovery conflict; preserve current file and inspect journal: $($part.path)"
        }
    }
    foreach ($part in @(
        [pscustomobject]@{ path=$doc; old=$pending.doc_before },
        [pscustomobject]@{ path=$script:IndexPath; old=$pending.index_before }
    )) {
        if ($null -eq $part.old) {
            if (Test-Path -LiteralPath $part.path -PathType Leaf) { Remove-Item -LiteralPath $part.path -Force }
        } else {
            Write-AgentKitAtomicBytes $part.path ([System.Convert]::FromBase64String([string]$part.old))
        }
    }
    Remove-Item -LiteralPath $script:JournalPath -Force
    Write-Warning 'AgentKit recovered an interrupted plan transaction from the undo journal.'
}
function Commit-PlanTransaction {
    if (-not $script:TxnActive) { throw 'No active plan transaction.' }
    $script:TxnData.phase = 'committed'
    Save-TxnJournal
    $script:TxnActive = $false
    try { Remove-Item -LiteralPath $script:JournalPath -Force }
    catch { Write-Warning 'Committed transaction journal is retained until next invocation.' }
}

function Save-Index($Index) {
    [void][System.IO.Directory]::CreateDirectory((Split-Path -Parent $script:IndexPath))
    $body = ConvertTo-Json -InputObject $Index -Depth 9
    Set-TxnExpected 'index' ($utf.GetBytes($body))
    Write-AgentKitAtomicText $script:IndexPath $body
}
function Get-Plan($Index, [string]$Id, [string]$Session, [bool]$NeedActive = $true) {
    $items = @($Index.tasks)
    if ($Id) { $items = @($items | Where-Object { [string]$_.id -eq $Id }) }
    elseif ($Session) {
        $selected = $Index.bindings.PSObject.Properties[$Session]
        if ($selected) {
            $items = @($items | Where-Object { [string]$_.id -eq [string]$selected.Value })
        } else {
        $matched = @($items | Where-Object { [string]$_.session_id -eq $Session -and [string]$_.status -eq 'active' })
        if ($matched.Count -gt 0) { $items = $matched }
        else {
            # An unscoped manually created plan may be used only if it is the sole active plan.
            # Never borrow a different session's active plan to authorize a mutating hook.
            $active = @($items | Where-Object { [string]$_.status -eq 'active' })
            if ($active.Count -eq 1 -and -not [string]$active[0].session_id) { $items = $active }
            else { $items = @() }
        }
        }
    } else { $items = @($items | Where-Object { [string]$_.status -eq 'active' }) }
    if ($NeedActive) { $items = @($items | Where-Object { [string]$_.status -eq 'active' }) }
    if ($items.Count -ne 1) { throw "Expected one matching plan, found $($items.Count). Supply -PlanId (and optionally -SessionId)." }
    $plan = $items[0]
    if ($Session -and $plan.session_id -and [string]$plan.session_id -ne $Session) { throw 'Plan belongs to a different agent session.' }
    $path = [System.IO.Path]::GetFullPath([string]$plan.path)
    Assert-AgentKitChild $path $script:PlanRoot
    Assert-AgentKitPlainPath $path
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "Plan document missing: $path" }
    $text = [System.IO.File]::ReadAllText($path, $utf)
    $rx = '^<!-- AGENTKIT:PLAN id=' + [regex]::Escape([string]$plan.id) + ' status=' + [regex]::Escape([string]$plan.status) + ' .*? -->'
    if (-not [regex]::IsMatch($text,$rx)) { throw "Plan document marker does not agree with index: $path" }
    return $plan
}
function Write-PlanChange($Plan, [string]$NewStatus, [string]$Message, [string]$WorkingDocument = $null) {
    $path = [string]$Plan.path
    $text = if ($null -ne $WorkingDocument) { $WorkingDocument } else { [System.IO.File]::ReadAllText($path, $utf) }
    $newMarker = '<!-- AGENTKIT:PLAN id=' + $Plan.id + ' status=' + $NewStatus + ' updated=' + (Get-Date).ToUniversalTime().ToString('o') + ' -->'
    $text = [regex]::Replace($text, '\A<!-- AGENTKIT:PLAN .*? -->', $newMarker)
    $localizedStatus = switch ($NewStatus) {
        'active' { '进行中' }
        'completed' { '已完成' }
        'partial' { '部分完成' }
        'blocked' { '受阻' }
        default { $NewStatus }
    }
    $text = [regex]::Replace($text, '(?m)^- 状态：[^\r\n]*$', ('- 状态：' + $localizedStatus))
    if ($NewStatus -ne 'active') {
        $text = [regex]::Replace($text, '(?m)^- 最终状态：[^\r\n]*$', ('- 最终状态：' + $localizedStatus))
    }
    $log = "`r`n`r`n### " + (Get-Date).ToString('yyyy-MM-dd HH:mm:ss') + "`r`n" + $Message + "`r`n"
    if (-not $text.Contains('## AgentKit 执行记录') -and -not $text.Contains('## AgentKit execution log')) { $text += "`r`n## AgentKit 执行记录`r`n" }
    $text += $log
    Write-PlanDocument $path $text
    $Plan.status = $NewStatus
    $Plan.updated_at = (Get-Date).ToUniversalTime().ToString('o')
}
function Read-HookEvent {
    $inputText = [Console]::In.ReadToEnd()
    if ([string]::IsNullOrWhiteSpace($inputText)) { return $null }
    try { return ($inputText | ConvertFrom-Json) }
    catch { throw 'Malformed hook event JSON.' }
}
function Is-MutatingHook($Event) {
    $name = [string]$Event.tool_name
    # Pure host-level read APIs only. Do NOT exempt arbitrary MCP functions by read/list prefixes:
    # providers may implement writes or side-effects under misleading action names.
    if ($name -match '(?i)^(Read|Glob|Grep|WebSearch|WebFetch|web_search|web_fetch)$') { return $false }
    # Every Shell invocation is guarded unless it is a single direct AgentKit plan management
    # invocation (Init/Ready/Resume/Bind/Repair). No generic git/find/ls read exemptions.
    # This prevents e.g. `find . -delete` and `git diff --output=...` from bypassing a plan.
    $cmd = [string]$Event.tool_input.command
    if (-not $cmd) { $cmd = [string]$Event.tool_input.cmd }
    if (-not $cmd) { $cmd = [string]$Event.tool_input.script }
    if ($name -match '(?i)^(Bash|shell|exec|exec_command|command|powershell|process)$') {
        if ([string]::IsNullOrWhiteSpace($cmd)) { return $true }
        # Remove quoted literals for separator detection while keeping the original string
        # for action inspection. Reject PowerShell interpolation, backticks and line breaks.
        $withoutQuotes = [regex]::Replace($cmd, '"(?:`.|[^"`])*"|''(?:''''|[^''])*''', '""')
        $singleCommand = ($withoutQuotes -notmatch '[;&|><`\r\n]' -and $cmd -notmatch '\$\(|`|\r|\n|\b(?:Invoke-Expression|iex|Start-Process)\b')
        $planAction = $cmd -match '(?i)-Action\s+(?:Init|Ready|Resume|Bind|Repair)\b'
        $direct = $cmd -match '(?i)^\s*(?:"[^"\r\n]*plan\.(?:ps1|cmd)"|[^\s"'';|&]*plan\.(?:ps1|cmd))\s+'
        $viaPowerShell = $cmd -match '(?i)^\s*(?:"[^"\r\n]*powershell(?:\.exe)?"|[^\s"'';|&]*powershell(?:\.exe)?)\s+.*?-File\s+(?:"[^"\r\n]*plan\.ps1"|[^\s"'';|&]*plan\.ps1)(?:\s|$)'
        if ($singleCommand -and $planAction -and ($direct -or $viaPowerShell)) { return $false }
    }
    return $true
}

try {
    if (-not $SessionId -and $env:AGENTKIT_SESSION_ID) { $SessionId = $env:AGENTKIT_SESSION_ID }
    if ($Action -eq 'HookCheck' -or $Action -eq 'HookStop') {
        $event = Read-HookEvent
        if ($null -eq $event) { throw 'Missing hook event.' }
        if ($event.cwd) { $ProjectPath = [string]$event.cwd }
        if (-not $SessionId -and $event.session_id) { $SessionId = [string]$event.session_id }
        if (-not $PlanId -and $event.plan_id) { $PlanId = [string]$event.plan_id }
        if ($Action -eq 'HookCheck' -and -not (Is-MutatingHook $event)) { Write-Output '{}'; exit 0 }
    }
    if (-not $PlanId -and $env:AGENTKIT_PLAN_ID) { $PlanId = [string]$env:AGENTKIT_PLAN_ID }
    $script:ProjectRoot = Resolve-AgentKitProjectRoot $ProjectPath
    if (-not (Test-Path -LiteralPath $script:ProjectRoot -PathType Container)) { throw "Project root not found: $script:ProjectRoot" }
    Assert-AgentKitPlainPath $script:ProjectRoot
    $script:PlanRoot = Join-Path $script:ProjectRoot 'docs\plans'
    $base = [Environment]::GetFolderPath('LocalApplicationData')
    if (-not $base) { $base = Join-Path ([Environment]::GetFolderPath('UserProfile')) 'AppData\Local' }
    $idHash = Get-ProjectHash $script:ProjectRoot
    $script:IndexPath = Join-Path $base ('AgentKit\plan-state\' + $idHash + '.json')
    $script:JournalPath = Join-Path $base ('AgentKit\plan-state\transactions\' + $idHash + '.json')
    $script:KitMutex = Enter-AgentKitMutex ('plan-' + $idHash) 12000
    Recover-PlanTransaction
    $index = Load-Index

    switch ($Action) {
        'Init' {
            if ([string]::IsNullOrWhiteSpace($Task)) { throw '-Task is required for Init.' }
            $Task = SingleLine $Task '-Task'
            $date = (Get-Date).ToString('yyyy-MM-dd')
            $newId = [guid]::NewGuid().ToString('N').Substring(0,12)
            # Validate every existing ancestor before creating docs/plans, not after following a junction.
            Assert-AgentKitPlainPath $script:PlanRoot
            [void][System.IO.Directory]::CreateDirectory($script:PlanRoot)
            Assert-AgentKitPlainPath $script:PlanRoot
            $docPath = Join-Path $script:PlanRoot ($date + '-' + (Safe-TaskSlug $Task) + '-' + $newId + '.md')
            $templatePath = Join-Path $PSScriptRoot 'EXECUTION_PLAN.md'
            if (-not (Test-Path -LiteralPath $templatePath -PathType Leaf)) {
                $templatePath = Join-Path (Split-Path -Parent $PSScriptRoot) 'templates\EXECUTION_PLAN.md'
            }
            $body = if (Test-Path -LiteralPath $templatePath -PathType Leaf) {
                [System.IO.File]::ReadAllText($templatePath, $utf)
            } else { '# Execution plan: <task>' + "`r`n`r`n- Status: active`r`n" }
            $pendingWord = [string][char]0x672a + [char]0x5f00 + [char]0x59cb
            $body = [regex]::Replace($body, '(?m)^- [^\r\n]*' + [regex]::Escape($pendingWord) + '[^\r\n]*$', '- 状态：进行中')
            $body = $body.Replace('<task>', $Task).Replace('<task-name>', $Task).Replace('<YYYY-MM-DD>', $date)
            $body = $body.Replace('<task-slug>', (Safe-TaskSlug $Task))
            $body = Set-PlanFields $body $Goal $Acceptance $StepsText
            $ready = $false
            if ($Goal -and $Acceptance -and $StepsText) { Assert-PlanReadyContent $body; $ready = $true }
            $body = $body.Replace('<' + [char]0x4efb + [char]0x52a1 + [char]0x540d + [char]0x79f0 + '>', $Task)
            $marker = '<!-- AGENTKIT:PLAN id=' + $newId + ' status=active updated=' + (Get-Date).ToUniversalTime().ToString('o') + ' -->'
            $doc = $marker + "`r`n" + $body.TrimStart([char[]]@([char]13,[char]10))
            $data = $utf.GetBytes($doc)
            Begin-PlanTransaction $docPath
            Set-TxnExpected 'doc' $data
            # Create the new document through the same-volume atomic writer. Never leave a
            # partially written plan when a process is killed during initial creation.
            if (Test-Path -LiteralPath $docPath) { throw 'Generated plan file unexpectedly already exists.' }
            Write-AgentKitAtomicBytes $docPath $data
            $record = [pscustomobject]@{ id=$newId; task=$Task; path=$docPath; status='active'; ready=$ready; session_id=$SessionId; created_at=(Get-Date).ToUniversalTime().ToString('o'); updated_at=(Get-Date).ToUniversalTime().ToString('o') }
            $index.tasks = @($index.tasks) + @($record)
            Save-Index $index
            Commit-PlanTransaction
            Write-Host "PLAN_CREATED id=$newId ready=$ready path=$docPath"
            if (-not $ready) { Write-Host 'PLAN_DRAFT: edit the plan and run -Action Ready before changing project code.' }
            break
        }
        'Bind' {
            if (-not $PlanId -or -not $SessionId) { throw 'Bind requires both -PlanId and -SessionId.' }
            $p = Get-Plan $index $PlanId $SessionId $true
            if (-not $p.ready) { throw 'Only ready plans may be bound to active sessions.' }
            if (-not [string]$p.session_id) { $p.session_id = $SessionId }
            $index.bindings | Add-Member -NotePropertyName $SessionId -NotePropertyValue $PlanId -Force
            Save-Index $index
            Write-Host "PLAN_BOUND session=$SessionId id=$PlanId"
            break
        }
        'Repair' {
            Write-Host 'PLAN_REPAIR_OK: no pending transaction (recovered if necessary).'
            break
        }
        'List' {
            foreach ($item in @($index.tasks)) { Write-Host ("{0} [{1}; ready={2}] {3} {4}" -f $item.id,$item.status,$item.ready,$item.task,$item.path) }
            break
        }
        'Status' {
            foreach ($item in @($index.tasks | Where-Object { -not $PlanId -or $_.id -eq $PlanId })) {
                Write-Host ("{0} [{1}; ready={2}] {3} {4}" -f $item.id,$item.status,$item.ready,$item.task,$item.path)
            }
            break
        }
        'Ready' {
            $p = Get-Plan $index $PlanId $SessionId $true
            $content = [System.IO.File]::ReadAllText([string]$p.path, $utf)
            $new = Set-PlanFields $content $Goal $Acceptance $StepsText
            Assert-PlanReadyContent $new
            Begin-PlanTransaction ([string]$p.path)
            if ($new -cne $content) { Write-PlanDocument ([string]$p.path) $new }
            if (-not $p.PSObject.Properties['ready']) { $p | Add-Member -NotePropertyName ready -NotePropertyValue $true }
            else { $p.ready = $true }
            $p.updated_at = (Get-Date).ToUniversalTime().ToString('o')
            Save-Index $index
            Commit-PlanTransaction
            Write-Host "PLAN_READY id=$($p.id) path=$($p.path)"
            break
        }
        'Check' {
            $p = Get-Plan $index $PlanId $SessionId $true
            if (-not $p.ready) { throw 'Plan draft is not ready. Fill goals, acceptance, steps and use -Action Ready.' }
            Assert-PlanReadyContent ([System.IO.File]::ReadAllText([string]$p.path, $utf))
            Write-Host "PLAN_OK id=$($p.id) path=$($p.path)"
            break
        }
        'Resume' {
            $p = Get-Plan $index $PlanId $SessionId $false
            if ($p.status -eq 'completed') { throw 'Completed plans cannot be resumed; create a new task.' }
            Begin-PlanTransaction ([string]$p.path)
            Write-PlanChange $p 'active' ("- 重新继续执行。" + $Notes)
            Save-Index $index
            Commit-PlanTransaction
            Write-Host "PLAN_RESUMED id=$($p.id) path=$($p.path)"
            break
        }
        'Step' {
            if (-not $Step) { throw '-Step is required for Step.' }
            $Step = SingleLine $Step '-Step'
            $p = Get-Plan $index $PlanId $SessionId $true
            if (-not $p.ready) { throw 'Plan must be Ready before checking off steps.' }
            $doc = [System.IO.File]::ReadAllText([string]$p.path, $utf)
            $pattern = '(?m)^- \[ \] ' + [regex]::Escape($Step.Trim()) + '[ \t]*$'
            if ([regex]::Matches($doc,$pattern).Count -ne 1) { throw 'Exactly one unchecked matching step is required.' }
            $doc = [regex]::Replace($doc,$pattern,(Protect-RegexReplacement ('- [x] ' + $Step.Trim())))
            Begin-PlanTransaction ([string]$p.path)
            Write-PlanChange $p 'active' ('- 已完成步骤：' + $Step + "`r`n- 备注：" + $Notes) $doc
            Save-Index $index
            Commit-PlanTransaction
            Write-Host "PLAN_UPDATED id=$($p.id) path=$($p.path)"
            break
        }
        'Finish' {
            $p = Get-Plan $index $PlanId $SessionId $true
            $doc = [System.IO.File]::ReadAllText([string]$p.path, $utf)
            if ($Result -eq 'Completed') {
                if (-not $p.ready) { throw 'A draft plan cannot be marked Completed.' }
                Assert-PlanReadyContent $doc
                if ([regex]::IsMatch($doc,'(?m)^- \[ \] ')) { throw 'Unchecked plan steps remain. Finish them or report Partial/Blocked.' }
                if (-not [regex]::IsMatch($doc,'(?m)^- \[([xX])\] ')) { throw 'No completed plan steps were recorded.' }
                if ([string]::IsNullOrWhiteSpace($Evidence) -or $Evidence.Trim().Length -lt 8 -or $Evidence -match '(?i)^(ok|pass|done|todo|待验证|未运行)$') {
                    throw 'Completed plans require -Evidence with a substantive, operator-provided validation result.'
                }
            }
            $deliverable = if ($Notes) { SingleLine $Notes '-Notes' } else { '详见已勾选步骤及执行记录' }
            $testResult = if ($Evidence) { SingleLine $Evidence '-Evidence' } else { '未运行（未宣称完成）' }
            $risk = if ($Result -eq 'Completed') { '无已知遗留项（操作者声明）' } elseif ($Notes) { SingleLine $Notes '-Notes' } else { '待处理：详见执行记录' }
            $doc = [regex]::Replace($doc,'(?m)^- 完成项/产物：[^\r\n]*$',(Protect-RegexReplacement ('- 完成项/产物：' + $deliverable)))
            $doc = [regex]::Replace($doc,'(?m)^- 步骤状态：[^\r\n]*$',('- 步骤状态：' + $(if ($Result -eq 'Completed') { '已勾选计划全部步骤' } else { '部分步骤未完成或受阻' })))
            $doc = [regex]::Replace($doc,'(?m)^- 验证及结果：[^\r\n]*$',(Protect-RegexReplacement ('- 验证及结果：' + $testResult)))
            $doc = [regex]::Replace($doc,'(?m)^- 未完成项、风险、下一步：[^\r\n]*$',(Protect-RegexReplacement ('- 未完成项、风险、下一步：' + $risk)))
            $newStatus = $Result.ToLowerInvariant()
            Begin-PlanTransaction ([string]$p.path)
            Write-PlanChange $p $newStatus ('- 最终状态：' + $Result + "`r`n- 验证证据（由操作者提供）：" + $testResult + "`r`n- 遗留事项/风险：" + $risk) $doc
            Save-Index $index
            Commit-PlanTransaction
            Write-Host "PLAN_FINISHED id=$($p.id) status=$newStatus path=$($p.path)"
            break
        }
        'HookCheck' {
            try {
                $p = Get-Plan $index $PlanId $SessionId $true
                if (-not $p.ready) {
                    if (Is-PlanDocumentEdit $event $p) { Write-Output '{}'; break }
                    throw 'Draft plan must be filled and marked Ready before changing project files.'
                }
                Assert-PlanReadyContent ([System.IO.File]::ReadAllText([string]$p.path, $utf))
                Write-Output '{}'
            } catch { [Console]::Error.WriteLine('AgentKit: initialize and ready a plan before changing files. ' + $_.Exception.Message); exit 2 }
            break
        }
        'HookStop' {
            $active = @($index.tasks | Where-Object { $_.status -eq 'active' -and (-not $SessionId -or $_.session_id -eq $SessionId -or -not $_.session_id) })
            # Stop must report every unfinished plan, including ambiguous same-session plans.
            if ($active.Count -gt 0) {
                $names = @($active | ForEach-Object { [string]$_.id + ':' + [string]$_.path }) -join '; '
                [Console]::Error.WriteLine('AgentKit: finish or explicitly mark Partial/Blocked every active plan before ending: ' + $names)
                exit 2
            }
            Write-Output '{}'
            break
        }
    }
} catch {
    $failure = $_.Exception.Message
    if ($script:TxnActive) {
        try { Recover-PlanTransaction; $script:TxnActive = $false }
        catch { $failure += '; recovery failed: ' + $_.Exception.Message }
    }
    [Console]::Error.WriteLine('AGENTKIT_PLAN_ERROR: ' + $failure)
    exit 2
} finally {
    Exit-AgentKitMutex $script:KitMutex
}
