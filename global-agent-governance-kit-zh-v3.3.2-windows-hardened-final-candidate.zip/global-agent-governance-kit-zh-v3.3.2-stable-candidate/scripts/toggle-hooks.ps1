﻿param(
    [ValidateSet('Enable','Disable')][string]$Mode = 'Enable',
    [ValidateSet('All','Pi','Codex','Claude')][string]$Platform = 'All',
    [switch]$ReplaceCustomized
)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'agentkit-common.ps1')
$script:AgentKitMutex = $null
$Utf8 = New-Object System.Text.UTF8Encoding -ArgumentList @($false, $true)
$HomeDir = [Environment]::GetFolderPath('UserProfile')
$AppData = [Environment]::GetFolderPath('LocalApplicationData')
if (-not $AppData) { $AppData = Join-Path $HomeDir 'AppData\Local' }
$KitDataRoot = Join-Path $AppData 'AgentKit'
$StatePath = Join-Path $KitDataRoot 'state.json'
$HookStatePath = Join-Path $KitDataRoot 'hook-state.json'
$RunId = (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [guid]::NewGuid().ToString('N').Substring(0,8)
$BackupRoot = Join-Path $KitDataRoot ('hook-backups\' + $RunId)
$script:Changed = @()

function Resolve-PlatformRoot([string]$Name) {
    if (-not (Test-Path -LiteralPath $StatePath -PathType Leaf)) { throw 'AgentKit is not installed; run install-all.cmd first.' }
    $state = ([System.IO.File]::ReadAllText($StatePath, $Utf8)) | ConvertFrom-Json
    if ($state.roots) {
        $value = [string]$state.roots.$Name
        if ($value) { return [System.IO.Path]::GetFullPath($value) }
    }
    switch ($Name) {
        'Pi' { return $(if ($env:PI_CODING_AGENT_DIR) { $env:PI_CODING_AGENT_DIR } else { Join-Path $HomeDir '.pi\agent' }) }
        'Codex' { return $(if ($env:CODEX_HOME) { $env:CODEX_HOME } else { Join-Path $HomeDir '.codex' }) }
        'Claude' { return $(if ($env:CLAUDE_CONFIG_DIR) { $env:CLAUDE_CONFIG_DIR } else { Join-Path $HomeDir '.claude' }) }
    }
}
function Stage-Backup([string]$Path) {
    Assert-AgentKitPlainPath $Path
    $entry = [pscustomobject]@{ path=$Path; existed=[bool](Test-Path -LiteralPath $Path -PathType Leaf); copy=$null }
    if ($entry.existed) {
        [void][System.IO.Directory]::CreateDirectory($BackupRoot)
        $copy = Join-Path $BackupRoot ([guid]::NewGuid().ToString('N') + '.bak')
        [System.IO.File]::Copy($Path, $copy)
        $entry.copy = $copy
    }
    $script:Changed += $entry
}
function Rollback-HookChanges {
    for ($i = $script:Changed.Count - 1; $i -ge 0; $i--) {
        $entry = $script:Changed[$i]
        try {
            if ($entry.existed) { Write-AgentKitAtomicBytes $entry.path ([System.IO.File]::ReadAllBytes($entry.copy)) }
            elseif (Test-Path -LiteralPath $entry.path -PathType Leaf) { Remove-Item -LiteralPath $entry.path -Force }
        } catch { Write-Warning "Hook rollback failed: $($entry.path) $($_.Exception.Message)" }
    }
}
function Configure-Hooks([string]$Name, [string]$Root) {
    $settingsPath = if ($Name -eq 'Codex') { Join-Path $Root 'hooks.json' } else { Join-Path $Root 'settings.json' }
    if ($Mode -eq 'Disable' -and -not (Test-Path -LiteralPath $settingsPath -PathType Leaf)) { return }
    $settings = if (Test-Path -LiteralPath $settingsPath -PathType Leaf) {
        [System.IO.File]::ReadAllText($settingsPath, $Utf8) | ConvertFrom-Json
    } else { [pscustomobject]@{} }
    if ($null -eq $settings) { throw "Empty settings: $settingsPath" }
    if (-not $settings.PSObject.Properties['hooks']) { $settings | Add-Member -NotePropertyName hooks -NotePropertyValue ([pscustomobject]@{}) }
    if (-not $settings.hooks) { $settings.hooks = [pscustomobject]@{} }
    $configuredChanges = 0
    foreach ($eventName in @('PreToolUse','Stop')) {
        $otherGroups = @()
        $oldGroups = @($settings.hooks.$eventName | Where-Object { $null -ne $_ })
        foreach ($group in $oldGroups) {
            if (-not $group.PSObject.Properties['hooks']) { throw "Unrecognized hook group format in $settingsPath; refusing to overwrite." }
            # Remove only our explicit plan hook. Other hooks are owned by the user.
            $otherHandlers = @($group.hooks | Where-Object {
                $command = [string]$_.command
                -not ($command -match '(?i)AgentKit[\\/]+bin[\\/]+plan\.ps1.*-Action\s+(HookCheck|HookStop)\b' -and $command -match '-AgentKitManaged')
            })
            if ($otherHandlers.Count -gt 0) {
                $group.hooks = $otherHandlers
                $otherGroups += $group
            }
        }
        if ($Mode -eq 'Enable') {
            $cmd = '"' + (Join-Path $KitDataRoot 'bin\plan.ps1') + '"'
            $systemExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
            # Codex versions on Windows have failed to invoke hooks whose program token is quoted.
            # A fixed, quote-free system executable prevents that silent no-op. Never resolve via PATH.
            if ($Name -eq 'Codex') {
                if ($systemExe -match '[\s"]') { throw 'Codex hook cannot safely launch a quoted SystemRoot PowerShell path; manual host validation required.' }
                $psExe = $systemExe
            } else { $psExe = '"' + $systemExe + '"' }
            $prefix = $psExe + ' -NoProfile -NonInteractive -ExecutionPolicy Bypass -File ' + $cmd
            $action = if ($eventName -eq 'PreToolUse') { 'HookCheck' } else { 'HookStop' }
            $handler = [pscustomobject]@{ type='command'; command=($prefix + ' -Action ' + $action + ' -AgentKitManaged'); timeout=12 }
            if ($Name -eq 'Codex') { $handler | Add-Member -NotePropertyName commandWindows -NotePropertyValue $handler.command }
            $group = [pscustomobject]@{
                matcher = if ($eventName -eq 'PreToolUse') { $(if ($Name -eq 'Codex') { '.*' } else { '*' }) } else { '' }
                hooks = @($handler)
            }
            $otherGroups += $group
        }
        if ($settings.hooks.PSObject.Properties[$eventName]) { $settings.hooks.$eventName = $otherGroups }
        else { $settings.hooks | Add-Member -NotePropertyName $eventName -NotePropertyValue $otherGroups }
    }
    Stage-Backup $settingsPath
    Write-AgentKitAtomicText $settingsPath (ConvertTo-Json -InputObject $settings -Depth 35)
    Write-Host "$Mode hooks: $settingsPath (configured; host trust and execution not yet verified)"
}
function Configure-Pi([string]$Root) {
    $target = Join-Path $Root 'extensions\agentkit-plan-guard.ts'
    if ($Mode -eq 'Enable') {
        $source = Join-Path $KitDataRoot 'bin\agentkit-plan-guard.ts'
        if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw 'Missing installed Pi extension template.' }
        if (Test-Path -LiteralPath $target -PathType Leaf) {
            $expected = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
            $current = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash
            $known = @(Get-AgentKitKnownPiExtensionHashes)
            if ($current -ne $expected -and $known -notcontains $current.ToLowerInvariant() -and -not $ReplaceCustomized) {
                throw "Pi extension is locally customized; refusing overwrite: $target"
            }
        }
        Stage-Backup $target
        Write-AgentKitAtomicBytes $target ([System.IO.File]::ReadAllBytes($source))
    } elseif (Test-Path -LiteralPath $target -PathType Leaf) {
        $source = Join-Path $KitDataRoot 'bin\agentkit-plan-guard.ts'
        $hash = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant()
        $expected = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($hash -ne $expected -and @(Get-AgentKitKnownPiExtensionHashes) -notcontains $hash) {
            throw "Refusing to delete locally customized Pi extension: $target"
        }
        Stage-Backup $target
        Remove-Item -LiteralPath $target -Force
    }
    Write-Host "$Mode Pi extension: $target"
}
try {
    $script:AgentKitMutex = Enter-AgentKitMutex 'install-restore'
    if ($Mode -eq 'Enable' -and -not (Test-Path -LiteralPath (Join-Path $KitDataRoot 'bin\plan.ps1') -PathType Leaf)) {
        throw 'The plan CLI is not installed. Run install-all.cmd first.'
    }
    $platforms = if ($Platform -eq 'All') { @('Pi','Codex','Claude') } else { @($Platform) }
    foreach ($name in $platforms) {
        $root = Resolve-PlatformRoot $name
        Assert-AgentKitPlainPath $root
        if ($name -eq 'Pi') { Configure-Pi $root } else { Configure-Hooks $name $root }
    }
    $installed = @()
    if (Test-Path -LiteralPath $HookStatePath -PathType Leaf) {
        $rawState = ([System.IO.File]::ReadAllText($HookStatePath, $Utf8)) | ConvertFrom-Json
        $installed = @($rawState.platforms)
    }
    if ($Mode -eq 'Enable') { $installed = @($installed + $platforms | Select-Object -Unique) }
    else { $installed = @($installed | Where-Object { $platforms -notcontains $_ }) }
    Stage-Backup $HookStatePath
    Write-AgentKitAtomicText $HookStatePath (ConvertTo-Json -InputObject ([pscustomobject]@{ platforms=$installed; updated_at=(Get-Date).ToString('o') }) -Depth 3)
    Write-Host "Hook $Mode configuration completed. Host activation NOT verified; run doctor.cmd and the real-host probe. Backups: $BackupRoot"
} catch {
    Rollback-HookChanges
    [Console]::Error.WriteLine('Hook configuration failed: ' + $_.Exception.Message)
    exit 1
} finally {
    Exit-AgentKitMutex $script:AgentKitMutex
}
