# 全局 Agent 治理套件：中文 Windows Hardened v3.3.2（稳定候选）

这是面向 Windows 10/11 的全局 Agent 治理包，统一 Pi、Codex、Claude Code 的默认工作方式。

**v3.3.2 稳定候选修复版**：在 v3.1.4 计划优先规则基础上新增恢复目标白名单、事务互斥、原子文件替换、升级冲突检测、计划 CLI、平台可选 Hooks、预览与源规则自动生成。保留 7 个原有 Skills。

## v3.3.2 新增稳定性修复与 Windows 兼容说明

- **修复验证矛盾**：安装默认保留旧 `.agent-global` / 旧备份目录，`verify.ps1` 将其正确标为 `PRESERVED` 而非失败。显式迁移必须先核对归属，再同时指定 `-MigrateLegacy -ConfirmLegacyOwnership`。
- **Shell Hook 默认拒绝无计划执行**：仅 `Read/Glob/Grep` 等原生只读工具可直接通过；`find -delete`、`git diff --output`、MCP 未知工具以及普通 Shell（**包括 `git status`**）都必须先有 Ready 计划。这样更保守，但避免“看似只读”的命令带有写入副作用。首次创建/准备/恢复/绑定/修复计划的单条可信命令允许执行；含管道/重定向等组合命令不豁免。
- **多任务绑定**：同一会话存在多个活动计划时执行 `plan.cmd -Action Bind -ProjectPath "D:\Code\MyProject" -SessionId "<session-id>" -PlanId "<id>"`，或设置 `AGENTKIT_PLAN_ID`；完成一个计划后，重新绑定另一个，不会隐式借用其他会话计划。
- **状态恢复**：计划 Markdown 与 JSON 索引以同项目互斥锁和预写式撤销日志保护；调用时自动检测未完成事务，`plan.cmd -Action Repair -ProjectPath "D:\Code\MyProject"` 触发恢复。有外部写入冲突时**拒绝覆盖**并保留日志；首次创建计划也使用同卷原子落盘。支持从项目子目录查找最近的 Git/已有计划根目录，必要时设置 `AGENTKIT_PROJECT_ROOT`。
- **可信旧版 Pi 扩展升级**：只对哈希严格匹配的原版 3.3.0/3.3.1 扩展自动替换，其他用户修改全部保留。Hooks 的实际信任/激活仍需在宿主验证。
- **Windows Codex Hook 启动防护**：Codex 专用命令不再给固定 Windows PowerShell 可执行文件路径添加首层双引号，避免部分 Codex Windows 版本无法启动命令的已知问题；仍支持包含空格的脚本文件路径。如果 Windows 目录本身包含空格会明确拒绝自动设置，而不是假成功。三平台 Hook 均**不是 OS 权限强制边界**。
- **维护**：`maintenance.cmd` 为只读预演。若确认可清理旧且不再需要的历史备份，在备份后使用 `maintenance.cmd -Apply -ConfirmPrune`；默认至少保留最近 12 份及 60 天以内目录，保留当前最后备份指针指向目录。注意历史备份清理不等同于自动删除项目计划。
- **发布测试**：`python -B -m unittest discover -s tests -p 'test_*.py' -v` 运行跨平台静态合同检查；`tests/windows-regression.ps1` 覆盖真实 Windows PowerShell 5.1 下的计划流程与负向用例；`tests/windows-install-e2e.ps1` **只能在全新 Windows Sandbox** 执行。`.github/workflows/windows-qa.yml` 可由仓库触发 Windows CI，但仅随包提供，当前没有远程运行记录。

**交付状态**：代码和包结构可做跨平台校验，但当前构建环境没有 Windows PowerShell 5.1、Pi/Codex/Claude 的真实 Windows 会话；因此“正式稳定版”验收条件尚未满足。建议先在 Windows Sandbox 验收，再升级日常开发机器。部分 Codex Windows 版本还存在宿主 Hook 不触发或命令报告假成功的问题，必须以实际探针结果为准。

## v3.3.1 历史修复（v3.3.2 保留）

- **计划不再凭空完成**：初始草稿须填写具体目标、验收标准、步骤并 `Ready`；只有勾选全部步骤且填写真实验证说明才能结束为 `Completed`。完成只是对操作者提供的信息做一致性校验，**不等于自动证明测试曾运行**。
- **并发/会话**：Pi Extension 传递会话标识；跨会话不能直接借用其他会话计划；Stop 发现多份未结束计划时逐项报告；无法在平台间保证同一会话 ID 时以唯一任务 ID 为准。
- **Hooks**：扩展至全工具触发，再按保守规则判断读写；Codex/Claude 的配置文件、宿主开关和实际激活为不同状态。Codex 可能需要 `/hooks` 明确信任。Pi `agent_end` 只能提醒，不能取消已结束的回合。任何 Hook 都**不是操作系统的强制安全边界**。
- **诊断**：安装后运行 `doctor.cmd`，检查托管文件与三个宿主的 Hook 配置，执行模拟写入拒绝/读取放行。`CONFIGURED` 和模拟 `PASS` 都不等于真实宿主触发成功。`UNVERIFIED` 必须在真实宿主人工验收。
- **升级与回滚**：安装默认**不删除旧版 `.agent-global` 及其备份**。`preview.cmd /nopause` 会展示历史内容和备份指针等变更。只有明确核对归属和内容后，才可传 `-MigrateLegacy` 显式迁移，强烈建议先在 Windows Sandbox 进行。
- **测试质量**：静态测试忽略自身生成的 `__pycache__`，并附有 Windows 计划回归与**仅允许 Windows Sandbox** 的安装/回滚破坏性测试。

### 建议的安全升级顺序

```cmd
preview.cmd /nopause
install-all.cmd /nopause
verify.cmd /nopause
doctor.cmd
```

确认现有 Codex/Pi/Claude 正常后，按需启动：

```cmd
enable-hooks.cmd -Platform All
doctor.cmd
disable-hooks.cmd -Platform All
```

启用后需分别在三个 Agent 内触发真实写入工具，验证 Hook 确实运行，不能仅以 `doctor` 报告作为证明。若 `preview` 出现 `CONFLICT`，先人工检查差异，**不要直接使用 `-ForceDrift`**。

## 最终运行结构

```text
~/.pi/agent/AGENTS.md                   Pi 全局规则
~/.pi/agent/prompts/agentkit-*.md      Pi 可选轻量 Prompt
$CODEX_HOME/AGENTS.md                  Codex 全局规则
~/.codex/AGENTS.md                     未设置 CODEX_HOME 时默认位置
~/.claude/CLAUDE.md                    Claude Code 全局规则
~/.agents/skills/agentkit-*/           Pi / Codex 用户级 Skills
~/.claude/skills/agentkit-*/           Claude Code 用户级 Skills
%LOCALAPPDATA%/AgentKit/               安装状态、备份和恢复安全快照
```

不会创建或依赖 `~/.agent-global/`。

## v3.3.0 全局规则增量（v3.3.1 沿用）

- **先建计划文件、再执行**：需要执行的任务（如开发、修复、排查、测试或交付）先定向了解必要上下文，然后创建真实 Markdown 计划文件；创建成功后继续实施，不停留在“只给计划”。
- **默认路径**：优先用户指定或项目既有约定，否则为项目根目录下的 `docs/plans/YYYY-MM-DD-<task-slug>.md`。包内提供 `templates/EXECUTION_PLAN.md`；计划写入**正在执行任务的项目**，而不是安装在本套件目录中。
- **始终回写结果**：完成、部分完成、失败或受阻时更新原计划文件，包括进度、改动产物、实际验证和遗留事项；简单任务的计划可以极简。
- **默认简体中文沟通**：用户明确要求其他语言、工程约定或程序接口有语言约束时按其要求；代码符号、日志、命令与引用原文不强行翻译。
- 此要求已同步到 `policy/GLOBAL_POLICY.md`、Pi/Codex/Claude 三个原生平台入口、Pi 的任务 Prompt、规划角色路由与任务模板；包自检的旧版“治理正文未扩张”提示也已修正。

## v3.1.3 历史安全加固（兼容性沿用；v3.3.0 另有新增修复）

- `install.ps1` / `verify.ps1` 不再硬编码版本号，统一读取 `VERSION.txt`。
- 文本读取显式使用严格 UTF-8；用户规则写入使用 UTF-8 no-BOM 原子替换。
- 备份 key 统一规范化为 Windows 相对路径，并限制在当前备份根目录内。
- 目录备份/恢复使用“精确复制”，不依赖 `Copy-Item -Recurse` 在已有目标上的容器语义。
- 写入 `AGENTKIT` 托管块前检查 BEGIN/END 是否成对、唯一且顺序正确；异常时拒绝自动改写。
- 文本控制字符检查只扫描 `PACKAGE_MANIFEST.json` 登记的包文件，不会因为用户在解压目录旁边放了无关 `.txt` 而阻断安装。
- `skills/` 是实际会被复制的受管 payload，因此拒绝未登记文件。
- 三个 `.cmd` 固定调用 `%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe`，先切换 code page 65001；不依赖 PATH 中可能被替换的 `powershell.exe`。
- `.cmd` 支持 `/nopause`，也支持环境变量 `AGENTKIT_NO_PAUSE=1`；双击时仍默认暂停，方便查看结果。
- 安装主事务使用 `finally`：PowerShell 在 `Ctrl+C` 时也会执行 `finally`，因此已登记修改会进入回滚路径。
- 对将被递归备份、删除或覆盖的目标检查 reparse point（符号链接/junction）；发现后拒绝自动处理，避免跨目录误操作。
- 文件写入采用同卷 `File.Replace`，避免目标文件被显式删除后的空窗；目录更新采用暂存目录、备份日志和失败恢复（目录交换不是全局原子事务）。
- 旧版备份归档改为“复制成功后再删除源”，不再依赖跨卷 `Move-Item` 的部分移动语义。
- `restore-latest.ps1` 限制备份指针必须位于 `%LOCALAPPDATA%\AgentKit\backups\` 下，并校验 manifest 中普通备份/legacy archive 的允许范围。
- 恢复前先把当前目标做成 `%LOCALAPPDATA%\AgentKit\restore-safety\...` 安全快照；恢复失败或 `Ctrl+C` 时从该快照回滚。
- 恢复旧 `move` 项时使用复制，不消耗原归档备份，因此失败后可重试。

> `Zone.Identifier` 不会被自动清除。启动器使用 `-ExecutionPolicy Bypass` 解决普通 ExecutionPolicy/MOTW 场景，但不会尝试绕过 AppLocker、WDAC 或组织级安全策略。

## 安装 / 升级

无需先卸载 v3.0 / v3.1.x：

1. 完整解压本 ZIP 到一个新目录；
2. 双击 `install-all.cmd`；
3. 安装完成后双击 `verify.cmd`；
4. 验证通过后重新打开 Pi / Codex / Claude Code；Pi 也可以执行 `/reload`。

命令行无人值守时可使用：

```cmd
install-all.cmd /nopause
verify.cmd /nopause
```

或：

```cmd
set AGENTKIT_NO_PAUSE=1
install-all.cmd
verify.cmd
```

## 备份与恢复

安装状态与安装前备份：

```text
%LOCALAPPDATA%\AgentKit\state.json
%LOCALAPPDATA%\AgentKit\last-backup.txt
%LOCALAPPDATA%\AgentKit\backups\...
```

执行：

```text
restore-latest.cmd
```

恢复器会：

1. 验证 `last-backup.txt` 只能指向 AgentKit 自己的 `backups` 目录；
2. 预检所有备份；
3. 为当前状态创建 `restore-safety` 快照；
4. 执行恢复；
5. 若中途失败或被 `Ctrl+C` 中断，尝试恢复到执行恢复之前的状态。

原安装备份不会因恢复而被消费。

## 包内目录

```text
policy/                规则源码与设计参考；不安装为运行时目录
platform/              Pi / Codex / Claude 的精简原生入口
skills/                7 个 namespaced 窄触发 Skills
templates/             项目差异 / 任务 / 执行计划 / Skill 模板
scripts/               包自检辅助脚本
install-all.cmd        一键完整安装
install.ps1            事务安装器
verify.cmd             一键完整验证
verify.ps1             验证器
restore-latest.cmd     一键恢复
restore-latest.ps1     事务恢复器
VERSION.txt            版本单一来源
PACKAGE_MANIFEST.json  SHA-256 / 大小清单
AUDIT_REPORT.md        本版增量审计与 v3.1.3 加固追溯
```

## 治理设计

- 常驻规则只保留目标、上下文、权限边界、最低充分验证与 Done；
- Skill 使用短、窄 description，并按需加载 `SKILL.md` / `references/`；
- **所有执行型任务先创建并更新计划文档**；简单任务用极简计划直接执行，复杂/高风险/确有并行收益时才增加专门 Planner 或子 Agent；
- 低风险、本地、可逆操作默认自主；真实外部副作用和不可逆高风险操作再确认；
- 对话默认使用简体中文，尊重用户显式语言要求及技术原文；
- 不为了流程完整而重复测试、重复读文档或强制 Review。

设计依据继续是 OpenAI《Rethinking skills and prompts for GPT-6 Astra》以及各平台当前原生规则/Skill 机制。

## 日常命令与计划生命周期

Windows: extract the whole ZIP, and execute these steps in order. The preview **does not modify installed files**:

```cmd
preview.cmd /nopause
install-all.cmd /nopause
verify.cmd /nopause
```

Optional plan enforcement hooks (enable only after review and verification):

```cmd
enable-hooks.cmd -Platform All
```

To remove only AgentKit-managed hooks while retaining other custom hooks:

```cmd
disable-hooks.cmd -Platform All
```

For Codex, open `/hooks` and explicitly trust the hook if your CLI requires it. Hooks may not run in all Codex/Claude clients or older versions. Pi requires a compatible TypeScript extension runtime.

Create and finish a concrete plan inside your **current project**, not the AgentKit installation directory:

```cmd
plan.cmd -Action Init -ProjectPath "D:\Code\MyProject" -Task "implement feature" -Goal "实现并交付功能" -Acceptance "构建与测试通过" -StepsText "实现|验证"
plan.cmd -Action Check -ProjectPath "D:\Code\MyProject" -PlanId <printed-id>
plan.cmd -Action Step -ProjectPath "D:\Code\MyProject" -PlanId <printed-id> -Step "实现"
plan.cmd -Action Step -ProjectPath "D:\Code\MyProject" -PlanId <printed-id> -Step "验证"
plan.cmd -Action Finish -ProjectPath "D:\Code\MyProject" -PlanId <printed-id> -Result Completed -Evidence "实际运行测试命令并通过"
plan.cmd -Action List -ProjectPath "D:\Code\MyProject"
```

如果先运行 `Init` 而未给出 `-Goal/-Acceptance/-StepsText`，只会创建 **草稿**，不允许进入开发写入阶段。需另行执行 `plan.cmd -Action Ready -ProjectPath "D:\Code\MyProject" -PlanId <printed-id> -Goal "..." -Acceptance "..." -StepsText "实现|验证"`，再执行 `Check`。`Finish Completed` 要求所有步骤勾选并填写非空验收证据；`Partial/Blocked` 可如实结束未完成工作。

The plan CLI is also installed at `%LOCALAPPDATA%\AgentKit\bin\plan.ps1`; PowerShell 5.1 and above can invoke it by absolute path from anywhere. When multiple plans are active, select `-PlanId` or `-SessionId` explicitly.

### Safe upgrade, drift and recovery

`preview.cmd` classifies managed destinations as `NEW`, `UPDATE`, `UNCHANGED`, or `CONFLICT` and summarizes managed-rule differences. A conflict blocks installation by default. Only after manually reviewing changed files should you use `powershell.exe -NoProfile -ExecutionPolicy Bypass -File install.ps1 -ForceDrift`.

Restoring from this release is blocked if the AgentKit hooks are still enabled: disable them first. If `pending-install.json` indicates an interrupted installation, run `recover-pending.cmd` before reattempting installation or restore. Each recovery first takes a safety snapshot. For v3.1.x backups, post-install fingerprints were not present; review the old backup manifest and explicitly pass `-AllowUntrackedBackup` to the restore script if needed.

Pi uses `PI_CODING_AGENT_DIR`, Codex uses `CODEX_HOME`, and Claude Code uses `CLAUDE_CONFIG_DIR`. The actual directories used at installation are recorded in `%LOCALAPPDATA%\AgentKit\state.json` for verification and safe restore.

### Rules and testing

`policy/GLOBAL_POLICY.md` is the canonical shared source; platform-specific supplements are stored in `policy/platform/*.md`. After editing them, run `powershell.exe -File scripts/render-policy.ps1 -Write`, then rebuild `PACKAGE_MANIFEST.json`. Do not edit generated `platform/*` copies as long-lived sources.

Static tests: `python3 -m unittest discover -s tests -p test_release.py -v` (Python needed **only for package development**, not normal Windows operation). Windows tests: `powershell.exe -NoProfile -ExecutionPolicy Bypass -File tests/windows-regression.ps1` on an isolated Windows test machine. **Destructive** full-lifecycle test only in a fresh Windows Sandbox (user `WDAGUtilityAccount`): set `AGENTKIT_SANDBOX_E2E=YES`, then run `powershell.exe -NoProfile -ExecutionPolicy Bypass -File tests/windows-install-e2e.ps1 -ConfirmWindowsSandbox`. Do not run the latter on your everyday Windows host.

See `RELEASE_NOTES.md` and `AUDIT_REPORT.md` for safeguards, compatibility, and limits of automated enforcement.

## 测试界限（含 v3.3.2）

随包附带 `VALIDATION_REPORT.md` 和 `tests/windows-regression.ps1`，构建环境已完成静态检查，但 **尚未运行 Windows PowerShell 5.1 实机安装、恢复与 Hooks 集成测试**。请在可回滚的 Windows 测试环境首先执行验收；不要因为 ZIP 哈希校验通过就直接推断系统级回滚行为已经验证。
