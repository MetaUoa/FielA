# v3.3.2 稳定候选发布说明

**状态：修复候选，Windows 运行时验收待完成；不得将未运行的宿主 Hook 测试宣称为 PASS。**

本版在 v3.3.1 上集中消除审计问题：保留旧数据但验证报错、Shell 白名单副作用绕过、多计划同会话歧义、计划文档与索引崩溃不一致、事务恢复日志路径错误、Pi 扩展历史版本升级、Codex Windows Hook 命令引用问题。新增显式 `Bind`/`Repair`、子目录项目根解析、只读维护预演与回归工作流。所有更改均保留原 7 Skills 与全局中文优先/先计划后执行的规则。

**已知限制**：PowerShell 5.1 真实安装/升级/恢复，以及三个 Agent 宿主 Hook 真实触发，均须在 Windows Sandbox 或等效隔离环境验收。计划守卫是治理辅助工具，不是操作系统层面的强制隔离。部分版本 Codex Windows Hook 存在宿主级启动/触发缺陷，`doctor` 只能证明配置和合成探针，不保证宿主实际覆盖。

**升级顺序**：`preview.cmd /nopause` → `install-all.cmd /nopause` → `verify.cmd /nopause` → `doctor.cmd`；确认无冲突后按需 `enable-hooks.cmd -Platform All`，三平台分别做真实调用验证；回滚前先 `disable-hooks.cmd -Platform All`。

---

# AgentKit v3.3.1 发布说明

发布日期：2026-10-08；在 v3.3.0 的基础上做定向加固，不重新设计现有 7 个 Skills。

## 修复

1. `plan.ps1`：草稿与就绪状态分离；`Ready/Check` 要求具体目标、验收及步骤；`Step` 勾选指定未完成项；`Finish Completed` 校验清单全部完成、结果说明非空且具有实质内容。`Partial/Blocked` 保留如实收尾能力。
2. `plan.ps1`：`HookStop` 发现多份活动计划也拒绝/提示；`HookCheck` 对未知工具保守检查，已识别只读工具可不受限；防止跨会话直接借用其他会话已登记计划。
3. `plan.ps1`：先对项目计划目录已有的父目录和重解析点进行安全检查，再 `CreateDirectory`；在 Windows 启动前防止通过符号链接改变建档位置。
4. `plan.ps1`：处理旧索引缺失 `ready` 字段的向后兼容、禁止计划字段注入控制符及换行、用户输入 `$1` 等内容不再影响正则替换；输出合法 Hook 成功 JSON `{}`。
5. Pi Extension：`AGENTKIT_SESSION_ID` 传到子进程，工具调用按事件检查；Pi 的 `agent_end` 仅警告，不能实际取消回合。
6. Codex/Claude：扩展所有工具的 `PreToolUse` matcher，保守区分读/写；保留其他自定义 Hooks，可显式启用、禁用和恢复。
7. `install.ps1`：历史 `.agent-global` 目录与旧版配置默认保留；只有显式 `-MigrateLegacy` 才允许归档与删除，并在预演中展示。
8. `preview.ps1`：列出安装状态、备份、指针、待恢复日志及可选迁移影响；`doctor.ps1`/`doctor.cmd` 提供安装与 Hook 自诊断，明确区分配置、模拟探针和真实宿主验证。
9. `tests/test_release.py`：排除自身生成的 `__pycache__`；`tests/windows-regression.ps1` 新增负向生命周期、多计划和会话隔离；`tests/windows-install-e2e.ps1` 仅在明确 Windows Sandbox 环境中执行有破坏性的真实安装/恢复检查。
10. `policy/GLOBAL_POLICY.md` 与三平台生成规则同步说明 `Init/Ready/Check/Step/Finish` 的使用边界。

## 需要真实 Windows 验证的范围

Windows PowerShell 5.1 的执行、应用目录权限、并发安装、恢复时锁定文件、Codex/Pi/Claude 真实 Hook 启动和信任均不能通过 Linux 静态测试证明。请在 Windows Sandbox 验证后决定是否部署。任何 Hook 的工具匹配和操作者提供的测试证据均非 OS 安全保证。

如需复查 v3.3.0 的全部基础变更，可查 `AUDIT_REPORT.md` 与 `README.md`。
