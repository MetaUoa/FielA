# AgentKit v3.3.2 验证报告（2026-10-09）

## 检查范围

基于实际打包文件执行：版本与清单哈希、ZIP CRC/路径安全、7 个 Skills 保留、PowerShell 5.1 编码/BOM/CRLF、CMD ASCII/CRLF、三平台公共规则一致性、计划/Hook 修复的静态合同、Pi TypeScript 语法分析。

## 结果（在构建结束后填写）

- Python 静态合同：构建后验证 16 项全过（跨平台合同测试；不含实际 PowerShell 执行）。
- ZIP / Manifest：包构建后由独立校验脚本检查 CRC、59/59 文件哈希、条目路径与大小。
- Pi TypeScript 语法：Node 22 `--experimental-strip-types --check` 已通过。
- Windows PowerShell 5.1：当前 Linux 环境无 WindowsPowerShell，不可执行；待隔离环境。
- Windows Sandbox 安装升级恢复：尚未执行；脚本仅在明确确认全新 Sandbox 时放行。
- Codex、Pi、Claude Code 实际 Hook：尚未执行；各宿主信任和执行路径未验证。

**发布分类**：Windows 运行时验收之前为候选版，不作为完全验证的稳定终版。详见 `tests/windows-regression.ps1` 与 `tests/windows-install-e2e.ps1`。
