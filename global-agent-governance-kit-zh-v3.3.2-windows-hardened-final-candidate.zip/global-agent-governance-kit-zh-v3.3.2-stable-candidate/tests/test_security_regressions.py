"""Independent contract checks for safety-critical wiring (NOT PowerShell E2E)."""
from __future__ import annotations
import hashlib
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def src(relative: str) -> str:
    return (ROOT / relative).read_text(encoding='utf-8-sig').replace('\r\n', '\n')

class StabilityContracts(unittest.TestCase):
    def test_legacy_preservation_is_not_failure(self):
        install, verify = src('install.ps1'), src('verify.ps1')
        self.assertIn('legacy_migrated=[bool]$MigrateLegacy', install)
        self.assertIn("Add-Result 'PRESERVED'", verify)
        self.assertNotIn("Add-Result 'FAIL' '旧 agent-global 已移除'", verify)
        self.assertIn('ConfirmLegacyOwnership', install)

    def test_shell_never_bypasses_on_readonly_prefix(self):
        text = src('scripts/plan.ps1')
        body = text.split('function Is-MutatingHook($Event) {', 1)[1].split('\ntry {', 1)[0]
        self.assertIn('Every Shell invocation is guarded', body)
        self.assertIn('Init|Ready|Resume|Bind|Repair', body)
        self.assertNotIn('git\\s+(status|diff|log|show)', body)
        self.assertNotIn('grep|find|search|', body.split('if ($name -match', 1)[1].split(') { return $false }', 1)[0])
        self.assertIn('return $true', body)
        runtime = src('tests/windows-regression.ps1')
        for command in ('find . -delete', 'find . -exec rm {} +', 'git diff --output=changed.patch', 'git status'):
            self.assertIn(command, runtime)

    def test_plan_binding_and_root_discovery(self):
        p = src('scripts/plan.ps1')
        self.assertIn('function Resolve-AgentKitProjectRoot(', p)
        self.assertIn("Join-Path $cursor '.git'", p)
        self.assertIn('AGENTKIT_PROJECT_ROOT', p)
        self.assertIn("'Bind' {", p)
        self.assertIn('PLAN_BOUND session=', p)
        self.assertIn('$Index.bindings.PSObject.Properties[$Session]', p)
        self.assertIn('AGENTKIT_PLAN_ID', p)
        self.assertIn('if (-not [string]$p.session_id)', p)

    def test_two_file_crash_recovery_and_user_drift_guard(self):
        p = src('scripts/plan.ps1')
        for fn in ('Begin-PlanTransaction','Recover-PlanTransaction','Commit-PlanTransaction',
                   'Save-TxnJournal','Set-TxnExpected','Write-PlanDocument'):
            self.assertIn('function '+fn, p)
        self.assertIn("phase='prepared'", p)
        self.assertIn("phase = 'committed'", p)
        self.assertIn('Recovery conflict; preserve current file', p)
        self.assertIn('Assert-AgentKitChild $doc $script:PlanRoot', p)
        self.assertIn('Recover-PlanTransaction\n    $index = Load-Index', p)
        self.assertIn('return ,([System.IO.File]::ReadAllBytes($Path))', p)
        self.assertIn("'AgentKit\\plan-state\\transactions\\' + $idHash + '.json'",p)
        self.assertIn('Write-AgentKitAtomicBytes $docPath $data',p)
        self.assertNotIn('[System.IO.FileMode]::CreateNew',p)

        self.assertGreaterEqual(p.count('Commit-PlanTransaction'), 6)
        self.assertIn('UNRELATED USER CHANGE', src('tests/windows-regression.ps1'))

    def test_pi_upgrade_exact_hash_and_restorable(self):
        expected='aeeab9a60bb148270ebe633feb4f705328c0cd0366affee9bfd567313f268a61'
        self.assertEqual(hashlib.sha256((ROOT/'tests/fixtures/pi-guard-v3.3.0.ts').read_bytes()).hexdigest(), expected)
        for name in ('scripts/agentkit-common.ps1','install.ps1','scripts/toggle-hooks.ps1'):
            self.assertIn('Get-AgentKitKnownPiExtensionHashes', src(name))
        self.assertIn("(Join-Path $pi 'extensions\\agentkit-plan-guard.ts')",src('restore-latest.ps1'))
        self.assertIn('pi-guard-v3.3.0.ts',src('tests/windows-install-e2e.ps1'))
        toggle=src('scripts/toggle-hooks.ps1')
        self.assertIn("if ($Name -eq 'Codex') {",toggle)
        self.assertIn('commandWindows',toggle)
        self.assertIn('if ($systemExe -match',toggle)


    def test_maintenance_dry_run_default(self):
        m=src('scripts/maintenance.ps1')
        self.assertIn('[switch]$Apply',m)
        self.assertIn('[switch]$ConfirmPrune',m)
        self.assertIn("if ($Apply -and -not $ConfirmPrune)",m)
        self.assertIn("last-backup.txt",m)
        self.assertIn('Assert-SafeTree',m)
        for name in ('install.ps1','verify.ps1','preview.ps1','restore-latest.ps1'):
            self.assertIn('maintenance.ps1',src(name))
        self.assertTrue((ROOT/'maintenance.cmd').is_file())

    def test_doctor_checks_matcher_and_no_false_host_claim(self):
        d=src('scripts/doctor.ps1')
        self.assertIn("$group.matcher -notin @('*','.*')",d)
        self.assertIn('UNVERIFIED',d)
        self.assertIn('Stopwatch',d)

if __name__ == '__main__':
    unittest.main()
