import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { spawnSync } from "node:child_process";
import { join } from "node:path";

// Optional. Enable using enable-hooks.cmd; never overwrites other Pi extensions.
function runCheck(action: "HookCheck" | "HookStop", payload: unknown) {
  const windows = process.env.SystemRoot || "C:\\Windows";
  const appData = process.env.LOCALAPPDATA || join(process.env.USERPROFILE || "", "AppData", "Local");
  const shell = join(windows, "System32", "WindowsPowerShell", "v1.0", "powershell.exe");
  const script = join(appData, "AgentKit", "bin", "plan.ps1");
  return spawnSync(shell, ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", script, "-Action", action], {
    input: JSON.stringify(payload), encoding: "utf8", timeout: 12000, windowsHide: true,
  });
}

export default function (pi: ExtensionAPI) {
  pi.on("tool_call", async (event, ctx) => {
    const name = event.toolName;
    if (/^(read|ls|grep|find|glob|webfetch|websearch|search)$/i.test(name)) return;
    const details = { tool_name: name, tool_input: event.input, cwd: ctx.cwd };
    // The CLI classifies shell calls conservatively. Pure reads stay available.
    const result = runCheck("HookCheck", details);
    if (result.error || result.status !== 0) {
      return { block: true, reason: `AgentKit plan check failed: ${(result.stderr || result.error?.message || "no active plan").trim()}` };
    }
  });
  pi.on("agent_end", async (_event, ctx) => {
    const result = runCheck("HookStop", { cwd: ctx.cwd });
    if (result.status === 2 && ctx.hasUI) {
      ctx.ui.notify("AgentKit: active plan must be finalized (plan.ps1 -Action Finish).", "warning");
    }
  });
}
