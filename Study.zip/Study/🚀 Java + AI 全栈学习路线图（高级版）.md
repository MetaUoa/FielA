
> 目标：成为具备 AI 应用落地能力的 Java 全栈工程师
> 
> 技术栈：Java + SpringBoot + SpringCloud + React/Vue + Python + AI Agent
> 
> 周期：6 ~ 12 个月
> 
> 使用方式：完成后将 `[ ]` 改为 `[x]`

---

# 📚 目录

- [阶段一：Java 基础](https://chatgpt.com/c/6a048cc6-2b64-83ea-88b6-3bcbfe3ff809#%E9%98%B6%E6%AE%B5%E4%B8%80java-%E5%9F%BA%E7%A1%8014-%E5%91%A8)
    
- [阶段二：数据库与缓存](https://chatgpt.com/c/6a048cc6-2b64-83ea-88b6-3bcbfe3ff809#%E9%98%B6%E6%AE%B5%E4%BA%8C%E6%95%B0%E6%8D%AE%E5%BA%93%E4%B8%8E%E7%BC%93%E5%AD%9856-%E5%91%A8)
    
- [阶段三：SpringBoot 企业开发](https://chatgpt.com/c/6a048cc6-2b64-83ea-88b6-3bcbfe3ff809#%E9%98%B6%E6%AE%B5%E4%B8%89springboot-%E4%BC%81%E4%B8%9A%E5%BC%80%E5%8F%9179-%E5%91%A8)
    
- [阶段四：微服务与中间件](https://chatgpt.com/c/6a048cc6-2b64-83ea-88b6-3bcbfe3ff809#%E9%98%B6%E6%AE%B5%E5%9B%9B%E5%BE%AE%E6%9C%8D%E5%8A%A1%E4%B8%8E%E4%B8%AD%E9%97%B4%E4%BB%B61013-%E5%91%A8)
    
- [阶段五：前端开发](https://chatgpt.com/c/6a048cc6-2b64-83ea-88b6-3bcbfe3ff809#%E9%98%B6%E6%AE%B5%E4%BA%94%E5%89%8D%E7%AB%AF%E5%BC%80%E5%8F%911416-%E5%91%A8)
    
- [阶段六：Python 与 AI](https://chatgpt.com/c/6a048cc6-2b64-83ea-88b6-3bcbfe3ff809#%E9%98%B6%E6%AE%B5%E5%85%ADpython-%E4%B8%8E-ai1720-%E5%91%A8)
    
- [阶段七：算法与面试](https://chatgpt.com/c/6a048cc6-2b64-83ea-88b6-3bcbfe3ff809#%E9%98%B6%E6%AE%B5%E4%B8%83%E7%AE%97%E6%B3%95%E4%B8%8E%E9%9D%A2%E8%AF%95%E9%95%BF%E6%9C%9F)
    
- [项目路线](https://chatgpt.com/c/6a048cc6-2b64-83ea-88b6-3bcbfe3ff809#%E9%A1%B9%E7%9B%AE%E8%B7%AF%E7%BA%BF)
    
- [每日学习模板](https://chatgpt.com/c/6a048cc6-2b64-83ea-88b6-3bcbfe3ff809#%E6%AF%8F%E6%97%A5%E5%AD%A6%E4%B9%A0%E6%A8%A1%E6%9D%BF)
    
- [每周复盘模板](https://chatgpt.com/c/6a048cc6-2b64-83ea-88b6-3bcbfe3ff809#%E6%AF%8F%E5%91%A8%E5%A4%8D%E7%9B%98%E6%A8%A1%E6%9D%BF)
    

---

# 🧭 总体路线图

```text
Java 基础
   ↓
MySQL + Redis
   ↓
SpringBoot
   ↓
SpringCloud + MQ
   ↓
Docker + Linux
   ↓
React/Vue
   ↓
Python
   ↓
LLM / RAG / Agent
   ↓
AI 项目落地
```

---

# 📈 学习进度

|阶段|状态|完成度|
|---|---|---|
|Java 基础|⬜ 未开始|0%|
|数据库与缓存|⬜ 未开始|0%|
|SpringBoot|⬜ 未开始|0%|
|微服务|⬜ 未开始|0%|
|前端|⬜ 未开始|0%|
|Python + AI|⬜ 未开始|0%|
|项目实战|⬜ 未开始|0%|
|面试准备|⬜ 未开始|0%|

---

# 第一阶段：Java 基础（1~4 周）

## 🎯 阶段目标

- 掌握 Java 核心语法
    
- 理解面向对象
    
- 理解集合与多线程
    
- 能独立完成小型项目
    

---

# 第 1 周：Java 入门

## 基础语法

-  安装 JDK
    
-  配置环境变量
    
-  安装 IntelliJ IDEA
    
-  HelloWorld
    
-  变量与数据类型
    
-  运算符
    
-  if / else
    
-  switch
    
-  for / while
    
-  数组
    

## 实战任务

-  实现计算器
    
-  实现猜数字游戏
    
-  实现学生成绩管理系统
    

## 学习输出

-  完成学习笔记
    
-  提交 GitHub
    

---

# 第 2 周：面向对象

## OOP 核心

-  类与对象
    
-  构造方法
    
-  封装
    
-  继承
    
-  多态
    
-  抽象类
    
-  接口
    
-  static
    
-  final
    

## 实战任务

-  图书管理系统
    
-  用户管理系统
    

## 学习输出

-  UML 类图
    
-  GitHub 提交
    

---

# 第 3 周：集合 + IO + 异常

## 集合

-  ArrayList
    
-  LinkedList
    
-  HashMap
    
-  HashSet
    
-  TreeMap
    

## IO

-  文件读写
    
-  BufferedReader
    
-  NIO 基础
    

## 异常

-  try-catch
    
-  throws
    
-  自定义异常
    

## 实战任务

-  文件备份工具
    
-  日志分析工具
    

---

# 第 4 周：多线程 + JVM

## 多线程

-  Thread
    
-  Runnable
    
-  Callable
    
-  synchronized
    
-  Lock
    
-  volatile
    
-  线程池
    
-  CompletableFuture
    

## JVM

-  JVM 内存结构
    
-  堆与栈
    
-  GC
    
-  类加载机制
    

## 实战任务

-  异步任务系统
    
-  线程池 Demo
    

---

# 第二阶段：数据库与缓存（5~6 周）

## 🎯 阶段目标

- 掌握 MySQL 核心能力
    
- 掌握 Redis 高并发场景
    
- 能解决缓存问题
    

---

# 第 5 周：MySQL

## SQL

-  CRUD
    
-  join
    
-  group by
    
-  子查询
    

## 高级部分

-  索引
    
-  explain
    
-  事务
    
-  MVCC
    
-  SQL 优化
    

## 实战任务

-  设计电商数据库
    
-  编写复杂 SQL
    

---

# 第 6 周：Redis

## Redis

-  String
    
-  Hash
    
-  List
    
-  Set
    
-  ZSet
    

## 高并发问题

-  缓存穿透
    
-  缓存击穿
    
-  缓存雪崩
    
-  Redis 分布式锁
    

## 实战任务

-  秒杀库存扣减
    
-  登录缓存系统
    

---

# 第三阶段：SpringBoot 企业开发（7~9 周）

## 🎯 阶段目标

- 能独立开发 RESTful API
    
- 能完成企业后台系统
    

---

# 第 7 周：SpringBoot 核心

## Spring

-  IOC
    
-  AOP
    
-  Bean 生命周期
    

## SpringBoot

-  Starter
    
-  自动配置
    
-  配置文件
    
-  日志系统
    

## 实战任务

-  REST API
    
-  统一返回结构
    

---

# 第 8 周：权限与数据库整合

## ORM

-  MyBatis
    
-  MyBatis Plus
    

## 企业功能

-  JWT 登录
    
-  Swagger/OpenAPI
    
-  全局异常处理
    
-  参数校验
    

## 实战任务

-  用户权限系统
    

---

# 第 9 周：SpringBoot 项目实战

## 项目要求

-  登录模块
    
-  用户模块
    
-  权限模块
    
-  文件上传
    
-  Redis 缓存
    

## 项目目标

-  GitHub 开源
    
-  README 文档
    
-  Docker 部署
    

---

# 第四阶段：微服务与中间件（10~13 周）

## 🎯 阶段目标

- 掌握微服务体系
    
- 掌握 MQ 与高并发
    
- 掌握 Docker 部署
    

---

# 第 10 周：SpringCloud

## 微服务

-  服务拆分
    
-  注册中心
    
-  配置中心
    
-  Gateway
    
-  OpenFeign
    
-  Sentinel
    

## 推荐组件

-  Nacos
    
-  Gateway
    
-  Sentinel
    

## 实战任务

-  用户服务
    
-  订单服务
    

---

# 第 11 周：MQ

## RabbitMQ

-  Exchange
    
-  Queue
    
-  Topic
    
-  ACK
    

## 企业重点

-  消息可靠性
    
-  幂等性
    
-  延迟消息
    
-  死信队列
    

## 实战任务

-  异步下单
    
-  超时取消订单
    

---

# 第 12 周：Docker + Linux

## Linux

-  文件命令
    
-  网络命令
    
-  shell
    

## Docker

-  镜像
    
-  容器
    
-  Dockerfile
    
-  docker-compose
    

## 实战任务

-  Docker 化部署
    

---

# 第 13 周：微服务商城项目

## 功能模块

-  用户系统
    
-  商品系统
    
-  订单系统
    
-  支付系统
    
-  Redis 缓存
    
-  MQ 消息队列
    

## 项目目标

-  Docker 部署
    
-  API 文档
    
-  GitHub 开源
    

---

# 第五阶段：前端开发（14~16 周）

## 🎯 阶段目标

- 能独立联调前后端
    
- 能开发后台管理系统
    

---

# Vue 路线

-  Vue3
    
-  Composition API
    
-  Pinia
    
-  Vue Router
    
-  Axios
    
-  Element Plus
    

## 实战任务

-  后台管理系统
    
-  用户管理页面
    

---

# React 路线

-  React
    
-  Hooks
    
-  Zustand/Redux
    
-  React Router
    
-  Ant Design
    
-  Vite
    

## 实战任务

-  AI Chat UI
    
-  Markdown 渲染
    
-  文件上传页面
    

---

# 第六阶段：Python 与 AI（17~20 周）

## 🎯 阶段目标

- 掌握 AI 应用开发
    
- 能开发 Agent 系统
    
- 能实现 RAG
    

---

# 第 17 周：Python

## Python

-  基础语法
    
-  requests
    
-  asyncio
    
-  FastAPI
    

## 实战任务

-  Python API 服务
    
-  文件解析服务
    

---

# 第 18 周：LLM 基础

## 必学

-  Token
    
-  Prompt Engineering
    
-  Function Calling
    
-  Embedding
    
-  RAG
    
-  MCP
    
-  Agent
    

## 实战任务

-  AI 聊天机器人
    
-  流式输出
    

---

# 第 19 周：AI 框架

## LangChain

-  PromptTemplate
    
-  Memory
    
-  Tool
    
-  Agent
    

## LangGraph

-  Workflow
    
-  StateGraph
    
-  多 Agent
    

## Spring AI

-  ChatClient
    
-  RAG
    
-  MCP
    

## 实战任务

-  AI 文档问答
    
-  AI SQL Agent
    

---

# 第 20 周：AI 项目实战

## AI 知识库

-  文档上传
    
-  向量检索
    
-  AI 问答
    
-  历史记录
    

## Agent 系统

-  自动日报
    
-  AI 客服
    
-  自动代码审查
    

## 项目目标

-  GitHub 开源
    
-  Docker 部署
    
-  项目文档
    

---

# 第七阶段：算法与面试（长期）

## 算法

-  数组
    
-  链表
    
-  哈希表
    
-  二叉树
    
-  DFS/BFS
    
-  动态规划
    

## LeetCode

-  热门 100 题
    
-  每日 1 题
    

---

# 面试八股

## Java

-  HashMap
    
-  ConcurrentHashMap
    
-  JVM
    
-  GC
    
-  线程池
    

## 微服务

-  分布式事务
    
-  熔断
    
-  限流
    
-  MQ 可靠性
    

## Redis

-  Redis 为什么快
    
-  Redis 持久化
    
-  缓存一致性
    

## AI

-  RAG 原理
    
-  Agent 工作流
    
-  Prompt 注入
    
-  MCP
    

---

# 🏗 项目路线

## 初级项目

-  博客系统
    
-  用户管理系统
    
-  后台管理系统
    

## 中级项目

-  SpringBoot 商城
    
-  微服务商城
    

## 高级项目

-  AI 知识库
    
-  AI Agent 系统
    
-  企业级 AI 助手
    

---

# 🧾 GitHub 目标

-  每周提交代码 ≥ 3 次
    
-  所有项目编写 README
    
-  项目附带截图
    
-  记录学习笔记
    

---

# 📅 每日学习模板

```markdown
# YYYY-MM-DD 学习记录

## 今日目标

- [ ]
- [ ]
- [ ]

## 今日完成

- [ ]
- [ ]
- [ ]

## 遇到的问题

-

## 学到的知识

-

## 明日计划

- [ ]
- [ ]
```

---

# 📌 每周复盘模板

```markdown
# 第 X 周复盘

## 本周完成

-

## 本周问题

-

## 本周收获

-

## 下周计划

-
```

---

# 🎯 学习完成标准

## 初级 Java

-  能独立开发 CRUD 系统
    
-  能独立部署项目
    

## 中级 Java

-  能开发微服务
    
-  能解决高并发问题
    
-  能独立完成企业项目
    

## AI 应用工程师

-  能开发 RAG 系统
    
-  能开发 AI Agent
    
-  能实现 AI 业务落地
    

---

# 🏁 最终目标

-  完成 3~5 个完整项目
    
-  GitHub 有持续提交记录
    
-  具备中高级 Java 能力
    
-  具备 AI 应用开发能力
    
-  达到 Java + AI 全栈工程师水平