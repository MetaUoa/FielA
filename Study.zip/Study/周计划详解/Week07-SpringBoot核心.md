# 第 7 周：SpringBoot 核心

> **本周学习目标**：理解 Spring IOC/AOP 思想，掌握 SpringBoot 项目结构与开发流程，能独立开发 RESTful API。
>
> **本周关键词**：IOC、AOP、Bean 生命周期、自动装配、Starter、配置文件、日志、统一返回、参数校验
>
> **预计投入时间**：35~45 小时

---

## 一、本周知识点详细分解

### 1. Spring 是什么、为什么用（半天）

#### 1.1 痛点回顾

之前 OOP 项目里：
- 类之间用 `new` 创建对象 → 强耦合
- 改一个实现要改 N 处代码
- 切换数据源、消息中间件像噩梦

#### 1.2 Spring 的核心思想

- **IOC（控制反转）**：对象的创建交给容器，不再 `new`
- **DI（依赖注入）**：容器把依赖注入到对象里
- **AOP（面向切面）**：横切关注点（日志、事务）从业务代码剥离

#### 1.3 SpringBoot vs Spring

| | Spring | SpringBoot |
| --- | --- | --- |
| 配置 | XML / 注解 | 自动配置 + 约定优于配置 |
| 启动 | 部署到 Tomcat | 内嵌 Tomcat，main 启动 |
| 依赖 | 手动管理 | Starter 自动管理 |

**完全掌握标准：**
- ✅ 能解释 IOC、DI、AOP 各是什么
- ✅ 能解释"控制反转"反转了什么（对象创建的控制权）
- ✅ 能解释 Spring 解决了什么问题（解耦）
- ✅ 知道 SpringBoot 是 Spring 的"全家桶启动器"

---

### 2. 创建第一个 SpringBoot 项目（半天）

#### 2.1 用 Spring Initializr

- 访问 [https://start.spring.io/](https://start.spring.io/)
- 或 IDEA：File → New → Project → Spring Initializr

**关键选项：**
- Project：Maven
- Language：Java
- SpringBoot：3.x（基于 Java 17）或 2.7.x（兼容 Java 8）
- 推荐：**SpringBoot 3.x + Java 17**

**Dependencies（先选这些）：**
- Spring Web
- Spring Boot DevTools
- Lombok

#### 2.2 项目结构

```
my-project/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/xxx/myproject/
│   │   │       ├── MyApplication.java   ← 启动类
│   │   │       ├── controller/
│   │   │       ├── service/
│   │   │       ├── mapper/
│   │   │       ├── entity/
│   │   │       └── config/
│   │   └── resources/
│   │       ├── application.yml          ← 配置
│   │       └── static/                  ← 静态资源
│   └── test/
└── pom.xml                              ← Maven 依赖
```

#### 2.3 第一个 Controller

```java
@RestController
@RequestMapping("/api")
public class HelloController {

    @GetMapping("/hello")
    public String hello() {
        return "Hello SpringBoot";
    }
}
```

**完全掌握标准：**
- ✅ 能用 IDEA + Spring Initializr 5 分钟搭起项目
- ✅ 能写 Controller 并跑通 `localhost:8080/api/hello`
- ✅ 能看懂启动日志（Tomcat 端口、Bean 加载）

---

### 3. IOC 容器与 Bean（1 天）

#### 3.1 把对象交给 Spring 管理

**4 种声明 Bean 的注解：**

| 注解 | 用途 |
| --- | --- |
| `@Component` | 通用组件 |
| `@Controller` | 表现层（前后端不分离） |
| `@RestController` | RESTful API |
| `@Service` | 业务层 |
| `@Repository` | DAO 层 |
| `@Configuration` | 配置类 |

> 这些注解功能上等价（都是 @Component），不同名是为了**语义清晰**。

#### 3.2 注入依赖（4 种方式）

```java
@Service
public class UserService {

    // 1. 字段注入（不推荐，难测试）
    @Autowired
    private UserMapper userMapper;

    // 2. setter 注入
    @Autowired
    public void setUserMapper(UserMapper userMapper) {
        this.userMapper = userMapper;
    }

    // 3. 构造方法注入（推荐⭐）
    private final UserMapper userMapper;
    public UserService(UserMapper userMapper) {
        this.userMapper = userMapper;
    }

    // 4. Lombok @RequiredArgsConstructor（推荐⭐⭐）
}

@Service
@RequiredArgsConstructor
public class UserService {
    private final UserMapper userMapper;   // 自动生成构造注入
}
```

**为什么推荐构造注入：**
- 依赖一目了然
- 字段可以是 final（不可变）
- 不依赖 Spring 也能 new（方便单测）
- 避免循环依赖时的隐藏问题

#### 3.3 @Autowired vs @Resource

| | @Autowired | @Resource |
| --- | --- | --- |
| 来源 | Spring | JSR-250 |
| 默认 | 按类型 | 按名称 |
| 配合 | @Qualifier 指定名称 | name 属性 |

#### 3.4 Bean 作用域

```java
@Component
@Scope("singleton")    // 单例（默认）
@Scope("prototype")    // 每次新建
```

**完全掌握标准：**
- ✅ 能用 @Service / @Autowired 写一个简单 Service
- ✅ 能解释为什么推荐构造注入
- ✅ 能解释 @Autowired vs @Resource
- ✅ 能解释 Bean 默认是单例的

---

### 4. Bean 生命周期（⭐重点 半天）

#### 4.1 生命周期 7 步

1. **实例化**：`new` Bean
2. **属性赋值**：注入依赖（@Autowired）
3. **Aware 接口回调**：如 `BeanNameAware`
4. **BeanPostProcessor 前置处理**
5. **初始化**：
   - `@PostConstruct` 注解方法
   - `InitializingBean.afterPropertiesSet`
   - 自定义 init-method
6. **BeanPostProcessor 后置处理**（AOP 在这里生效）
7. **使用**
8. **销毁**：
   - `@PreDestroy`
   - `DisposableBean.destroy`

#### 4.2 实战代码

```java
@Component
public class MyBean implements InitializingBean, DisposableBean {

    @PostConstruct
    public void init() {
        System.out.println("初始化");
    }

    @Override
    public void afterPropertiesSet() {
        System.out.println("afterPropertiesSet");
    }

    @PreDestroy
    public void cleanup() {
        System.out.println("销毁前");
    }

    @Override
    public void destroy() {
        System.out.println("destroy");
    }
}
```

**完全掌握标准：**
- ✅ 能背出生命周期的核心 7 步
- ✅ 能用 @PostConstruct 在 Bean 初始化时执行代码（常用于加载配置）
- ✅ 能解释 BeanPostProcessor 的作用

---

### 5. 循环依赖（⭐了解）

```
A 依赖 B，B 依赖 A
```

Spring 用**三级缓存**解决单例 Bean 的循环依赖（构造注入解决不了，会报错）。

**完全掌握标准：**
- ✅ 能解释为什么构造注入循环依赖会报错
- ✅ 知道三级缓存的存在（不强求细节）

---

### 6. AOP（⭐⭐重点 1 天）

#### 6.1 概念

**横切关注点（Cross-cutting Concerns）：** 多个业务方法共同需要的功能，如：
- 日志
- 事务
- 权限校验
- 性能监控

**AOP 让这些代码从业务方法中剥离。**

#### 6.2 核心术语

| 术语 | 含义 |
| --- | --- |
| Aspect（切面） | 一个类，里面定义增强逻辑 |
| Pointcut（切点） | 哪些方法被增强（表达式） |
| Advice（通知） | 增强逻辑（Before、After、Around） |
| JoinPoint（连接点） | 方法被增强的时刻 |
| Weaving（织入） | Spring 创建代理对象的过程 |

#### 6.3 5 种通知

```java
@Aspect
@Component
public class LogAspect {

    @Pointcut("execution(* com.xxx.service..*.*(..))")
    public void servicePointcut() {}

    @Before("servicePointcut()")
    public void before(JoinPoint jp) { ... }

    @After("servicePointcut()")
    public void after(JoinPoint jp) { ... }

    @AfterReturning(value = "servicePointcut()", returning = "result")
    public void afterReturning(JoinPoint jp, Object result) { ... }

    @AfterThrowing(value = "servicePointcut()", throwing = "e")
    public void afterThrowing(JoinPoint jp, Exception e) { ... }

    @Around("servicePointcut()")
    public Object around(ProceedingJoinPoint pjp) throws Throwable {
        long start = System.currentTimeMillis();
        Object result = pjp.proceed();
        System.out.println("耗时: " + (System.currentTimeMillis() - start));
        return result;
    }
}
```

#### 6.4 切点表达式

```java
execution(修饰符 返回值 包.类.方法(参数))

execution(* com.xxx.service.*.*(..))        // service 包下所有类的所有方法
execution(public * *(..))                    // 所有 public 方法
execution(* save*(..))                       // 所有 save 开头的方法
@annotation(com.xxx.MyAnnotation)            // 标注了 @MyAnnotation 的方法
@within(org.springframework.stereotype.Service)  // Service 类的所有方法
```

#### 6.5 AOP 底层

- 接口：JDK 动态代理（默认）
- 类：CGLIB 代理

**完全掌握标准：**
- ✅ 能写一个统计方法耗时的 AOP
- ✅ 能写一个日志 AOP（记录请求参数、返回值、异常）
- ✅ 能用 @annotation 切点（结合自定义注解）
- ✅ 能解释 JDK 代理 vs CGLIB 区别

---

### 7. SpringBoot 自动装配（⭐重点 半天）

#### 7.1 @SpringBootApplication

```java
@SpringBootApplication
public class MyApplication {
    public static void main(String[] args) {
        SpringApplication.run(MyApplication.class, args);
    }
}
```

`@SpringBootApplication` = `@SpringBootConfiguration` + `@EnableAutoConfiguration` + `@ComponentScan`

#### 7.2 自动装配原理

- `@EnableAutoConfiguration` 通过 `spring.factories`（SpringBoot 2.x）或 `META-INF/spring/...imports`（3.x）加载配置类
- 配置类用 `@Conditional` 决定是否生效
  - `@ConditionalOnClass`：classpath 有该类才生效
  - `@ConditionalOnMissingBean`：容器没有该 Bean 才生效
  - `@ConditionalOnProperty`：配置满足才生效

**例子：** 引入 `spring-boot-starter-data-redis`，因为 classpath 有 RedisTemplate，自动装配生效 → RedisTemplate Bean 自动注入。

**完全掌握标准：**
- ✅ 能解释 @SpringBootApplication 的 3 个核心注解
- ✅ 能解释自动装配的原理（Starter + spring.factories + @Conditional）
- ✅ 知道 SpringBoot 2.x 和 3.x 自动装配文件名的变化

---

### 8. 配置文件（半天）

#### 8.1 application.yml（推荐）

```yaml
server:
  port: 8080
  servlet:
    context-path: /api

spring:
  application:
    name: my-app
  profiles:
    active: dev

logging:
  level:
    com.xxx: DEBUG
    root: INFO
```

#### 8.2 多环境配置

```
application.yml         # 通用
application-dev.yml     # 开发
application-prod.yml    # 生产
```

激活方式：
- `spring.profiles.active=dev`
- 启动参数：`--spring.profiles.active=prod`

#### 8.3 读取配置

```java
// 方式 1：@Value
@Value("${server.port}")
private int port;

// 方式 2：@ConfigurationProperties（推荐多字段）
@ConfigurationProperties(prefix = "app")
@Data
@Component
public class AppConfig {
    private String name;
    private int maxSize;
}
```

```yaml
app:
  name: myapp
  max-size: 100
```

**完全掌握标准：**
- ✅ 能用 yml 配置端口、上下文路径
- ✅ 能配置多环境（dev/test/prod）
- ✅ 能用 @Value 和 @ConfigurationProperties 读取配置
- ✅ 知道 yml 命名规范（小写中划线 → 驼峰自动映射）

---

### 9. 日志（半天）

#### 9.1 SLF4J + Logback（SpringBoot 默认）

```java
private static final Logger log = LoggerFactory.getLogger(MyClass.class);

// 或用 Lombok
@Slf4j
public class MyService {
    public void doSth() {
        log.info("处理完成 userId={}", userId);
    }
}
```

#### 9.2 日志级别

`TRACE < DEBUG < INFO < WARN < ERROR`

#### 9.3 配置 logback-spring.xml

```xml
<configuration>
    <appender name="FILE" class="ch.qos.logback.core.rolling.RollingFileAppender">
        <file>logs/app.log</file>
        <rollingPolicy class="ch.qos.logback.core.rolling.TimeBasedRollingPolicy">
            <fileNamePattern>logs/app-%d{yyyy-MM-dd}.log</fileNamePattern>
            <maxHistory>30</maxHistory>
        </rollingPolicy>
        <encoder>
            <pattern>%d{HH:mm:ss.SSS} [%thread] %-5level %logger{36} - %msg%n</pattern>
        </encoder>
    </appender>
    <root level="INFO">
        <appender-ref ref="FILE"/>
    </root>
</configuration>
```

**完全掌握标准：**
- ✅ 能用 @Slf4j 打日志
- ✅ 能用占位符 `{}` 而不是字符串拼接
- ✅ 能配置日志按天滚动 + 保留 30 天
- ✅ 知道生产用 INFO，调试用 DEBUG

---

### 10. RESTful API 开发（1 天）

#### 10.1 RESTful 风格

| 方法 | 语义 | 示例 |
| --- | --- | --- |
| GET | 查 | GET /users/1 |
| POST | 增 | POST /users |
| PUT | 全量改 | PUT /users/1 |
| PATCH | 部分改 | PATCH /users/1 |
| DELETE | 删 | DELETE /users/1 |

#### 10.2 注解

```java
@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    @GetMapping("/{id}")
    public User getById(@PathVariable Long id) { ... }

    @GetMapping
    public List<User> list(@RequestParam(defaultValue = "1") int page,
                            @RequestParam(defaultValue = "10") int size) { ... }

    @PostMapping
    public User create(@RequestBody @Valid UserDTO dto) { ... }

    @PutMapping("/{id}")
    public User update(@PathVariable Long id, @RequestBody UserDTO dto) { ... }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) { ... }
}
```

#### 10.3 参数接收方式

| 注解 | 用途 |
| --- | --- |
| `@PathVariable` | URL 路径 `/users/{id}` |
| `@RequestParam` | URL 查询参数 `?page=1` |
| `@RequestBody` | 请求体 JSON |
| `@RequestHeader` | 请求头 |
| `@CookieValue` | Cookie |

**完全掌握标准：**
- ✅ 能写出完整的 CRUD API
- ✅ 能用 Postman / Apifox 测试
- ✅ 知道 GET 用 @RequestParam，POST 用 @RequestBody

---

### 11. 统一返回结构（半天）

#### 11.1 设计 Result 类

```java
@Data
@AllArgsConstructor
public class Result<T> {
    private int code;
    private String message;
    private T data;

    public static <T> Result<T> success(T data) {
        return new Result<>(200, "success", data);
    }

    public static <T> Result<T> error(int code, String msg) {
        return new Result<>(code, msg, null);
    }
}
```

#### 11.2 Controller 返回

```java
@GetMapping("/{id}")
public Result<User> getById(@PathVariable Long id) {
    return Result.success(userService.getById(id));
}
```

**进阶：** 用 `@ControllerAdvice + ResponseBodyAdvice` 自动包装。

**完全掌握标准：**
- ✅ 能设计 Result<T> 统一返回
- ✅ 能用 Result.success/error
- ✅ 知道前端怎么用（判断 code = 200）

---

### 12. 全局异常处理（半天）

```java
@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    @ExceptionHandler(BusinessException.class)
    public Result<?> handleBiz(BusinessException e) {
        log.warn("业务异常: {}", e.getMessage());
        return Result.error(e.getCode(), e.getMessage());
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Result<?> handleValid(MethodArgumentNotValidException e) {
        String msg = e.getBindingResult().getFieldErrors().stream()
            .map(f -> f.getField() + ": " + f.getDefaultMessage())
            .collect(Collectors.joining("; "));
        return Result.error(400, msg);
    }

    @ExceptionHandler(Exception.class)
    public Result<?> handleAll(Exception e) {
        log.error("系统异常", e);
        return Result.error(500, "系统异常");
    }
}
```

**完全掌握标准：**
- ✅ 能用 @RestControllerAdvice 写全局异常处理
- ✅ 能区分业务异常和系统异常
- ✅ 能让前端拿到统一的错误响应

---

### 13. 参数校验（半天）

```java
@Data
public class UserDTO {
    @NotBlank(message = "用户名不能为空")
    @Length(min = 2, max = 20, message = "用户名 2-20 字符")
    private String name;

    @NotNull(message = "年龄不能为空")
    @Min(value = 0, message = "年龄非法")
    @Max(value = 150)
    private Integer age;

    @Email(message = "邮箱格式错误")
    private String email;
}

@PostMapping
public Result<?> create(@RequestBody @Valid UserDTO dto) { ... }
```

**完全掌握标准：**
- ✅ 能用 JSR-303 注解（@NotBlank、@Email、@Min 等）
- ✅ 知道 @Valid 和 @Validated 的区别（后者支持分组）
- ✅ 能配合全局异常处理返回友好错误

---

## 二、每日学习安排

| 天 | 学习内容 | 上机练习 | 时长 |
| --- | --- | --- | --- |
| **周一** | Spring 概念 + 创建项目 + 第一个 Controller | HelloController + 多个 GET | 5h |
| **周二** | IOC + Bean + 注入 + 生命周期 | 用 @Service + @Autowired 调用 | 6h |
| **周三** | AOP ⭐ | 实现耗时统计 AOP + 日志 AOP | 6h |
| **周四** | 自动装配 + 配置文件 + 多环境 | 拆 dev/prod 配置 + 读取配置 | 5h |
| **周五** | 日志 + RESTful API | CRUD 接口 | 6h |
| **周六** | 统一返回 + 全局异常 + 参数校验 ⭐ | 改造接口，统一规范 | 6h |
| **周日** | 复盘 + 综合项目 | 完成一个完整的"留言板" API | 6h |

---

## 三、本周必做实战项目

### 项目：留言板 API（含规范化）

**需求：**
- `POST /api/messages` 发布留言（需校验：内容 1~500 字）
- `GET /api/messages` 列表分页
- `GET /api/messages/{id}` 详情
- `DELETE /api/messages/{id}` 删除
- 暂时用 `ConcurrentHashMap` 当存储（下周整合 MySQL）

**规范要求：**
- ✅ 统一返回 Result<T>
- ✅ 参数校验 + 全局异常处理
- ✅ AOP 打印每个请求的耗时
- ✅ 日志规范（INFO 业务，ERROR 异常）
- ✅ 多环境配置（dev / prod 端口不同）
- ✅ 用 @Slf4j 打日志
- ✅ 构造注入

**验收：**
- ✅ Postman/Apifox 测试通过
- ✅ 参数错误返回 400 + 友好提示
- ✅ 日志清晰
- ✅ AOP 能打印耗时
- ✅ 提交 GitHub 并写 README

---

## 四、完全掌握检查清单

### Spring 思想
- [ ] 能解释 IOC、DI、AOP
- [ ] 能解释 SpringBoot 解决了什么问题
- [ ] 能解释为什么推荐构造注入

### Bean
- [ ] 会用 @Component / @Service / @Controller
- [ ] 会用 @Autowired / @Resource
- [ ] 能背出 Bean 生命周期核心步骤
- [ ] 知道 Bean 默认单例

### AOP
- [ ] 能写一个耗时统计 AOP
- [ ] 能写一个日志 AOP
- [ ] 能写自定义注解 + AOP 组合
- [ ] 知道 JDK 代理 vs CGLIB

### SpringBoot
- [ ] 能解释 @SpringBootApplication
- [ ] 能解释自动装配原理
- [ ] 能配置多环境
- [ ] 能读取配置（@Value / @ConfigurationProperties）

### Web
- [ ] 能写出 CRUD RESTful API
- [ ] 能用 Postman 测试
- [ ] 能写统一返回 + 全局异常 + 参数校验
- [ ] 能用 @Slf4j 打日志

### 综合
- [ ] 完成留言板项目并提交 GitHub
- [ ] 写一篇 SpringBoot 学习总结

---

## 五、自测题

**Q1：** IOC 反转了什么？
**答案：** 反转了对象创建的控制权。原来由程序员 `new`，现在由 Spring 容器创建并注入。

---

**Q2：** Bean 默认是单例还是多例？
**答案：** 单例。每个 ApplicationContext 中只有一个实例。

---

**Q3：** @Autowired 和 @Resource 的区别？
**答案：**
- @Autowired：Spring 提供，按**类型**注入（多个时配合 @Qualifier）
- @Resource：JSR-250，按**名称**注入

---

**Q4：** 为什么推荐构造注入？
**答案：**
- 依赖一目了然
- 字段可以 final
- 不依赖 Spring 容器也能 new（方便单测）
- 避免循环依赖隐藏 bug

---

**Q5：** AOP 用了什么设计模式？
**答案：** **代理模式**。Spring 用 JDK 动态代理（接口）或 CGLIB（类）。

---

**Q6：** SpringBoot 是怎么自动装配的？
**答案：**
1. @EnableAutoConfiguration 扫描 `spring.factories` / `AutoConfiguration.imports`
2. 加载里面声明的配置类
3. 配置类用 @Conditional 决定是否生效

---

**Q7：** @Value 和 @ConfigurationProperties 的区别？
**答案：**
- @Value：单个字段，支持 SpEL
- @ConfigurationProperties：批量绑定，需要类，命名自动映射

---

## 六、常见坑与误区

| 坑 | 描述 | 解决 |
| --- | --- | --- |
| @Autowired 在 final 字段 | 编译失败 | 改用构造注入 |
| 同名 Bean 冲突 | NoUniqueBeanDefinitionException | @Qualifier 指定 |
| Bean 注入失败 | 没扫到（包不在启动类下） | @ComponentScan 或调整包结构 |
| AOP 内部调用失效 | 同一个类内方法调用绕过代理 | 注入自己 / 提取到另一个 Bean |
| 配置不生效 | yml 缩进错误 / 拼错 key | 用 IDE 配置提示 |
| 中文乱码 | 默认 ISO-8859-1 | spring.servlet.encoding.* |
| 端口被占 | 启动失败 | 改端口或杀进程 |
| @Valid 不生效 | 漏了注解 | 必须在 controller 方法参数加 @Valid |

---

## 七、推荐学习资源

### 视频
- 【B站】黑马程序员 SpringBoot 实战
- 【B站】尚硅谷 雷丰阳 SpringBoot 2

### 书籍
- 《Spring 实战（第 6 版）》
- 《SpringBoot 实战》

### 官方
- [Spring Boot Reference](https://docs.spring.io/spring-boot/docs/current/reference/htmlsingle/)
- [Spring Guides](https://spring.io/guides)

### 工具
- Postman / Apifox（API 测试）
- IDEA Ultimate（学生免费，强烈推荐）

---

## 八、本周完成后的"自我画像"

> "我能用 SpringBoot 5 分钟搭起一个项目，写出 RESTful API。
> 我懂 IOC、DI、AOP，能用 AOP 实现日志和耗时统计。
> 我能用统一返回 + 全局异常 + 参数校验让代码更规范。
> 我能配置多环境、读取配置、打印结构化日志。
> 我完成了留言板项目并提交了 GitHub。"

---

## 九、下周预告

第 8 周：**数据库整合**。
你会把第 5 周学的 MySQL 与 SpringBoot 联起来，引入 MyBatis Plus 提升开发效率，加入 JWT 登录、Swagger 文档，把项目做得更"企业级"。

下周见！💪
