# 第 6 周：Redis

> **本周学习目标**：掌握 Redis 5 大数据结构、缓存设计模式、持久化、分布式锁、Lua 脚本，能解决"缓存穿透/击穿/雪崩"等经典问题。
>
> **本周关键词**：String、Hash、List、Set、ZSet、缓存三大问题、持久化、分布式锁、Lua
>
> **预计投入时间**：35~45 小时

---

## 一、本周知识点详细分解

### 1. Redis 基础与安装（半天）

#### 1.1 Redis 是什么

- 内存型 **K-V 数据库**
- 单线程（IO 多路复用），快（10 万+ QPS）
- 支持多种数据结构
- 支持持久化（RDB + AOF）

#### 1.2 安装

**推荐方式：Docker**（最简单）
```bash
docker run -d --name redis -p 6379:6379 redis:7
```

**客户端工具：**
- 命令行 `redis-cli`
- **RedisInsight**（官方 GUI）
- **Another Redis Desktop Manager**
- IDEA 插件

**完全掌握标准：**
- ✅ 能在 10 分钟内装好 Redis 并连上
- ✅ 知道 Redis 默认端口 6379
- ✅ 能用 `redis-cli` 执行命令

---

### 2. 通用命令（半天）

```bash
SET key value
GET key
DEL key
EXISTS key
KEYS pattern        # ❌ 生产禁用，O(n) 阻塞
SCAN 0 MATCH user:*   # ✅ 替代 KEYS

EXPIRE key 60        # 过期 60 秒
TTL key              # 查剩余时间（-1 永久, -2 不存在）
PERSIST key          # 取消过期

TYPE key             # 查类型
DBSIZE               # 当前库 key 数量
FLUSHDB              # 清当前库
FLUSHALL             # 清所有库（生产慎用）

SELECT 0~15          # 切换库（默认 16 个）
INFO                 # 服务器信息
```

**完全掌握标准：**
- ✅ 能用 `SET/GET/DEL/EXISTS`
- ✅ 知道 KEYS 生产禁用，要用 SCAN
- ✅ 能为 key 设过期时间并查询 TTL

---

### 3. Redis 数据结构详解（2 天）

### 3.1 String（字符串）

**最基础也最重要。**

#### 常用命令

```bash
SET key value
GET key
SETEX key 60 value         # 带过期
SETNX key value            # 不存在才设
SET key value EX 60 NX     # 组合：过期 + 不存在才设

INCR key                   # +1
DECR key                   # -1
INCRBY key 10              # +10
INCRBYFLOAT key 1.5        # 浮点

APPEND key "world"         # 追加
STRLEN key                 # 长度

MSET k1 v1 k2 v2
MGET k1 k2
```

#### 应用场景

- 缓存对象（JSON 字符串）
- 计数器（点赞数、阅读数）
- 分布式锁（SETNX）
- 限流（INCR + 过期）
- 验证码

**完全掌握标准：**
- ✅ 能用 String 实现计数器
- ✅ 能用 `SET key value EX 60 NX` 实现简单分布式锁
- ✅ 能存对象（JSON 序列化）

---

### 3.2 Hash（哈希）

**类似 HashMap，适合存对象。**

#### 命令

```bash
HSET user:1 name "Alice" age 20
HGET user:1 name
HGETALL user:1
HMSET user:1 name "X" age 25      # 一次设多个
HMGET user:1 name age
HDEL user:1 name
HEXISTS user:1 name
HINCRBY user:1 age 1
HLEN user:1
HKEYS user:1
HVALS user:1
```

#### 应用场景

- 存储对象（比 String 存 JSON 更节省空间，可单独修改字段）
- 购物车（user_id → {product_id: count}）
- 配置信息

**完全掌握标准：**
- ✅ 能用 Hash 存用户对象，单独更新某字段
- ✅ 能用 Hash 实现购物车

---

### 3.3 List（列表）

**双向链表，可作队列、栈。**

#### 命令

```bash
LPUSH list a b c       # 左插：[c, b, a]
RPUSH list x y z       # 右插：[..., x, y, z]
LRANGE list 0 -1       # 查全部
LPOP list              # 左弹
RPOP list              # 右弹
LLEN list              # 长度

BLPOP list 0           # 阻塞左弹（队列）
BRPOP list 0
```

#### 应用场景

- 消息队列（LPUSH + BRPOP）
- 最新 N 条记录（LPUSH + LTRIM）
- 浏览历史
- 朋友圈点赞列表

**完全掌握标准：**
- ✅ 能用 List 实现简单消息队列
- ✅ 能用 LPUSH + LTRIM 保留最新 N 条
- ✅ 知道 BLPOP 阻塞读

---

### 3.4 Set（集合）

**无序、不重复。**

#### 命令

```bash
SADD set a b c
SMEMBERS set
SISMEMBER set a
SREM set a
SCARD set                   # 大小

SINTER s1 s2                # 交集
SUNION s1 s2                # 并集
SDIFF s1 s2                 # 差集
SRANDMEMBER set 3           # 随机取 3 个
SPOP set                    # 随机弹出
```

#### 应用场景

- 标签（用户标签、文章标签）
- 共同好友（SINTER）
- 抽奖（SRANDMEMBER / SPOP）
- 黑名单
- 去重

**完全掌握标准：**
- ✅ 能用 Set 实现"共同好友"
- ✅ 能用 SPOP 实现抽奖

---

### 3.5 ZSet（有序集合，⭐重点）

**每个元素带 score，按 score 排序。**

#### 命令

```bash
ZADD rank 90 Alice 85 Bob 95 Charlie
ZRANGE rank 0 -1                           # 升序
ZRANGE rank 0 -1 WITHSCORES                # 带 score
ZREVRANGE rank 0 -1                        # 降序
ZRANGEBYSCORE rank 80 90                   # 按 score 范围
ZINCRBY rank 5 Alice                       # 增加 score

ZRANK rank Alice                           # 升序排名
ZREVRANK rank Alice                        # 降序排名
ZSCORE rank Alice                          # 取 score
ZREM rank Alice
ZCARD rank
```

#### 应用场景

- **排行榜**（最经典）
- 延迟队列（score 是执行时间）
- 热搜
- 范围查询（按时间、按权重）

**完全掌握标准：**
- ✅ 能用 ZSet 实现游戏积分排行榜
- ✅ 能用 ZSet 实现简单延迟队列
- ✅ 能用 ZRANGEBYSCORE 范围查询

---

### 4. 其他数据结构（半天，了解）

- **Bitmap**：位图，存布尔状态（签到、活跃用户）
- **HyperLogLog**：基数估算（UV 统计，误差 0.81%）
- **Geo**：地理位置（附近的人）
- **Stream**：消息流（5.0+，类 Kafka）

```bash
# Bitmap 签到
SETBIT user:1:sign:202405 13 1
GETBIT user:1:sign:202405 13
BITCOUNT user:1:sign:202405

# HyperLogLog UV
PFADD page:uv user1 user2 user3
PFCOUNT page:uv
```

---

### 5. 缓存设计模式（⭐⭐重点，1 天）

#### 5.1 Cache-Aside（最常用）

```
读：
1. 查 Redis
2. 未命中查 MySQL
3. 写回 Redis
4. 返回

写：
1. 写 MySQL
2. 删除 Redis（不是更新，避免并发问题）
```

#### 5.2 Read/Write Through

应用只与缓存交互，缓存自己同步数据库。复杂，少用。

#### 5.3 Write Back

只写缓存，异步刷数据库。性能高但可能丢数据。

---

### 6. 缓存三大问题（⭐⭐⭐重点）

#### 6.1 缓存穿透（Penetration）

**问题：** 查一个数据库**不存在**的 key（恶意攻击常见），每次都打到 MySQL。

**解决：**
1. **缓存空值**：MySQL 没查到也缓存 `null`（设短过期，1~5 分钟）
2. **布隆过滤器（BloomFilter）**：提前过滤不存在的 key
3. 接口层做参数校验（拒绝非法 ID）

#### 6.2 缓存击穿（Breakdown）

**问题：** **热点 key** 突然过期，瞬间大量请求打到 MySQL。

**解决：**
1. **互斥锁（推荐）**：只让一个线程查库，其他等待
2. **热点 key 永不过期**（或后台异步刷新）
3. 逻辑过期：value 里存过期时间，过期后异步刷新

```java
// 互斥锁伪代码
String value = redis.get(key);
if (value == null) {
    if (redis.setnx(lockKey, "1", 10)) {  // 加锁
        try {
            value = mysql.get(key);
            redis.set(key, value, 60);
        } finally {
            redis.del(lockKey);
        }
    } else {
        Thread.sleep(50);
        return get(key);  // 重试
    }
}
```

#### 6.3 缓存雪崩（Avalanche）

**问题：** 大量 key 同时过期 / Redis 宕机，全部请求打到 MySQL。

**解决：**
1. **过期时间加随机数**：避免同时过期 `expire = base + random(0, 300)`
2. **多级缓存**：本地缓存（Caffeine） + Redis
3. **熔断降级**：MySQL 压力大时返回默认值
4. **Redis 高可用**：主从、哨兵、集群

**完全掌握标准：**
- ✅ 能用一句话解释 3 个问题的区别
- ✅ 能写出 3 种解决方案
- ✅ 能用伪代码实现互斥锁防止击穿
- ✅ 知道布隆过滤器是什么（位数组 + 多个哈希）

---

### 7. 缓存一致性（⭐重点）

#### 7.1 4 种方案

1. **先更新数据库，再更新缓存** ❌ 并发问题
2. **先删缓存，再更新数据库** ❌ 并发问题（读线程把旧值写回）
3. **先更新数据库，再删缓存**（**推荐**）✅
4. **延迟双删**：删 → 写库 → sleep → 再删

#### 7.2 终极方案：消息队列 + binlog

用 Canal 监听 MySQL binlog，异步更新 Redis（保证最终一致性）。

**完全掌握标准：**
- ✅ 能解释为什么"先删缓存再更新库"有并发问题
- ✅ 能解释"先更库再删缓存"的潜在问题（删缓存失败、读到旧值瞬间）
- ✅ 知道延迟双删
- ✅ 知道 binlog + canal 方案

---

### 8. 持久化（⭐重点 半天）

#### 8.1 RDB（默认）

- **快照**：把当前内存数据写入磁盘
- 触发：定时（save 配置） / `BGSAVE` 命令 / 主从同步
- **优点**：恢复快、文件小
- **缺点**：宕机时可能丢失最后一次快照后的数据

#### 8.2 AOF

- **追加日志**：每条写命令追加到 .aof 文件
- 触发：`appendfsync` 配置
  - `always`：每次写都刷盘，最安全但慢
  - `everysec`（默认）：每秒刷盘，平衡
  - `no`：交给操作系统，最快但可能丢更多
- **优点**：丢数据少（最多 1 秒）
- **缺点**：文件大、恢复慢

#### 8.3 混合持久化（4.0+）

AOF 文件 = RDB 全量 + 增量 AOF 命令。结合两者优点。

**完全掌握标准：**
- ✅ 能解释 RDB vs AOF 区别
- ✅ 能解释 AOF 三种刷盘策略
- ✅ 知道生产推荐 AOF + everysec 或混合持久化

---

### 9. 分布式锁（⭐重点 半天）

#### 9.1 简单实现

```bash
SET lock "owner_id" EX 10 NX
# 操作...
# 解锁前判断 owner_id 是否一致（Lua 脚本保证原子）
```

#### 9.2 问题与改进

| 问题 | 解决 |
| --- | --- |
| 业务超时，锁自动释放，被别人拿走 | 锁续期（看门狗） |
| 误删别人的锁 | value 设唯一标识，解锁前比对 |
| 主从切换丢锁 | RedLock 算法（5 节点过半成功） |

#### 9.3 Redisson（生产推荐）

```java
RLock lock = redisson.getLock("myLock");
lock.lock();        // 自动续期
try {
    // 业务
} finally {
    lock.unlock();
}
```

**完全掌握标准：**
- ✅ 能用 SETNX + EX 实现简单分布式锁
- ✅ 能解释为什么需要原子性（Lua 解锁）
- ✅ 能解释看门狗机制（Redisson 默认 10 秒续期）
- ✅ 了解 RedLock 算法

---

### 10. Lua 脚本（半天）

#### 10.1 为什么用 Lua

- **原子性**：脚本内多命令一起执行，中间不会被打断
- 减少网络往返

#### 10.2 示例：分布式锁解锁

```lua
if redis.call("get", KEYS[1]) == ARGV[1] then
    return redis.call("del", KEYS[1])
else
    return 0
end
```

```bash
EVAL "上面的脚本" 1 lockKey ownerId
```

#### 10.3 示例：限流（令牌桶/计数器）

```lua
local count = redis.call("incr", KEYS[1])
if count == 1 then
    redis.call("expire", KEYS[1], ARGV[1])
end
if count > tonumber(ARGV[2]) then
    return 0
else
    return 1
end
```

**完全掌握标准：**
- ✅ 能写 Lua 实现"原子比较并删除"
- ✅ 能用 Lua 实现限流计数器

---

### 11. Redis 高可用与集群（半天，了解）

#### 11.1 主从复制

- 一主多从，从节点同步主节点数据
- 读写分离（主写从读）

#### 11.2 哨兵（Sentinel）

- 监控主节点
- 主节点宕机自动选举新主

#### 11.3 集群（Cluster）

- 数据分片（16384 个槽）
- 每个节点负责一部分槽
- 节点间通信用 gossip 协议

**完全掌握标准：**
- ✅ 能解释主从、哨兵、集群的区别
- ✅ 了解 16384 槽的概念

---

## 二、每日学习安排

| 天 | 学习内容 | 上机练习 | 时长 |
| --- | --- | --- | --- |
| **周一** | 安装 + 通用命令 + String | 实现计数器、验证码缓存 | 4h |
| **周二** | Hash + List + Set | 实现购物车 + 消息队列 + 共同好友 | 6h |
| **周三** | ZSet ⭐ + Bitmap + HyperLogLog | 排行榜 + 签到统计 + UV 统计 | 6h |
| **周四** | 缓存设计 + 三大问题 ⭐ | 用代码模拟穿透/击穿/雪崩 | 6h |
| **周五** | 缓存一致性 + 持久化 | 配置 RDB + AOF | 5h |
| **周六** | 分布式锁 + Lua 脚本 ⭐ | 实现秒杀库存扣减（含 Lua） | 6h |
| **周日** | 高可用 + 复盘 | 综合项目 + 提交 GitHub | 6h |

---

## 三、本周必做实战项目

### 项目 1：登录验证码服务

**功能：**
- 接口 1：生成验证码（4 位数字），存 Redis，5 分钟过期
- 接口 2：验证验证码（一致就清除，3 次失败锁定 10 分钟）
- 用 Java（或暂时用 redis-cli 模拟流程）

**Redis 设计：**
```
sms:code:13800000000  → "1234"  TTL 300
sms:fail:13800000000  → 0~3     TTL 600
sms:lock:13800000000  → 1       TTL 600
```

**验收：**
- ✅ 验证码 5 分钟自动清除
- ✅ 3 次失败锁定
- ✅ Lua 脚本保证原子性（可选）

---

### 项目 2：秒杀库存扣减（核心）

**场景：** 1000 个用户同时抢 100 件商品。

**Redis 设计：**
```
seckill:stock:1001  → 100   (库存)
seckill:user:1001   → SET   (已抢用户)
```

**Lua 脚本：**
```lua
local stock = tonumber(redis.call("get", KEYS[1]))
local userId = ARGV[1]
local hasBought = redis.call("sismember", KEYS[2], userId)
if hasBought == 1 then return -1 end   -- 重复抢
if stock <= 0 then return 0 end        -- 库存不足
redis.call("decr", KEYS[1])
redis.call("sadd", KEYS[2], userId)
return 1                                -- 成功
```

**验收：**
- ✅ 1000 并发下库存不会负数
- ✅ 同一用户不能重复抢
- ✅ 用 JMeter 或自写多线程测试

---

### 项目 3：游戏排行榜

**场景：** 玩家上传分数，查 Top 10、查自己排名。

**Redis 设计：**
```
game:rank  → ZSet  member=userId score=分数
```

**接口：**
- 上传分数：`ZADD game:rank score userId`
- Top 10：`ZREVRANGE game:rank 0 9 WITHSCORES`
- 我的排名：`ZREVRANK game:rank userId`
- 我前后 5 名：`ZREVRANGE game:rank (rank-5) (rank+5)`

**验收：**
- ✅ 实时更新
- ✅ 取 Top N 性能 < 10ms

---

## 四、完全掌握检查清单

### 数据结构
- [ ] 能为 5 大类型各举一个应用场景
- [ ] 能用 Hash 存对象
- [ ] 能用 List 实现简单队列
- [ ] 能用 Set 实现共同好友
- [ ] 能用 ZSet 实现排行榜

### 缓存问题
- [ ] 能用一句话区分穿透、击穿、雪崩
- [ ] 能写出每种问题的至少 2 种解决方案
- [ ] 能写互斥锁防止击穿

### 一致性
- [ ] 能解释为什么先删缓存再更新库有问题
- [ ] 能解释延迟双删
- [ ] 了解 binlog + Canal 方案

### 持久化
- [ ] 能解释 RDB vs AOF 区别
- [ ] 能配置 AOF everysec

### 分布式锁
- [ ] 能用 SETNX 实现简单锁
- [ ] 能用 Lua 原子解锁
- [ ] 能解释看门狗机制

### Lua
- [ ] 能写"判断 + 操作"的原子 Lua

### 综合
- [ ] 完成验证码、秒杀、排行榜 3 个项目
- [ ] 提交 GitHub

---

## 五、自测题

**Q1：** 为什么 Redis 这么快？
**答案：**
- 内存存储
- 单线程，无上下文切换、无锁竞争
- IO 多路复用（epoll）
- 高效数据结构（SDS、跳表）

---

**Q2：** Redis 是单线程的吗？
**答案：** 命令执行是单线程，但 6.0+ 引入了多线程处理网络 IO。

---

**Q3：** 假设有热点 key 突然过期，怎么处理？
**答案：**
- 互斥锁（SETNX）让一个线程查库
- 永不过期 + 异步刷新
- 提前续期

---

**Q4：** Redis 怎么实现延迟队列？
**答案：** ZSet，score 设为执行时间戳。后台轮询取出 `score < now()` 的元素。

---

**Q5：** Redis 内存淘汰策略有哪些？
**答案：**
- noeviction：不淘汰（默认）
- allkeys-lru / volatile-lru：LRU
- allkeys-lfu / volatile-lfu：LFU（4.0+）
- allkeys-random / volatile-random：随机
- volatile-ttl：将要过期的优先

---

**Q6：** 用 SETNX 实现的简单分布式锁有什么问题？
**答案：**
- 没有过期时间 → 业务异常导致锁永远不释放（用 `SET ... EX NX`）
- 锁被别人误删（value 加唯一标识 + Lua）
- 业务执行超过锁时间（看门狗续期）
- 主从切换丢锁（RedLock）

---

**Q7：** Redis 的 ZSet 底层是什么？
**答案：** **跳表（skiplist） + 哈希表**。元素少时（128 个以内）用 ziplist。

---

## 六、常见坑与误区

| 坑 | 描述 | 解决 |
| --- | --- | --- |
| KEYS * 阻塞 | 大量 key 时卡死 | 用 SCAN |
| 大 key | 单 key 几 MB 影响性能 | 拆分 |
| 热 key | 单 key 高 QPS 打挂节点 | 多副本 / 本地缓存 |
| 没设过期 | 内存爆炸 | 必须设 TTL |
| 缓存与库不一致 | 直接更新缓存导致并发问题 | 删除缓存 |
| 分布式锁不原子 | 误删别人锁 | Lua |
| FLUSHALL 生产执行 | 全清 | 禁用危险命令 |
| 字符串当 JSON 反复反序列化 | 性能差 | 用 Hash |

---

## 七、推荐学习资源

### 视频
- 【B站】黑马程序员 Redis 入门到实战
- 【B站】尚硅谷 Redis 6 教程

### 书籍
- 《Redis 设计与实现》（黄健宏）——原理必读
- 《Redis 开发与运维》（付磊）——实战
- 《Redis 实战》

### 官方
- [Redis 官方文档](https://redis.io/docs/)
- [Redis 命令参考](https://redis.io/commands/)

### 工具
- RedisInsight（官方 GUI）
- [Redisson 文档](https://github.com/redisson/redisson)

---

## 八、本周完成后的"自我画像"

> "我能熟练用 Redis 5 大数据结构解决实际问题。
> 我能用一句话区分缓存穿透/击穿/雪崩，并写出对应解决方案。
> 我懂 Cache-Aside 模式和缓存一致性方案。
> 我能用 SETNX + Lua 实现分布式锁。
> 我完成了验证码、秒杀、排行榜 3 个项目。"

---

## 九、下周预告

第 7 周进入 **SpringBoot 核心**——Java 后端的事实标准框架。
你会真正开始写"企业级"代码，告别控制台 demo。
本周 Redis、上周 MySQL 都会在 SpringBoot 项目里整合。

下周见！💪
