# 第 20 周：AI 项目实战

> **本周学习目标**：把前 3 周（17/18/19 周）AI 知识整合成**一个完整的 AI 应用**，作为简历上的"AI 项目"。
>
> **本周关键词**：完整 AI 应用、RAG、Agent、流式、前后端联调、Docker、文档、面试讲解
>
> **预计投入时间**：45~55 小时（项目周，时间投入大）

---

## 一、项目选型（三选一）

### 选项 A：企业 AI 知识库（推荐⭐入门友好）

**业务场景：** 公司内部知识检索 + 问答助手

**功能模块：**
- 文档管理（上传 PDF/Word/Markdown）
- 智能问答（流式输出 + 引用来源）
- 历史对话
- 知识库管理（分类、权限）
- 后台管理（用户、文档统计）

**技术亮点：**
- LangChain RAG
- 多种文档源
- 向量数据库
- 流式 SSE
- React Chat UI

---

### 选项 B：AI Agent 系统（推荐⭐中级）

**业务场景：** 自动化日报 / 代码审查 / SQL 助手

**子项目（选 1~2 个）：**

#### B1：自动日报 Agent
- 工具：读 Git log、读 PR、读 Jira
- 流程：Agent 调用工具收集 → 总结 → 生成日报
- 输出：Markdown 日报 + 发邮件

#### B2：代码审查 Agent
- 工具：读 GitHub PR、调用 LSP
- 流程：分析 diff → 提建议 → 评论 PR
- 输出：评审报告

#### B3：SQL Agent
- 工具：查表结构、执行 SQL（白名单）
- 流程：自然语言 → SQL → 执行 → 解释
- 输出：表格 + 图表

**技术亮点：**
- LangGraph 工作流
- 工具调用（Function Calling）
- 多 Agent 协作
- 安全沙箱

---

### 选项 C：AI 客服系统（推荐⭐企业向）

**业务场景：** 电商 / SaaS 客服

**功能：**
- 接入企业知识库（FAQ）
- RAG 回答常见问题
- 不懂的转人工
- 工单系统
- 后台监控

**技术亮点：**
- RAG + 多轮对话
- 工单流转（用第 11 周的 MQ）
- 对话日志分析

---

**本文档以"选项 A：AI 知识库"为例展开。其他选项思路类似。**

---

## 二、系统架构

```
                ┌─────────────────────┐
                │   前端（React）       │
                │ - 对话 UI            │
                │ - 文档上传            │
                │ - 知识库管理          │
                │ - 历史会话            │
                └──────────┬──────────┘
                           │ HTTP / SSE
                ┌──────────▼──────────┐
                │   FastAPI 后端        │
                │ ├─ 用户/认证（JWT）    │
                │ ├─ 文档上传 + 解析     │
                │ ├─ 对话 API（SSE）    │
                │ └─ RAG 引擎          │
                └──┬──────┬──────┬─────┘
                   │      │      │
              ┌────▼┐ ┌──▼──┐ ┌─▼────────┐
              │MySQL│ │Redis│ │ Chroma    │
              └─────┘ └─────┘ │向量数据库  │
                              └─┬─────────┘
                                │
                       ┌────────▼────────┐
                       │   LLM (DeepSeek) │
                       │   Embedding 模型 │
                       └─────────────────┘
```

---

## 三、技术栈

| 类别 | 技术 |
| --- | --- |
| 后端 | FastAPI + Pydantic |
| AI 框架 | LangChain |
| 数据库 | MySQL（业务数据） + Chroma（向量） |
| 缓存 | Redis（对话历史 + 限流） |
| LLM | DeepSeek / OpenAI / Claude |
| 前端 | React + Vite + Ant Design + react-markdown |
| 文档解析 | pypdf、python-docx |
| 部署 | Docker + docker-compose |

---

## 四、本周每日安排

### 周一：项目设计 + 后端基础

**任务：**
1. 写需求文档（功能列表、用户故事）
2. 设计数据库：
   - users
   - knowledge_bases（知识库）
   - documents（文档）
   - chunks（切片，含向量 ID 索引）
   - chat_sessions（会话）
   - chat_messages（消息）
3. 设计接口：
   - 认证：register / login / me
   - 知识库：create / list / delete
   - 文档：upload / list / delete
   - 对话：sessions CRUD / chat（SSE）
4. FastAPI 项目骨架 + JWT 认证

**验收：**
- ✅ 数据库表设计完成
- ✅ 接口列表（至少 15 个）
- ✅ JWT 注册登录通过

---

### 周二：文档上传 + 解析 + 切分 + 入库

**任务：**

1. **文档上传接口**：
```python
@router.post("/documents/upload")
async def upload(kb_id: int, file: UploadFile, user: User = Depends(get_current_user)):
    # 1. 保存文件
    # 2. 解析（用 LangChain Loader）
    # 3. 切分
    # 4. 向量化 + 存 Chroma
    # 5. 元信息存 MySQL
```

2. **支持格式**：PDF / DOCX / TXT / MD

3. **切分策略**：
```python
splitter = RecursiveCharacterTextSplitter(
    chunk_size=500,
    chunk_overlap=50,
    separators=["\n\n", "\n", "。"]
)
```

4. **Chroma 集合命名**：`kb_{kb_id}` 实现多知识库隔离

**验收：**
- ✅ 4 种文档格式都能上传 + 解析
- ✅ Chroma 能看到向量
- ✅ MySQL 中有文档元信息

---

### 周三：RAG 问答接口（核心⭐）

**任务：**

1. **构建 RAG Chain**：

```python
def build_rag_chain(kb_id: int):
    vectorstore = Chroma(
        collection_name=f"kb_{kb_id}",
        embedding_function=embeddings,
        persist_directory="./chroma_db"
    )
    retriever = vectorstore.as_retriever(search_kwargs={"k": 4})

    prompt = ChatPromptTemplate.from_template("""
你是知识库助手。请基于参考信息回答问题。

参考信息：
{context}

历史对话：
{history}

问题：{question}

要求：
1. 仅基于参考信息回答，找不到就说不知道
2. 引用文档来源（编号 1 2 3）
""")

    chain = (
        {"context": retriever | format_docs,
         "history": RunnablePassthrough(),
         "question": RunnablePassthrough()}
        | prompt
        | llm
        | StrOutputParser()
    )
    return chain, retriever
```

2. **流式输出**：

```python
@router.post("/chat/{session_id}/stream")
async def chat_stream(session_id: int, req: ChatRequest, user = Depends(...)):
    session = get_session(session_id, user.id)
    history = load_history(session_id)

    chain, retriever = build_rag_chain(session.kb_id)

    async def gen():
        full = ""
        # 检索（拿来源）
        docs = retriever.invoke(req.message)
        sources = [{"file": d.metadata['file'], "page": d.metadata.get('page')} for d in docs]
        yield f"data: {json.dumps({'type': 'sources', 'data': sources})}\n\n"

        # 流式回答
        async for chunk in chain.astream(req.message):
            full += chunk
            yield f"data: {json.dumps({'type': 'token', 'data': chunk})}\n\n"

        yield "data: [DONE]\n\n"

        # 保存到 DB
        save_message(session_id, "user", req.message)
        save_message(session_id, "assistant", full, sources)

    return StreamingResponse(gen(), media_type="text/event-stream")
```

3. **历史对话窗口**：保留最近 10 轮，防止 token 爆

**验收：**
- ✅ 问问题能正确返回
- ✅ 包含来源引用
- ✅ 流式输出
- ✅ 多轮对话能记住上文

---

### 周四：前端 UI（聊天界面）

**任务：**

1. **页面**：
   - 登录 / 注册
   - 主界面：左侧会话列表 + 中间聊天 + 右侧文档列表
   - 知识库管理页

2. **聊天 UI 核心：流式渲染**

```jsx
import { useState } from 'react';
import ReactMarkdown from 'react-markdown';

function ChatPanel({ sessionId }) {
    const [messages, setMessages] = useState([]);
    const [input, setInput] = useState('');
    const [streaming, setStreaming] = useState(false);

    async function send() {
        const userMsg = { role: 'user', content: input };
        setMessages(m => [...m, userMsg, { role: 'assistant', content: '', sources: [] }]);
        setInput('');
        setStreaming(true);

        const res = await fetch(`/api/chat/${sessionId}/stream`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ message: input })
        });

        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            buffer += decoder.decode(value);
            const lines = buffer.split('\n\n');
            buffer = lines.pop();
            for (const line of lines) {
                if (line.startsWith('data: ')) {
                    const text = line.slice(6);
                    if (text === '[DONE]') continue;
                    const data = JSON.parse(text);
                    setMessages(m => {
                        const last = m[m.length - 1];
                        if (data.type === 'token') {
                            return [...m.slice(0, -1), { ...last, content: last.content + data.data }];
                        } else if (data.type === 'sources') {
                            return [...m.slice(0, -1), { ...last, sources: data.data }];
                        }
                    });
                }
            }
        }
        setStreaming(false);
    }

    return (
        <div className="chat">
            <div className="messages">
                {messages.map((m, i) => (
                    <div key={i} className={`msg msg-${m.role}`}>
                        <ReactMarkdown>{m.content}</ReactMarkdown>
                        {m.sources && (
                            <div className="sources">
                                {m.sources.map((s, j) => <span key={j}>[{j+1}] {s.file}</span>)}
                            </div>
                        )}
                    </div>
                ))}
            </div>
            <div className="input">
                <input value={input} onChange={e => setInput(e.target.value)}
                       onKeyDown={e => e.key === 'Enter' && !streaming && send()} />
                <button onClick={send} disabled={streaming}>发送</button>
            </div>
        </div>
    );
}
```

3. **文档上传 UI**：拖拽 + 进度

**验收：**
- ✅ UI 接近 ChatGPT 风格
- ✅ 流式打字效果
- ✅ Markdown / 代码块正确渲染
- ✅ 文档上传有进度

---

### 周五：高级特性

**任务：**

1. **缓存优化**：
   - Redis 缓存高频问题的回答（5 分钟）
   - Embedding 计算缓存（避免重复计算）

2. **混合检索（可选）**：
   - 向量检索 + 关键词检索（BM25）
   - 用 `rank_bm25` 库

3. **Reranker**（可选）：
   - 用 BGE-reranker 重排检索结果

4. **限流**：
   - 每个用户每天 100 次问答（Redis 计数）
   - 每个 API 限流 10 QPS

5. **统计**：
   - 用户提问次数
   - 文档使用频率
   - Token 消耗

**验收：**
- ✅ 重复问答秒回（缓存命中）
- ✅ 超过限制返回 429
- ✅ 后台能看统计

---

### 周六：Docker 部署 + 性能优化

**任务：**

1. **写 Dockerfile**（后端 + 前端）
2. **docker-compose.yml**：
```yaml
services:
  mysql:
    image: mysql:8.0
    ...

  redis:
    image: redis:7-alpine
    ...

  chroma:
    image: chromadb/chroma:latest
    volumes:
      - chroma_data:/chroma/chroma
    ports:
      - "8001:8000"
    ...

  backend:
    build: ./backend
    environment:
      DEEPSEEK_API_KEY: ${DEEPSEEK_API_KEY}
    ...

  frontend:
    build: ./frontend
    ports:
      - "80:80"
    ...

volumes:
  mysql_data:
  redis_data:
  chroma_data:
```

3. **性能优化**：
   - 后端用 uvicorn workers
   - Chroma 用持久化
   - 大文件上传分片
   - 数据库索引

**验收：**
- ✅ `docker-compose up -d` 一键启动整套
- ✅ 重启数据不丢
- ✅ 100 并发问答稳定

---

### 周日：文档 + 测试 + 演示 + 上线

**任务：**

1. **README** 全面：
   - 项目介绍
   - 截图（至少 8 张）
   - 架构图
   - 部署步骤
   - API 文档（Swagger 链接）
   - 演示视频（用 Loom / 录屏）

2. **测试**：
   - 完整问答测试用例
   - 边界情况（大文件、奇怪格式、攻击 prompt）

3. **可选：上线**：
   - 阿里云 / 腾讯云学生服务器
   - 域名 + HTTPS
   - 公网访问的 demo（简历加分）

**验收：**
- ✅ README 写得别人能照着部署
- ✅ 至少 8 张截图
- ✅ 提交 GitHub（至少 30 次提交）
- ✅ （可选）有线上 demo URL

---

## 五、完全掌握检查清单

### 功能完整度
- [ ] 用户注册登录（JWT）
- [ ] 知识库管理（增删改查）
- [ ] 文档上传（4+ 种格式）
- [ ] 自动切分 + 向量化
- [ ] RAG 问答 + 引用来源
- [ ] 流式输出
- [ ] 多轮对话历史
- [ ] 至少 2 处优化（缓存 / 限流 / 混合检索）

### 工程化
- [ ] FastAPI 项目结构清晰
- [ ] 全局异常处理
- [ ] 参数校验（Pydantic）
- [ ] 日志规范
- [ ] 环境变量配置（.env）
- [ ] 多环境（dev / prod）

### 前端
- [ ] ChatGPT 风格 UI
- [ ] 流式打字效果
- [ ] Markdown 渲染
- [ ] 文档上传（拖拽 / 进度）
- [ ] 响应式布局

### 部署
- [ ] Docker 化
- [ ] docker-compose 一键启动
- [ ] 持久化（数据库 / 向量库）
- [ ] 健康检查

### 文档
- [ ] README 详尽
- [ ] 8+ 张截图
- [ ] 架构图
- [ ] 部署文档
- [ ] （可选）演示视频

---

## 六、面试讲解准备（重点⭐）

**3 分钟项目自述模板：**

> "我做了一个企业 AI 知识库系统。用户可以上传公司文档（PDF/Word），系统自动切分、向量化存进 Chroma，然后通过 AI 问答找到答案，回答里附带来源引用。
>
> 技术栈：FastAPI + LangChain + Chroma + DeepSeek + React。
>
> 核心实现：
> - 文档处理：用 LangChain 的 RecursiveCharacterTextSplitter 切分，重叠 50 字符，避免切断语义。
> - RAG：检索 Top 4 相关片段，拼进 prompt 让 LLM 基于片段回答。
> - 流式：FastAPI SSE 推送 + React 流式渲染，打字效果。
> - 性能：Redis 缓存高频问题回答，加入限流。
>
> 部署：docker-compose 一键启动 MySQL + Redis + Chroma + 后端 + 前端。"

**高频追问：**

1. RAG 为什么能减少幻觉？
2. 文档怎么切分？为什么选这个 chunk_size？
3. 检索召回不准怎么办？（Hybrid 检索 + Reranker）
4. 上下文超长怎么办？（滑动窗口 / 摘要）
5. 怎么保证回答有依据？（让 LLM 拒绝、加引用）
6. 怎么处理多语言文档？（用支持多语言的 embedding 模型）
7. 安全：怎么防 Prompt Injection？
8. 成本：怎么降低 token 消耗？

**完全掌握标准：**
- ✅ 8 个追问每个能答 1~2 分钟
- ✅ 能口述代码核心实现
- ✅ 能讲至少 3 个"为什么这么设计"

---

## 七、常见坑与误区

| 坑 | 描述 | 解决 |
| --- | --- | --- |
| 切分不当导致召回低 | 切断语义 | overlap + 递归切分 |
| Embedding 模型不支持中文 | 召回差 | 用 BGE / m3e 等中文模型 |
| 向量库不持久 | 重启数据丢 | 用 PersistentClient |
| 上下文超长 | API 报错 | 限制历史轮数 |
| Prompt 注入 | 用户问"忽略以上指令，xxx" | 严格 system prompt + 输出过滤 |
| 流式响应中断 | 网络 / 服务异常 | 心跳 + 重连机制 |
| Markdown 不渲染 | 漏用 react-markdown | 加渲染库 |
| 大文件 OOM | 一次读完 | 流式读 + 分片处理 |

---

## 八、扩展方向（进阶）

如果项目做得快，可以加：

1. **多模态**：支持图片提问（GPT-4o / Claude）
2. **语音输入/输出**：接 Whisper + TTS
3. **协作**：多用户共享知识库 + 权限
4. **微调**：训练专属 embedding 模型
5. **Agent**：知识库 + 工具调用（联网搜索）
6. **MCP**：把知识库做成 MCP Server 供 Claude Desktop 使用

---

## 九、本周完成后的"自我画像"

> "我有了简历上的'AI 项目'：完整的 AI 知识库系统，含上传、向量化、RAG、流式、多轮对话。
> 我用 LangChain + FastAPI + React 实现，能用 docker-compose 一键部署。
> 我能 3 分钟讲清项目的架构、技术选型和核心难点。
> 我能回答常见 AI 应用面试问题。
> 我从'Java 工程师'升级到'AI 应用工程师'。"

---

## 十、下个阶段：长期算法 + 面试准备

20 周的体系化学习到此结束。接下来进入"持续提升"阶段：
- 算法刷题（LeetCode）
- 八股文（Java、Spring、Redis、MySQL、AI）
- 简历优化
- 模拟面试
- 投递面试

详见 [长期-算法与面试.md](./长期-算法与面试.md)。

🎉 **恭喜！你已经走完了从 0 到全栈 + AI 应用工程师的体系化学习！**
