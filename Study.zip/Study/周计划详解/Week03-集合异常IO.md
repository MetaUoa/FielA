# 第 3 周：集合 + 异常 + IO

> **本周学习目标**：掌握 Java 工程师每天都在用的"三大件"——集合（取代数组）、异常（让代码健壮）、IO（读写文件）。学完后你能处理"动态数据 + 错误处理 + 文件读写"。
>
> **本周关键词**：ArrayList、HashMap、HashSet、try-catch、自定义异常、BufferedReader、NIO
>
> **预计投入时间**：35~45 小时

---

## 一、本周知识点详细分解

### 1. 集合框架总览（半天）

#### 1.1 为什么要有集合？

数组的缺点：
- 长度固定，不能扩容
- 类型单一
- 增删麻烦（要手动移位）
- API 少（没有 sort、contains 等）

集合的优点：
- 自动扩容
- 丰富 API
- 多种数据结构（线性、键值对、集合、树、队列）

#### 1.2 集合框架两大顶层接口

```
Collection（单列）
├── List（有序可重复）
│   ├── ArrayList    （数组实现）
│   ├── LinkedList   （链表实现）
│   └── Vector       （线程安全，老旧不用）
├── Set（无序不重复）
│   ├── HashSet      （哈希表实现）
│   ├── LinkedHashSet（保持插入顺序）
│   └── TreeSet      （有序，红黑树）
└── Queue（队列）
    ├── ArrayDeque   （双端队列）
    └── PriorityQueue（优先队列）

Map（双列，键值对）
├── HashMap         （哈希表）
├── LinkedHashMap   （保持插入顺序）
├── TreeMap         （按 key 排序）
└── ConcurrentHashMap（线程安全，第 4 周学）
```

**完全掌握标准：**
- ✅ 能闭眼画出集合框架结构图
- ✅ 能为每种集合举一个适用场景
- ✅ 能解释 List / Set / Map 的核心区别

---

### 2. ArrayList（1 天）

#### 2.1 基本使用

```java
List<String> list = new ArrayList<>();   // 推荐用接口声明
list.add("A");
list.add(0, "B");               // 指定位置插入
list.set(0, "C");               // 修改
list.remove(0);                 // 按索引删
list.remove("A");               // 按对象删
String x = list.get(0);
int size = list.size();
boolean has = list.contains("A");
```

#### 2.2 遍历方式（4 种）

```java
// 1. 普通 for
for (int i = 0; i < list.size(); i++) { ... }

// 2. 增强 for
for (String s : list) { ... }

// 3. 迭代器
Iterator<String> it = list.iterator();
while (it.hasNext()) { it.next(); }

// 4. forEach + Lambda
list.forEach(s -> System.out.println(s));
```

#### 2.3 ArrayList 底层原理（⭐高频面试题）

- 底层是**数组**（`Object[]`）
- 初始容量 10（懒加载，第一次 add 才分配）
- 扩容机制：满了之后扩容为 **1.5 倍**（`oldCapacity + (oldCapacity >> 1)`）
- 扩容用 `Arrays.copyOf` 复制到新数组
- 中间插入/删除性能差（要移位 O(n)）
- 随机访问性能好（O(1)）

**完全掌握标准：**
- ✅ 能默写出 ArrayList 的 5 个常用方法
- ✅ 能解释扩容机制（1.5 倍）
- ✅ 能解释为什么 add 平均是 O(1)（均摊分析）
- ✅ 能解释 ArrayList 不是线程安全的，怎么解决（`Collections.synchronizedList` / `CopyOnWriteArrayList`）
- ✅ 能解释 `ArrayList<int>` 为什么不行（泛型不支持基本类型，用 Integer）

---

### 3. LinkedList（半天）

#### 3.1 特性

- 底层是**双向链表**
- 增删快（O(1)，前提是已经知道节点）
- 随机访问慢（O(n)）
- 实现了 `List` + `Deque`（可当队列、栈用）

#### 3.2 ArrayList vs LinkedList（⭐高频面试题）

| | ArrayList | LinkedList |
| --- | --- | --- |
| 底层 | 数组 | 双向链表 |
| 随机访问 | O(1) | O(n) |
| 中间插入 | O(n) | O(1)（知道位置） |
| 内存占用 | 小 | 大（每个节点有前后指针） |
| 应用场景 | 读多写少 | 频繁中间插入删除 |

**完全掌握标准：**
- ✅ 能列出至少 5 处区别
- ✅ 能解释"实际项目中 90% 用 ArrayList"的原因（即使中间插入，O(n) 的常数项 ArrayList 更小，缓存友好）
- ✅ 能用 LinkedList 实现栈和队列

---

### 4. HashMap（重难点⭐⭐⭐，2 天）

#### 4.1 基本使用

```java
Map<String, Integer> map = new HashMap<>();
map.put("A", 1);
map.put("B", 2);
map.put("A", 10);                      // 覆盖

Integer v = map.get("A");              // 10
boolean has = map.containsKey("A");
map.remove("A");
int size = map.size();

// 遍历方式 1：entrySet（推荐）
for (Map.Entry<String, Integer> e : map.entrySet()) {
    System.out.println(e.getKey() + ":" + e.getValue());
}

// 遍历方式 2：keySet
for (String k : map.keySet()) { ... }

// 遍历方式 3：forEach
map.forEach((k, v) -> ...);
```

#### 4.2 HashMap 底层原理（高频面试⭐⭐⭐）

**JDK 8 之前：** 数组 + 链表
**JDK 8 之后：** 数组 + 链表 + 红黑树

**核心字段：**
- `Node<K,V>[] table`：哈希桶数组
- 默认初始容量：**16**
- 默认负载因子：**0.75**
- 树化阈值：链表长度 **>=8** 且数组长度 **>=64**
- 退化阈值：树节点 <=6

**put 流程：**
1. 计算 key 的 hash：`hash = (h = key.hashCode()) ^ (h >>> 16)` （扰动，让高位也参与运算）
2. 确定桶位：`index = (n - 1) & hash`
3. 桶为空 → 直接放入
4. 桶有数据：
   - key 相同（equals 比较）→ 覆盖
   - key 不同 → 链表尾插（JDK 7 是头插，会有死循环问题）
   - 链表长度 >= 8 且数组 >= 64 → 转红黑树
5. 检查是否需要扩容：`size > capacity * 0.75` → 扩容为 2 倍

**扩容机制：**
- 容量始终为 2 的幂（方便 `(n-1) & hash`）
- 扩容后元素要么在原位，要么在原位 + 旧容量

**完全掌握标准：**
- ✅ 能完整讲述 put 流程
- ✅ 能解释为什么默认容量是 16（2 的幂 + 折中）
- ✅ 能解释为什么负载因子是 0.75（时间空间权衡）
- ✅ 能解释为什么链表长度 >=8 才树化（泊松分布概率小于千万分之一）
- ✅ 能解释为什么必须重写 equals 和 hashCode（否则 HashMap 出错）
- ✅ 能解释 JDK 7 vs JDK 8 的 HashMap 区别
- ✅ 能解释 HashMap 不是线程安全的，多线程下用 `ConcurrentHashMap`

---

### 5. HashSet（半天）

- 底层就是 HashMap（key 为元素，value 是固定的 PRESENT 对象）
- 用法：add / remove / contains / size
- 不允许重复元素（用 equals + hashCode 判断）

**完全掌握标准：**
- ✅ 能解释 HashSet 底层就是 HashMap
- ✅ 能用 HashSet 实现"数组去重"
- ✅ 能解释为什么自定义对象放进 HashSet 要重写 equals 和 hashCode

---

### 6. TreeMap / TreeSet（半天）

- 底层是**红黑树**（自平衡 BST）
- key 必须实现 `Comparable` 或传入 `Comparator`
- 自动按 key 排序
- 增删改查 O(log n)
- 应用场景：需要按 key 排序的场景（如时间戳）

**完全掌握标准：**
- ✅ 能用 TreeMap 实现"按字典序排序的 key 输出"
- ✅ 能传入自定义 Comparator
- ✅ 能解释红黑树是什么（自平衡二叉搜索树，了解即可）

---

### 7. Collections 工具类（半天）

```java
Collections.sort(list);                    // 排序
Collections.reverse(list);                 // 反转
Collections.shuffle(list);                 // 打乱
Collections.max(list);                     // 最大值
Collections.binarySearch(list, x);         // 二分查找
List<String> unmod = Collections.unmodifiableList(list);  // 不可变
List<String> sync = Collections.synchronizedList(list);   // 同步
```

**完全掌握标准：**
- ✅ 能用 `Collections.sort` 排序自定义对象（实现 Comparable 或传 Comparator）

---

### 8. 泛型基础（半天）

```java
// 泛型类
public class Box<T> {
    private T data;
    public T get() { return data; }
    public void set(T data) { this.data = data; }
}

// 泛型方法
public static <T> T firstOf(List<T> list) {
    return list.get(0);
}

// 通配符
List<?> list1;              // 任意类型
List<? extends Number> l2;  // Number 及其子类
List<? super Integer> l3;   // Integer 及其父类
```

**完全掌握标准：**
- ✅ 能定义泛型类、泛型方法
- ✅ 能解释 PECS 原则：**P**roducer **E**xtends, **C**onsumer **S**uper
- ✅ 能解释**类型擦除**（Java 泛型只在编译期检查，运行时无类型信息）

---

### 9. 异常处理（1 天）

#### 9.1 异常体系

```
Throwable
├── Error（不该 catch，如 OutOfMemoryError）
└── Exception
    ├── RuntimeException（运行时异常，可不处理）
    │   ├── NullPointerException
    │   ├── ArrayIndexOutOfBoundsException
    │   ├── ClassCastException
    │   ├── IllegalArgumentException
    │   └── ArithmeticException
    └── 其他 Exception（受检异常，必须处理）
        ├── IOException
        ├── SQLException
        └── ClassNotFoundException
```

#### 9.2 try-catch-finally

```java
try {
    // 可能抛异常的代码
} catch (FileNotFoundException e) {
    // 处理具体异常
} catch (IOException e) {
    // 处理父类异常（必须放后面）
} catch (Exception e) {
    // 兜底
} finally {
    // 无论是否异常都执行（资源关闭）
}

// JDK 7+ try-with-resources（推荐）
try (BufferedReader br = new BufferedReader(new FileReader("a.txt"))) {
    // 用 br
} catch (IOException e) {
    e.printStackTrace();
}
// br 会自动关闭（必须实现 AutoCloseable）
```

#### 9.3 throws 与 throw

```java
// throws 声明可能抛出的异常
public void read() throws IOException { ... }

// throw 主动抛出
if (age < 0) throw new IllegalArgumentException("年龄非法");
```

#### 9.4 自定义异常

```java
public class BusinessException extends RuntimeException {
    private int code;
    public BusinessException(int code, String msg) {
        super(msg);
        this.code = code;
    }
    public int getCode() { return code; }
}

throw new BusinessException(40001, "用户不存在");
```

**完全掌握标准：**
- ✅ 能画出异常体系图
- ✅ 能区分**受检异常**（编译器强制处理）和**非受检异常**（运行时异常）
- ✅ 能解释 finally 一定会执行吗？（除了 `System.exit(0)` 和 JVM 崩溃）
- ✅ 能解释 try-with-resources 的原理
- ✅ 能定义自定义异常并使用
- ✅ 知道企业项目中通常用 RuntimeException 而非 Checked Exception（避免侵入式声明）

---

### 10. IO 流（1 天）

#### 10.1 IO 流分类

```
按流向：     输入流（Input） / 输出流（Output）
按数据类型： 字节流（Stream） / 字符流（Reader/Writer）
按功能：     节点流（直接读源） / 处理流（包装其他流）
```

#### 10.2 字节流

```java
// 读
try (FileInputStream fis = new FileInputStream("a.txt")) {
    int b;
    while ((b = fis.read()) != -1) {
        System.out.print((char) b);
    }
}

// 写
try (FileOutputStream fos = new FileOutputStream("b.txt")) {
    fos.write("Hello".getBytes());
}
```

#### 10.3 字符流

```java
try (FileReader fr = new FileReader("a.txt");
     FileWriter fw = new FileWriter("b.txt")) {
    int c;
    while ((c = fr.read()) != -1) {
        fw.write(c);
    }
}
```

#### 10.4 缓冲流（推荐用）

```java
try (BufferedReader br = new BufferedReader(new FileReader("a.txt"));
     BufferedWriter bw = new BufferedWriter(new FileWriter("b.txt"))) {
    String line;
    while ((line = br.readLine()) != null) {
        bw.write(line);
        bw.newLine();
    }
}
```

#### 10.5 字节流 vs 字符流

| | 字节流 | 字符流 |
| --- | --- | --- |
| 单位 | byte（1 字节） | char（2 字节） |
| 适用 | 二进制文件（图片、视频） | 文本文件 |
| 编码 | 无编码概念 | 涉及字符集（UTF-8/GBK） |

**完全掌握标准：**
- ✅ 能用字节流复制图片
- ✅ 能用字符流读写文本
- ✅ 能解释缓冲流为什么快（减少 IO 次数）
- ✅ 能用 try-with-resources 自动关流
- ✅ 知道指定字符集：`new InputStreamReader(fis, "UTF-8")`

---

### 11. NIO 基础（了解，半天）

#### 11.1 BIO vs NIO 三大区别

| | BIO | NIO |
| --- | --- | --- |
| 流向 | 单向（输入或输出） | 双向（通过 Buffer） |
| 阻塞 | 阻塞 | 非阻塞 |
| 模型 | 流（Stream） | 通道（Channel） + 缓冲区（Buffer） |

#### 11.2 NIO 三大核心

- **Channel**：双向通道（FileChannel、SocketChannel）
- **Buffer**：缓冲区（ByteBuffer、CharBuffer）
- **Selector**：多路复用器（一个线程管理多个通道）

#### 11.3 Path / Files（JDK 7+ NIO.2，推荐）

```java
import java.nio.file.*;

// 写
Files.write(Paths.get("a.txt"), "Hello".getBytes());

// 读
List<String> lines = Files.readAllLines(Paths.get("a.txt"));
String content = Files.readString(Paths.get("a.txt"));   // JDK 11+

// 复制
Files.copy(Paths.get("a.txt"), Paths.get("b.txt"));

// 删除
Files.delete(Paths.get("a.txt"));

// 判断存在
boolean exists = Files.exists(Paths.get("a.txt"));
```

**完全掌握标准：**
- ✅ 能说出 BIO 和 NIO 的区别
- ✅ 能用 NIO.2 (`Files`) 读写文件（比传统 IO 简洁很多）
- ✅ 知道 NIO 适合高并发场景（Netty 底层就是 NIO）

---

## 二、每日学习安排

| 天 | 学习内容 | 上机练习 | 时长 |
| --- | --- | --- | --- |
| **周一** | 集合框架总览 + ArrayList | 用 ArrayList 重写学生管理系统 | 5h |
| **周二** | LinkedList + Iterator + 遍历 | 链表/数组性能对比测试 | 5h |
| **周三** | HashMap（重点⭐） | 单词频率统计 + 源码阅读 | 6h |
| **周四** | HashSet + TreeMap + Collections + 泛型 | 数组去重 + 排序练习 | 6h |
| **周五** | 异常体系 + try-catch + 自定义异常 | 改造之前的项目加异常处理 | 5h |
| **周六** | IO 流（字节、字符、缓冲） | 实现 **文件备份工具** | 6h |
| **周日** | NIO.2 + 复盘 | 实现 **日志分析工具** + 提交 GitHub | 6h |

---

## 三、本周必做实战项目（2 个）

### 项目 1：文件备份工具

**需求：**
- 输入源文件夹和目标文件夹
- 递归复制所有文件
- 显示进度（已复制 X 个文件）
- 处理异常：源不存在、目标无权限、磁盘满

**进阶：**
- 支持增量备份（只复制新增/修改的文件）
- 用 NIO.2 实现

**验收标准：**
- ✅ 能正确复制嵌套文件夹
- ✅ 文件内容字节完全一致
- ✅ 异常处理完善
- ✅ 用 try-with-resources

### 项目 2：日志分析工具

**需求：**
- 输入：一个日志文件（每行一条日志，含时间戳、级别、内容）
- 输出：
  - 总行数
  - 各级别（INFO/WARN/ERROR）数量
  - 包含 "ERROR" 的所有行
  - Top 10 出现频率最高的 IP（如果日志含 IP）

**技术要点：**
- 用 BufferedReader 逐行读
- 用 HashMap 统计频率
- 用 List + 自定义 Comparator 排序

**验收标准：**
- ✅ 能处理 100MB+ 大文件
- ✅ 用 HashMap 统计
- ✅ 异常处理完善
- ✅ 输出格式美观

---

## 四、完全掌握检查清单

### 集合
- [ ] 能画出集合框架结构图
- [ ] 能默写 ArrayList 的扩容机制
- [ ] 能讲述 HashMap put 完整流程
- [ ] 能解释 HashMap 默认容量 16、负载因子 0.75、树化阈值 8 的原因
- [ ] 能用 4 种方式遍历集合
- [ ] 能解释为什么自定义对象放 HashMap 要重写 equals + hashCode

### 异常
- [ ] 能画出异常体系图
- [ ] 能区分受检异常和非受检异常
- [ ] 能定义自定义异常并抛出
- [ ] 能正确使用 try-with-resources

### IO
- [ ] 能用 IO 流复制文件
- [ ] 能用 BufferedReader 逐行读
- [ ] 能解释字节流 vs 字符流的差异
- [ ] 能用 NIO.2 的 Files 简化文件操作

### 综合
- [ ] 完成 2 个实战项目并提交 GitHub
- [ ] HashMap 源码看过一遍并写了笔记

---

## 五、自测题

**Q1：** ArrayList 和 LinkedList 哪个查找快？哪个增删快？为什么？
**答案：** ArrayList 查找快（O(1) 随机访问），LinkedList 增删快（O(1)，前提是知道节点位置）。

---

**Q2：** HashMap 在 JDK 8 中链表什么时候转红黑树？
**答案：** 链表长度 >= 8 **且** 数组长度 >= 64。否则只是扩容数组。

---

**Q3：** HashMap 的 key 可以是 null 吗？value 呢？
**答案：** 都可以。key 为 null 时 hash 为 0，固定放在桶 0。

---

**Q4：** 为什么 HashMap 的容量必须是 2 的幂？
**答案：** 因为求桶下标用 `(n-1) & hash`，n 是 2 的幂时 `n-1` 二进制全 1，分布均匀。

---

**Q5：** 下面代码会输出什么？
```java
Map<Integer, String> map = new HashMap<>();
map.put(1, "A");
map.put(2, "B");
for (int i = 3; i <= 16; i++) map.put(i, "X");
System.out.println(map.size());
```
**答案：** `16`
**考点：** 此时触发扩容（size > 16 * 0.75 = 12），但 size 还是 16。

---

**Q6：** finally 一定会执行吗？
**答案：** 除非：
- JVM 退出（`System.exit(0)`）
- 当前线程被杀死
- finally 之前发生死循环
- 守护线程的情况

---

**Q7：** 自定义异常应该继承 Exception 还是 RuntimeException？
**答案：** 看场景：
- 业务异常通常继承 `RuntimeException`（不强制处理，配合全局异常处理器）
- 必须让调用方处理的，继承 `Exception`

---

## 六、常见坑与误区

| 坑 | 描述 | 解决方案 |
| --- | --- | --- |
| 边遍历边修改 | `ConcurrentModificationException` | 用 Iterator.remove() 或 stream |
| HashMap 多线程 | put 死循环（JDK 7） / 数据丢失 | 用 ConcurrentHashMap |
| 自定义对象在 Set/Map | 表现异常（add 重复进去） | 重写 equals + hashCode |
| 异常被吞 | catch 后不处理也不抛 | 至少 log，不要静默吞 |
| 流没关 | 资源泄漏 | 用 try-with-resources |
| BufferedWriter 没 flush | 文件没内容 | close 时会自动 flush（推荐 try-with-resources） |
| 中文乱码 | 字符集不一致 | 明确指定 UTF-8 |
| 大文件读到内存 | OOM | 流式读，逐行处理 |

---

## 七、推荐学习资源

### 视频
- 【B站】黑马程序员 Java 集合（约 10 小时）
- 【B站】尚硅谷 宋红康 集合框架部分

### 书籍
- 《Java 核心技术 · 卷 I》第 9~10 章（集合 + 异常）
- 《Effective Java》第 9 章（异常处理最佳实践）

### 源码阅读（必读⭐）
- ArrayList 源码：`add`、`grow` 方法
- HashMap 源码：`put`、`resize`、`treeifyBin` 方法
- 推荐文章：[HashMap 源码解析（美团技术团队）](https://tech.meituan.com/2016/06/24/java-hashmap.html)

---

## 八、本周完成后的"自我画像"

> "我能熟练使用 ArrayList、HashMap、HashSet 处理动态数据。
> 我能讲清楚 HashMap 的 put 流程、扩容机制、为什么默认容量是 16。
> 我能用 try-catch 和自定义异常让代码更健壮。
> 我能用 IO 流读写文件，知道用 BufferedReader 提升性能。
> 我独立完成了文件备份工具和日志分析工具。"

---

## 九、下周预告

第 4 周进入 **多线程 + JVM**——Java 工程师的"分水岭"。
你将学会让多个任务同时执行（提升性能 + 处理并发问题），并理解 JVM 内存模型和 GC（面试必问）。

下周见！💪
