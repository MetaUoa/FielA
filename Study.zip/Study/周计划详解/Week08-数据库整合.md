# 第 8 周：数据库整合（MyBatis Plus + JWT + Swagger）

> **本周学习目标**：把 MySQL 与 SpringBoot 接起来，引入 MyBatis Plus 提升开发效率，加上 JWT 登录、Swagger 文档、参数校验，让项目企业级。
>
> **本周关键词**：MyBatis、MyBatis Plus、JPA、JWT、Swagger/OpenAPI、拦截器、过滤器
>
> **预计投入时间**：35~45 小时

---

## 一、本周知识点详细分解

### 1. JDBC 与 数据源（半天）

#### 1.1 JDBC 基础（先了解，不重点写）

JDBC 是 Java 操作数据库的最底层 API：
```java
Class.forName("com.mysql.cj.jdbc.Driver");
Connection conn = DriverManager.getConnection(url, user, pwd);
PreparedStatement ps = conn.prepareStatement("SELECT * FROM user WHERE id = ?");
ps.setLong(1, 1L);
ResultSet rs = ps.executeQuery();
// ...
```

**痛点：** 代码冗余、容易资源泄漏、SQL 写在 Java 里难维护。

#### 1.2 连接池

**为什么用：** 每次 new Connection 开销大（TCP 握手 + 认证），池化复用。

**主流连接池：**
- **HikariCP**（SpringBoot 默认，性能最好）
- Druid（阿里出，监控好）
- DBCP（老旧）

#### 1.3 配置数据源

```yaml
spring:
  datasource:
    url: jdbc:mysql://localhost:3306/shop?useUnicode=true&characterEncoding=UTF-8&serverTimezone=Asia/Shanghai
    username: root
    password: 123456
    driver-class-name: com.mysql.cj.jdbc.Driver
    hikari:
      maximum-pool-size: 10
      minimum-idle: 2
      idle-timeout: 30000
      max-lifetime: 1800000
```

**完全掌握标准：**
- ✅ 能解释 JDBC 是什么、为什么不直接用
- ✅ 知道 HikariCP 是默认连接池
- ✅ 能配置数据源 URL 参数（字符集、时区）
- ✅ 知道连接池的核心参数（maxPoolSize、minIdle）

---

### 2. MyBatis（重点 1 天）

#### 2.1 MyBatis 概念

- **半自动 ORM**：SQL 自己写，结果自动映射
- 比 JDBC 省代码，比 JPA 灵活
- 国内主流

#### 2.2 引入依赖

```xml
<dependency>
    <groupId>org.mybatis.spring.boot</groupId>
    <artifactId>mybatis-spring-boot-starter</artifactId>
    <version>3.0.3</version>
</dependency>
<dependency>
    <groupId>com.mysql</groupId>
    <artifactId>mysql-connector-j</artifactId>
</dependency>
```

#### 2.3 三种写 SQL 方式

**方式 1：注解（简单 SQL 用）**

```java
@Mapper
public interface UserMapper {
    @Select("SELECT * FROM user WHERE id = #{id}")
    User getById(Long id);

    @Insert("INSERT INTO user (name, age) VALUES (#{name}, #{age})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(User user);
}
```

**方式 2：XML（复杂 SQL 用，推荐）**

UserMapper.java:
```java
@Mapper
public interface UserMapper {
    User getById(Long id);
    int insert(User user);
}
```

UserMapper.xml（放 resources/mapper/ 下）:
```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE mapper PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="com.xxx.mapper.UserMapper">

    <select id="getById" resultType="com.xxx.entity.User">
        SELECT * FROM user WHERE id = #{id}
    </select>

    <insert id="insert" useGeneratedKeys="true" keyProperty="id">
        INSERT INTO user (name, age) VALUES (#{name}, #{age})
    </insert>
</mapper>
```

application.yml:
```yaml
mybatis:
  mapper-locations: classpath:mapper/*.xml
  configuration:
    map-underscore-to-camel-case: true   # user_name → userName
    log-impl: org.apache.ibatis.logging.stdout.StdOutImpl   # 打印 SQL
```

#### 2.4 动态 SQL（XML 强项）

```xml
<select id="search" resultType="User">
    SELECT * FROM user
    <where>
        <if test="name != null and name != ''">
            AND name LIKE CONCAT('%', #{name}, '%')
        </if>
        <if test="ageMin != null">
            AND age &gt;= #{ageMin}
        </if>
        <if test="ageMax != null">
            AND age &lt;= #{ageMax}
        </if>
    </where>
    ORDER BY id DESC
</select>

<!-- foreach 批量 -->
<insert id="batchInsert">
    INSERT INTO user (name, age) VALUES
    <foreach collection="list" item="u" separator=",">
        (#{u.name}, #{u.age})
    </foreach>
</insert>
```

#### 2.5 `#{}` vs `${}`（⭐高频面试）

- `#{}`：预编译参数，**防 SQL 注入**（变成 ?）
- `${}`：字符串拼接，**有 SQL 注入风险**，仅用于表名/字段名等结构

#### 2.6 一对多 / 多对一关联

```xml
<resultMap id="userWithOrders" type="User">
    <id property="id" column="id"/>
    <result property="name" column="name"/>
    <collection property="orders" ofType="Order">
        <id property="id" column="oid"/>
        <result property="amount" column="amount"/>
    </collection>
</resultMap>
```

**完全掌握标准：**
- ✅ 能写 注解版 / XML 版 CRUD
- ✅ 能写动态 SQL（`<if> <where> <foreach>`）
- ✅ 能解释 `#{}` 和 `${}` 区别
- ✅ 能用 resultMap 处理一对多
- ✅ 知道 mapper-locations 配置位置

---

### 3. MyBatis Plus（⭐⭐推荐 1.5 天）

#### 3.1 为什么用 MP

MyBatis 痛点：
- 简单 CRUD 也要写 SQL
- 分页要手写
- 没有代码生成

MP 解决：
- **内置 CRUD**：继承 BaseMapper 就有 20+ 方法
- **条件构造器**：链式写 SQL
- **分页插件**：一行配置
- **代码生成器**

#### 3.2 引入

```xml
<dependency>
    <groupId>com.baomidou</groupId>
    <artifactId>mybatis-plus-spring-boot3-starter</artifactId>
    <version>3.5.5</version>
</dependency>
```

#### 3.3 实体类

```java
@Data
@TableName("user")
public class User {
    @TableId(type = IdType.AUTO)
    private Long id;
    private String name;
    private Integer age;

    @TableField("created_at")
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createdAt;

    @TableLogic
    private Integer isDeleted;
}
```

#### 3.4 Mapper 直接用

```java
@Mapper
public interface UserMapper extends BaseMapper<User> {
    // 无需写代码，已经有 selectById / insert / update / delete 等方法
}
```

#### 3.5 Service 层

```java
public interface UserService extends IService<User> {}

@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {
    // 自动有 list / page / save / removeById 等方法
}
```

#### 3.6 条件构造器（LambdaQueryWrapper）

```java
// 推荐 Lambda 写法（编译期检查字段名）
List<User> list = userService.lambdaQuery()
    .like(User::getName, "张")
    .ge(User::getAge, 18)
    .le(User::getAge, 30)
    .orderByDesc(User::getCreatedAt)
    .list();

// 普通 QueryWrapper
QueryWrapper<User> qw = new QueryWrapper<>();
qw.like("name", "张").ge("age", 18);
```

#### 3.7 分页插件

```java
@Configuration
public class MybatisPlusConfig {
    @Bean
    public MybatisPlusInterceptor interceptor() {
        MybatisPlusInterceptor interceptor = new MybatisPlusInterceptor();
        interceptor.addInnerInterceptor(new PaginationInnerInterceptor(DbType.MYSQL));
        return interceptor;
    }
}

// 使用
Page<User> page = userService.lambdaQuery()
    .like(User::getName, "张")
    .page(new Page<>(1, 10));
page.getRecords();   // 当前页数据
page.getTotal();     // 总条数
page.getPages();     // 总页数
```

#### 3.8 自动填充

```java
@Component
public class MyMetaObjectHandler implements MetaObjectHandler {
    @Override
    public void insertFill(MetaObject metaObject) {
        this.strictInsertFill(metaObject, "createdAt", LocalDateTime.class, LocalDateTime.now());
        this.strictInsertFill(metaObject, "updatedAt", LocalDateTime.class, LocalDateTime.now());
    }
    @Override
    public void updateFill(MetaObject metaObject) {
        this.strictUpdateFill(metaObject, "updatedAt", LocalDateTime.class, LocalDateTime.now());
    }
}
```

#### 3.9 逻辑删除

```yaml
mybatis-plus:
  global-config:
    db-config:
      logic-delete-field: isDeleted
      logic-delete-value: 1
      logic-not-delete-value: 0
```

`removeById` 实际执行 `UPDATE ... SET is_deleted = 1`。

**完全掌握标准：**
- ✅ 能用 MP 实现 CRUD（不写 SQL）
- ✅ 能用 LambdaQueryWrapper 写条件查询
- ✅ 能配置分页插件
- ✅ 能用 @TableLogic 实现逻辑删除
- ✅ 能用 MetaObjectHandler 自动填充时间
- ✅ 知道什么时候 MP 不够要回到原生 MyBatis（复杂 JOIN）

---

### 4. JPA（了解，半天）

#### 4.1 JPA 概念

- 全自动 ORM 规范，Spring Data JPA 是实现
- 不需要写 SQL，操作对象
- Spring Boot 全家桶之一

#### 4.2 简单例子

```java
@Entity
@Table(name = "user")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
}

public interface UserRepository extends JpaRepository<User, Long> {
    List<User> findByNameLike(String name);   // 方法名直接成查询
}
```

#### 4.3 MyBatis vs JPA（高频面试）

| | MyBatis（+ MP） | JPA |
| --- | --- | --- |
| SQL | 半自动（自己写或 MP 生成） | 全自动 |
| 灵活性 | 高 | 低 |
| 学习成本 | 低 | 较高 |
| 国内主流 | ⭐⭐⭐ | ⭐ |
| 国外主流 | ⭐ | ⭐⭐⭐ |

**完全掌握标准（了解）：**
- ✅ 知道 JPA 是规范，Hibernate / Spring Data JPA 是实现
- ✅ 能解释 MyBatis vs JPA 的区别
- ✅ 知道国内大多用 MyBatis + MP

---

### 5. 事务管理（⭐重点 半天）

#### 5.1 @Transactional 基本用法

```java
@Service
@RequiredArgsConstructor
public class TransferService {
    private final AccountMapper accountMapper;

    @Transactional(rollbackFor = Exception.class)
    public void transfer(Long from, Long to, BigDecimal amount) {
        accountMapper.decrease(from, amount);
        // 假设这里抛异常
        accountMapper.increase(to, amount);
    }
}
```

#### 5.2 关键属性

| 属性 | 说明 |
| --- | --- |
| `rollbackFor` | 遇到哪些异常回滚（推荐 `Exception.class`） |
| `noRollbackFor` | 遇到哪些异常不回滚 |
| `propagation` | 传播行为（REQUIRED / REQUIRES_NEW 等） |
| `isolation` | 隔离级别（默认数据库的） |
| `timeout` | 超时秒数 |
| `readOnly` | 只读事务 |

#### 5.3 7 种传播行为

| 行为 | 含义 |
| --- | --- |
| **REQUIRED**（默认） | 有就加入，没有就新建 |
| REQUIRES_NEW | 总是新建（挂起当前） |
| SUPPORTS | 有就加入，没有就非事务 |
| NOT_SUPPORTED | 总是非事务 |
| NEVER | 有事务就抛异常 |
| MANDATORY | 必须有事务，没就抛异常 |
| NESTED | 嵌套事务（部分回滚） |

#### 5.4 事务失效的 7 种情况（⭐高频面试）

1. **方法非 public**
2. **同类内部调用**（绕过代理）
3. **异常被 catch 吃掉**
4. **抛 checked 异常但 rollbackFor 没指定**
5. **类没被 Spring 管理**（没加 @Service）
6. **数据库不支持事务**（如 MyISAM 引擎）
7. **propagation 配置错误**（如 NOT_SUPPORTED）

**完全掌握标准：**
- ✅ 能用 @Transactional 实现事务
- ✅ 能背出 7 种失效场景
- ✅ 能解释为什么同类调用失效
- ✅ 能解释 REQUIRED vs REQUIRES_NEW 的区别
- ✅ 知道为什么要写 rollbackFor = Exception.class

---

### 6. JWT 登录（⭐重点 1 天）

#### 6.1 JWT 是什么

**JWT (JSON Web Token)** 是一种紧凑的 token 格式：
```
Header.Payload.Signature
eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjMifQ.signature
```

#### 6.2 JWT vs Session

| | Session | JWT |
| --- | --- | --- |
| 存储 | 服务端 | 客户端 |
| 扩展 | 难（需共享 session） | 易（无状态） |
| 撤销 | 容易 | 难（要黑名单） |
| 适用 | 单体应用 | 微服务、分布式 |

#### 6.3 流程

```
登录：
  Client → POST /login {账号, 密码}
  Server → 验证 → 生成 JWT → 返回
  Client → 保存 JWT（localStorage / cookie）

后续请求：
  Client → 带 Authorization: Bearer xxx
  Server → 拦截器解析 JWT → 验签 → 取用户ID
```

#### 6.4 代码实现

```xml
<dependency>
    <groupId>com.auth0</groupId>
    <artifactId>java-jwt</artifactId>
    <version>4.4.0</version>
</dependency>
```

```java
public class JwtUtil {
    private static final String SECRET = "my-secret-key-must-be-long-enough";
    private static final long EXPIRATION = 24 * 60 * 60 * 1000L;

    public static String generate(Long userId) {
        return JWT.create()
            .withSubject(userId.toString())
            .withIssuedAt(new Date())
            .withExpiresAt(new Date(System.currentTimeMillis() + EXPIRATION))
            .sign(Algorithm.HMAC256(SECRET));
    }

    public static Long parse(String token) {
        DecodedJWT jwt = JWT.require(Algorithm.HMAC256(SECRET))
            .build()
            .verify(token);
        return Long.parseLong(jwt.getSubject());
    }
}
```

#### 6.5 拦截器

```java
@Component
public class AuthInterceptor implements HandlerInterceptor {
    @Override
    public boolean preHandle(HttpServletRequest req, HttpServletResponse resp, Object h) {
        String token = req.getHeader("Authorization");
        if (token == null || !token.startsWith("Bearer ")) {
            resp.setStatus(401);
            return false;
        }
        try {
            Long userId = JwtUtil.parse(token.substring(7));
            UserContext.set(userId);   // ThreadLocal 存到当前请求上下文
            return true;
        } catch (Exception e) {
            resp.setStatus(401);
            return false;
        }
    }

    @Override
    public void afterCompletion(HttpServletRequest req, HttpServletResponse resp, Object h, Exception e) {
        UserContext.clear();   // 防止内存泄漏
    }
}

@Configuration
@RequiredArgsConstructor
public class WebConfig implements WebMvcConfigurer {
    private final AuthInterceptor authInterceptor;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(authInterceptor)
            .addPathPatterns("/api/**")
            .excludePathPatterns("/api/login", "/api/register");
    }
}
```

#### 6.6 ThreadLocal 存登录用户

```java
public class UserContext {
    private static final ThreadLocal<Long> CTX = new ThreadLocal<>();
    public static void set(Long id) { CTX.set(id); }
    public static Long get() { return CTX.get(); }
    public static void clear() { CTX.remove(); }
}
```

**完全掌握标准：**
- ✅ 能解释 JWT 三段格式
- ✅ 能解释 JWT vs Session 优缺点
- ✅ 能写 JwtUtil 生成 + 解析
- ✅ 能用拦截器验证 token
- ✅ 能用 ThreadLocal 传递用户信息
- ✅ 知道 ThreadLocal 必须 remove（线程池场景）

---

### 7. 拦截器 vs 过滤器（半天）

| | 过滤器（Filter） | 拦截器（Interceptor） |
| --- | --- | --- |
| 来源 | Servlet 规范 | Spring |
| 作用 | 请求/响应过滤 | Controller 前后增强 |
| 时机 | Servlet 前后 | Spring MVC 流程内 |
| Spring 注入 | 较麻烦 | 简单 |
| 应用 | 编码、CORS、日志 | 登录验证、权限 |

```java
// Filter
@Component
public class MyFilter implements Filter {
    @Override
    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) {
        // 前置
        chain.doFilter(req, resp);
        // 后置
    }
}
```

**完全掌握标准：**
- ✅ 能区分拦截器和过滤器
- ✅ 知道认证用拦截器更合适

---

### 8. Swagger / OpenAPI（半天）

#### 8.1 引入 springdoc-openapi（替代旧 SpringFox）

```xml
<dependency>
    <groupId>org.springdoc</groupId>
    <artifactId>springdoc-openapi-starter-webmvc-ui</artifactId>
    <version>2.3.0</version>
</dependency>
```

访问 `http://localhost:8080/swagger-ui.html` 查看文档。

#### 8.2 注解

```java
@Tag(name = "用户管理")
@RestController
@RequestMapping("/api/users")
public class UserController {

    @Operation(summary = "查用户")
    @Parameter(name = "id", description = "用户 ID", required = true)
    @GetMapping("/{id}")
    public Result<User> getById(@PathVariable Long id) { ... }
}

@Schema(description = "用户")
public class UserDTO {
    @Schema(description = "姓名", example = "张三")
    private String name;
}
```

**完全掌握标准：**
- ✅ 能让 Swagger UI 自动展示所有接口
- ✅ 能用 @Operation / @Schema 完善文档

---

### 9. 密码加密（半天）

#### 9.1 BCrypt（推荐）

```xml
<dependency>
    <groupId>org.springframework.security</groupId>
    <artifactId>spring-security-crypto</artifactId>
</dependency>
```

```java
PasswordEncoder encoder = new BCryptPasswordEncoder();
String hash = encoder.encode("123456");
boolean ok = encoder.matches("123456", hash);
```

**完全掌握标准：**
- ✅ 知道**不能明文存密码**
- ✅ 知道为什么不用 MD5（彩虹表攻击）
- ✅ 能用 BCryptPasswordEncoder

---

## 二、每日学习安排

| 天 | 学习内容 | 上机练习 | 时长 |
| --- | --- | --- | --- |
| **周一** | 数据源 + JDBC 概念 + MyBatis 入门 | 配置数据源 + 注解版 CRUD | 5h |
| **周二** | MyBatis XML + 动态 SQL + 关联查询 | XML 版 CRUD + 一对多 | 6h |
| **周三** | MyBatis Plus ⭐ | 用 MP 重写昨天的代码 | 6h |
| **周四** | MP 高级（分页、自动填充、逻辑删除） | 实现分页查询接口 | 5h |
| **周五** | 事务 @Transactional + 传播行为 ⭐ | 写转账例子模拟事务回滚 | 6h |
| **周六** | JWT + 拦截器 + 密码加密 ⭐ | 实现登录 + 拦截 | 6h |
| **周日** | Swagger + 综合项目 + 复盘 | 留言板加上登录 + 文档 | 6h |

---

## 三、本周必做实战项目

### 项目：用户登录 + 权限管理系统

**功能：**
1. **注册**：用户名 + 密码（BCrypt 加密存入 MySQL）
2. **登录**：账号密码验证，返回 JWT token
3. **CRUD 用户**：需要登录才能访问（拦截器拦截）
4. **修改个人信息**：从 JWT 取 userId，不能改别人
5. **角色字段**：ADMIN 才能删除用户（角色信息存 JWT 或 DB）
6. **分页查询用户列表**
7. **Swagger 接口文档**

**表结构：**
```sql
CREATE TABLE `user` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(50) NOT NULL UNIQUE,
    `password` VARCHAR(100) NOT NULL,
    `role` VARCHAR(20) DEFAULT 'USER',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `is_deleted` TINYINT DEFAULT 0
);
```

**技术要求：**
- ✅ SpringBoot 3 + MyBatis Plus
- ✅ JWT 登录
- ✅ BCrypt 密码加密
- ✅ 全局异常 + 统一返回 + 参数校验
- ✅ Swagger 文档
- ✅ 分页插件
- ✅ 逻辑删除
- ✅ 自动填充时间

**验收：**
- ✅ Postman 测全部接口通过
- ✅ Swagger UI 能看到所有接口
- ✅ 未登录访问受保护接口返回 401
- ✅ 普通用户尝试删除其他用户返回 403
- ✅ 提交 GitHub，README 含截图

---

## 四、完全掌握检查清单

### MyBatis
- [ ] 能写注解版 + XML 版 CRUD
- [ ] 能写动态 SQL（if、where、foreach）
- [ ] 能解释 #{} 和 ${} 区别
- [ ] 能用 resultMap 处理关联

### MyBatis Plus
- [ ] 能用 BaseMapper 内置 CRUD
- [ ] 能用 LambdaQueryWrapper 查询
- [ ] 能配置分页插件
- [ ] 能用 @TableLogic 实现逻辑删除
- [ ] 能用自动填充

### 事务
- [ ] 能用 @Transactional
- [ ] 能背 7 种事务失效场景
- [ ] 能解释 REQUIRED vs REQUIRES_NEW
- [ ] 知道为什么要 rollbackFor

### JWT
- [ ] 能生成 + 解析 JWT
- [ ] 能用拦截器验证
- [ ] 能用 ThreadLocal 传用户
- [ ] 知道 ThreadLocal 要 remove

### 其他
- [ ] 能用 BCryptPasswordEncoder
- [ ] 能用 Swagger 看文档
- [ ] 能区分拦截器和过滤器

### 综合
- [ ] 完成用户登录 + 权限项目并提交 GitHub

---

## 五、自测题

**Q1：** MyBatis 的 `#{}` 和 `${}` 区别？为什么 `#{}` 安全？
**答案：**
- `#{}` 预编译，会变成 `?`，再通过 PreparedStatement 设置，**防 SQL 注入**
- `${}` 字符串拼接，有 SQL 注入风险，只用于表名/字段名

---

**Q2：** @Transactional 用在 private 方法上有用吗？
**答案：** 没用。Spring 用代理实现事务，private 方法外部不可见，无法被代理拦截。

---

**Q3：** 同类内部调用，事务为什么失效？
**答案：** Spring 通过代理对象拦截方法调用。同类内部用 `this.xxx()` 直接调用本对象，绕过代理。
**解决：** 注入自己 `this.proxy.xxx()`、或 `((MyService) AopContext.currentProxy()).xxx()`。

---

**Q4：** JWT 怎么实现退出登录（让 token 失效）？
**答案：**
- 黑名单：把 token 存 Redis，过期时间设为 token 剩余时间
- 短期 token + Refresh token：access token 15 分钟，refresh 7 天

---

**Q5：** ThreadLocal 为什么必须 remove？
**答案：**
- 线程池场景下线程复用，残留数据会导致**业务错乱**
- 可能导致**内存泄漏**（强引用 Entry 中的 value）

---

**Q6：** MP 的 `removeById` 如何实现逻辑删除？
**答案：** 配置 `logic-delete-field`，MP 拦截 SQL，把 DELETE 改成 `UPDATE ... SET is_deleted = 1`，并且查询时自动追加 `WHERE is_deleted = 0`。

---

## 六、常见坑与误区

| 坑 | 描述 | 解决 |
| --- | --- | --- |
| 字段下划线 vs 驼峰 | mybatis 默认不映射 | 开启 map-underscore-to-camel-case |
| MP 字段名错 | 运行时报错 | 用 Lambda 写法（编译期检查） |
| 事务回滚不生效 | 默认只回滚 RuntimeException | rollbackFor = Exception.class |
| 同类调用事务失效 | this 调用绕过代理 | 抽到另一个 Bean |
| JWT 太长 | URL 限制 | 别放 URL，放 Header |
| JWT 没法主动失效 | 客户端持有 | 用 Redis 黑名单 |
| ThreadLocal 内存泄漏 | 线程池复用 | finally remove |
| BCrypt 验签慢 | 故意慢防爆破 | 不要循环调用 |
| Swagger 暴露生产 | 安全风险 | prod 环境禁用 |

---

## 七、推荐学习资源

### 视频
- 【B站】黑马 SpringBoot + MyBatisPlus 整合
- 【B站】MyBatis Plus 官方教程

### 书籍
- 《MyBatis 从入门到精通》

### 官方
- [MyBatis](https://mybatis.org/mybatis-3/zh/index.html)
- [MyBatis Plus](https://baomidou.com/)
- [springdoc-openapi](https://springdoc.org/)
- [JWT.io](https://jwt.io/)

---

## 八、本周完成后的"自我画像"

> "我能用 MyBatis Plus 5 分钟写完一个 CRUD 接口。
> 我懂 #{} 和 ${} 的区别，会写动态 SQL，能解决一对多关联。
> 我懂 @Transactional 的传播行为和 7 种失效场景。
> 我能用 JWT + 拦截器实现登录认证，能用 ThreadLocal 传用户上下文。
> 我能让项目有规范的 Swagger 文档，密码用 BCrypt 加密。
> 我完成了用户登录 + 权限项目并提交了 GitHub。"

---

## 九、下周预告

第 9 周是 **SpringBoot 项目实战周**——把前 8 周学的东西整合成一个完整项目：用户、登录、权限、文件上传、Redis 缓存、日志、API 文档。
这是你简历上的"第一个真正项目"。

下周见！💪
