# 第 17 周：Python + FastAPI

> **本周学习目标**：作为已经懂 Java 的工程师，1 周掌握 Python 基础 + FastAPI，为下个月接入 LLM 做准备。
>
> **本周关键词**：Python 语法、虚拟环境、requests、asyncio、FastAPI、Pydantic、Uvicorn
>
> **预计投入时间**：30~40 小时（懂 Java 后学 Python 会快很多）

---

## 一、为什么 AI 应用要用 Python

**几个原因：**
1. **生态最全**：LangChain、LangGraph、LlamaIndex 等主流 AI 框架都是 Python 优先
2. **机器学习基础设施**：PyTorch、Transformers、NumPy 都是 Python
3. **OpenAI SDK 等优先支持 Python**
4. **数据处理**：pandas、numpy 无可替代

**Java 也能做 AI（Spring AI），但 Python 是大势。掌握 Python 让你不被生态绑死。**

---

## 二、本周知识点详细分解

### 1. Python 环境搭建（半天）

#### 1.1 安装 Python

- **版本推荐：Python 3.11+**
- Windows / Mac：从 [python.org](https://python.org) 下载
- 验证：`python --version` 或 `python3 --version`

#### 1.2 包管理：pip

```bash
pip install requests
pip install requests==2.31.0
pip install -r requirements.txt
pip list
pip freeze > requirements.txt
pip uninstall requests
```

#### 1.3 虚拟环境（⭐重要）

**为什么：** 每个项目独立依赖，避免冲突。

```bash
# 创建虚拟环境
python -m venv venv

# 激活（Windows）
venv\Scripts\activate

# 激活（Mac/Linux）
source venv/bin/activate

# 退出
deactivate
```

**或用更现代的工具 uv（推荐）：**
```bash
pip install uv
uv venv
uv pip install requests
```

#### 1.4 IDE 推荐

- **PyCharm**（Community 免费 / Professional 收费）
- **VSCode + Python 插件**（推荐）

**完全掌握标准：**
- ✅ 能装好 Python 3.11+ 并验证
- ✅ 能创建虚拟环境并激活
- ✅ 能用 pip 装包
- ✅ 配好 VSCode / PyCharm

---

### 2. Python 基础语法（1 天，对照 Java 学）

#### 2.1 基础对照（Java ↔ Python）

| Java | Python |
| --- | --- |
| `int x = 10;` | `x = 10` |
| `String s = "hi";` | `s = "hi"` |
| `// 注释` | `# 注释` |
| `;` | （没有，换行结束语句） |
| `{}` 代码块 | **缩进**（4 空格） |
| `System.out.println(x);` | `print(x)` |
| `List<Integer>` | `list` 或 `[1, 2, 3]` |
| `Map<String, Integer>` | `dict` 或 `{"a": 1}` |
| `null` | `None` |
| `true / false` | `True / False` |

#### 2.2 数据类型

```python
# 基本类型
i = 10                    # int
f = 3.14                  # float
s = "hello"               # str
b = True                  # bool
n = None                  # None

# 字符串
name = "Alice"
msg = f"Hello {name}, age {20}"     # f-string，类似 Java 模板字符串
"hello".upper()
"  hi  ".strip()
"a,b,c".split(",")
"-".join(["a", "b", "c"])
"hello".replace("l", "L")
len("hello")
```

#### 2.3 集合类型

```python
# list（类似 Java 的 ArrayList）
arr = [1, 2, 3]
arr.append(4)
arr.pop()
arr[0] = 10
len(arr)
arr.sort()
arr.reverse()
arr[1:3]              # 切片 [2, 10]
arr[-1]               # 最后一个

# tuple（不可变）
t = (1, 2, 3)
x, y, z = t           # 解包

# dict（类似 Java 的 HashMap）
d = {"a": 1, "b": 2}
d["c"] = 3
d.get("a")
d.keys()
d.values()
d.items()
del d["a"]

# set
s = {1, 2, 3}
s.add(4)
s.remove(1)
s & s2    # 交集
s | s2    # 并集
```

#### 2.4 流程控制

```python
# 条件
if age >= 18:
    print("成年")
elif age >= 13:
    print("少年")
else:
    print("儿童")

# 三元
result = "成年" if age >= 18 else "未成年"

# for
for i in range(10):     # 0~9
    print(i)

for i in range(1, 11):  # 1~10
    print(i)

for item in [1, 2, 3]:
    print(item)

for k, v in d.items():
    print(k, v)

# while
while count < 10:
    count += 1

# break / continue 同 Java
```

#### 2.5 函数

```python
def add(a, b):
    return a + b

# 默认参数
def greet(name="World"):
    return f"Hello {name}"

# 关键字参数
def create_user(name, age, email=None):
    return {"name": name, "age": age, "email": email}

create_user(name="Alice", age=20)
create_user("Bob", 25, email="bob@test.com")

# 可变参数
def sum_all(*args):
    return sum(args)

sum_all(1, 2, 3, 4)

# 关键字可变参数
def show(**kwargs):
    for k, v in kwargs.items():
        print(k, v)

show(name="Alice", age=20)

# Lambda（匿名函数）
square = lambda x: x * x
square(5)        # 25
```

#### 2.6 列表推导式（Python 特色⭐）

```python
# 1~10 的平方
squares = [x * x for x in range(1, 11)]

# 偶数的平方
even_squares = [x * x for x in range(1, 11) if x % 2 == 0]

# 字典推导
d = {k: v * 2 for k, v in {"a": 1, "b": 2}.items()}
```

**完全掌握标准：**
- ✅ 能写出对应 Java 程序的 Python 版
- ✅ 能用 list / dict / tuple / set
- ✅ 能用 f-string
- ✅ 能用列表推导式
- ✅ 能用默认参数 / 关键字参数 / *args / **kwargs

---

### 3. 面向对象（半天）

```python
class Animal:
    # 类变量（类似 Java static）
    species = "动物"

    # 构造方法
    def __init__(self, name, age):
        self.name = name        # 实例变量
        self.age = age
        self._secret = "private"   # 约定 _ 开头是 private
        self.__strict = "really"   # __ 开头会被改名

    # 实例方法
    def eat(self):
        print(f"{self.name} 在吃")

    # 类方法
    @classmethod
    def from_dict(cls, d):
        return cls(d["name"], d["age"])

    # 静态方法
    @staticmethod
    def hello():
        print("Hello")

    # 魔术方法
    def __str__(self):                # 类似 Java toString
        return f"Animal({self.name})"

    def __eq__(self, other):
        return self.name == other.name


class Dog(Animal):
    def __init__(self, name, age, breed):
        super().__init__(name, age)
        self.breed = breed

    def eat(self):
        print(f"{self.name} 在啃骨头")
```

### Python OOP vs Java OOP

| | Java | Python |
| --- | --- | --- |
| 多继承 | 不支持（接口可多实现） | 支持 |
| private | 关键字 | 约定 `_` 或 `__` |
| 接口 | interface | duck typing / Protocol |
| 抽象类 | abstract | `abc.ABC` |

### 完全掌握标准
- ✅ 能写类、继承
- ✅ 能用 `__init__` 构造
- ✅ 能重写父类方法
- ✅ 知道魔术方法（dunder）

---

### 4. 异常处理（半天）

```python
try:
    result = 10 / 0
except ZeroDivisionError as e:
    print(f"除零错误: {e}")
except Exception as e:
    print(f"其他错误: {e}")
else:
    print("无异常时执行")
finally:
    print("一定执行")

# 抛出
raise ValueError("参数非法")

# 自定义异常
class BusinessException(Exception):
    def __init__(self, code, message):
        self.code = code
        super().__init__(message)
```

### 完全掌握标准
- ✅ 能用 try/except/finally
- ✅ 能自定义异常

---

### 5. 文件 IO（半天）

```python
# 读
with open("data.txt", "r", encoding="utf-8") as f:
    content = f.read()
    # 或逐行
    for line in f:
        print(line.strip())

# 写
with open("out.txt", "w", encoding="utf-8") as f:
    f.write("hello")

# 追加
with open("out.txt", "a", encoding="utf-8") as f:
    f.write("\n更多")

# JSON
import json

data = {"name": "Alice"}
with open("data.json", "w") as f:
    json.dump(data, f, ensure_ascii=False, indent=2)

with open("data.json") as f:
    data = json.load(f)
```

### 完全掌握标准
- ✅ 能用 `with open` 读写文件
- ✅ 能用 json 读写

---

### 6. 模块与包（半天）

```
my_project/
├── main.py
├── utils/
│   ├── __init__.py
│   ├── string_util.py
│   └── math_util.py
```

```python
# utils/math_util.py
def add(a, b):
    return a + b

PI = 3.14
```

```python
# main.py
from utils.math_util import add, PI
import utils.string_util as su

print(add(1, 2))
```

### 完全掌握标准
- ✅ 能创建多文件项目并相互 import
- ✅ 知道 `__init__.py` 的作用

---

### 7. 第三方库（半天）

#### 7.1 requests（HTTP 客户端）

```python
import requests

# GET
r = requests.get("https://api.example.com/users")
print(r.status_code)
print(r.json())

# 带参数
r = requests.get("https://api.example.com/users", params={"page": 1})

# POST JSON
r = requests.post("https://api.example.com/users",
                   json={"name": "Alice"},
                   headers={"Authorization": "Bearer xxx"})

# 超时
r = requests.get(url, timeout=5)
```

#### 7.2 其他必装

```bash
pip install requests           # HTTP
pip install python-dotenv      # .env 配置
pip install pydantic           # 数据校验
pip install loguru             # 日志
```

#### 7.3 dotenv

```python
# .env
OPENAI_API_KEY=sk-xxx
```

```python
from dotenv import load_dotenv
import os
load_dotenv()
api_key = os.getenv("OPENAI_API_KEY")
```

### 完全掌握标准
- ✅ 能用 requests 调用 API
- ✅ 能用 dotenv 读环境变量

---

### 8. asyncio 异步编程（半天）

```python
import asyncio
import time

async def task(n):
    print(f"任务 {n} 开始")
    await asyncio.sleep(1)
    print(f"任务 {n} 完成")
    return n * 2

async def main():
    # 串行
    a = await task(1)
    b = await task(2)
    # 总耗时 2 秒

    # 并发（类似 Java CompletableFuture.allOf）
    results = await asyncio.gather(task(1), task(2), task(3))
    # 总耗时约 1 秒
    print(results)

asyncio.run(main())
```

### 异步 HTTP

```python
import httpx
import asyncio

async def fetch(url):
    async with httpx.AsyncClient() as client:
        r = await client.get(url)
        return r.json()

async def main():
    urls = ["url1", "url2", "url3"]
    results = await asyncio.gather(*[fetch(u) for u in urls])
```

### 完全掌握标准
- ✅ 能用 async/await
- ✅ 能用 asyncio.gather 并发
- ✅ 知道 LLM 流式输出要用 async

---

### 9. FastAPI（⭐重点 2 天）

#### 9.1 FastAPI 是什么

- **Python 版 SpringBoot**（差不多的角色）
- 基于 Starlette + Pydantic
- 性能强（接近 Node.js / Go）
- 自动生成 OpenAPI 文档
- 现代 Python 主流 Web 框架

#### 9.2 第一个 FastAPI

```bash
pip install fastapi uvicorn[standard]
```

```python
# main.py
from fastapi import FastAPI

app = FastAPI(title="My API")

@app.get("/")
def root():
    return {"message": "Hello FastAPI"}

@app.get("/hello/{name}")
def hello(name: str):
    return {"hello": name}
```

```bash
# 运行
uvicorn main:app --reload --port 8000
```

访问：
- `http://localhost:8000/` → JSON 响应
- `http://localhost:8000/docs` → 自动 Swagger UI
- `http://localhost:8000/redoc` → ReDoc 文档

#### 9.3 路径参数 + 查询参数

```python
@app.get("/users/{user_id}")
def get_user(user_id: int, detail: bool = False):
    return {"id": user_id, "detail": detail}

# /users/1?detail=true
```

#### 9.4 Pydantic（请求/响应模型）

```python
from pydantic import BaseModel, Field, EmailStr
from typing import Optional

class UserCreate(BaseModel):
    name: str = Field(..., min_length=2, max_length=50)
    age: int = Field(..., ge=0, le=150)
    email: EmailStr
    bio: Optional[str] = None

@app.post("/users")
def create_user(user: UserCreate):
    return {"created": user}
```

请求体非法时，FastAPI 自动返回 422 + 详细错误。

#### 9.5 响应模型

```python
class UserResp(BaseModel):
    id: int
    name: str
    age: int

@app.get("/users/{id}", response_model=UserResp)
def get_user(id: int):
    return {"id": id, "name": "Alice", "age": 20}
```

#### 9.6 异步接口

```python
@app.get("/async-test")
async def test():
    await asyncio.sleep(1)
    return {"ok": True}
```

#### 9.7 中间件 + CORS

```python
from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"]
)

@app.middleware("http")
async def log_requests(request, call_next):
    start = time.time()
    response = await call_next(request)
    print(f"{request.url.path} - {time.time() - start:.2f}s")
    return response
```

#### 9.8 依赖注入

```python
from fastapi import Depends

def get_db():
    db = create_db_session()
    try:
        yield db
    finally:
        db.close()

@app.get("/users")
def list_users(db = Depends(get_db)):
    return db.query(User).all()
```

#### 9.9 异常处理

```python
from fastapi import HTTPException

@app.get("/users/{id}")
def get_user(id: int):
    user = find_user(id)
    if not user:
        raise HTTPException(status_code=404, detail="用户不存在")
    return user
```

#### 9.10 项目结构

```
my-api/
├── main.py
├── requirements.txt
├── .env
├── app/
│   ├── __init__.py
│   ├── routers/
│   │   ├── __init__.py
│   │   ├── users.py
│   │   └── chat.py
│   ├── models/
│   ├── services/
│   └── core/
│       ├── config.py
│       └── deps.py
```

```python
# app/routers/users.py
from fastapi import APIRouter

router = APIRouter(prefix="/users", tags=["users"])

@router.get("/")
def list_users():
    return []

# main.py
from fastapi import FastAPI
from app.routers import users, chat

app = FastAPI()
app.include_router(users.router)
app.include_router(chat.router)
```

### 完全掌握标准
- ✅ 能装好 FastAPI 并跑起来
- ✅ 能用 Pydantic 定义请求/响应模型
- ✅ 能写同步 + 异步接口
- ✅ 能用依赖注入
- ✅ 能用中间件 + CORS
- ✅ 能看自动生成的 Swagger UI
- ✅ 能合理拆分路由模块

---

## 三、每日学习安排

| 天 | 学习内容 | 上机练习 | 时长 |
| --- | --- | --- | --- |
| **周一** | 环境 + Python 语法（对照 Java） | 重写第 1 周的猜数字、计算器 | 4h |
| **周二** | OOP + 异常 + 文件 IO | 用 Python 写 OOP 例子 | 5h |
| **周三** | 模块 + requests + dotenv | 调用一个公开 API（如天气） | 5h |
| **周四** | asyncio 异步 | 并发抓 10 个 URL | 5h |
| **周五** | FastAPI 入门 + Pydantic | Hello World + CRUD | 6h |
| **周六** | FastAPI 进阶（依赖注入、中间件、异常） | 完整文章 CRUD | 6h |
| **周日** | 综合项目 + 复盘 | 实战项目 + 提交 GitHub | 6h |

---

## 四、本周必做实战项目

### 项目：文件解析服务

**需求：**
- 上传 PDF / Word / TXT / Markdown 文件
- 解析出纯文本内容
- 返回字符数、词数
- 异步处理大文件

**依赖：**
```bash
pip install fastapi uvicorn python-multipart
pip install pypdf python-docx markdown
```

**接口：**
- `POST /api/parse` 上传文件，返回解析结果
- `GET /api/files` 列出已上传文件
- `GET /api/files/{id}` 查文件详情

**关键代码：**

```python
from fastapi import FastAPI, UploadFile, File, HTTPException
from pypdf import PdfReader
from docx import Document
import io

app = FastAPI()

@app.post("/api/parse")
async def parse_file(file: UploadFile = File(...)):
    content = await file.read()
    suffix = file.filename.split(".")[-1].lower()

    if suffix == "pdf":
        text = parse_pdf(content)
    elif suffix == "docx":
        text = parse_docx(content)
    elif suffix in ("txt", "md"):
        text = content.decode("utf-8")
    else:
        raise HTTPException(400, "格式不支持")

    return {
        "filename": file.filename,
        "chars": len(text),
        "words": len(text.split()),
        "preview": text[:500]
    }

def parse_pdf(content):
    reader = PdfReader(io.BytesIO(content))
    return "\n".join(page.extract_text() for page in reader.pages)

def parse_docx(content):
    doc = Document(io.BytesIO(content))
    return "\n".join(p.text for p in doc.paragraphs)
```

**验收：**
- ✅ 4 种格式都能解析
- ✅ Swagger UI 能上传文件测试
- ✅ 非法格式返回 400
- ✅ README 详细
- ✅ 提交 GitHub

---

## 五、完全掌握检查清单

### Python 语法
- [ ] 能写出 Python 版的 OOP 程序
- [ ] 能用 list / dict / tuple / set
- [ ] 能用 f-string、列表推导式
- [ ] 能用函数（默认参数、*args、**kwargs）

### 环境
- [ ] 能创建虚拟环境
- [ ] 能用 pip install -r requirements.txt
- [ ] 能用 .env 读配置

### 异步
- [ ] 能用 async/await
- [ ] 能用 asyncio.gather 并发

### FastAPI
- [ ] 能用 Pydantic 定义模型
- [ ] 能写 CRUD 接口
- [ ] 能配 CORS
- [ ] 能用依赖注入
- [ ] 能看 Swagger UI

### 综合
- [ ] 完成文件解析服务并提交 GitHub

---

## 六、自测题

**Q1：** Python 和 Java 在 OOP 上的主要差异？
**答案：**
- Python 支持多继承
- Python 用约定（`_` `__`）而非关键字表达可见性
- Python 无显式 interface / abstract（用 abc.ABC 或 Protocol）
- Python 是动态类型（运行时检查）

---

**Q2：** Python 的列表推导式：`[x*x for x in range(10) if x % 2 == 0]` 写成 Java 代码？
**答案：**
```java
List<Integer> result = new ArrayList<>();
for (int x = 0; x < 10; x++) {
    if (x % 2 == 0) result.add(x * x);
}
// 或用 Stream
IntStream.range(0, 10).filter(x -> x % 2 == 0).map(x -> x * x).boxed().toList();
```

---

**Q3：** FastAPI 和 SpringBoot 对比？
**答案：**
- 都是 Web 框架
- FastAPI 自动生成文档、Pydantic 校验更轻便
- SpringBoot 生态成熟、企业级特性强
- 性能 FastAPI 略胜（异步）
- AI 应用首选 FastAPI

---

**Q4：** Python 的 GIL 是什么？
**答案：** 全局解释器锁。同一时刻只有一个线程执行 Python 字节码 → 多线程无法并行计算。
- IO 密集：用多线程 / asyncio 仍有效（IO 等待时释放 GIL）
- CPU 密集：用多进程（multiprocessing）

---

**Q5：** Pydantic 解决什么问题？
**答案：** 类型校验 + 自动文档。把 JSON 自动转 Python 对象，参数错误自动返回 422。

---

## 七、常见坑与误区

| 坑 | 描述 | 解决 |
| --- | --- | --- |
| 缩进错误 | Python 用缩进 | 4 空格统一，别 Tab 和空格混用 |
| 列表浅拷贝 | a = b 是引用 | `a = b.copy()` 或 `a = b[:]` |
| 默认参数是可变对象 | `def f(x=[]):` 跨调用共享 | 改用 `x=None` |
| `is` vs `==` | is 比地址，== 比值 | 用 == |
| 全局变量 | 函数内修改要 `global` | 一般避免 |
| 编码 | 默认 UTF-8 但读文件要指定 | `open(..., encoding="utf-8")` |
| Windows 换行 \r\n | 文件读到 \r | 用 readlines 或 strip |
| 异步函数没 await | 不会执行 | 必须 await 或 asyncio.run |

---

## 八、推荐学习资源

### 视频
- 【B站】尚硅谷 Python 入门到精通
- 【B站】FastAPI 全栈教程

### 书籍
- 《Fluent Python（流畅的 Python）》⭐
- 《Python Cookbook》

### 官方
- [Python 官方教程](https://docs.python.org/zh-cn/3/tutorial/)
- [FastAPI 官方文档](https://fastapi.tiangolo.com/zh/)（中文翻译质量高）
- [Pydantic 文档](https://docs.pydantic.dev/)

---

## 九、本周完成后的"自我画像"

> "我从 Java 转 Python 不超过 1 周就上手了。
> 我能用 FastAPI 5 分钟写出一个 API，自动生成 Swagger 文档。
> 我懂 Pydantic 校验、异步编程、依赖注入。
> 我完成了文件解析服务并提交了 GitHub。
> 我准备好下个月接入 LLM 了。"

---

## 十、下周预告

第 18 周进入 **LLM 基础**：
- Token、Prompt Engineering、Function Calling、Embedding、RAG、MCP、Agent 全部入门
- 直接调用 OpenAI / 国产大模型 API
- 实现 AI 聊天机器人 + 流式输出

正式进入 AI 应用工程师赛道！🚀
