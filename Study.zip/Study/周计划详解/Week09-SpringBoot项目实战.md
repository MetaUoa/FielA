# 第 9 周：SpringBoot 项目实战

> **本周学习目标**：把前 8 周学到的所有内容**整合成一个完整项目**——这是你简历上的"第一个真正项目"。
>
> **本周关键词**：完整项目、Git 管理、README、文件上传、Redis 缓存、定时任务、单元测试
>
> **预计投入时间**：40~50 小时（项目周，时间投入更集中）

---

## 一、项目选型

本周不是学新知识，是**做项目**。从下面 3 个里选一个（按难度递增）：

### 选项 A：博客系统（推荐入门）
**模块：** 用户、文章、分类、标签、评论、点赞、收藏
**亮点：** 文章 Markdown 支持、首页热门文章

### 选项 B：在线考试系统
**模块：** 用户（学生/教师）、题库、试卷、考试、自动判分、成绩
**亮点：** 题目随机抽取、防作弊机制（每个学生题序不同）

### 选项 C：任务管理系统（推荐）
**模块：** 用户、项目、任务、评论、附件、提醒
**亮点：** 看板拖拽、定时提醒、@通知

> 不管选哪个，技术要求和验收标准一样。

---

## 二、技术架构要求

### 必须使用
- **SpringBoot 3.x**（或 2.7.x）
- **MyBatis Plus**
- **MySQL 8** + **Redis 7**
- **JWT** 登录
- **BCrypt** 密码加密
- **Lombok**
- **Hutool** 或 **Apache Commons**（工具库）
- **Logback** 日志（按天滚动）
- **springdoc-openapi**（Swagger）

### 选用（加分项）
- Caffeine（本地缓存）
- EasyExcel（Excel 导入导出）
- MapStruct（对象映射）
- SpringBoot Test + Mockito（单元测试）

---

## 三、项目结构（标准）

```
my-project/
├── pom.xml
├── README.md
├── docker-compose.yml          ← 一键启动 MySQL + Redis
├── sql/
│   └── init.sql                ← 建表脚本
├── docs/
│   ├── api.md                  ← 接口设计
│   ├── db.md                   ← 数据库设计
│   └── screenshots/            ← 截图
└── src/main/
    ├── java/com/xxx/blog/
    │   ├── BlogApplication.java
    │   ├── common/             ← 通用：Result、异常、常量
    │   ├── config/             ← 配置类
    │   ├── controller/         ← 接口层
    │   ├── service/
    │   │   ├── XxxService.java
    │   │   └── impl/
    │   ├── mapper/
    │   ├── entity/             ← 数据库实体
    │   ├── dto/                ← 请求/响应 DTO
    │   ├── vo/                 ← 视图对象
    │   ├── utils/
    │   ├── interceptor/        ← 拦截器
    │   └── aspect/             ← AOP
    └── resources/
        ├── application.yml
        ├── application-dev.yml
        ├── application-prod.yml
        ├── mapper/
        ├── logback-spring.xml
        └── static/
```

---

## 四、本周每日安排（以博客系统为例）

### 周一：项目规划 + 设计

**任务：**
1. 用 [draw.io](https://app.diagrams.net/) 画系统架构图、模块图
2. 用 [draw.io] 画 ER 图（实体关系）
3. 写 `docs/db.md` 数据库设计文档
4. 写 `docs/api.md` 接口设计文档（接口名、方法、参数、返回）
5. **重点：先想清楚再写代码**

**产出：**
- 系统设计文档
- 数据库脚本（init.sql）
- 接口列表

**完全掌握标准：**
- ✅ ER 图至少 8 张表，含字段、类型、注释、索引
- ✅ 接口至少 20 个
- ✅ 文档放到 docs/ 目录

---

### 周二：基础搭建 + 用户模块

**任务：**
1. Spring Initializr 创建项目
2. 引入依赖、配置 yml、Logback
3. 配置 MyBatis Plus、Redis、Swagger
4. 写 `common/` 包：Result、BusinessException、GlobalExceptionHandler、ResultCode 枚举
5. 写 JwtUtil、UserContext、AuthInterceptor
6. **用户注册 + 登录**：
   - 注册：BCrypt 加密
   - 登录：返回 JWT
7. 用户信息修改、密码修改

**验收：**
- ✅ Postman 注册、登录、获取个人信息全通
- ✅ 未登录访问 `/api/users/me` 返回 401
- ✅ 日志正确打印

---

### 周三：核心业务模块（文章 CRUD）

**任务：**
1. 文章模块：分类、标签、文章
2. 接口：
   - `POST /api/articles` 发布
   - `PUT /api/articles/{id}` 修改
   - `DELETE /api/articles/{id}` 删除
   - `GET /api/articles/{id}` 详情
   - `GET /api/articles` 列表（分页 + 多条件查询）
3. 权限：只能操作自己的文章（管理员除外）
4. 数据校验

**验收：**
- ✅ Markdown 内容能正确存取
- ✅ 分页 + 关键字搜索 + 分类筛选都能用
- ✅ 别人改你的文章返回 403

---

### 周四：缓存 + 性能优化

**任务：**
1. **Redis 缓存热门文章**：
   - 查文章详情先查 Redis
   - 未命中查 DB，写回 Redis（5 分钟过期）
   - 修改/删除文章时清缓存
2. **首页热门列表**：用 ZSet 按阅读量排序，定时刷新
3. **浏览量计数**：用 Redis INCR，定时刷回 DB
4. **防穿透**：缓存空值（5 秒过期）
5. **AOP 实现接口耗时统计**
6. **自定义注解 + AOP 实现接口限流**（用 Redis）

**示例：限流注解**

```java
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface RateLimit {
    int qps() default 10;
}

@Aspect
@Component
@RequiredArgsConstructor
public class RateLimitAspect {
    private final StringRedisTemplate redis;

    @Around("@annotation(rl)")
    public Object around(ProceedingJoinPoint pjp, RateLimit rl) throws Throwable {
        String key = "rl:" + pjp.getSignature().toShortString() + ":" + UserContext.get();
        Long count = redis.opsForValue().increment(key);
        if (count == 1) redis.expire(key, 1, TimeUnit.SECONDS);
        if (count > rl.qps()) throw new BusinessException(429, "请求过于频繁");
        return pjp.proceed();
    }
}
```

**验收：**
- ✅ 第二次查文章详情明显变快（看日志）
- ✅ 高频请求触发限流（429）
- ✅ AOP 打印每个接口耗时

---

### 周五：评论、点赞、文件上传

**任务：**
1. **评论模块**：评论 + 回复（自关联表）
2. **点赞模块**：用 Redis Set 存（user → article 集合），减少 DB 压力
3. **文件上传**：
   - 头像上传：`MultipartFile`
   - 存本地或 OSS（推荐 [阿里 OSS](https://www.aliyun.com/product/oss) / [七牛云](https://www.qiniu.com/)）
   - 限制大小（5MB）、类型（jpg/png）
   - 返回访问 URL

**文件上传代码：**

```java
@PostMapping("/upload/avatar")
public Result<String> upload(@RequestPart MultipartFile file) {
    if (file.isEmpty()) throw new BusinessException(400, "文件为空");
    if (file.getSize() > 5 * 1024 * 1024) throw new BusinessException(400, "超过 5MB");

    String suffix = FilenameUtils.getExtension(file.getOriginalFilename());
    if (!Set.of("jpg", "png", "jpeg").contains(suffix.toLowerCase()))
        throw new BusinessException(400, "格式不支持");

    String fileName = UUID.randomUUID() + "." + suffix;
    File dest = new File("/data/uploads/" + fileName);
    file.transferTo(dest);

    return Result.success("/uploads/" + fileName);
}
```

**验收：**
- ✅ 头像上传成功
- ✅ 评论 + 嵌套回复正常
- ✅ 点赞 + 取消点赞、查点赞数

---

### 周六：定时任务、邮件、单元测试

**任务：**
1. **定时任务**：
   - 每天 0 点统计昨日发文数
   - 每 10 分钟把 Redis 浏览量刷回 DB
2. **邮件发送**：注册时发欢迎邮件
3. **单元测试**：至少为 UserService、ArticleService 写 5 个测试用例

**定时任务：**

```java
@Component
@Slf4j
public class StatsTask {
    @Scheduled(cron = "0 0 0 * * ?")  // 每天 0 点
    public void dailyStats() {
        log.info("开始统计...");
    }

    @Scheduled(fixedDelay = 10 * 60 * 1000)
    public void syncViewCount() {
        // ...
    }
}

// 启动类
@EnableScheduling
```

**单元测试：**

```java
@SpringBootTest
class UserServiceTest {
    @Autowired UserService userService;

    @Test
    void testRegister() {
        User u = userService.register("test", "123456");
        assertNotNull(u.getId());
    }
}
```

**验收：**
- ✅ 定时任务能跑（日志看到）
- ✅ 邮件能发送
- ✅ 单元测试至少 5 个，全部通过

---

### 周日：收尾、文档、上传 GitHub

**任务：**
1. **统一日志格式**：每个请求加 traceId（MDC）
2. **接口测试**：用 Postman / Apifox 整理所有接口测试集
3. **写 README**（见下文模板）
4. **截图**：登录、首页、文章详情、Swagger UI、数据库表
5. **打包**：`mvn clean package`，确认能运行 jar
6. **Push 到 GitHub**：含 README、SQL、文档、截图

**README 模板：**

```markdown
# 博客系统

> 个人博客系统：支持注册登录、发文、评论、点赞、Markdown 渲染。

## 技术栈
- SpringBoot 3.2 / MyBatis Plus / MySQL 8 / Redis 7
- JWT / BCrypt / Swagger / Logback

## 功能模块
- [x] 用户注册 / 登录 / 个人信息
- [x] 文章 CRUD + 分类 + 标签
- [x] 评论 + 嵌套回复
- [x] 点赞 / 收藏
- [x] 文件上传
- [x] Redis 缓存 + 限流
- [x] 定时任务
- [x] Swagger 文档

## 快速开始
1. `git clone ...`
2. `docker-compose up -d`（启动 MySQL + Redis）
3. 执行 `sql/init.sql`
4. 修改 `application-dev.yml` 数据库配置
5. `mvn spring-boot:run`
6. 访问 `http://localhost:8080/swagger-ui.html`

## 接口文档
访问 Swagger：`/swagger-ui.html`

## 项目结构
（贴目录树）

## 数据库设计
（贴 ER 图）

## 系统架构
（贴架构图）

## 部分截图
![登录](docs/screenshots/login.png)
![首页](docs/screenshots/home.png)
```

---

## 五、完全掌握检查清单

### 项目完整度
- [ ] 至少 8 张表，至少 30 个接口
- [ ] 至少 3 个角色的业务（如普通用户、作者、管理员）
- [ ] 至少有 3 处使用了 Redis 缓存
- [ ] 至少有 1 处定时任务
- [ ] 至少有 1 处文件上传
- [ ] 至少有 1 个自定义 AOP（如限流、日志）

### 代码质量
- [ ] 包结构清晰（controller/service/mapper/entity/dto/vo）
- [ ] 全局异常 + 统一返回
- [ ] 参数校验 + 全局异常
- [ ] 日志规范（INFO 业务，ERROR 异常，含上下文）
- [ ] 构造注入（不用字段注入）
- [ ] 字段命名规范（驼峰）

### 安全
- [ ] 密码 BCrypt
- [ ] JWT 拦截
- [ ] SQL 注入防护（用 #{}）
- [ ] 权限校验（不能改别人数据）
- [ ] 限流防刷

### 部署
- [ ] 多环境配置（dev / prod）
- [ ] 能打包成 jar 运行
- [ ] docker-compose.yml 一键启动依赖

### 文档
- [ ] README 详细（功能、技术栈、启动步骤、截图）
- [ ] Swagger UI 完整
- [ ] 数据库设计文档
- [ ] 至少 5 张项目截图

### Git
- [ ] 提交记录至少 20 次
- [ ] commit message 规范（feat / fix / docs / refactor）
- [ ] 有 .gitignore（忽略 target、.idea 等）

---

## 六、自测题（项目复盘）

### 项目讲解（必练 ⭐）

面试时一定被问"介绍下你的项目"。准备 3 分钟自我介绍：

> "我做的是一个博客系统，前后端分离。后端用 SpringBoot 3 + MyBatis Plus + MySQL + Redis。
> 用户登录用 JWT 无状态认证，文章详情和热门列表用 Redis 缓存提升了 N 倍性能。
> 我用 AOP + Redis 实现了接口限流，用 ZSet 实现了首页热门文章排行榜。
> 项目有 30 多个接口，部署用 Docker Compose 一键启动……"

**Q1：** 项目里 Redis 解决了什么问题？
**Q2：** 缓存怎么和数据库保持一致？
**Q3：** 限流是怎么实现的？
**Q4：** JWT 怎么实现退出登录？
**Q5：** 你最得意的设计是什么？
**Q6：** 你踩过最大的坑是什么？

**完全掌握标准：**
- ✅ 每个问题都能流畅回答 1~2 分钟
- ✅ 能口述代码实现思路
- ✅ 能讲出至少 2 处"为什么这么设计"

---

## 七、常见坑与误区

| 坑 | 描述 | 解决 |
| --- | --- | --- |
| 把所有逻辑写 Controller | 难维护 | 严格分层（Controller 只校验、Service 处理业务） |
| Service 直接返回 Entity | 字段暴露 | 用 VO（视图对象）转换 |
| 缓存数据不一致 | 老数据返回 | 改数据后**删除**缓存（不是更新） |
| 文件上传到项目目录 | 重启丢失 | 放到独立目录 / OSS |
| 把密码、密钥写代码里 | 安全风险 | 放配置文件 / 环境变量 |
| 没有 traceId | 排查难 | 用 MDC 加 traceId |
| 大量 SELECT * | 浪费 | 只查需要的字段 |
| N+1 查询 | 性能差 | 联表或缓存 |

---

## 八、推荐学习资源

### 项目参考（GitHub）
- [vhr](https://github.com/lenve/vhr)：人事管理系统（经典）
- [novel](https://github.com/201206030/novel)：小说平台
- [mall](https://github.com/macrozheng/mall)：电商系统

### 工具
- Apifox / Postman（接口测试）
- DBeaver / Navicat（数据库）
- Docker Desktop（容器化）

---

## 九、本周完成后的"自我画像"

> "我有了一个能拿出去面试的 SpringBoot 项目。
> 它有完整的用户/认证/业务/缓存/限流/定时任务模块，至少 30 个接口。
> 我能 3 分钟讲清楚项目的架构、技术选型、亮点设计。
> 项目上传到 GitHub 有规范的 README 和截图。
> 我开始有'后端工程师'的样子了。"

---

## 十、下周预告

第 10 周进入 **微服务（SpringCloud）**——把单体应用拆成多个服务。
你将学会服务注册、配置中心、网关、远程调用，进入真正的"分布式系统"领域。

下周见！💪
