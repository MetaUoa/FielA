# 第 11 周：MQ 消息队列

> **本周学习目标**：掌握 RabbitMQ（重点）+ Kafka（了解），能用 MQ 解决异步、解耦、削峰、可靠投递等场景。
>
> **本周关键词**：Exchange、Queue、RoutingKey、ACK、消息可靠性、幂等性、死信队列、延迟消息、Kafka
>
> **预计投入时间**：35~45 小时

---

## 一、本周知识点详细分解

### 1. MQ 概念（半天）

#### 1.1 为什么需要 MQ

**3 大经典场景：**

1. **异步解耦**：用户注册 → 同步发短信 + 邮件 → 改为发消息异步处理
2. **削峰填谷**：秒杀 → 1 万请求 → MQ 缓冲 → 后端按能力消费
3. **服务解耦**：订单服务 → MQ → 物流、积分、推送多个下游

#### 1.2 主流 MQ 对比

| | RabbitMQ | Kafka | RocketMQ | ActiveMQ |
| --- | --- | --- | --- | --- |
| 性能 | 万级 QPS | 百万级 | 十万级 | 万级 |
| 延迟 | 微秒 | 毫秒 | 毫秒 | 毫秒 |
| 可靠性 | 高 | 高 | 高 | 较低 |
| 适用 | 业务消息、低延迟 | 日志、大数据 | 金融、订单 | 老旧 |
| 学习 | ⭐⭐ 简单 | ⭐⭐⭐ 较难 | ⭐⭐⭐ 中等 | - |

**本周重点 RabbitMQ，了解 Kafka。**

#### 1.3 AMQP 协议

RabbitMQ 实现的标准协议。核心概念：
- **Producer**：生产者
- **Consumer**：消费者
- **Broker**：MQ 服务器
- **Virtual Host**：虚拟主机（隔离）
- **Exchange**：交换机（路由）
- **Queue**：队列
- **Binding**：绑定关系

**完全掌握标准：**
- ✅ 能解释 MQ 3 大经典场景
- ✅ 能解释 RabbitMQ 和 Kafka 各自适用什么场景
- ✅ 能解释 AMQP 核心概念

---

### 2. RabbitMQ 安装与基础（半天）

#### 2.1 Docker 安装

```bash
docker run -d --name rabbitmq \
  -p 5672:5672 -p 15672:15672 \
  -e RABBITMQ_DEFAULT_USER=admin \
  -e RABBITMQ_DEFAULT_PASS=admin \
  rabbitmq:3.13-management
```

访问管理界面：`http://localhost:15672`（admin/admin）

#### 2.2 核心模型

```
Producer → Exchange → (binding + routing key) → Queue → Consumer
```

#### 2.3 4 种 Exchange 类型（⭐重点）

##### 2.3.1 Direct（直连）

- 完全匹配 routing key
- 简单点对点

```
Producer (routingKey=info) → Direct Exchange → Queue (binding=info)
```

##### 2.3.2 Fanout（扇出）

- **广播**：忽略 routing key，发给所有绑定的队列
- 适合：消息广播、用户通知

```
Producer → Fanout Exchange → Queue A
                          → Queue B
                          → Queue C
```

##### 2.3.3 Topic（主题）⭐最常用

- routing key 支持模式匹配：
  - `*` 匹配一个单词
  - `#` 匹配多个单词
- 如 `order.*.created` 匹配 `order.normal.created`、`order.vip.created`

```
Producer (routingKey=order.normal.paid) → Topic Exchange
   ↓ binding=order.*.paid    → Queue 支付队列
   ↓ binding=order.#         → Queue 全部订单
```

##### 2.3.4 Headers（不常用）

- 不用 routing key，根据 headers 匹配

**完全掌握标准：**
- ✅ 能画出 RabbitMQ 核心模型图
- ✅ 能解释 4 种 Exchange 的区别
- ✅ 能为不同业务场景选合适的 Exchange

---

### 3. SpringBoot 整合 RabbitMQ（⭐重点 1 天）

#### 3.1 依赖

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-amqp</artifactId>
</dependency>
```

#### 3.2 配置

```yaml
spring:
  rabbitmq:
    host: localhost
    port: 5672
    username: admin
    password: admin
    virtual-host: /
    publisher-confirm-type: correlated   # 发布确认
    publisher-returns: true               # 路由失败回退
    listener:
      simple:
        acknowledge-mode: manual          # 手动 ACK
        prefetch: 1                        # 一次最多预取
        retry:
          enabled: true
          max-attempts: 3
```

#### 3.3 声明 Exchange / Queue / Binding

```java
@Configuration
public class MqConfig {

    public static final String EXCHANGE = "order.exchange";
    public static final String QUEUE_NORMAL = "order.queue.normal";

    @Bean
    public TopicExchange orderExchange() {
        return new TopicExchange(EXCHANGE, true, false);
    }

    @Bean
    public Queue normalQueue() {
        return QueueBuilder.durable(QUEUE_NORMAL)
            .withArgument("x-message-ttl", 60000)          // 消息 60 秒过期
            .withArgument("x-dead-letter-exchange", "dlx.exchange")
            .build();
    }

    @Bean
    public Binding bindNormal() {
        return BindingBuilder.bind(normalQueue())
            .to(orderExchange())
            .with("order.*.created");
    }
}
```

#### 3.4 生产者

```java
@Service
@RequiredArgsConstructor
@Slf4j
public class OrderMessageProducer {
    private final RabbitTemplate rabbitTemplate;

    public void sendOrderCreated(Order order) {
        rabbitTemplate.convertAndSend(
            MqConfig.EXCHANGE,
            "order.normal.created",
            order
        );
        log.info("订单消息已发送: {}", order.getId());
    }
}
```

#### 3.5 消费者

```java
@Component
@Slf4j
public class OrderMessageConsumer {

    @RabbitListener(queues = MqConfig.QUEUE_NORMAL)
    public void onMessage(Order order, Channel channel, Message message) throws IOException {
        long tag = message.getMessageProperties().getDeliveryTag();
        try {
            log.info("消费订单: {}", order.getId());
            // 业务处理
            channel.basicAck(tag, false);              // 手动确认
        } catch (Exception e) {
            log.error("消费失败", e);
            channel.basicNack(tag, false, false);     // false 不重回队列，进死信
        }
    }
}
```

**完全掌握标准：**
- ✅ 能用 SpringBoot 整合 RabbitMQ 收发消息
- ✅ 能用 @Bean 声明 Exchange / Queue / Binding
- ✅ 能开手动 ACK
- ✅ 能用 publisher-confirm 确保发送成功

---

### 4. 消息可靠性（⭐⭐重点 1 天）

消息从生产者到消费者要经过 4 个环节，每个环节都可能丢：

```
Producer → [1] → Exchange → [2] → Queue → [3] → Consumer → [4]
```

#### 4.1 生产者到 Exchange（[1]）

**发布确认（publisher confirm）：**

```yaml
spring.rabbitmq.publisher-confirm-type: correlated
```

```java
rabbitTemplate.setConfirmCallback((correlationData, ack, cause) -> {
    if (!ack) {
        log.error("消息未到 Exchange，原因: {}", cause);
        // 持久化失败消息，定时重发
    }
});
```

#### 4.2 Exchange 到 Queue（[2]）

**路由失败回退（returns）：**

```yaml
spring.rabbitmq.publisher-returns: true
spring.rabbitmq.template.mandatory: true
```

```java
rabbitTemplate.setReturnsCallback(returned -> {
    log.error("路由失败: {}", returned.getMessage());
});
```

#### 4.3 Queue 中间持久化（[3]）

- 队列持久化：`durable=true`
- 消息持久化：`MessageProperties.PERSISTENT_TEXT_PLAIN`
- Spring 默认就持久化

#### 4.4 Queue 到 Consumer（[4]）

**手动 ACK + 异常处理：**
- 业务成功 → `basicAck`
- 业务失败 → `basicNack`，决定是否重回队列
- 消费者崩溃 → RabbitMQ 重新投递给其他消费者

#### 4.5 综合方案：本地消息表 + 重试

1. 业务 + 消息记录在同一个本地事务
2. 提交事务后异步发 MQ
3. 定时任务扫描"未确认"的消息重发
4. 限制最大重试次数，超过进死信处理

**完全掌握标准：**
- ✅ 能列出消息可能丢失的 4 个环节
- ✅ 能配置 publisher-confirm + returns 回调
- ✅ 能用手动 ACK
- ✅ 能解释为什么需要本地消息表

---

### 5. 幂等性（⭐重点 半天）

#### 5.1 为什么需要

- 网络抖动 → 消息重发
- 消费失败 → 重投递
- 同一消息可能被消费多次

#### 5.2 实现方案

##### 方案 1：业务唯一键（推荐）

```java
@Transactional
public void onMessage(Order order) {
    int count = orderMapper.exist(order.getId());
    if (count > 0) {
        log.warn("订单已处理: {}", order.getId());
        return;     // 幂等
    }
    orderMapper.insert(order);
}
```

##### 方案 2：Redis 标记

```java
String key = "msg:processed:" + msgId;
Boolean isNew = redis.opsForValue().setIfAbsent(key, "1", 1, TimeUnit.DAYS);
if (Boolean.FALSE.equals(isNew)) {
    return;  // 已处理
}
// 处理
```

##### 方案 3：数据库唯一索引

数据库层兜底：`UNIQUE KEY uk_msg_id (msg_id)`，重复插入抛异常。

**完全掌握标准：**
- ✅ 能解释为什么消费者要做幂等
- ✅ 能写出 3 种幂等方案
- ✅ 知道方案 1 业务唯一键最常用

---

### 6. 死信队列（DLX，⭐重点 半天）

#### 6.1 什么时候进死信

- 消息被 `basicNack(requeue=false)`
- 消息 TTL 过期
- 队列长度超限

#### 6.2 配置

```java
@Bean
public Queue businessQueue() {
    return QueueBuilder.durable("business.queue")
        .withArgument("x-message-ttl", 60000)
        .withArgument("x-dead-letter-exchange", "dlx.exchange")
        .withArgument("x-dead-letter-routing-key", "dlx.routing.key")
        .build();
}

@Bean
public Queue dlxQueue() {
    return QueueBuilder.durable("dlx.queue").build();
}

@Bean
public DirectExchange dlxExchange() {
    return new DirectExchange("dlx.exchange");
}

@Bean
public Binding dlxBinding() {
    return BindingBuilder.bind(dlxQueue())
        .to(dlxExchange())
        .with("dlx.routing.key");
}
```

#### 6.3 应用场景

- 失败消息存档 → 人工处理
- 延迟队列（业务队列 TTL + DLX）
- 重试次数耗尽

**完全掌握标准：**
- ✅ 能解释 3 种进死信的情况
- ✅ 能配置队列绑定 DLX
- ✅ 能用 DLX 实现失败消息存档

---

### 7. 延迟消息（半天）

#### 7.1 方案 1：TTL + DLX

```
business.queue (TTL=30min) → 30 分钟没人消费 → DLX → delay.consumer.queue
```

**问题：** TTL 不能精确（队头阻塞）。

#### 7.2 方案 2：rabbitmq-delayed-message-exchange 插件（推荐）

```bash
docker exec rabbitmq rabbitmq-plugins enable rabbitmq_delayed_message_exchange
```

```java
@Bean
public CustomExchange delayExchange() {
    Map<String, Object> args = new HashMap<>();
    args.put("x-delayed-type", "direct");
    return new CustomExchange("delay.exchange", "x-delayed-message", true, false, args);
}

// 发送时指定延迟
rabbitTemplate.convertAndSend("delay.exchange", "key", payload, msg -> {
    msg.getMessageProperties().setHeader("x-delay", 30000);  // 30 秒后
    return msg;
});
```

#### 7.3 应用场景

- 订单超时取消（30 分钟未支付）
- 定时提醒
- 优惠券过期通知

**完全掌握标准：**
- ✅ 能用 TTL + DLX 实现延迟
- ✅ 能用插件方式实现精确延迟
- ✅ 能解释为什么 TTL + DLX 不精确

---

### 8. Kafka（了解，1 天）

#### 8.1 Kafka 是什么

- 分布式流处理平台
- 高吞吐（百万 QPS）
- 适合日志、大数据、流计算

#### 8.2 核心概念

- **Producer**：生产者
- **Consumer**：消费者
- **Topic**：主题
- **Partition**：分区（同 Topic 拆多份并行）
- **Replica**：副本
- **Broker**：节点
- **Consumer Group**：消费者组

#### 8.3 Producer / Consumer / Partition 关系

- 一个 Topic 有多个 Partition
- 一个 Partition 内消息有序
- 同一 Consumer Group 内每个 Partition 只被一个消费者消费 → 并行
- 不同 Group 各自消费完整 Topic（广播）

#### 8.4 SpringBoot 整合（了解）

```xml
<dependency>
    <groupId>org.springframework.kafka</groupId>
    <artifactId>spring-kafka</artifactId>
</dependency>
```

```yaml
spring:
  kafka:
    bootstrap-servers: localhost:9092
    producer:
      key-serializer: org.apache.kafka.common.serialization.StringSerializer
      value-serializer: org.springframework.kafka.support.serializer.JsonSerializer
    consumer:
      group-id: my-group
      key-deserializer: org.apache.kafka.common.serialization.StringDeserializer
      value-deserializer: org.springframework.kafka.support.serializer.JsonDeserializer
```

```java
// Producer
kafkaTemplate.send("topic-order", order);

// Consumer
@KafkaListener(topics = "topic-order")
public void onMessage(Order order) { ... }
```

#### 8.5 RabbitMQ vs Kafka

| | RabbitMQ | Kafka |
| --- | --- | --- |
| 设计 | 推（Push） | 拉（Pull） |
| 顺序 | 队列内有序 | Partition 内有序 |
| 吞吐 | 万级 | 百万级 |
| 延迟 | 微秒 | 毫秒 |
| 适用 | 业务消息 | 日志、大数据 |

**完全掌握标准（了解级别）：**
- ✅ 能解释 Topic / Partition / Consumer Group
- ✅ 能解释 Kafka 高吞吐的原因（顺序写、零拷贝、分区并行）
- ✅ 能解释 RabbitMQ vs Kafka 区别

---

## 二、每日学习安排

| 天 | 学习内容 | 上机练习 | 时长 |
| --- | --- | --- | --- |
| **周一** | MQ 概念 + 安装 RabbitMQ + 管理界面 | Hello World 发收 | 4h |
| **周二** | 4 种 Exchange + SpringBoot 整合 ⭐ | 各 Exchange 写 demo | 6h |
| **周三** | 消息可靠性 ⭐ | 配 confirm + return + 手动 ACK | 6h |
| **周四** | 幂等性 + 死信队列 ⭐ | 实现幂等消费 + DLX | 6h |
| **周五** | 延迟消息 ⭐ | 订单超时取消 demo | 6h |
| **周六** | Kafka 概念 + SpringBoot 整合 | Kafka 收发 | 5h |
| **周日** | 综合实战 + 复盘 | 异步下单 + 提交 GitHub | 6h |

---

## 三、本周必做实战项目（2 个）

### 项目 1：异步下单系统

**业务流程：**
1. 用户下单 → 写库（订单状态：待支付）
2. 发 MQ 消息（订单已创建）
3. 异步：扣库存、加积分、发邮件、推送通知

**技术要点：**
- ✅ Topic Exchange 一发多消费
- ✅ 多个 Consumer 监听不同子任务
- ✅ 消费失败进 DLX
- ✅ 消费者做幂等

**验收：**
- ✅ 下单接口快速返回（不等异步任务）
- ✅ 异步任务都成功执行
- ✅ 模拟失败 → 进死信 → 能看到

---

### 项目 2：订单超时自动取消

**业务流程：**
1. 用户下单 → 状态待支付
2. 发延迟消息（30 分钟后到期）
3. 30 分钟后消费 → 查订单状态
   - 已支付 → 跳过
   - 未支付 → 取消 + 回退库存

**技术要点：**
- ✅ rabbitmq-delayed-message-exchange 插件
- ✅ 消费者幂等
- ✅ 状态机判断

**验收：**
- ✅ 30 分钟内支付：订单成功，无取消
- ✅ 不支付：30 分钟自动取消，库存回退

---

## 四、完全掌握检查清单

### 基础
- [ ] 能解释 MQ 3 大经典场景
- [ ] 能画 RabbitMQ 核心模型
- [ ] 能解释 4 种 Exchange 区别

### 整合
- [ ] 能用 SpringBoot 收发消息
- [ ] 能用 @Bean 声明 Exchange/Queue/Binding
- [ ] 能开手动 ACK

### 可靠性
- [ ] 能列出消息丢失的 4 个环节
- [ ] 能配置 publisher-confirm
- [ ] 能写 return callback
- [ ] 能解释本地消息表

### 幂等
- [ ] 能用业务唯一键防重
- [ ] 能用 Redis 防重
- [ ] 能解释为什么消费者要幂等

### DLX
- [ ] 能解释 3 种进死信的情况
- [ ] 能配置 DLX

### 延迟
- [ ] 能用 TTL + DLX 实现延迟
- [ ] 能用插件方式实现精确延迟

### Kafka
- [ ] 能解释 Topic/Partition/Consumer Group
- [ ] 能用 SpringBoot 整合 Kafka

### 综合
- [ ] 完成 2 个项目并提交 GitHub

---

## 五、自测题

**Q1：** RabbitMQ 的 4 种 Exchange 分别用于什么场景？
**答案：**
- Direct：点对点，精确匹配
- Fanout：广播（用户通知）
- Topic：模式匹配（最常用）
- Headers：按 header 匹配（少用）

---

**Q2：** 消息会丢吗？怎么保证不丢？
**答案：** 4 个环节都可能丢：
1. Producer → Exchange：publisher-confirm
2. Exchange → Queue：returns + 持久化
3. Queue 存储：队列 + 消息持久化
4. Queue → Consumer：手动 ACK

---

**Q3：** 消费者重复消费怎么办？
**答案：** 做幂等：
- 业务唯一键
- Redis 标记
- 数据库唯一索引

---

**Q4：** 死信队列什么时候用？
**答案：**
- 消息被 nack 不重回时
- 消息 TTL 过期
- 队列满
- 应用：失败消息存档、延迟消息

---

**Q5：** RabbitMQ 怎么实现延迟消息？
**答案：**
- 方案 1：业务队列设置 TTL + DLX，TTL 到期进死信
- 方案 2：rabbitmq-delayed-message-exchange 插件（推荐）

---

**Q6：** Kafka 为什么这么快？
**答案：**
- 顺序写磁盘
- 零拷贝（sendfile）
- 批量发送
- 分区并行
- 压缩

---

## 六、常见坑与误区

| 坑 | 描述 | 解决 |
| --- | --- | --- |
| 默认自动 ACK | 业务异常消息也消费成功 | 改手动 ACK |
| 消息没设持久化 | 重启丢失 | 队列 + 消息持久化 |
| 没做幂等 | 重复消费产生脏数据 | 业务唯一键 |
| TTL 不精确 | 队头阻塞 | 用插件 |
| nack(requeue=true) 死循环 | 失败消息无限重投 | requeue=false 进 DLX |
| 大消息 | 阻塞队列 | 拆分或用对象存储 |
| 网络抖动 confirm 丢 | 误以为发送失败 | 加重试 + 本地消息表 |

---

## 七、推荐学习资源

### 视频
- 【B站】黑马程序员 RabbitMQ 入门到实战
- 【B站】尚硅谷 Kafka 教程

### 书籍
- 《RabbitMQ 实战指南》
- 《Kafka 权威指南》

### 官方
- [RabbitMQ 教程](https://www.rabbitmq.com/getstarted.html)
- [Spring AMQP](https://docs.spring.io/spring-amqp/docs/current/reference/html/)

---

## 八、本周完成后的"自我画像"

> "我懂 MQ 解决的 3 大经典场景（异步、解耦、削峰）。
> 我能用 RabbitMQ + SpringBoot 实现消息可靠投递、幂等消费、死信处理、延迟消息。
> 我能解释 4 种 Exchange 的差异和适用场景。
> 我了解 Kafka 的高吞吐设计。
> 我完成了异步下单和订单超时取消 2 个项目。"

---

## 九、下周预告

第 12 周：**Docker + Linux**。
你将学会容器化部署应用，让"在我电脑上能跑"变成"在哪都能跑"。
是连接开发和运维的关键桥梁。

下周见！💪
