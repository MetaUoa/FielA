# 第 5 周：MySQL

> **本周学习目标**：能独立设计数据库表结构、写复杂 SQL、用索引优化查询、理解事务和 MVCC。
>
> **本周关键词**：CRUD、JOIN、子查询、索引、explain、事务、ACID、MVCC、慢查询、SQL 优化
>
> **预计投入时间**：35~45 小时

---

## 一、本周知识点详细分解

### 1. MySQL 环境准备（半天）

#### 1.1 安装与连接

- **MySQL 版本**：推荐 8.0+（默认字符集 utf8mb4，性能优化）
- **客户端工具**：
  - **DBeaver**（推荐，免费跨平台）
  - **Navicat**（收费但好用）
  - **DataGrip**（JetBrains，学生免费）
  - 命令行 `mysql` 也要会用

#### 1.2 必会基础操作

```sql
-- 数据库
CREATE DATABASE shop CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
SHOW DATABASES;
USE shop;
DROP DATABASE shop;

-- 表
SHOW TABLES;
DESC user;
SHOW CREATE TABLE user;
```

**完全掌握标准：**
- ✅ 能在 10 分钟内装好 MySQL 8 并连上客户端
- ✅ 能创建数据库并指定 utf8mb4 字符集
- ✅ 知道为什么用 utf8mb4 不用 utf8（utf8 是 3 字节，存不下 emoji；utf8mb4 是真正的 4 字节 UTF-8）

---

### 2. 表设计与数据类型（半天）

#### 2.1 常用数据类型

| 类型 | 说明 | 例子 |
| --- | --- | --- |
| `TINYINT` | 1 字节，常用作布尔 | `is_deleted TINYINT` |
| `INT` | 4 字节 | `id INT` |
| `BIGINT` | 8 字节，自增主键推荐 | `id BIGINT` |
| `DECIMAL(10,2)` | 精确小数（金额必用） | `price DECIMAL(10,2)` |
| `VARCHAR(n)` | 变长字符串 | `name VARCHAR(50)` |
| `CHAR(n)` | 定长字符串 | `code CHAR(6)` |
| `TEXT` | 长文本（< 64KB） | `content TEXT` |
| `LONGTEXT` | 超长文本（< 4GB） | - |
| `DATETIME` | 日期时间 | `created_at DATETIME` |
| `TIMESTAMP` | 时间戳（自动更新） | - |
| `JSON` | JSON 类型（MySQL 5.7+） | `extra JSON` |

#### 2.2 表设计规范（阿里规范）

- 主键必须：`id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY`
- 必有 3 字段：`created_at`、`updated_at`、`is_deleted`
- 字段名小写下划线：`user_name`，不用驼峰
- 表名小写复数或单数（团队统一）
- VARCHAR 不超过 5000，超过用 TEXT
- 禁用 ENUM（不灵活）
- **不用** float / double 存金额，用 DECIMAL
- 表必须有注释，字段必须有注释

```sql
CREATE TABLE `user` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(50) NOT NULL COMMENT '用户名',
    `age` TINYINT UNSIGNED COMMENT '年龄',
    `email` VARCHAR(100) COMMENT '邮箱',
    `balance` DECIMAL(10,2) DEFAULT 0 COMMENT '余额',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `is_deleted` TINYINT DEFAULT 0 COMMENT '0未删 1已删'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';
```

**完全掌握标准：**
- ✅ 能为电商场景设计 user / product / order 表
- ✅ 能解释为什么金额用 DECIMAL
- ✅ 能解释为什么主键用 BIGINT 而不是 INT
- ✅ 能解释 VARCHAR vs CHAR 的区别（前者变长省空间，后者定长更快）
- ✅ 知道 DATETIME vs TIMESTAMP（前者 8 字节范围广，后者 4 字节 2038 问题）

---

### 3. CRUD 基础（1 天）

#### 3.1 增

```sql
-- 单条
INSERT INTO user (name, age) VALUES ('Alice', 20);

-- 多条
INSERT INTO user (name, age) VALUES ('Bob', 25), ('Charlie', 30);

-- INSERT ... SELECT
INSERT INTO user_backup SELECT * FROM user WHERE created_at < '2024-01-01';

-- 主键冲突时更新（UPSERT）
INSERT INTO user (id, name) VALUES (1, 'X')
ON DUPLICATE KEY UPDATE name = 'X';
```

#### 3.2 删

```sql
DELETE FROM user WHERE id = 1;
DELETE FROM user WHERE created_at < '2023-01-01' LIMIT 1000;  -- 分批删

-- 注意区别
DELETE FROM user;          -- 可回滚，慢
TRUNCATE TABLE user;       -- 不可回滚，快，自增重置
DROP TABLE user;           -- 删表结构
```

#### 3.3 改

```sql
UPDATE user SET age = 21 WHERE id = 1;
UPDATE user SET balance = balance + 100 WHERE id = 1;
```

#### 3.4 查（重点⭐）

```sql
-- 基本查询
SELECT id, name, age FROM user WHERE age > 18;

-- 排序
SELECT * FROM user ORDER BY created_at DESC, age ASC;

-- 分页
SELECT * FROM user LIMIT 10;            -- 前 10 条
SELECT * FROM user LIMIT 20, 10;        -- 跳过 20，取 10（第 3 页）
SELECT * FROM user LIMIT 10 OFFSET 20;  -- 同上

-- 去重
SELECT DISTINCT city FROM user;

-- 模糊查询
SELECT * FROM user WHERE name LIKE 'A%';   -- A 开头
SELECT * FROM user WHERE name LIKE '%a%';  -- 含 a（不走索引）

-- 范围查询
SELECT * FROM user WHERE age BETWEEN 18 AND 30;
SELECT * FROM user WHERE city IN ('北京', '上海');

-- NULL 判断（不能用 = ）
SELECT * FROM user WHERE email IS NULL;
SELECT * FROM user WHERE email IS NOT NULL;
```

**完全掌握标准：**
- ✅ 能写出 CRUD 各种变体
- ✅ 知道 LIMIT 分页公式：`LIMIT (page-1)*size, size`
- ✅ 知道 NULL 比较必须用 IS NULL 而不是 = NULL
- ✅ 知道 DELETE / TRUNCATE / DROP 区别
- ✅ 知道 INSERT ... ON DUPLICATE KEY UPDATE 的用法

---

### 4. 聚合与分组（半天）

#### 4.1 聚合函数

```sql
SELECT COUNT(*) FROM user;
SELECT COUNT(DISTINCT city) FROM user;
SELECT AVG(age), SUM(balance), MIN(age), MAX(age) FROM user;
```

#### 4.2 GROUP BY + HAVING

```sql
-- 每个城市的用户数
SELECT city, COUNT(*) AS cnt
FROM user
GROUP BY city;

-- 用户数超过 100 的城市
SELECT city, COUNT(*) AS cnt
FROM user
GROUP BY city
HAVING cnt > 100
ORDER BY cnt DESC;
```

**WHERE vs HAVING：**
- WHERE 在分组前过滤行
- HAVING 在分组后过滤组

#### 4.3 SQL 执行顺序（⭐高频面试）

```
FROM → ON → JOIN → WHERE → GROUP BY → HAVING → SELECT → DISTINCT → ORDER BY → LIMIT
```

**完全掌握标准：**
- ✅ 能写出 GROUP BY + HAVING 的查询
- ✅ 能背出 SQL 执行顺序
- ✅ 能解释 WHERE 和 HAVING 的区别
- ✅ 知道 `COUNT(*)` vs `COUNT(1)` vs `COUNT(column)` 的区别（前两个等价，第三个不统计 NULL）

---

### 5. JOIN（连接，⭐重点 1 天）

#### 5.1 7 种 JOIN

```
A 表    B 表
┌───┐  ┌───┐
│ A │  │ B │
└───┘  └───┘

INNER JOIN：  A ∩ B          只取交集
LEFT  JOIN：  A 全部 + 交集    左外
RIGHT JOIN：  B 全部 + 交集    右外
FULL  JOIN：  A ∪ B（MySQL 不支持，用 UNION 模拟）

LEFT  JOIN + B.x IS NULL：    只在 A 不在 B
RIGHT JOIN + A.x IS NULL：    只在 B 不在 A
FULL  JOIN + IS NULL：        对称差
```

#### 5.2 示例

```sql
-- 用户和订单（左连接：所有用户，包括没订单的）
SELECT u.id, u.name, o.id AS order_id, o.amount
FROM user u
LEFT JOIN order o ON u.id = o.user_id;

-- 内连接（只取有订单的用户）
SELECT u.id, u.name, o.id AS order_id
FROM user u
INNER JOIN order o ON u.id = o.user_id;

-- 找出从未下单的用户
SELECT u.*
FROM user u
LEFT JOIN order o ON u.id = o.user_id
WHERE o.id IS NULL;

-- 多表连接
SELECT u.name, o.id AS order_id, p.name AS product
FROM user u
JOIN order o ON u.id = o.user_id
JOIN order_item oi ON o.id = oi.order_id
JOIN product p ON oi.product_id = p.id;
```

**完全掌握标准：**
- ✅ 能画出 7 种 JOIN 的韦恩图
- ✅ 能用 LEFT JOIN 找"未下单的用户"
- ✅ 能写 3 表 JOIN
- ✅ 知道 ON 和 WHERE 的区别（LEFT JOIN 时 ON 不过滤左表，WHERE 会）

---

### 6. 子查询（半天）

#### 6.1 子查询类型

```sql
-- 标量子查询（返回单值）
SELECT * FROM user WHERE age > (SELECT AVG(age) FROM user);

-- 行子查询（返回一行）
SELECT * FROM user WHERE (city, age) = (SELECT city, MAX(age) FROM user WHERE city='北京');

-- 列子查询（返回一列）
SELECT * FROM user WHERE id IN (SELECT user_id FROM order WHERE amount > 100);

-- 表子查询（FROM 后）
SELECT a.city, a.cnt FROM (
    SELECT city, COUNT(*) AS cnt FROM user GROUP BY city
) a WHERE a.cnt > 100;

-- EXISTS（高效，不返回数据）
SELECT * FROM user u WHERE EXISTS (
    SELECT 1 FROM order o WHERE o.user_id = u.id
);
```

#### 6.2 IN vs EXISTS

- IN：先查子查询，再外查
- EXISTS：外表驱动，逐行判断
- 一般：**小表 IN，大表 EXISTS**

**完全掌握标准：**
- ✅ 能写 4 种子查询
- ✅ 能用 EXISTS 替代 IN 优化
- ✅ 能用子查询找"工资比领导高的员工"

---

### 7. 索引（⭐⭐⭐重点 1 天）

#### 7.1 索引类型

| 类型 | 说明 |
| --- | --- |
| 主键索引（PRIMARY KEY） | 自动创建，唯一非空 |
| 唯一索引（UNIQUE） | 不可重复 |
| 普通索引（INDEX） | 加速查询 |
| 联合索引（多列） | 最左前缀原则 |
| 全文索引（FULLTEXT） | 文本搜索 |

#### 7.2 索引底层（InnoDB）

- **B+ 树**结构
- **聚簇索引**：数据和主键索引在一起（叶子节点存完整行）
- **二级索引**：叶子节点存主键值，需要"回表"

为什么是 B+ 树？
- 比 B 树矮（叶子才存数据，非叶子能放更多 key）
- 叶子链表，范围查询快
- 比哈希表支持范围查询和排序

#### 7.3 创建索引

```sql
-- 建表时
CREATE TABLE user (
    id BIGINT PRIMARY KEY,
    email VARCHAR(100) UNIQUE,
    name VARCHAR(50),
    INDEX idx_name (name),
    INDEX idx_city_age (city, age)   -- 联合索引
);

-- 已有表
CREATE INDEX idx_name ON user(name);
ALTER TABLE user ADD INDEX idx_email (email);

-- 删除
DROP INDEX idx_name ON user;
```

#### 7.4 最左前缀原则（⭐）

联合索引 `(a, b, c)` 实际有效的索引使用：
- `WHERE a = ?`            ✅
- `WHERE a = ? AND b = ?`  ✅
- `WHERE a = ? AND b = ? AND c = ?` ✅
- `WHERE b = ?`            ❌ 不走索引
- `WHERE a = ? AND c = ?`  ⚠ 只用 a

#### 7.5 索引失效场景（⭐高频面试）

```sql
-- 1. 函数操作
WHERE YEAR(created_at) = 2024     -- ❌
WHERE created_at BETWEEN '2024-01-01' AND '2024-12-31'  -- ✅

-- 2. 隐式类型转换
WHERE phone = 13800000000          -- ❌（phone 是 varchar）
WHERE phone = '13800000000'        -- ✅

-- 3. LIKE 左模糊
WHERE name LIKE '%张'              -- ❌
WHERE name LIKE '张%'              -- ✅

-- 4. != 或 <>
WHERE status != 1                  -- 可能不走索引

-- 5. NULL 判断（取决于 MySQL 版本）
-- 6. OR 连接的非索引列
-- 7. 索引列参与运算
WHERE age + 1 = 20                 -- ❌
WHERE age = 19                     -- ✅
```

#### 7.6 覆盖索引

如果 SELECT 的字段都在索引里，无需回表。

```sql
-- 假设有 (name, age) 联合索引
SELECT name, age FROM user WHERE name = 'Alice';  -- ✅ 覆盖索引
SELECT * FROM user WHERE name = 'Alice';          -- ❌ 需要回表
```

**完全掌握标准：**
- ✅ 能解释 B+ 树为什么适合做索引
- ✅ 能解释聚簇索引 vs 二级索引（回表）
- ✅ 能背出最左前缀原则
- ✅ 能背出至少 5 种索引失效场景
- ✅ 能解释覆盖索引的好处
- ✅ 能为常见查询设计合理的索引
- ✅ 知道索引不是越多越好（占空间 + 影响写性能）

---

### 8. explain（⭐⭐重点，半天）

#### 8.1 用法

```sql
EXPLAIN SELECT * FROM user WHERE name = 'Alice';
```

#### 8.2 重要字段

| 字段 | 含义 |
| --- | --- |
| `id` | 查询序号，越大越先执行 |
| `select_type` | SIMPLE / PRIMARY / SUBQUERY 等 |
| `table` | 表名 |
| `type`⭐ | **访问类型**：system > const > eq_ref > ref > range > index > ALL |
| `possible_keys` | 可能用到的索引 |
| `key`⭐ | 实际用到的索引 |
| `key_len` | 索引使用的字节数（看联合索引用了几列） |
| `ref` | 索引比较的字段 |
| `rows`⭐ | 估计要扫描的行数 |
| `Extra`⭐ | 额外信息（Using index / Using filesort / Using temporary） |

#### 8.3 type 类型从快到慢

- `system`：表只有一行
- `const`：主键 / 唯一索引等值查询
- `eq_ref`：JOIN 用主键 / 唯一索引等值
- `ref`：普通索引等值
- `range`：范围查询（BETWEEN、>、<、IN）
- `index`：扫描整个索引
- `ALL`：全表扫描（最差）

#### 8.4 Extra 重要项

- `Using index`：覆盖索引（好）
- `Using where`：过滤
- `Using filesort`：需要额外排序（差）
- `Using temporary`：使用临时表（差）
- `Using join buffer`：JOIN 无索引

**完全掌握标准：**
- ✅ 能用 explain 看 SQL 执行计划
- ✅ 能判断哪些 SQL 慢、为什么慢
- ✅ 知道 `type = ALL` 必须优化
- ✅ 知道 `Using filesort` 和 `Using temporary` 都是性能警告

---

### 9. 事务与 ACID（半天）

#### 9.1 ACID

- **A**tomicity（原子性）：要么全成功，要么全失败（靠 undo log）
- **C**onsistency（一致性）：数据约束不破坏
- **I**solation（隔离性）：多事务互不干扰
- **D**urability（持久性）：提交后永久（靠 redo log）

#### 9.2 事务用法

```sql
START TRANSACTION;
UPDATE account SET balance = balance - 100 WHERE id = 1;
UPDATE account SET balance = balance + 100 WHERE id = 2;
COMMIT;     -- 或 ROLLBACK;
```

#### 9.3 4 种隔离级别（⭐）

| 级别 | 脏读 | 不可重复读 | 幻读 |
| --- | --- | --- | --- |
| READ UNCOMMITTED 读未提交 | ✓ | ✓ | ✓ |
| READ COMMITTED 读已提交（Oracle 默认） | ✗ | ✓ | ✓ |
| **REPEATABLE READ 可重复读**（MySQL 默认） | ✗ | ✗ | ✓ |
| SERIALIZABLE 串行化 | ✗ | ✗ | ✗ |

**三个问题：**
- **脏读**：读到其他事务**未提交**的数据
- **不可重复读**：同一事务内同一行**读两次值不同**
- **幻读**：同一事务内同一查询**返回的行数不同**

#### 9.4 MySQL 怎么实现的

- READ COMMITTED：每次读都生成新 read view
- REPEATABLE READ：事务开始时生成 read view，全程不变（靠 MVCC）
- 幻读：靠间隙锁（Gap Lock）解决

**完全掌握标准：**
- ✅ 能背出 ACID 四个特性
- ✅ 能背出 4 种隔离级别和对应解决的问题
- ✅ 知道 MySQL 默认 REPEATABLE READ
- ✅ 能解释脏读 / 不可重复读 / 幻读的区别

---

### 10. MVCC（多版本并发控制，⭐重点 半天）

#### 10.1 核心思想

每行数据有多个版本，读不加锁，写新版本。

#### 10.2 实现

每行隐藏字段：
- `DB_TRX_ID`：最后修改的事务 ID
- `DB_ROLL_PTR`：指向 undo log 的指针
- `DB_ROW_ID`：行 ID

**undo log** 链：保存历史版本。

#### 10.3 read view（读视图）

事务读取时，根据 trx_id 判断版本是否可见：
- 比当前 trx 小且已提交 → 可见
- 否则 → 顺着 undo log 找上一个版本

**完全掌握标准：**
- ✅ 能解释 MVCC 实现高并发读
- ✅ 能解释 REPEATABLE READ 下的可重复读如何实现的（read view 不变）
- ✅ 知道 MVCC 只在 InnoDB 引擎

---

### 11. 锁（半天）

#### 11.1 锁的分类

按粒度：
- 表锁：MyISAM
- 行锁：InnoDB
- 页锁：很少

按类型：
- 共享锁（S 锁，读锁）：`SELECT ... LOCK IN SHARE MODE`
- 排它锁（X 锁，写锁）：`SELECT ... FOR UPDATE`、UPDATE/DELETE

#### 11.2 InnoDB 行锁

- **记录锁（Record Lock）**：锁单行
- **间隙锁（Gap Lock）**：锁区间（RR 隔离级别）
- **临键锁（Next-Key Lock）**：记录 + 前面的间隙

**完全掌握标准：**
- ✅ 能解释共享锁 vs 排它锁
- ✅ 能用 `FOR UPDATE` 加行锁
- ✅ 知道行锁基于索引（没有索引会升级为表锁）

---

### 12. SQL 优化（半天）

#### 12.1 基础优化

- **避免 `SELECT *`**：只查需要的字段
- **WHERE 加索引**：常查字段建索引
- **LIMIT 优化**：深分页用游标 + ID
  ```sql
  -- 慢
  SELECT * FROM order LIMIT 1000000, 10;
  -- 快
  SELECT * FROM order WHERE id > 1000000 LIMIT 10;
  ```
- **JOIN 顺序**：小表驱动大表
- **批量插入**：INSERT 多条 vs 多次 INSERT
- **避免函数**：`WHERE YEAR(created_at)` → 范围查询
- **避免类型转换**：字符串字段不要传数字

#### 12.2 慢查询日志

```sql
-- 开启
SET GLOBAL slow_query_log = ON;
SET GLOBAL long_query_time = 1;  -- 超过 1 秒算慢

-- 查看
SHOW VARIABLES LIKE 'slow_query_log%';
```

**完全掌握标准：**
- ✅ 能列出 5+ SQL 优化技巧
- ✅ 能解释深分页问题及优化方案
- ✅ 能用慢查询日志找慢 SQL

---

## 二、每日学习安排

| 天 | 学习内容 | 上机练习 | 时长 |
| --- | --- | --- | --- |
| **周一** | 安装 + 数据类型 + 表设计 | 设计电商 5 张表 | 5h |
| **周二** | CRUD + 聚合 + 分组 | 写 30 道 CRUD 题 | 5h |
| **周三** | JOIN ⭐ + 子查询 | 写 20 道多表查询题 | 6h |
| **周四** | 索引 + B+ 树原理 ⭐ | 为已有表加索引 + 测试性能 | 6h |
| **周五** | explain + SQL 优化 | 分析慢 SQL + 优化 | 6h |
| **周六** | 事务 + ACID + 隔离级别 + MVCC ⭐ | 模拟脏读/不可重复读 | 5h |
| **周日** | 锁 + 综合实战 + 复盘 | 设计完整电商数据库 + 提交 GitHub | 6h |

---

## 三、本周必做实战项目

### 项目：电商数据库设计 + 复杂查询

**表设计要求（至少 8 张）：**

```sql
-- user 用户表
-- product 商品表
-- product_category 商品分类表
-- order 订单表
-- order_item 订单明细表
-- address 收货地址表
-- coupon 优惠券表
-- review 评价表
```

**每张表要求：**
- 有主键（BIGINT 自增）
- 有 created_at / updated_at / is_deleted
- 有合理索引
- 有外键关系（先用逻辑外键，不一定建物理外键）
- 字段有 COMMENT

**复杂查询任务（写 SQL，不用代码）：**

1. 查询每个用户的订单总数和总金额
2. 查询最近 7 天每天的销售额
3. 查询销量 Top 10 的商品
4. 查询从未下单的用户
5. 查询消费金额超过 1000 的用户
6. 查询每个分类下销量最高的商品（窗口函数或子查询）
7. 查询用户的"上次购买时间到现在的天数"
8. 查询连续下单 3 天以上的用户
9. 用 LEFT JOIN + IS NULL 找有评论但没收货地址的用户
10. 用 EXISTS 查询有过订单的用户

**验收标准：**
- ✅ 至少 100 条测试数据（用 SQL 批量生成）
- ✅ 所有查询都能跑通
- ✅ 用 explain 分析每个查询并截图说明
- ✅ 至少 3 个查询通过加索引优化性能

---

## 四、完全掌握检查清单

### 基础
- [ ] 能默写表创建语句（含注释、字符集、引擎）
- [ ] 能写出 CRUD 所有变体
- [ ] 能用 GROUP BY + HAVING
- [ ] 能背 SQL 执行顺序

### JOIN
- [ ] 能画出 7 种 JOIN 韦恩图
- [ ] 能写 3 表 JOIN
- [ ] 能用 LEFT JOIN 找"独立用户"

### 索引
- [ ] 能解释 B+ 树为什么适合做索引
- [ ] 能解释聚簇索引 vs 二级索引
- [ ] 能背最左前缀原则
- [ ] 能列出 5 种索引失效场景
- [ ] 能为查询设计合适的联合索引

### explain
- [ ] 能用 explain 分析 SQL
- [ ] 能解释 type 各值
- [ ] 能识别 Using filesort / Using temporary

### 事务
- [ ] 能背 ACID
- [ ] 能背 4 种隔离级别
- [ ] 能解释脏读 / 不可重复读 / 幻读
- [ ] 能解释 MVCC

### 综合
- [ ] 完成电商数据库设计项目
- [ ] 至少 10 条复杂查询能跑通
- [ ] 提交 SQL 脚本到 GitHub

---

## 五、自测题

**Q1：** `COUNT(*)`、`COUNT(1)`、`COUNT(column)` 有什么区别？
**答案：**
- `COUNT(*)` 和 `COUNT(1)` 等价，统计所有行
- `COUNT(column)` 不统计 column 为 NULL 的行
- 在 InnoDB 中 `COUNT(*)` 已优化，不比 `COUNT(1)` 慢

---

**Q2：** 下面哪个 SQL 走索引？（假设 `name` 有索引）
```sql
A. WHERE name = 'Alice'
B. WHERE name LIKE 'A%'
C. WHERE name LIKE '%A'
D. WHERE LEFT(name, 1) = 'A'
```
**答案：** A、B 走，C、D 不走。

---

**Q3：** 有联合索引 (a, b, c)，下面哪个 SQL 走索引？
```sql
A. WHERE a = 1 AND b = 2 AND c = 3
B. WHERE b = 2 AND a = 1 AND c = 3
C. WHERE a = 1 AND c = 3
D. WHERE b = 2 AND c = 3
```
**答案：** A、B、C 走，D 不走。B 走是因为 MySQL 优化器会重排顺序。

---

**Q4：** MySQL 默认隔离级别是什么？解决了什么问题？
**答案：** REPEATABLE READ。解决了脏读、不可重复读，并通过间隙锁解决了大部分幻读。

---

**Q5：** 什么时候索引会失效？至少说 5 种。
**答案：**
1. 函数运算 `YEAR(col)`
2. 隐式类型转换
3. LIKE 左模糊 `'%x'`
4. OR 连接非索引列
5. != 或 <>
6. 索引列参与运算 `col + 1 = 10`
7. 不符合最左前缀

---

**Q6：** 解释 `EXPLAIN` 中 `type` 各值的含义和从快到慢的顺序。
**答案：** system > const > eq_ref > ref > range > index > ALL

---

**Q7：** 怎么优化深分页（`LIMIT 1000000, 10`）？
**答案：**
- 用主键游标：`WHERE id > last_id LIMIT 10`
- 用覆盖索引：`SELECT id FROM ... LIMIT N, 10` 再 JOIN
- 业务上限制最大页数

---

## 六、常见坑与误区

| 坑 | 描述 | 解决方案 |
| --- | --- | --- |
| 用 float 存金额 | 精度丢失 | 用 DECIMAL |
| utf8 存 emoji | 失败 | 用 utf8mb4 |
| 索引乱建 | 影响写性能 + 占空间 | 看 explain 实际是否用到 |
| 大事务 | 锁多、慢 | 拆分 |
| `SELECT *` | 网络/内存浪费 | 只查需要的字段 |
| WHERE 在 LEFT JOIN | 退化为 INNER JOIN | 用 ON |
| 不区分 = 和 IS NULL | 永远查不到 | NULL 用 IS NULL |
| 联合索引顺序错 | 不走索引 | 把区分度高、常查的放前面 |

---

## 七、推荐学习资源

### 视频
- 【B站】黑马程序员 MySQL 全套（含进阶）
- 【B站】尚硅谷 MySQL 8.0 + 性能优化

### 书籍
- 《MySQL 必知必会》（入门）
- 《高性能 MySQL》（进阶必读⭐）
- 《MySQL 是怎样运行的》（原理）

### 在线练习
- [SQLZOO](https://sqlzoo.net/)
- [LeetCode 数据库题](https://leetcode.cn/problemset/database/)

### 官方文档
- [MySQL 8.0 Reference Manual](https://dev.mysql.com/doc/refman/8.0/en/)

---

## 八、本周完成后的"自我画像"

> "我能设计规范的数据库表，用 DECIMAL 存金额、用 utf8mb4 字符集。
> 我能写 JOIN、子查询、聚合等复杂 SQL。
> 我懂 B+ 树索引原理，能背最左前缀和索引失效场景。
> 我能用 explain 分析慢 SQL 并优化。
> 我知道 ACID、4 种隔离级别、MVCC 原理。
> 我完成了电商数据库设计并提交了 GitHub。"

---

## 九、下周预告

第 6 周进入 **Redis**——后端必备的缓存利器。
你将学会 Redis 5 大数据结构、缓存设计、分布式锁、秒杀场景实战。
本周的 MySQL + 下周的 Redis 是面试两座大山。

下周见！💪
