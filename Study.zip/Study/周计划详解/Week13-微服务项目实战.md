# 第 13 周：微服务项目实战

> **本周学习目标**：把第 10~12 周学的微服务、MQ、Docker **整合成一个完整的微服务电商系统**。这是简历上的"中级项目"。
>
> **本周关键词**：微服务架构、分布式事务、链路追踪、Docker 化、API 网关、限流、监控
>
> **预计投入时间**：45~55 小时（项目周，时间投入大）

---

## 一、项目选型

二选一：

### 选项 A：微服务电商系统（推荐）⭐
**模块：** user、product、order、pay、stock、notification、gateway
**亮点：** 完整电商流程、分布式事务、消息异步

### 选项 B：微服务在线教育系统
**模块：** user、course、order、video、live、comment、gateway
**亮点：** 视频处理、直播、社区

下面以**电商**为例展开。

---

## 二、系统架构

```
                      ┌──────────────────┐
                      │   前端 (下周做)   │
                      └────────┬─────────┘
                               │
                      ┌────────▼─────────┐
                      │   Gateway 网关    │ ← 统一鉴权、限流、跨域
                      │  (Spring Cloud)  │
                      └────────┬─────────┘
                               │
        ┌───────────┬──────────┼──────────┬──────────────┐
        ▼           ▼          ▼          ▼              ▼
   ┌─────────┐ ┌─────────┐ ┌────────┐ ┌─────────┐  ┌──────────────┐
   │  user   │ │ product │ │ order  │ │  pay    │  │  stock       │
   │ service │ │ service │ │ service│ │ service │  │  service     │
   └────┬────┘ └────┬────┘ └────┬───┘ └────┬────┘  └──────┬───────┘
        │           │           │          │              │
   ┌────▼─────┐┌────▼─────┐┌────▼─────┐┌────▼────┐  ┌─────▼──────┐
   │ user_db  ││product_db││ order_db ││ pay_db  │  │ stock_db   │
   └──────────┘└──────────┘└──────────┘└─────────┘  └────────────┘

  公共组件：
   ┌────────────┬─────────────┬──────────┬────────────┐
   │   Nacos    │  RabbitMQ   │  Redis   │  Sentinel  │
   │ (注册+配置) │ (异步消息)   │ (缓存)   │ (限流熔断) │
   └────────────┴─────────────┴──────────┴────────────┘
```

---

## 三、技术栈清单

| 类别 | 技术 |
| --- | --- |
| 微服务框架 | SpringBoot 3 + SpringCloud Alibaba |
| 注册/配置 | Nacos |
| 网关 | Spring Cloud Gateway |
| 远程调用 | OpenFeign |
| 熔断限流 | Sentinel |
| 数据库 | MySQL 8（每服务一个库） |
| 缓存 | Redis 7 |
| 消息队列 | RabbitMQ |
| 分布式事务 | Seata（可选）/ 最终一致 + 本地消息表 |
| 链路追踪 | SkyWalking / Sleuth + Zipkin |
| 文档 | springdoc-openapi（每个服务） |
| ORM | MyBatis Plus |
| 部署 | Docker + docker-compose |

---

## 四、各服务职责

### 1. user-service（用户服务）
- 注册、登录、JWT
- 个人信息维护
- 收货地址

### 2. product-service（商品服务）
- 商品 CRUD
- 分类、规格
- 商品搜索（可选 Elasticsearch）

### 3. order-service（订单服务）
- 创建订单
- 订单查询
- 订单状态机（待支付 / 已支付 / 已发货 / 已完成 / 已取消）
- 订单超时取消（MQ 延迟消息）

### 4. pay-service（支付服务）
- 模拟支付（不接真实通道）
- 支付成功回调
- 支付状态查询

### 5. stock-service（库存服务）
- 库存扣减（Redis + Lua）
- 库存回退
- 库存查询

### 6. notification-service（通知服务）
- 监听 MQ 消息
- 发邮件、短信（模拟）、站内信
- 异步执行

### 7. gateway（网关）
- 路由
- JWT 鉴权
- 跨域
- 限流（Sentinel）

---

## 五、本周每日安排

### 周一：项目设计 + 公共模块

**任务：**
1. 画系统架构图
2. 设计各服务的数据库表
3. 设计接口列表（每个服务）
4. 写出**调用关系图**（谁调用谁、用什么调用）
5. 抽出公共依赖模块 `common`：
   - Result / BusinessException / ErrorCode 枚举
   - 工具类（JwtUtil、UserContext、SnowflakeId 等）
   - 通用 DTO

**完全掌握标准：**
- ✅ 架构图清晰
- ✅ 5+ 个数据库设计完成（每个 3~5 张表）
- ✅ common 模块可被各服务引用

---

### 周二：基础设施 + user-service

**任务：**
1. **docker-compose 起依赖**：MySQL、Redis、Nacos、RabbitMQ
2. 搭建项目骨架（多模块 Maven）
3. 开发 user-service：
   - 注册（BCrypt）
   - 登录（生成 JWT）
   - 个人信息查询/修改
   - 注册到 Nacos
4. 各服务公共配置放 Nacos

**验收：**
- ✅ Nacos 控制台能看到 user-service
- ✅ Nacos 配置中心配置生效
- ✅ Postman 测注册登录通过

---

### 周三：网关 + 鉴权 + product-service

**任务：**
1. 开发 gateway：
   - 路由配置
   - 全局鉴权过滤器（解 JWT → 加 X-User-Id）
   - 跨域
2. 开发 product-service：
   - 商品 CRUD
   - 分类管理
   - Redis 缓存热门商品
3. 配置 Sentinel 限流

**验收：**
- ✅ 经过网关访问各服务
- ✅ 未登录访问受保护接口 401
- ✅ 商品详情第二次访问明显变快（缓存命中）

---

### 周四：order-service + Feign 调用

**任务：**
1. 开发 order-service：
   - 创建订单流程
   - 订单状态机
2. Feign 接口：
   - 调用 user-service 查用户
   - 调用 product-service 查商品
   - 调用 stock-service 扣库存
3. **下单核心流程**：
   ```
   下单 → 查用户 → 查商品 → 扣库存 → 写订单 → 发 MQ
   ```

**验收：**
- ✅ 完整下单流程通过
- ✅ Feign 失败有降级

---

### 周五：stock-service + pay-service + 异步消息

**任务：**
1. 开发 stock-service：
   - **Redis + Lua 扣库存**（原子）
   - 定时刷库存到 DB
2. 开发 pay-service：
   - 模拟支付接口
   - 支付成功发 MQ
3. notification-service 监听 MQ：
   - 订单创建 → 发邮件
   - 支付成功 → 发短信
4. **延迟消息**：订单创建后 30 分钟未支付 → 自动取消 + 回退库存

**验收：**
- ✅ 并发扣库存不会超卖
- ✅ 支付成功收到通知
- ✅ 未支付订单 30 分钟后自动取消

---

### 周六：分布式事务 + 链路追踪 + 监控

**任务：**

#### 6.1 分布式事务（选一）

**方案 1：最终一致性（推荐）**
- 用 MQ + 本地消息表
- 优点：性能好、简单
- 缺点：不强一致

**方案 2：Seata（学习用）**
- 强一致
- 性能差

下单场景示例（用最终一致）：
1. 订单服务：写订单 + 本地消息表（同一事务）
2. 提交后异步发 MQ 给库存服务
3. 库存服务消费 → 扣库存 + 标记消息已处理
4. 失败重试，超过次数进死信

#### 6.2 链路追踪

引入 Spring Cloud Sleuth + Zipkin（简单）或 SkyWalking（功能强）：

```xml
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-sleuth</artifactId>
</dependency>
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-sleuth-zipkin</artifactId>
</dependency>
```

Docker 启动 Zipkin：
```bash
docker run -d -p 9411:9411 openzipkin/zipkin
```

访问 `http://localhost:9411` 看链路。

#### 6.3 监控（可选）

- Prometheus + Grafana
- Spring Boot Admin

**验收：**
- ✅ 链路图能看到从网关到各服务的调用
- ✅ 失败的链路能追溯

---

### 周日：Docker 化 + 文档 + 提交

**任务：**
1. 给每个服务写 Dockerfile（多阶段构建）
2. 写完整的 docker-compose.yml（所有服务 + 依赖）
3. 写超详细 README：
   - 架构图
   - 模块说明
   - 部署步骤
   - 测试用例（Postman 集合）
   - 截图（Nacos、链路、Swagger）
4. 性能测试（用 JMeter / wrk 压秒杀场景）
5. 提交 GitHub

**docker-compose.yml 示例骨架：**

```yaml
version: "3.8"
services:
  mysql: { image: mysql:8.0, ... }
  redis: { image: redis:7-alpine, ... }
  nacos: { image: nacos/nacos-server:v2.3.0, ... }
  rabbitmq: { image: rabbitmq:3.13-management, ... }
  zipkin: { image: openzipkin/zipkin, ... }

  user-service:
    build: ./user-service
    depends_on: [mysql, nacos]
    environment:
      SPRING_PROFILES_ACTIVE: prod
      NACOS_HOST: nacos
    networks: [shop-net]

  product-service:
    build: ./product-service
    ...

  order-service: ...
  pay-service: ...
  stock-service: ...
  notification-service: ...

  gateway:
    build: ./gateway
    ports: ["8080:8080"]
    ...

networks:
  shop-net:
volumes:
  mysql_data:
  redis_data:
```

**验收：**
- ✅ `docker-compose up -d` 一键启动整套
- ✅ 提交 GitHub 含 README、截图、SQL、API 集合

---

## 六、完全掌握检查清单

### 项目完整度
- [ ] 6+ 个微服务正常运行
- [ ] Nacos 控制台看到所有服务
- [ ] 网关统一入口
- [ ] 服务间通过 Feign 调用
- [ ] 至少 3 处使用 Redis 缓存
- [ ] 至少 2 处使用 MQ（异步通知、延迟取消）
- [ ] 至少 1 处分布式锁（库存扣减）
- [ ] 至少 1 处分布式事务方案

### 工程化
- [ ] 多模块 Maven 项目
- [ ] 公共依赖抽到 common
- [ ] 各服务独立数据库
- [ ] 配置统一在 Nacos
- [ ] 链路追踪能看
- [ ] Docker 化 + docker-compose

### 健壮性
- [ ] 全局异常 + 统一返回
- [ ] 参数校验
- [ ] 接口限流（Sentinel）
- [ ] 服务降级（Feign fallback）
- [ ] 幂等消费
- [ ] 失败重试 + 死信处理

### 文档
- [ ] README 详细
- [ ] 架构图
- [ ] Swagger UI 全（每服务）
- [ ] 至少 8 张截图
- [ ] Postman 接口集合

### 性能
- [ ] 压测过秒杀场景（库存扣减）
- [ ] 缓存命中率统计
- [ ] 慢 SQL 优化

---

## 七、关键代码片段

### 1. Redis + Lua 扣库存（防超卖）

```lua
local stock = tonumber(redis.call("get", KEYS[1]))
if stock == nil or stock < tonumber(ARGV[1]) then
    return 0
end
redis.call("decrby", KEYS[1], ARGV[1])
return 1
```

```java
public boolean deductStock(Long productId, int count) {
    String script = "...";  // 上面的 Lua
    Long result = redisTemplate.execute(
        new DefaultRedisScript<>(script, Long.class),
        List.of("stock:" + productId),
        String.valueOf(count)
    );
    return result == 1L;
}
```

### 2. 订单超时延迟消息

```java
// 创建订单后发延迟消息
rabbitTemplate.convertAndSend("delay.exchange", "order.timeout", orderId, msg -> {
    msg.getMessageProperties().setHeader("x-delay", 30 * 60 * 1000);
    return msg;
});

// 监听
@RabbitListener(queues = "order.timeout.queue")
public void onTimeout(Long orderId) {
    Order o = orderMapper.selectById(orderId);
    if (o.getStatus() == OrderStatus.UNPAID) {
        // 取消订单 + 回退库存
        cancelAndReleaseStock(o);
    }
}
```

### 3. 网关 JWT 鉴权

（见第 10 周示例代码）

### 4. 本地消息表实现最终一致

```sql
CREATE TABLE message_outbox (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    business_key VARCHAR(64),
    payload JSON,
    status TINYINT DEFAULT 0,  -- 0 未发送，1 已发送
    retry_count INT DEFAULT 0,
    created_at DATETIME
);
```

```java
@Transactional
public void createOrder(Order order) {
    orderMapper.insert(order);                          // 写订单
    msgOutboxMapper.insert(new MsgOutbox(order));       // 写消息表（同事务）
}

// 定时任务扫描未发送
@Scheduled(fixedDelay = 5000)
public void sendOutbox() {
    List<MsgOutbox> list = msgOutboxMapper.selectUnsent();
    for (MsgOutbox m : list) {
        rabbitTemplate.convertAndSend(...);
        msgOutboxMapper.markSent(m.getId());
    }
}
```

---

## 八、面试讲解准备（重点⭐）

**3 分钟项目自述模板：**

> "我做的是一个微服务电商系统，分了 6 个服务：用户、商品、订单、支付、库存、通知。
>
> 架构上：注册中心用 Nacos，网关用 Spring Cloud Gateway 做统一鉴权和路由，服务间用 OpenFeign 通信，配 Sentinel 做限流熔断。
>
> 在核心场景上：下单时用 Redis + Lua 扣库存防超卖，订单超时用 MQ 延迟消息自动取消，分布式事务用本地消息表 + MQ 实现最终一致。
>
> 工程化上：每个服务独立数据库，配置统一在 Nacos，用 Sleuth + Zipkin 做链路追踪，整套用 docker-compose 一键部署。"

**高频追问：**

1. 为什么选 Nacos 而不是 Eureka？
2. Gateway 怎么实现鉴权？
3. 下单流程涉及多个服务，如何保证一致性？
4. Redis + Lua 为什么能防超卖？
5. 延迟消息怎么实现的？
6. Feign 失败了怎么处理？
7. 服务雪崩怎么避免？
8. 怎么定位线上问题（链路追踪）？

**完全掌握标准：**
- ✅ 每个追问都能流畅回答 1~2 分钟
- ✅ 能口述设计思路和代码实现
- ✅ 能说出至少 3 个设计权衡

---

## 九、常见坑与误区

| 坑 | 描述 | 解决 |
| --- | --- | --- |
| 服务间共享 DB | 失去微服务意义 | 严格独立 DB |
| 循环依赖 | A 调 B，B 也调 A | 重新设计边界 |
| Feign 调用频繁失败没降级 | 雪崩 | 必须配 fallback |
| 分布式事务过度设计 | 用 Seata 杀鸡用牛刀 | 优先最终一致 |
| 日志查询难 | 没链路追踪 | 必须配 traceId |
| Docker compose 启动顺序 | 服务还没就绪就调用 | healthcheck + retry |
| Nacos 配置改了不生效 | 漏 @RefreshScope | 加注解 |
| 容器内连不上 Nacos | localhost 错 | 用 nacos:8848 |

---

## 十、本周完成后的"自我画像"

> "我有了简历上的第二个项目：一个真正的微服务电商系统。
> 它有 6 个微服务、独立数据库、网关、注册中心、配置中心、消息队列、缓存、链路追踪。
> 它能用 docker-compose 一键部署。
> 我能 3 分钟讲清楚架构、技术选型和核心难点。
> 我能回答常见微服务面试问题。
> 我从'会写代码'升级到'会设计系统'。"

---

## 十一、下周预告

第 14~16 周：**前端（Vue / React）**。
你将学会前端开发，做一个能"看得到、点得到"的管理后台和聊天页面。
后端工程师也需要懂前端，AI 应用更需要。

下周见！💪
