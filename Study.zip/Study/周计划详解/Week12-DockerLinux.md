# 第 12 周：Docker + Linux

> **本周学习目标**：掌握 Linux 基础命令 + Docker 容器化部署，能用 docker-compose 一键部署微服务系统。
>
> **本周关键词**：Linux 命令、vim、shell、Docker、镜像、容器、Dockerfile、docker-compose、网络、数据卷
>
> **预计投入时间**：30~40 小时

---

## 一、本周知识点详细分解

### 1. Linux 基础（1 天）

#### 1.1 为什么学 Linux

- 服务器主流是 Linux（CentOS / Ubuntu / Debian）
- 部署、排查问题、监控都要用
- Docker 底层是 Linux

#### 1.2 环境准备

3 种方式选一：
1. **WSL2**（Windows 推荐）：在 Windows 装 Ubuntu，体验最好
2. **虚拟机 VirtualBox + CentOS / Ubuntu**
3. **云服务器**：阿里云 / 腾讯云学生服务器

#### 1.3 文件操作命令

| 命令 | 作用 |
| --- | --- |
| `pwd` | 显示当前路径 |
| `ls -lah` | 列出文件（详细 + 隐藏 + 友好大小） |
| `cd /path` | 切换目录 |
| `mkdir -p a/b/c` | 创建多级目录 |
| `touch a.txt` | 创建空文件 |
| `cp src dst` | 复制 |
| `cp -r dir1 dir2` | 复制目录 |
| `mv src dst` | 移动/重命名 |
| `rm a.txt` | 删除 |
| `rm -rf dir` | 强制删除目录（小心！） |
| `find /path -name "*.log"` | 按名查找 |
| `find /path -mtime -7` | 7 天内修改的 |

#### 1.4 查看与编辑

| 命令 | 作用 |
| --- | --- |
| `cat file` | 查看完整文件 |
| `less file` | 分页查看（q 退出，/ 搜索） |
| `head -n 20 file` | 前 20 行 |
| `tail -n 20 file` | 后 20 行 |
| `tail -f log` | 实时跟踪（看日志必用） |
| `grep "error" file` | 搜索内容 |
| `grep -rn "TODO" dir` | 递归 + 行号 |
| `wc -l file` | 统计行数 |
| `sort` / `uniq -c` | 排序 / 去重计数 |

#### 1.5 权限

```bash
ls -l a.sh
# -rwxr-xr-- 1 user group 100 May 13 a.sh
# 文件类型  所有者 同组 其他

chmod +x a.sh         # 加可执行权限
chmod 755 a.sh        # 数字模式（rwx rx rx）
chown user:group a.sh # 改所有者
```

数字含义：r=4, w=2, x=1
- 7 = rwx
- 5 = r-x
- 0 = ---

#### 1.6 进程与端口

| 命令 | 作用 |
| --- | --- |
| `ps -ef \| grep java` | 看进程 |
| `top` | 实时进程监控（q 退出） |
| `htop` | 更好用的 top |
| `kill -9 PID` | 强杀进程 |
| `netstat -tlnp` 或 `ss -tlnp` | 看端口监听 |
| `lsof -i:8080` | 看 8080 端口占用 |
| `nohup java -jar app.jar > out.log 2>&1 &` | 后台运行 |

#### 1.7 网络

| 命令 | 作用 |
| --- | --- |
| `ip addr` 或 `ifconfig` | 看 IP |
| `ping baidu.com` | 测网络 |
| `curl http://...` | 发请求 |
| `curl -X POST -H "Content-Type: application/json" -d '{}' url` | 发 POST |
| `wget url` | 下载 |
| `scp file user@ip:/path` | 远程复制 |
| `ssh user@ip` | SSH 登录 |

#### 1.8 文件传输

```bash
# 上传
scp local.txt user@server:/path/

# 下载
scp user@server:/path/file.txt ./

# rsync（增量、断点续传）
rsync -avz src/ user@server:dst/
```

#### 1.9 vim 编辑器（重点⭐）

**vim 三种模式：**
- **命令模式**（默认）：按 i/a/o 进入编辑
- **编辑模式**：写字
- **底线模式**：按 `:`，输入命令

**必会命令：**

| 按键 | 作用 |
| --- | --- |
| `i` | 在光标前插入 |
| `a` | 在光标后插入 |
| `o` | 下一行新行插入 |
| `Esc` | 回命令模式 |
| `:w` | 保存 |
| `:q` | 退出 |
| `:wq` | 保存退出 |
| `:q!` | 强制退出不保存 |
| `dd` | 删除一行 |
| `yy` | 复制一行 |
| `p` | 粘贴 |
| `u` | 撤销 |
| `Ctrl+r` | 重做 |
| `/word` | 搜索 word |
| `n` / `N` | 下一个 / 上一个 |
| `:%s/old/new/g` | 全局替换 |
| `gg` / `G` | 文件首 / 末 |
| `:100` | 跳到第 100 行 |

**完全掌握标准：**
- ✅ 能在 vim 中编辑文件并保存退出
- ✅ 能用 less + tail -f 看日志
- ✅ 能用 grep 搜索关键字
- ✅ 能用 ps + kill 管理进程
- ✅ 能用 netstat 查端口
- ✅ 能用 scp / ssh 操作远程服务器
- ✅ 能用 chmod 改权限

---

### 2. Shell 脚本基础（半天）

#### 2.1 基础语法

```bash
#!/bin/bash

# 变量
name="Alice"
echo "Hello $name"

# 输入
read -p "请输入年龄: " age
echo "你的年龄是 $age"

# 条件
if [ $age -ge 18 ]; then
    echo "成年"
elif [ $age -ge 13 ]; then
    echo "少年"
else
    echo "儿童"
fi

# 循环
for i in 1 2 3 4 5; do
    echo $i
done

for i in $(seq 1 10); do
    echo $i
done

# 函数
greet() {
    echo "Hello $1"
}
greet "World"

# 命令替换
files=$(ls)
count=$(ls | wc -l)
```

#### 2.2 实用脚本示例

**部署脚本：**
```bash
#!/bin/bash
APP_NAME=my-app
JAR_FILE=/data/$APP_NAME.jar

# 停旧进程
PID=$(ps -ef | grep $APP_NAME | grep -v grep | awk '{print $2}')
if [ -n "$PID" ]; then
    kill -9 $PID
    echo "已停止 $PID"
fi

# 启动新进程
nohup java -jar $JAR_FILE > /data/logs/app.log 2>&1 &
echo "已启动"
```

**完全掌握标准：**
- ✅ 能写一个部署脚本（停旧 + 启新）
- ✅ 能用变量、条件、循环
- ✅ 能用 `$(...)` 命令替换

---

### 3. Docker 概念（半天）

#### 3.1 Docker 是什么

**核心问题：** "在我电脑上能跑"
- 不同环境（JDK 版本、依赖、操作系统）
- 不同部署（开发、测试、生产配置不同）

**Docker 解决：** 把应用 + 依赖 + 环境打包成镜像，到处运行。

#### 3.2 容器 vs 虚拟机

| | 虚拟机 | 容器 |
| --- | --- | --- |
| 启动 | 分钟 | 秒 |
| 大小 | GB | MB |
| 隔离 | 完整 OS | 共享内核 |
| 资源 | 多 | 少 |

#### 3.3 核心概念

- **镜像（Image）**：只读模板（类似 OOP 的类）
- **容器（Container）**：镜像的运行实例（类似对象）
- **仓库（Registry）**：镜像存储（Docker Hub / 阿里 / 私有）
- **Dockerfile**：构建镜像的脚本

**完全掌握标准：**
- ✅ 能解释 Docker 解决了什么问题
- ✅ 能解释镜像 vs 容器
- ✅ 能解释容器 vs 虚拟机

---

### 4. Docker 安装与基本命令（半天）

#### 4.1 安装

- **Windows**：Docker Desktop（含 WSL2）
- **Mac**：Docker Desktop
- **Linux**：
  ```bash
  curl -fsSL https://get.docker.com | bash
  systemctl start docker
  ```

#### 4.2 配置加速器

```json
// /etc/docker/daemon.json
{
  "registry-mirrors": [
    "https://docker.mirrors.ustc.edu.cn",
    "https://registry.docker-cn.com"
  ]
}
```

#### 4.3 必会命令

```bash
# 镜像
docker pull nginx:latest        # 拉取镜像
docker images                    # 列出镜像
docker rmi nginx                 # 删除镜像
docker build -t my-app:1.0 .    # 构建镜像

# 容器
docker run -d --name web -p 8080:80 nginx    # 启动并后台运行
docker ps                        # 看运行中容器
docker ps -a                     # 看所有（含停止）
docker stop web                  # 停止
docker start web                 # 启动
docker restart web               # 重启
docker rm web                    # 删除（容器必须先停）
docker logs -f web               # 看日志
docker exec -it web bash         # 进入容器

# 系统
docker info                      # 系统信息
docker system df                 # 占用空间
docker system prune              # 清理无用资源
```

#### 4.4 run 参数详解

```bash
docker run \
  -d                       # 后台
  --name myapp             # 容器名
  -p 8080:80               # 端口映射 主:容器
  -v /data/logs:/logs      # 挂载目录
  -e ENV_KEY=value         # 环境变量
  --network mynet          # 加入网络
  --restart=always         # 重启策略
  myimage:1.0
```

**完全掌握标准：**
- ✅ 能拉取 + 运行 nginx 容器并访问
- ✅ 能用 docker logs 看日志
- ✅ 能用 docker exec 进入容器
- ✅ 能记住 8 个核心命令

---

### 5. Dockerfile（⭐重点 1 天）

#### 5.1 基本语法

```dockerfile
# 基础镜像
FROM openjdk:17-jdk-slim

# 维护者
LABEL maintainer="me@example.com"

# 工作目录
WORKDIR /app

# 复制文件
COPY target/myapp.jar app.jar

# 环境变量
ENV TZ=Asia/Shanghai

# 暴露端口（仅声明，需要 run 时 -p）
EXPOSE 8080

# 启动命令
ENTRYPOINT ["java", "-jar", "/app/app.jar"]
```

#### 5.2 常用指令

| 指令 | 作用 |
| --- | --- |
| `FROM` | 基础镜像 |
| `LABEL` | 标签元数据 |
| `RUN` | 构建时运行（创建层） |
| `WORKDIR` | 工作目录 |
| `COPY` | 复制本地文件到镜像 |
| `ADD` | 类似 COPY，支持解压、URL |
| `ENV` | 环境变量 |
| `ARG` | 构建参数 |
| `EXPOSE` | 声明端口 |
| `VOLUME` | 声明挂载点 |
| `USER` | 切换用户 |
| `CMD` | 默认命令（可被 run 覆盖） |
| `ENTRYPOINT` | 入口命令（建议 + CMD 参数） |

#### 5.3 多阶段构建（推荐⭐）

减小镜像体积：

```dockerfile
# 阶段 1: 构建
FROM maven:3.9-eclipse-temurin-17 AS builder
WORKDIR /build
COPY pom.xml .
RUN mvn dependency:go-offline
COPY src ./src
RUN mvn clean package -DskipTests

# 阶段 2: 运行
FROM eclipse-temurin:17-jre-alpine
WORKDIR /app
COPY --from=builder /build/target/*.jar app.jar
EXPOSE 8080
ENTRYPOINT ["java","-jar","/app/app.jar"]
```

**优势：** 最终镜像只包含 JRE 和 jar，无 Maven、源码，体积减少 80%。

#### 5.4 构建优化技巧

1. **基础镜像用 alpine / slim**（更小）
2. **多阶段构建**
3. **合并 RUN**（减少层数）
4. **.dockerignore**（排除无关文件）
5. **依赖先复制 pom.xml**（利用缓存）

#### 5.5 .dockerignore

```
target/
.git/
.idea/
*.log
node_modules/
```

**完全掌握标准：**
- ✅ 能为 SpringBoot 项目写 Dockerfile
- ✅ 能用多阶段构建
- ✅ 能用 .dockerignore
- ✅ 能解释 CMD vs ENTRYPOINT

---

### 6. Docker 网络与数据卷（半天）

#### 6.1 网络类型

| 类型 | 说明 |
| --- | --- |
| **bridge**（默认） | 桥接，容器间通过 IP 通信 |
| **host** | 共享宿主机网络（性能好但无隔离） |
| **none** | 无网络 |
| **自定义 bridge** | 推荐，容器间可用名称互访 |

```bash
# 创建网络
docker network create mynet

# 用网络
docker run -d --name redis --network mynet redis
docker run -d --name app --network mynet \
  -e REDIS_HOST=redis my-app
```

注意：自定义网络可以**通过容器名访问**，默认 bridge 不行。

#### 6.2 数据卷

**为什么：** 容器删除后数据丢失，要持久化。

```bash
# 命名卷（推荐）
docker volume create mydata
docker run -v mydata:/data ...

# 绑定挂载（开发用）
docker run -v /host/path:/container/path ...

# 临时卷
docker run --tmpfs /tmp ...
```

```bash
docker volume ls
docker volume inspect mydata
docker volume rm mydata
```

**完全掌握标准：**
- ✅ 能创建自定义网络让容器互访
- ✅ 能用 volume 持久化数据库数据
- ✅ 知道 bridge / host 区别

---

### 7. docker-compose（⭐重点 1 天）

#### 7.1 为什么用

多个容器手动 docker run 太麻烦：
- 网络、依赖顺序、环境变量
- docker-compose 一个 yaml 搞定

#### 7.2 安装

Docker Desktop 自带。Linux 单独装：
```bash
curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose
```

或用新版 `docker compose`（无连字符）。

#### 7.3 docker-compose.yml 示例

```yaml
version: "3.8"

services:
  mysql:
    image: mysql:8.0
    container_name: mysql
    environment:
      MYSQL_ROOT_PASSWORD: 123456
      MYSQL_DATABASE: shop
      TZ: Asia/Shanghai
    ports:
      - "3306:3306"
    volumes:
      - mysql_data:/var/lib/mysql
      - ./sql/init.sql:/docker-entrypoint-initdb.d/init.sql
    networks:
      - app-net
    restart: always

  redis:
    image: redis:7-alpine
    container_name: redis
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data
    networks:
      - app-net
    restart: always

  app:
    build: .
    container_name: my-app
    depends_on:
      - mysql
      - redis
    environment:
      SPRING_PROFILES_ACTIVE: prod
      SPRING_DATASOURCE_URL: jdbc:mysql://mysql:3306/shop
      SPRING_REDIS_HOST: redis
    ports:
      - "8080:8080"
    networks:
      - app-net
    restart: always

volumes:
  mysql_data:
  redis_data:

networks:
  app-net:
```

#### 7.4 常用命令

```bash
docker-compose up -d              # 启动（后台）
docker-compose up -d --build      # 重新构建并启动
docker-compose down               # 停止并移除
docker-compose ps                 # 查看状态
docker-compose logs -f app        # 看 app 日志
docker-compose restart app        # 重启某服务
docker-compose exec app bash      # 进入容器
docker-compose stop               # 停止但不移除
```

#### 7.5 健康检查

```yaml
mysql:
  healthcheck:
    test: ["CMD", "mysqladmin", "ping", "-h", "localhost"]
    interval: 10s
    timeout: 5s
    retries: 5

app:
  depends_on:
    mysql:
      condition: service_healthy
```

**完全掌握标准：**
- ✅ 能写 docker-compose.yml 启动 MySQL + Redis + App
- ✅ 能用 depends_on 控制启动顺序
- ✅ 能用 healthcheck 等待依赖就绪
- ✅ 能用 volume + bind mount

---

### 8. 部署 SpringBoot 项目（半天）

#### 8.1 准备

```bash
# 1. 打包
mvn clean package -DskipTests

# 2. 写 Dockerfile
# (前面已示例)

# 3. 写 docker-compose.yml
# (前面已示例)
```

#### 8.2 启动

```bash
docker-compose up -d --build
docker-compose logs -f app
```

#### 8.3 配置注意点

- **数据库 URL 不要写 localhost**，写容器名 `mysql`
- **配置项用环境变量**，方便覆盖
- **日志挂载到宿主机**，方便查看
- **时区设 Asia/Shanghai**

**完全掌握标准：**
- ✅ 能用 docker-compose 一键部署完整项目
- ✅ 数据库 host 写容器名而非 localhost
- ✅ 能挂载日志目录

---

## 二、每日学习安排

| 天 | 学习内容 | 上机练习 | 时长 |
| --- | --- | --- | --- |
| **周一** | Linux 文件 + 权限 + 进程 + 网络 | 在 WSL/虚拟机练 50 个命令 | 5h |
| **周二** | vim + shell 脚本 | 写部署脚本 | 4h |
| **周三** | Docker 概念 + 安装 + 常用命令 | 拉 nginx / mysql / redis 镜像跑 | 5h |
| **周四** | Dockerfile + 多阶段构建 ⭐ | 给 SpringBoot 项目写 Dockerfile | 6h |
| **周五** | 网络 + 数据卷 | 自定义网络让容器互访 | 5h |
| **周六** | docker-compose ⭐ | 部署 MySQL+Redis+SpringBoot | 6h |
| **周日** | 综合实战 + 复盘 | 部署上周的微服务项目 | 6h |

---

## 三、本周必做实战项目

### 项目：用 docker-compose 部署微服务系统

**任务：**
- 用上周（第 10/11 周）的微服务项目
- 写 docker-compose.yml 一键启动：
  - MySQL
  - Redis
  - Nacos
  - RabbitMQ
  - Gateway
  - user-service
  - product-service
  - order-service

**技术要求：**
- ✅ 每个微服务写 Dockerfile（多阶段构建）
- ✅ 自定义网络让容器互访
- ✅ 配置统一通过环境变量
- ✅ 数据卷持久化 MySQL / Redis 数据
- ✅ 依赖启动顺序（depends_on）
- ✅ 健康检查
- ✅ 日志挂载

**验收：**
- ✅ `docker-compose up -d` 一键启动
- ✅ `docker-compose down` 干净停止
- ✅ 重启电脑后数据还在
- ✅ README 写部署步骤
- ✅ 提交 GitHub

---

## 四、完全掌握检查清单

### Linux
- [ ] 能在 vim 中编辑文件
- [ ] 会用 grep / find / ps / netstat
- [ ] 能用 chmod 改权限
- [ ] 能用 scp / ssh
- [ ] 能写简单 shell 脚本

### Docker
- [ ] 能解释镜像 vs 容器
- [ ] 能用 docker run 启动容器
- [ ] 能用 docker logs / exec
- [ ] 能写 Dockerfile
- [ ] 能用多阶段构建
- [ ] 能解释 CMD vs ENTRYPOINT

### 网络与数据
- [ ] 能创建自定义网络
- [ ] 能让容器互相访问
- [ ] 能用 volume 持久化数据

### docker-compose
- [ ] 能写 docker-compose.yml
- [ ] 能用 depends_on
- [ ] 能配 healthcheck
- [ ] 能用 docker-compose up/down

### 综合
- [ ] 用 docker-compose 部署微服务并提交 GitHub
- [ ] README 含部署步骤

---

## 五、自测题

**Q1：** Docker 容器和虚拟机的区别？
**答案：**
- 容器共享内核，启动秒级，体积 MB
- 虚拟机带完整 OS，启动分钟级，体积 GB
- 容器适合应用部署，虚拟机适合更强隔离

---

**Q2：** Dockerfile 中 CMD 和 ENTRYPOINT 的区别？
**答案：**
- CMD：默认命令，可被 `docker run` 后参数覆盖
- ENTRYPOINT：入口命令，参数追加而不是覆盖
- 推荐：ENTRYPOINT + CMD（CMD 作为默认参数）

---

**Q3：** 为什么我连接不上容器里的 MySQL？
**答案：**
- localhost 在容器内指容器自己
- 同 compose 内服务用**服务名**访问（如 mysql:3306）
- 宿主机访问要做端口映射

---

**Q4：** 为什么容器删除后数据丢了？
**答案：** 容器是临时的，数据要存到 **volume 或 bind mount**。

---

**Q5：** 如何减小镜像体积？
**答案：**
- 用 alpine / slim 基础镜像
- 多阶段构建
- 合并 RUN 命令
- .dockerignore 排除无关
- 用 distroless（更激进）

---

**Q6：** docker-compose 的 depends_on 真的能保证依赖就绪吗？
**答案：** 只保证启动顺序，**不等服务就绪**。要等服务就绪用 `condition: service_healthy` + healthcheck。

---

## 六、常见坑与误区

| 坑 | 描述 | 解决 |
| --- | --- | --- |
| Windows 路径在 -v 失败 | 路径格式不对 | 用 /c/Users/... 或在 WSL 内运行 |
| 容器内连 localhost 不通 | 指容器自己 | 用宿主机 IP 或服务名 |
| 镜像越构越大 | 没清理中间产物 | 多阶段构建 |
| 数据丢了 | 没挂 volume | 必须挂载关键数据 |
| 端口冲突 | 多个容器映射同端口 | 改一个 |
| Compose 启动顺序错 | depends_on 不等服务就绪 | healthcheck |
| logs 撑满磁盘 | 没配 log-driver | 限制 log size |
| 镜像没标签 | latest 不可控 | 显式版本号 |
| 时区不对 | 默认 UTC | 设 TZ=Asia/Shanghai |

---

## 七、推荐学习资源

### 视频
- 【B站】黑马程序员 Docker 实战教程
- 【B站】Linux 命令大全（鸟哥版）

### 书籍
- 《鸟哥的 Linux 私房菜》（Linux 圣经）
- 《Docker 容器与容器云》
- 《第一本 Docker 书》

### 官方
- [Docker 官方文档](https://docs.docker.com/)
- [docker-compose 参考](https://docs.docker.com/compose/compose-file/)

### 工具
- Docker Desktop（GUI）
- Portainer（Docker GUI 管理）

---

## 八、本周完成后的"自我画像"

> "我能熟练用 Linux 命令操作服务器、看日志、查进程、用 vim 编辑。
> 我能写 Dockerfile + docker-compose.yml 一键部署任何项目。
> 我懂容器 vs 虚拟机，能用多阶段构建减小镜像体积。
> 我把微服务系统部署到 Docker 容器，README 写好了部署文档。
> 我开始有'能独立部署项目'的能力了。"

---

## 九、下周预告

第 13 周：**微服务项目实战周**——把所有微服务相关知识整合，做一个完整的电商类微服务系统。
这是简历上的"第二个大项目"，含微服务 + MQ + Docker。

下周见！💪
