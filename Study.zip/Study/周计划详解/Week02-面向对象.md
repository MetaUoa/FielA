# 第 2 周：面向对象（OOP）

> **本周学习目标**：从"写代码"升级到"设计代码"。能用类、对象、继承、多态、接口组织一个程序的结构，建立"对象思维"。
>
> **本周关键词**：类、对象、封装、继承、多态、抽象类、接口、static、final
>
> **预计投入时间**：35~45 小时（OOP 是 Java 的灵魂，多花时间值得）

---

## 一、本周知识点详细分解

### 1. 类与对象（1 天）

#### 1.1 类是什么、对象是什么

**核心概念：**
- 类（Class） = 模板 / 图纸
- 对象（Object）= 实例 / 根据图纸造出来的具体东西
- 类是一种"自定义数据类型"

**代码示例：**
```java
public class Student {
    // 成员变量（属性 / 字段）
    String name;
    int age;
    double score;

    // 成员方法（行为）
    public void study() {
        System.out.println(name + " is studying");
    }
}

// 使用
Student s = new Student();
s.name = "小明";
s.study();
```

**完全掌握标准：**
- ✅ 能闭眼写一个 Student 类，含字段和方法
- ✅ 能用 `new` 创建对象并调用方法
- ✅ 能解释 `new` 做了什么（在堆里开辟内存 + 调用构造方法 + 返回引用）
- ✅ 能解释"栈中存引用，堆中存对象"

#### 1.2 成员变量 vs 局部变量

| | 成员变量 | 局部变量 |
| --- | --- | --- |
| 位置 | 类里方法外 | 方法内 |
| 默认值 | 有（0/false/null） | 没有，必须初始化 |
| 作用域 | 整个类 | 方法内 |
| 存储 | 堆（对象内） | 栈（方法栈帧） |

**完全掌握标准：**
- ✅ 能写出一个例子展示两者的区别
- ✅ 知道为什么局部变量不能不初始化

---

### 2. 构造方法（半天）

**学什么：**
```java
public class Student {
    String name;
    int age;

    // 无参构造
    public Student() {
    }

    // 有参构造（重载）
    public Student(String name, int age) {
        this.name = name;
        this.age = age;
    }
}
```

**关键点：**
- 方法名与类名相同，无返回值类型（连 void 都没有）
- 如果不写构造方法，编译器会自动加一个无参构造
- 一旦写了有参构造，无参构造会消失（要手动写）
- 构造方法可以重载

**完全掌握标准：**
- ✅ 能写出无参 + 有参构造
- ✅ 知道为什么"写了有参构造还要写无参构造"（很多框架反射调用无参构造）
- ✅ 能解释构造方法和普通方法的 3 个区别
- ✅ 能用 IDEA 快捷键 `Alt+Insert` 自动生成构造方法

---

### 3. this 与 super（半天）

#### 3.1 this

- `this` = "当前对象"的引用
- 用法：
  - `this.字段` —— 区分成员变量和参数（参数名相同时必须用）
  - `this.方法()` —— 调用本类其他方法（可省略）
  - `this(...)` —— 调用本类其他构造方法（必须在第一行）

#### 3.2 super

- `super` = "父类对象"的引用
- 用法：
  - `super.字段` —— 访问父类字段
  - `super.方法()` —— 调用父类被覆盖的方法
  - `super(...)` —— 调用父类构造方法（必须在第一行）

**完全掌握标准：**
- ✅ 能解释为什么 `this(...)` 和 `super(...)` 都必须在第一行
- ✅ 能解释"子类构造方法第一行如果没写 super()，编译器会自动加"
- ✅ 能写一个 demo 展示 super 调用父类被覆盖的方法

---

### 4. 封装（半天）

**核心思想：** 隐藏内部细节，对外暴露统一接口。

**实现方式：**
- 字段用 `private`
- 提供 `public` 的 getter / setter

```java
public class Student {
    private int age;

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        if (age < 0 || age > 150) {
            throw new IllegalArgumentException("年龄非法");
        }
        this.age = age;
    }
}
```

**为什么要封装？**
1. 数据保护：在 setter 里校验
2. 灵活性：内部实现可以变，外部接口不变
3. 可读性：通过方法名表达意图

**完全掌握标准：**
- ✅ 能解释封装的 3 个好处
- ✅ 能为字段写"有校验的 setter"
- ✅ 能用 IDEA `Alt+Insert → Getter/Setter` 自动生成
- ✅ 能解释"为什么不直接 public 字段就完了"
- ✅ 知道 Lombok 的 `@Data` 注解可以自动生成（先了解，第 7 周用）

---

### 5. 继承（1 天）

#### 5.1 基础语法

```java
public class Animal {
    String name;
    public void eat() { System.out.println("吃饭"); }
}

public class Dog extends Animal {
    public void bark() { System.out.println("汪汪"); }
}
```

#### 5.2 关键规则

- Java 是**单继承**：一个类只能 `extends` 一个父类
- 所有类的根父类是 `Object`
- 子类继承父类的**非 private** 成员
- 构造方法**不会被继承**
- 子类构造必须先调用父类构造（默认 super() 无参）

#### 5.3 方法重写（Override）

```java
public class Dog extends Animal {
    @Override
    public void eat() {
        System.out.println("狗在啃骨头");
    }
}
```

**重写规则（口诀：两同两小一大）：**
- 方法名相同 ✓
- 参数列表相同 ✓
- 返回值类型小于等于父类
- 抛出异常小于等于父类
- 访问权限大于等于父类

**完全掌握标准：**
- ✅ 能解释继承的优缺点（复用 vs 强耦合）
- ✅ 能正确使用 `@Override` 注解（虽然不写也行，但建议写）
- ✅ 能区分**重写（Override）**和**重载（Overload）**：
  - 重写：子类 vs 父类，方法签名相同
  - 重载：同类内部，方法名相同但参数不同
- ✅ 能说清楚为什么 Java 设计单继承（避免菱形继承问题，多继承用接口替代）

---

### 6. 多态（1 天，重难点⚠️）

#### 6.1 多态的 3 个前提

1. 继承（或接口实现）
2. 方法重写
3. 父类引用指向子类对象：`Animal a = new Dog();`

#### 6.2 多态的核心特点

```java
Animal a = new Dog();
a.eat();          // 输出"狗在啃骨头"（运行时确定）
// a.bark();      // 编译错误！父类引用看不到子类独有方法
```

- **编译看左边，运行看右边**
- 调用方法时，**实际执行的是对象的实际类型的方法**（动态分派）

#### 6.3 向上转型 vs 向下转型

```java
Animal a = new Dog();           // 向上转型（自动）
Dog d = (Dog) a;                // 向下转型（强制）

// 安全的向下转型
if (a instanceof Dog) {
    Dog d = (Dog) a;
}

// JDK 16+ 模式匹配
if (a instanceof Dog d) {
    d.bark();
}
```

**完全掌握标准：**
- ✅ 能用一句话讲清多态：**"同一个方法调用，因对象不同而表现不同"**
- ✅ 能预测多态代码的运行结果（关键面试题）
- ✅ 能解释 `instanceof` 的用法
- ✅ 能写出多态的经典 demo（动物园、形状面积）
- ✅ 能解释"多态如何提升扩展性"（新增子类不改原有代码）

---

### 7. 抽象类（半天）

**特点：**
- 用 `abstract` 修饰
- 不能 `new`（不能实例化）
- 可以有抽象方法（无方法体），也可以有普通方法
- 子类必须实现所有抽象方法（除非子类也是抽象的）

```java
public abstract class Shape {
    public abstract double area();   // 抽象方法
    public void describe() {          // 普通方法
        System.out.println("面积是: " + area());
    }
}

public class Circle extends Shape {
    private double r;
    public Circle(double r) { this.r = r; }
    @Override
    public double area() { return Math.PI * r * r; }
}
```

**完全掌握标准：**
- ✅ 能解释抽象类和普通类的区别
- ✅ 能解释为什么抽象类不能 new（有抽象方法没法调用）
- ✅ 知道抽象类可以有构造方法（虽然不能 new，但子类构造会调用）

---

### 8. 接口（重点⚠️，1 天）

#### 8.1 接口基础

```java
public interface Flyable {
    void fly();   // 默认 public abstract，可以省略
}

public class Bird implements Flyable {
    @Override
    public void fly() {
        System.out.println("鸟在飞");
    }
}
```

#### 8.2 接口的特性（JDK 8+）

- 所有方法默认 `public abstract`（JDK 7 之前）
- JDK 8+ 支持：
  - `default` 方法：有方法体的默认实现
  - `static` 方法：接口的静态方法
- JDK 9+ 支持：`private` 方法（用于代码复用）

```java
public interface Calculator {
    int calc(int a, int b);
    default int doubleCalc(int a, int b) {
        return calc(a, b) * 2;
    }
    static Calculator add() {
        return (a, b) -> a + b;
    }
}
```

#### 8.3 接口 vs 抽象类（高频面试题）

| | 抽象类 | 接口 |
| --- | --- | --- |
| 关系 | extends（单继承） | implements（多实现） |
| 字段 | 普通字段 | 默认 public static final |
| 方法 | 抽象 + 普通 | 抽象 + default + static |
| 构造方法 | 有 | 无 |
| 设计含义 | "是什么"（is-a） | "能做什么"（can-do） |

**完全掌握标准：**
- ✅ 能写出接口定义、实现、多实现
- ✅ 能解释接口 vs 抽象类的区别（至少 5 点）
- ✅ 能用接口实现"策略模式"小 demo
- ✅ 能解释为什么 Java 用接口解决"伪多继承"
- ✅ 能列举 JDK 中常见接口：`Comparable`、`Comparator`、`Runnable`、`Iterable`

---

### 9. static（半天）

#### 9.1 static 修饰的位置

- **静态变量**（类变量）：属于类，所有对象共享
- **静态方法**：可以通过类名直接调用，不能用 this，不能直接访问实例变量
- **静态代码块**：类加载时执行一次
- **静态内部类**：不依赖外部类实例

#### 9.2 经典代码

```java
public class Counter {
    private static int count = 0;   // 所有对象共享

    public Counter() {
        count++;
    }

    public static int getCount() {  // 类名直接调用
        return count;
    }
}

// 使用
new Counter();
new Counter();
System.out.println(Counter.getCount());   // 2
```

**完全掌握标准：**
- ✅ 能解释静态方法不能用 this 的原因（this 是对象引用，静态方法无对象）
- ✅ 能用 static 实现计数器
- ✅ 能用 static 实现工具类（如 Math 类）
- ✅ 知道 main 方法为什么是 static（JVM 启动时无对象）

---

### 10. final（半天）

| 修饰位置 | 作用 |
| --- | --- |
| final 变量 | 常量，只能赋值一次 |
| final 方法 | 不能被子类重写 |
| final 类 | 不能被继承（如 String） |

```java
public final class Config {           // 类不能被继承
    public static final int MAX = 100;  // 常量
    public final void run() { }        // 方法不能被重写
}
```

**完全掌握标准：**
- ✅ 能解释 `final` 修饰引用类型变量时，引用不变但对象内容可变
- ✅ 能解释 String 为什么是 final（线程安全 + 字符串常量池 + 安全性）
- ✅ 知道 `static final` 联合使用定义常量的规范（全大写 + 下划线）

---

### 11. UML 类图基础（半天）

**学什么：**
- 类的表示：`Class Name | 字段 | 方法`
- 继承：实线箭头 ▷
- 实现：虚线箭头 ▷
- 关联：实线 →
- 聚合：空心菱形 ◇
- 组合：实心菱形 ◆

**完全掌握标准：**
- ✅ 能为本周项目画一张 UML 类图（手画或用工具）
- ✅ 推荐工具：[draw.io](https://app.diagrams.net/) / PlantUML

---

## 二、每日学习安排

| 天 | 学习内容 | 上机练习 | 时长 |
| --- | --- | --- | --- |
| **周一** | 类、对象、构造方法、this | 写 Student / Book / Car 类，体验 new | 5h |
| **周二** | 封装 + getter/setter + 包 | 重构周一代码为封装版 | 5h |
| **周三** | 继承 + 方法重写 + super | 动物园例子（Animal → Dog/Cat/Bird） | 5h |
| **周四** | 多态 ⭐（重点） | 动物园多态调用 + 形状面积 | 6h |
| **周五** | 抽象类 + 接口 | 接口写法 + 接口 vs 抽象类对比 | 6h |
| **周六** | static + final + UML | 实现 **用户管理系统** OOP 版 | 6h |
| **周日** | 复盘 + 写笔记 + 重构 | 实现 **图书管理系统** + 画 UML 类图 | 6h |

---

## 三、本周必做实战项目（2 个）

### 项目 1：用户管理系统（OOP 版）

**需求：**
- 设计 `User` 类（id、name、age、email、role）
- 设计 `UserManager` 类（用数组存储用户，提供 CRUD 方法）
- 设计 `UserService` 接口（addUser、deleteUser、findById、findAll）
- `UserManager` 实现 `UserService` 接口
- 主类 `Main` 提供菜单循环

**进阶要求：**
- 用户分为 `AdminUser` 和 `NormalUser`（继承 User）
- 不同角色有不同行为（多态）
- 用 static 实现自增 ID
- 用 final 定义用户角色常量

**验收标准：**
- ✅ 有清晰的包结构（model / service / impl / Main）
- ✅ 字段全部 private，方法 public
- ✅ 有 UML 类图
- ✅ 至少使用：继承 + 多态 + 接口 + static 各 1 处
- ✅ 注释清楚（每个类有 JavaDoc）

### 项目 2：图书管理系统

**需求：**
- `Book` 类（书名、作者、ISBN、是否借出）
- `Reader` 类（姓名、卡号、借书列表）
- `Library` 类（管理书和读者，借书、还书）
- 接口 `Borrowable`（被借阅的能力）

**业务逻辑：**
- 一个读者最多借 5 本书
- 借出的书不能再借
- 还书后状态恢复
- 查询读者已借书列表

**验收标准：**
- ✅ 类结构清晰
- ✅ 有边界检查（如借太多、借已借出的书）
- ✅ 提交 GitHub 并写 README

---

## 四、完全掌握检查清单（周末自测）

### 类与对象
- [ ] 能解释类、对象、引用、实例的关系
- [ ] 能用 IDEA `Alt+Insert` 自动生成构造方法 / getter / setter / toString / equals
- [ ] 能画出 `new Student()` 的内存图（栈中引用 → 堆中对象）

### 继承与多态
- [ ] 能闭眼写出继承代码并解释执行流程
- [ ] 能解释 Override vs Overload 的区别
- [ ] 能预测多态代码的输出（编译看左，运行看右）
- [ ] 能解释为什么 Java 是单继承

### 接口与抽象类
- [ ] 能列出接口与抽象类的至少 5 处区别
- [ ] 能解释何时用接口、何时用抽象类
- [ ] 能用 JDK 8 default 方法

### 关键字
- [ ] 能解释 this / super / static / final 的所有用法
- [ ] 能解释 String 为什么是 final
- [ ] 能解释静态方法为什么不能用 this

### 综合
- [ ] 完成 2 个 OOP 项目并提交 GitHub
- [ ] 为项目画了 UML 类图
- [ ] 写了 OOP 总结笔记

---

## 五、自测题（必做）

### 基础题

**Q1：** 下面代码输出什么？
```java
class A {
    public A() { System.out.println("A 构造"); }
}
class B extends A {
    public B() { System.out.println("B 构造"); }
}
public class Main {
    public static void main(String[] args) {
        new B();
    }
}
```
**答案：** `A 构造` / `B 构造`
**考点：** 子类构造默认先调用 super()

---

**Q2：** 下面代码输出什么？
```java
class Animal {
    public void eat() { System.out.println("Animal eat"); }
    public static void run() { System.out.println("Animal run"); }
}
class Dog extends Animal {
    @Override
    public void eat() { System.out.println("Dog eat"); }
    public static void run() { System.out.println("Dog run"); }
}
public class Main {
    public static void main(String[] args) {
        Animal a = new Dog();
        a.eat();
        a.run();
    }
}
```
**答案：** `Dog eat` / `Animal run`
**考点：** 实例方法是动态绑定（看对象），静态方法是静态绑定（看引用类型）

---

**Q3：** 下面代码能编译通过吗？为什么？
```java
abstract class Shape {
    public abstract double area();
}
class Circle extends Shape {
}
```
**答案：** 不能。Circle 没实现 area() 又不是抽象类，必须实现或自己变成 abstract。

---

**Q4：** 接口里能写构造方法吗？为什么？
**答案：** 不能。接口是规范，不是实体，没有"对象"概念。

---

### 设计题

**Q5：** 设计一个支付系统，支持微信、支付宝、银行卡 3 种支付方式。
**思路：**
- 定义 `PayService` 接口（方法 `pay(double amount)`）
- 3 个实现类：`WeChatPay`、`AliPay`、`BankCardPay`
- 上下文类 `PaymentContext` 持有 `PayService`，调用 `pay`
- 体现：**策略模式 + 多态 + 接口**

**Q6：** 为什么 `equals` 和 `hashCode` 通常一起重写？
**答案：** Java 规范：两个 equals 相等的对象必须 hashCode 相等，否则在 HashMap/HashSet 里会出错。

---

## 六、常见坑与误区

| 坑 | 描述 | 怎么避免 |
| --- | --- | --- |
| 写了有参构造，无参没了 | 反射调用失败 | 永远显式声明无参构造 |
| 父类构造异常 | 子类 new 时父类构造抛异常 | 用 try-catch 包住，或调整逻辑 |
| 误以为是重写实际是重载 | 参数列表不同 | 用 `@Override` 注解强制检查 |
| 静态方法重写？ | 实际是隐藏（hiding），不是重写 | 注意：静态方法不参与多态 |
| 接口字段被修改 | 接口字段默认 `public static final` | 不要把可变状态放接口里 |
| 父类引用调用子类独有方法 | 编译错误 | 先 instanceof 判断再向下转型 |
| equals 没重写直接用 | 默认比较地址，不是内容 | 自定义类要重写 equals + hashCode |

---

## 七、推荐学习资源

### 视频
- 【B站】黑马程序员 Java 面向对象（OOP 部分）
- 【B站】尚硅谷 宋红康 第 5~10 章

### 书籍
- 《Java 核心技术 · 卷 I》第 4~6 章
- 《Head First 设计模式》第 1 章（理解多态最佳读物）

### 经典文章
- [Oracle Java Tutorials - Classes and Objects](https://docs.oracle.com/javase/tutorial/java/javaOO/index.html)
- [Oracle Java Tutorials - Interfaces and Inheritance](https://docs.oracle.com/javase/tutorial/java/IandI/index.html)

---

## 八、本周完成后的"自我画像"

完成本周后你应该能说：

> "我能用面向对象的思想拆解现实问题，能设计类的字段和方法。
> 我能解释封装、继承、多态的原理，能区分接口和抽象类的使用场景。
> 我独立完成了用户管理系统和图书管理系统，并画了 UML 类图。
> 我开始体会到'面向对象'比'写流水账代码'优雅在哪里。"

---

## 九、下周预告

第 3 周进入 **集合框架 + 异常 + IO**——Java 工程师每天用的核心 API。
ArrayList、HashMap 这些工具能让你告别"用数组手工管理一切"的痛苦。
异常处理让你的代码更健壮，IO 让你能读写文件。

下周见！💪
