# 第 19 周：AI 框架（LangChain / LangGraph / Spring AI）

> **本周学习目标**：从"手写 RAG/Agent"升级到"用框架开发"，效率提升 10 倍。掌握 LangChain（Python）+ LangGraph（多 Agent）+ Spring AI（Java AI）。
>
> **本周关键词**：LangChain、PromptTemplate、Memory、Chain、Agent、LangGraph、StateGraph、Spring AI、ChatClient
>
> **预计投入时间**：40~50 小时

---

## 一、为什么用框架

第 18 周手写 RAG 时你应该发现：
- 文档加载、切分要自己实现
- Prompt 拼接重复劳动
- 多步流程难管理
- 切换模型要改一堆代码

**框架解决：**
- **抽象统一**：换模型不改代码
- **组件丰富**：30+ 文档加载器、20+ 向量库、各种 Chain
- **生态**：社区贡献的 Agent、Tool

**但也有坑：**
- 抽象太重，黑盒难调试
- 版本变化快
- 性能开销

**学习思路：先理解原理（第 18 周已经会手写），再学框架（事半功倍）。**

---

## 二、本周知识点详细分解

### 1. LangChain 总览（半天）

#### 1.1 LangChain 是什么

Python 生态最流行的 LLM 应用开发框架。提供：
- 统一的模型接口
- Prompt 管理
- Memory（对话记忆）
- Chain（流程串联）
- Agent + Tool
- RAG 完整支持
- 文档加载器（30+）

#### 1.2 LangChain 生态

```
langchain-core    ←  核心抽象
langchain         ←  主包
langchain-openai  ←  OpenAI 集成
langchain-community ← 社区集成（Chroma、PDF 等）
langgraph         ←  多 Agent 工作流
langsmith         ←  调试和监控（SaaS）
```

#### 1.3 安装

```bash
pip install langchain langchain-openai langchain-community
pip install langchain-chroma     # Chroma 集成
pip install pypdf                # PDF 解析
```

---

### 2. LangChain 核心组件（1 天）

#### 2.1 ChatModel（模型）

```python
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(
    model="deepseek-chat",
    api_key="...",
    base_url="https://api.deepseek.com/v1",
    temperature=0.7
)

# 直接调用
response = llm.invoke("你好")
print(response.content)
```

#### 2.2 PromptTemplate

```python
from langchain_core.prompts import ChatPromptTemplate

prompt = ChatPromptTemplate.from_messages([
    ("system", "你是一个 {role}"),
    ("user", "{question}")
])

messages = prompt.invoke({"role": "Python 老师", "question": "什么是装饰器？"})
response = llm.invoke(messages)
```

#### 2.3 Output Parser（输出解析）

```python
from langchain_core.output_parsers import StrOutputParser, JsonOutputParser

# 字符串
str_parser = StrOutputParser()

# JSON
from pydantic import BaseModel
class Person(BaseModel):
    name: str
    age: int

json_parser = JsonOutputParser(pydantic_object=Person)
```

#### 2.4 LCEL（LangChain Expression Language）⭐

用 `|` 串联组件：

```python
# 完整链
chain = prompt | llm | StrOutputParser()
result = chain.invoke({"role": "老师", "question": "什么是 OOP"})
print(result)

# 流式
for chunk in chain.stream({"role": "老师", "question": "..."}):
    print(chunk, end="", flush=True)
```

#### 2.5 Memory（对话记忆）

```python
from langchain_core.chat_history import InMemoryChatMessageHistory
from langchain_core.runnables.history import RunnableWithMessageHistory

prompt = ChatPromptTemplate.from_messages([
    ("system", "你是 AI"),
    ("placeholder", "{history}"),
    ("user", "{input}")
])

chain = prompt | llm

store = {}
def get_history(session_id):
    if session_id not in store:
        store[session_id] = InMemoryChatMessageHistory()
    return store[session_id]

chain_with_history = RunnableWithMessageHistory(
    chain, get_history,
    input_messages_key="input",
    history_messages_key="history"
)

# 使用
chain_with_history.invoke(
    {"input": "我是 Alice"},
    config={"configurable": {"session_id": "user1"}}
)
chain_with_history.invoke(
    {"input": "我叫什么？"},
    config={"configurable": {"session_id": "user1"}}
)
# AI 能记得是 Alice
```

**完全掌握标准：**
- ✅ 能用 ChatPromptTemplate 写带变量的 prompt
- ✅ 能用 LCEL 串联 prompt | llm | parser
- ✅ 能用 RunnableWithMessageHistory 加记忆
- ✅ 能流式输出

---

### 3. LangChain 实现 RAG（1 天）

#### 3.1 文档加载

```python
from langchain_community.document_loaders import (
    TextLoader, PyPDFLoader, Docx2txtLoader, WebBaseLoader
)

# PDF
loader = PyPDFLoader("doc.pdf")
docs = loader.load()

# Word
loader = Docx2txtLoader("doc.docx")

# 网页
loader = WebBaseLoader("https://example.com/article")

# 目录
from langchain_community.document_loaders import DirectoryLoader
loader = DirectoryLoader("./docs", glob="**/*.pdf", loader_cls=PyPDFLoader)
```

#### 3.2 文档切分

```python
from langchain_text_splitters import RecursiveCharacterTextSplitter

splitter = RecursiveCharacterTextSplitter(
    chunk_size=500,
    chunk_overlap=50,
    separators=["\n\n", "\n", "。", "！", "？", "，"]
)
chunks = splitter.split_documents(docs)
```

#### 3.3 向量化 + 入库

```python
from langchain_openai import OpenAIEmbeddings
from langchain_chroma import Chroma

embeddings = OpenAIEmbeddings(
    model="text-embedding-3-small",
    api_key="...",
    base_url="..."
)

vectorstore = Chroma.from_documents(
    chunks,
    embeddings,
    persist_directory="./chroma_db"
)
```

#### 3.4 检索 + 问答（RAG Chain）

```python
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser

retriever = vectorstore.as_retriever(search_kwargs={"k": 3})

prompt = ChatPromptTemplate.from_template("""
基于以下信息回答问题：

{context}

问题：{question}
""")

def format_docs(docs):
    return "\n\n".join(d.page_content for d in docs)

rag_chain = (
    {"context": retriever | format_docs, "question": RunnablePassthrough()}
    | prompt
    | llm
    | StrOutputParser()
)

answer = rag_chain.invoke("公司年假多少天？")
print(answer)
```

#### 3.5 进阶：带来源引用

```python
from langchain_core.runnables import RunnableLambda, RunnableParallel

def format_with_sources(docs):
    return {
        "context": "\n\n".join(d.page_content for d in docs),
        "sources": [d.metadata for d in docs]
    }

chain = RunnableParallel({
    "docs": retriever,
    "question": RunnablePassthrough()
}) | RunnableLambda(lambda x: {
    "answer": (prompt | llm | StrOutputParser()).invoke({
        "context": format_docs(x["docs"]),
        "question": x["question"]
    }),
    "sources": [d.metadata for d in x["docs"]]
})

result = chain.invoke("问题")
# result = {"answer": "...", "sources": [...]}
```

**完全掌握标准：**
- ✅ 能用 LangChain 加载 PDF / Word
- ✅ 能用 RecursiveCharacterTextSplitter 切分
- ✅ 能搭出完整 RAG Chain
- ✅ 能返回回答 + 来源

---

### 4. LangChain Agent（1 天）

#### 4.1 Tool 定义

```python
from langchain_core.tools import tool

@tool
def get_weather(city: str) -> str:
    """获取某个城市的天气"""
    return f"{city} 今天晴，25 度"

@tool
def calculate(expression: str) -> str:
    """计算数学表达式"""
    try:
        return str(eval(expression))
    except:
        return "无法计算"

tools = [get_weather, calculate]
```

#### 4.2 创建 Agent

```python
from langchain.agents import create_tool_calling_agent, AgentExecutor

prompt = ChatPromptTemplate.from_messages([
    ("system", "你是助手，必要时调用工具"),
    ("user", "{input}"),
    ("placeholder", "{agent_scratchpad}")
])

agent = create_tool_calling_agent(llm, tools, prompt)
executor = AgentExecutor(agent=agent, tools=tools, verbose=True)

result = executor.invoke({"input": "北京天气怎么样？1+2 等于几？"})
print(result["output"])
```

#### 4.3 Tool 进阶

```python
from langchain_core.tools import Tool

# 从函数包装
def search_db(query: str) -> str:
    return "..."

search_tool = Tool(
    name="search_db",
    description="从数据库查询信息",
    func=search_db
)

# 从 Pydantic 定义参数
from pydantic import BaseModel, Field
class SearchInput(BaseModel):
    query: str = Field(description="搜索关键字")
    limit: int = Field(default=10, description="最大返回数")

@tool(args_schema=SearchInput)
def search(query: str, limit: int = 10) -> str:
    """搜索数据库"""
    ...
```

#### 4.4 常用预置 Tool

```python
from langchain_community.tools import (
    DuckDuckGoSearchRun,     # 搜索引擎
    PythonREPLTool,          # 执行 Python 代码
    ShellTool                # 执行 Shell 命令（危险）
)
```

**完全掌握标准：**
- ✅ 能用 @tool 装饰器定义工具
- ✅ 能创建 Agent 执行多步任务
- ✅ 能让 Agent 自动选择工具

---

### 5. LangGraph（⭐重点 1 天）

#### 5.1 为什么需要 LangGraph

LangChain 的 Agent 是黑盒：
- 流程不可控
- 难加复杂分支
- 难做循环、人在回路

**LangGraph = 状态图 + 节点 + 边**

把工作流变成显式的图：
- 节点（Node）：执行单元（一个函数）
- 边（Edge）：流程控制（条件、循环）
- 状态（State）：跨节点共享

#### 5.2 基础例子

```python
from langgraph.graph import StateGraph, END
from typing import TypedDict, Annotated, List
from langgraph.graph.message import add_messages

class State(TypedDict):
    messages: Annotated[List, add_messages]

def chatbot(state: State):
    response = llm.invoke(state["messages"])
    return {"messages": [response]}

graph_builder = StateGraph(State)
graph_builder.add_node("chatbot", chatbot)
graph_builder.set_entry_point("chatbot")
graph_builder.set_finish_point("chatbot")
graph = graph_builder.compile()

# 使用
result = graph.invoke({
    "messages": [("user", "你好")]
})
```

#### 5.3 条件分支

```python
def should_continue(state):
    last_msg = state["messages"][-1]
    if last_msg.tool_calls:
        return "tools"
    return END

graph_builder.add_conditional_edges(
    "chatbot",
    should_continue,
    {
        "tools": "tools_node",
        END: END
    }
)
```

#### 5.4 多 Agent 协作示例（深入研究 + 写作）

```python
class State(TypedDict):
    topic: str
    research: str
    article: str

def research_agent(state):
    # 调研究 LLM 收集资料
    research = research_llm.invoke(f"研究：{state['topic']}").content
    return {"research": research}

def writer_agent(state):
    article = writer_llm.invoke(f"基于以下资料写文章：\n{state['research']}").content
    return {"article": article}

graph = StateGraph(State)
graph.add_node("researcher", research_agent)
graph.add_node("writer", writer_agent)
graph.add_edge("researcher", "writer")
graph.set_entry_point("researcher")
graph.set_finish_point("writer")
app = graph.compile()

result = app.invoke({"topic": "RAG 技术"})
print(result["article"])
```

#### 5.5 人在回路（Human-in-the-Loop）

```python
graph = graph_builder.compile(interrupt_before=["sensitive_node"])

# 执行到 sensitive_node 前会暂停
state = graph.invoke(initial_state)
# 人工 review
# 继续执行
state = graph.invoke(None, config)
```

**完全掌握标准：**
- ✅ 能定义 State 和节点
- ✅ 能用 add_edge / add_conditional_edges
- ✅ 能实现多 Agent 协作
- ✅ 知道 LangGraph 适合复杂工作流

---

### 6. Spring AI（Java 生态 AI 框架，半天）

#### 6.1 Spring AI 是什么

Spring 官方的 AI 框架。设计上类似 Spring Data：
- 统一 API（OpenAI / Anthropic / Ollama / 通义 / 智谱）
- 与 SpringBoot 无缝集成
- Java 工程师友好

#### 6.2 依赖

```xml
<dependency>
    <groupId>org.springframework.ai</groupId>
    <artifactId>spring-ai-openai-spring-boot-starter</artifactId>
</dependency>
```

#### 6.3 配置

```yaml
spring:
  ai:
    openai:
      api-key: ${OPENAI_KEY}
      base-url: https://api.deepseek.com
      chat:
        options:
          model: deepseek-chat
          temperature: 0.7
```

#### 6.4 ChatClient（推荐）

```java
@RestController
@RequiredArgsConstructor
public class ChatController {
    private final ChatClient.Builder builder;

    @GetMapping("/chat")
    public String chat(@RequestParam String q) {
        return builder.build()
            .prompt()
            .user(q)
            .call()
            .content();
    }

    @GetMapping(value = "/chat/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public Flux<String> stream(@RequestParam String q) {
        return builder.build()
            .prompt()
            .user(q)
            .stream()
            .content();
    }
}
```

#### 6.5 RAG（Spring AI 版）

```java
@Service
public class KnowledgeService {
    private final ChatClient chat;
    private final VectorStore vectorStore;

    public KnowledgeService(ChatClient.Builder b, VectorStore v) {
        this.chat = b.build();
        this.vectorStore = v;
    }

    public String ask(String question) {
        // 检索相关文档
        List<Document> docs = vectorStore.similaritySearch(SearchRequest.query(question).withTopK(3));
        String context = docs.stream().map(Document::getText).collect(Collectors.joining("\n\n"));

        return chat.prompt()
            .system("根据参考信息回答")
            .user(u -> u.text("参考：\n{ctx}\n\n问题：{q}").param("ctx", context).param("q", question))
            .call()
            .content();
    }
}
```

#### 6.6 Function Calling

```java
@Bean
public Function<WeatherRequest, WeatherResponse> getWeather() {
    return req -> new WeatherResponse(req.city(), 25, "晴");
}

// 调用时
String result = chatClient.prompt()
    .user("北京天气？")
    .functions("getWeather")     // Bean 名
    .call()
    .content();
```

#### 6.7 MCP 支持

Spring AI 1.x 已支持 MCP，可以连接 MCP Server（如本地数据库 MCP）。

**完全掌握标准：**
- ✅ 能用 Spring AI 调用 LLM
- ✅ 能用 ChatClient + Flux 实现流式
- ✅ 能用 VectorStore 实现 RAG
- ✅ 能用 Function Calling
- ✅ 能让现有 SpringBoot 项目无缝接入 AI

---

## 三、每日学习安排

| 天 | 学习内容 | 上机练习 | 时长 |
| --- | --- | --- | --- |
| **周一** | LangChain 概览 + 核心组件 | Hello World + Prompt + LCEL | 5h |
| **周二** | Memory + 多轮对话 | 重写第 18 周聊天机器人 | 5h |
| **周三** | LangChain RAG ⭐ | 用 LangChain 重写 RAG | 6h |
| **周四** | LangChain Agent + Tool | 多工具 Agent | 6h |
| **周五** | LangGraph 基础 + 多 Agent ⭐ | 写作工作流（调研→写作→校对） | 6h |
| **周六** | Spring AI ⭐ | 把 SpringBoot 项目接 AI | 6h |
| **周日** | 综合项目 + 复盘 | 实战 + 提交 GitHub | 6h |

---

## 四、本周必做实战项目（2 个）

### 项目 1：LangChain 版 AI 文档问答系统

**功能：**
- 上传 PDF / Word / 网页 URL
- 自动切分 + 向量化（用 LangChain Loader + Splitter）
- 问答接口（用 LangChain RAG Chain）
- 流式输出
- 返回引用来源

**架构：**
```
FastAPI → LangChain（Loader/Splitter/VectorStore/Chain） → DeepSeek
```

**验收：**
- ✅ 比第 18 周的代码少 50% 但功能更全
- ✅ 支持 3+ 种文档源
- ✅ 流式输出
- ✅ 提交 GitHub

---

### 项目 2：AI SQL Agent（Spring AI 或 LangChain）

**场景：** 用户用自然语言查询数据库
> "查最近 7 天销售额 Top 10 商品"

**实现：**
1. 工具 1：`getSchema()` 返回数据库表结构
2. 工具 2：`executeSql(sql)` 执行 SQL（**白名单只允许 SELECT**）
3. LLM 流程：
   - 调用 getSchema 了解结构
   - 生成 SQL
   - 调用 executeSql
   - 解释结果给用户

**安全：**
- ✅ 只允许 SELECT，禁用 INSERT/UPDATE/DELETE/DROP
- ✅ SQL 复杂度限制
- ✅ 超时控制

**验收：**
- ✅ 自然语言能转 SQL 并执行
- ✅ 拒绝危险 SQL
- ✅ 输出可读的结果说明
- ✅ 提交 GitHub

---

## 五、完全掌握检查清单

### LangChain
- [ ] 能用 ChatPromptTemplate + LCEL
- [ ] 能用 Memory 实现多轮对话
- [ ] 能用 Loader + Splitter + VectorStore 搭 RAG
- [ ] 能定义 @tool 给 Agent 调用
- [ ] 能用 stream 流式

### LangGraph
- [ ] 能定义 State 和节点
- [ ] 能用 add_edge / add_conditional_edges
- [ ] 能实现多 Agent 协作

### Spring AI
- [ ] 能用 ChatClient 调 LLM
- [ ] 能实现流式输出
- [ ] 能用 VectorStore 实现 RAG
- [ ] 能用 Function Calling
- [ ] 能在原有 SpringBoot 项目接入

### 综合
- [ ] 完成 LangChain RAG + AI SQL Agent 2 个项目
- [ ] 提交 GitHub

---

## 六、自测题

**Q1：** LCEL（`|` 运算符）的底层原理？
**答案：** LangChain 把所有组件抽象成 `Runnable` 接口。`|` 调用 `__or__` 把两个 Runnable 组合，本质是责任链模式。

---

**Q2：** LangChain 的 Memory 怎么避免上下文爆炸？
**答案：**
- ConversationBufferMemory：全量保留（最多 token 限制）
- ConversationBufferWindowMemory：保留最近 N 轮
- ConversationSummaryMemory：用 LLM 摘要历史
- VectorStore Memory：把历史向量化，检索相关的注入

---

**Q3：** LangGraph 和 LangChain Agent 的区别？
**答案：**
- LangChain Agent：黑盒，固定 ReAct 循环
- LangGraph：白盒，状态图，可自定义节点、边、分支、循环
- LangGraph 适合复杂工作流（多 Agent、人在回路）

---

**Q4：** Spring AI 和 LangChain4j 的区别？
**答案：**
- Spring AI：Spring 官方，与 Spring 生态集成深
- LangChain4j：LangChain 的 Java 版，API 接近原版
- 选择：用 Spring 生态选 Spring AI，否则可考虑 LangChain4j

---

**Q5：** 如何让 SQL Agent 防注入？
**答案：**
- 用户输入不直接拼 SQL
- 让 LLM 输出 SQL 时只允许 SELECT
- 在执行前用正则 / SQL 解析器校验
- 用最小权限的数据库账号
- 限制超时和 LIMIT

---

## 七、常见坑与误区

| 坑 | 描述 | 解决 |
| --- | --- | --- |
| LangChain 版本升级破坏 | API 大改 | 锁定版本 |
| 抽象过重 | 简单需求被绑死 | 简单场景手写更清晰 |
| Memory 累积 | token 爆 | 用 Window / Summary |
| Agent 失控 | 工具用错 / 死循环 | 限制 max_iter |
| RAG 召回低 | 切分 / embedding 不匹配 | 调参 / Hybrid 检索 |
| Spring AI 旧版 API | 1.0 之前不稳定 | 用最新 GA 版本 |

---

## 八、推荐学习资源

### 视频
- 【B站】LangChain 中文教程
- LangChain 官方 YouTube

### 官方
- [LangChain 文档](https://python.langchain.com/docs/get_started/introduction)
- [LangGraph 文档](https://langchain-ai.github.io/langgraph/)
- [Spring AI 文档](https://docs.spring.io/spring-ai/reference/)

### 项目参考
- [GPT Engineer](https://github.com/AntonOsika/gpt-engineer)
- [AutoGen](https://github.com/microsoft/autogen)

---

## 九、本周完成后的"自我画像"

> "我能用 LangChain 5 分钟搭出一个 RAG 系统，比手写代码少一半。
> 我能用 LangGraph 设计多 Agent 协作工作流。
> 我能用 Spring AI 把 AI 能力无缝接入现有 SpringBoot 项目。
> 我做了 LangChain 知识库 + AI SQL Agent 2 个项目。
> 我具备完整 AI 应用工程师的技术栈了。"

---

## 十、下周预告

第 20 周：**AI 项目实战周**——做一个完整的 AI 应用，作为简历上的"AI 项目"。
推荐方向：AI 知识库 / AI Agent / AI 客服。

下周见！🚀
