# 第 18 周：LLM 基础

> **本周学习目标**：理解大模型的核心概念（Token、Prompt、Function Calling、Embedding、RAG、MCP、Agent），能直接调用 LLM API 实现聊天机器人 + 流式输出。
>
> **本周关键词**：Token、Prompt、Temperature、Function Calling、Embedding、RAG、向量数据库、MCP、Agent、流式输出
>
> **预计投入时间**：35~45 小时

---

## 一、LLM 全景图

```
                  ┌─────────────────┐
                  │   大模型（LLM）   │
                  │  GPT / Claude / │
                  │  Gemini / DeepSeek
                  └────────┬────────┘
                           │ API
                           ▼
        ┌──────────────────────────────────┐
        │      你的 AI 应用                  │
        ├──────────────────────────────────┤
        │ 1. Prompt Engineering（提示词）    │
        │ 2. Function Calling（工具调用）     │
        │ 3. Embedding + 向量数据库（语义检索） │
        │ 4. RAG（检索增强生成）              │
        │ 5. Agent（智能体）                 │
        │ 6. MCP（标准协议）                 │
        └──────────────────────────────────┘
```

---

## 二、本周知识点详细分解

### 1. LLM 是什么 & 模型选择（半天）

#### 1.1 概念

- **LLM (Large Language Model)** = 大语言模型
- 输入：文本（Prompt）
- 输出：文本（生成）
- 本质：**概率性预测下一个 token**

#### 1.2 主流模型

| 提供商 | 模型 | 特点 |
| --- | --- | --- |
| OpenAI | GPT-4o / GPT-4-Turbo | 综合最强 |
| Anthropic | **Claude Opus 4 / Sonnet 4 / Haiku 4**（最新） | 长上下文、写作、代码强 |
| Google | Gemini Pro / Flash | 多模态、便宜 |
| **国产** | DeepSeek、通义千问、文心一言、智谱 GLM、Kimi、月之暗面 | 中文好、价格便宜 |
| 开源 | Llama 3 / Qwen / DeepSeek 开源版 | 可本地部署 |

**学习建议：**
- **国内访问方便**：用 DeepSeek、通义、智谱（国内直连）
- **OpenAI**：需要中转或代理
- **Anthropic Claude**：与代码、Agent 任务结合最强

#### 1.3 价格对比（粗略）

按每百万 token 计费（输入 / 输出）：
- GPT-4o：$2.5 / $10
- Claude Sonnet 4：$3 / $15
- DeepSeek：约 ¥1 / ¥2
- Gemini Flash：很便宜

**学习阶段推荐 DeepSeek**（便宜、能力够用）。

#### 1.4 申请 API Key

**DeepSeek：**
1. 注册 [https://platform.deepseek.com/](https://platform.deepseek.com/)
2. 充值 ¥10（用不完）
3. 创建 API Key

**OpenAI（需要海外卡 + 代理）：**
1. 注册 [https://platform.openai.com/](https://platform.openai.com/)
2. 绑定信用卡
3. 创建 Key

**完全掌握标准：**
- ✅ 能说出 3+ 主流模型
- ✅ 能区分闭源（GPT、Claude）vs 开源（Llama、Qwen）
- ✅ 有一个能用的 API Key

---

### 2. Token（重点）（半天）

#### 2.1 什么是 Token

- LLM 处理的最小单位
- 英文：约 1 word ≈ 1~2 tokens
- 中文：约 1 字 ≈ 1~2 tokens
- 标点、空格也算 token

**例子：** "Hello, world!" → ["Hello", ",", " world", "!"] = 4 tokens

#### 2.2 为什么要在乎 Token

1. **API 计费**：按 token 算钱
2. **上下文限制**：每个模型最大 token 数有限
   - GPT-4-Turbo：128K
   - Claude 4：200K~1M
   - DeepSeek：64K~128K
3. **性能**：token 越多越慢

#### 2.3 工具

```python
# OpenAI 的 tokenizer
pip install tiktoken
```

```python
import tiktoken
enc = tiktoken.encoding_for_model("gpt-4")
tokens = enc.encode("Hello world")
print(len(tokens))      # 2
print(tokens)            # [9906, 1917]
print(enc.decode(tokens))
```

**完全掌握标准：**
- ✅ 能解释 token 是什么
- ✅ 能用 tiktoken 数 token
- ✅ 知道为什么 1000 字中文 ≈ 1500~2000 tokens
- ✅ 知道上下文窗口大小

---

### 3. 调用 LLM API（重点⭐）（1 天）

#### 3.1 OpenAI SDK（标准接口）

```bash
pip install openai
```

```python
from openai import OpenAI

client = OpenAI(
    api_key="sk-xxx",
    base_url="https://api.deepseek.com/v1"   # DeepSeek 兼容 OpenAI 协议
)

response = client.chat.completions.create(
    model="deepseek-chat",
    messages=[
        {"role": "system", "content": "你是一个友善的助手"},
        {"role": "user", "content": "Hello"}
    ],
    temperature=0.7,
    max_tokens=1000
)

print(response.choices[0].message.content)
print(f"用了 {response.usage.total_tokens} tokens")
```

#### 3.2 三种 Role

| role | 含义 |
| --- | --- |
| **system** | 系统提示，设定角色和规则（一开始一次） |
| **user** | 用户输入 |
| **assistant** | AI 之前的回复（多轮对话用） |

#### 3.3 参数详解

| 参数 | 含义 | 默认 |
| --- | --- | --- |
| `model` | 模型名 | - |
| `messages` | 对话列表 | - |
| **`temperature`** | 创造性（0~2），越高越发散 | 1.0 |
| `top_p` | 核采样，与 temperature 二选一 | 1.0 |
| `max_tokens` | 最大生成 token | - |
| `stream` | 流式输出 | false |
| `tools` / `tool_choice` | 工具调用 | - |
| `response_format` | 强制 JSON 输出 | - |

#### 3.4 多轮对话

```python
history = [
    {"role": "system", "content": "你是 AI 助手"}
]

def chat(user_input):
    history.append({"role": "user", "content": user_input})
    response = client.chat.completions.create(
        model="deepseek-chat",
        messages=history
    )
    reply = response.choices[0].message.content
    history.append({"role": "assistant", "content": reply})
    return reply

print(chat("我是 Alice"))
print(chat("我叫什么名字？"))     # 能记得是 Alice
```

#### 3.5 流式输出（重要⭐）

```python
stream = client.chat.completions.create(
    model="deepseek-chat",
    messages=[{"role": "user", "content": "写一首诗"}],
    stream=True
)

for chunk in stream:
    delta = chunk.choices[0].delta.content
    if delta:
        print(delta, end="", flush=True)
```

#### 3.6 强制 JSON 输出

```python
response = client.chat.completions.create(
    model="deepseek-chat",
    messages=[{
        "role": "user",
        "content": "提取以下文本的姓名和年龄，输出 JSON：张三今年 20 岁"
    }],
    response_format={"type": "json_object"}
)
# {"name": "张三", "age": 20}
```

#### 3.7 Anthropic Claude SDK

```bash
pip install anthropic
```

```python
from anthropic import Anthropic

client = Anthropic(api_key="sk-ant-xxx")

response = client.messages.create(
    model="claude-sonnet-4-6",
    max_tokens=1024,
    system="你是助手",
    messages=[
        {"role": "user", "content": "Hello"}
    ]
)
print(response.content[0].text)
```

**完全掌握标准：**
- ✅ 能用 OpenAI SDK 调用 LLM
- ✅ 能写多轮对话（管理 history）
- ✅ 能用 stream=True 实现流式
- ✅ 能调 temperature 控制风格
- ✅ 能强制 JSON 输出
- ✅ 知道 system / user / assistant 三种 role

---

### 4. Prompt Engineering（提示词工程，⭐⭐重点）（1 天）

#### 4.1 为什么重要

**同样的模型，不同 prompt 效果天差地别。**

#### 4.2 基本技巧

##### 4.2.1 明确角色

```
你是一名 10 年经验的 Python 开发工程师。

❌ "写代码"  →  ✅ "为以下需求写 Python 代码"
```

##### 4.2.2 提供上下文

```
背景：我在做一个电商系统
任务：设计用户订单表的字段
要求：用 MySQL DDL
```

##### 4.2.3 给例子（Few-shot）

```
请把下面句子改成正式语气：

例子 1：
输入：哥们儿，干啥呢？
输出：您好，请问您在做什么呢？

例子 2：
输入：搞快点
输出：请尽快处理。

现在改写：
输入：饭吃了没？
输出：
```

##### 4.2.4 限定格式

```
输出 JSON 格式：
{
  "summary": "...",
  "keywords": ["...", "..."]
}
```

##### 4.2.5 一步步思考（CoT, Chain of Thought）

```
请一步步分析以下问题：
1. 列出已知条件
2. 分析每个条件
3. 得出结论
```

##### 4.2.6 让 AI 自我检查

```
完成后请检查：
- 是否遗漏要求？
- 代码是否能运行？
- 是否有边界情况？
```

#### 4.3 结构化 Prompt 模板

```
# 角色
你是 XXX

# 任务
完成 XXX

# 输入
{input}

# 要求
1. ...
2. ...

# 输出格式
JSON
```

#### 4.4 高级技巧

- **ReAct**：Thought → Action → Observation 循环（Agent 用）
- **Self-Refinement**：让 AI 自我改进
- **Multi-step**：拆分大任务

**完全掌握标准：**
- ✅ 能写出包含角色、任务、要求、格式的结构化 prompt
- ✅ 能用 Few-shot 引导输出
- ✅ 能用 CoT 让模型分步推理
- ✅ 能限定 JSON 输出

---

### 5. Function Calling（工具调用，⭐重点）（半天）

#### 5.1 概念

让 LLM 调用外部函数：
- 查询数据库
- 调用 API
- 执行代码

#### 5.2 流程

```
1. 用户："明天北京天气如何？"
2. LLM 分析 → 决定调用 get_weather(city="北京", date="2026-05-14")
3. 你的代码执行函数 → 拿到结果 → 回传给 LLM
4. LLM 生成最终回答
```

#### 5.3 代码示例

```python
def get_weather(city, date):
    # 模拟
    return {"city": city, "date": date, "temp": 25, "weather": "晴"}

tools = [{
    "type": "function",
    "function": {
        "name": "get_weather",
        "description": "查询某个城市某天的天气",
        "parameters": {
            "type": "object",
            "properties": {
                "city": {"type": "string", "description": "城市名"},
                "date": {"type": "string", "description": "日期 YYYY-MM-DD"}
            },
            "required": ["city", "date"]
        }
    }
}]

response = client.chat.completions.create(
    model="deepseek-chat",
    messages=[{"role": "user", "content": "明天北京天气？"}],
    tools=tools
)

tool_call = response.choices[0].message.tool_calls[0]
import json
args = json.loads(tool_call.function.arguments)
result = get_weather(**args)

# 把结果回传给 LLM
final = client.chat.completions.create(
    model="deepseek-chat",
    messages=[
        {"role": "user", "content": "明天北京天气？"},
        response.choices[0].message,
        {"role": "tool", "tool_call_id": tool_call.id, "content": json.dumps(result)}
    ]
)
print(final.choices[0].message.content)
```

**完全掌握标准：**
- ✅ 能定义工具 schema
- ✅ 能解析 tool_calls 并执行
- ✅ 能把结果回传 LLM
- ✅ 能理解为什么这是 Agent 的基础

---

### 6. Embedding & 向量数据库（⭐重点）（半天）

#### 6.1 Embedding 是什么

把文本转成**向量**（一组浮点数），相似文本的向量也相似。

```python
response = client.embeddings.create(
    model="text-embedding-3-small",
    input="今天天气真好"
)
vector = response.data[0].embedding
# [0.012, -0.453, 0.789, ...] 长度比如 1536
```

#### 6.2 向量相似度

**余弦相似度**：
```python
import numpy as np
def cosine(a, b):
    return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))
```

#### 6.3 向量数据库

存储 + 高效搜索向量：

| 数据库 | 特点 |
| --- | --- |
| **Chroma** | 简单易用，本地，学习推荐 |
| **Milvus** | 性能强，企业级 |
| **Qdrant** | Rust 写的，性能好 |
| **Pinecone** | SaaS，免运维 |
| **Weaviate** | 多模态 |
| pgvector | PostgreSQL 扩展 |

#### 6.4 Chroma 示例

```bash
pip install chromadb
```

```python
import chromadb

client = chromadb.PersistentClient(path="./vector_db")
collection = client.get_or_create_collection("docs")

# 加入文档
collection.add(
    documents=["今天天气真好", "明天会下雨", "Python 是好语言"],
    metadatas=[{"src": "doc1"}, {"src": "doc2"}, {"src": "doc3"}],
    ids=["1", "2", "3"]
)

# 查询
results = collection.query(
    query_texts=["天气怎么样"],
    n_results=2
)
print(results['documents'])
# [["今天天气真好", "明天会下雨"]]
```

**完全掌握标准：**
- ✅ 能用 OpenAI / DeepSeek embedding 把文本转向量
- ✅ 能用 Chroma 存储 + 查询
- ✅ 能理解向量相似度的意义

---

### 7. RAG（检索增强生成，⭐⭐⭐核心）（1 天）

#### 7.1 什么是 RAG

**Retrieval-Augmented Generation**：让 LLM 基于"私有知识"回答问题。

#### 7.2 为什么需要

LLM 的局限：
- 训练数据有截止时间（不知道最新）
- 不知道你的私有文档
- 容易"幻觉"（编造）

RAG 解决：
- 把私有文档向量化存进向量库
- 用户问问题 → 检索相关片段 → 塞进 prompt → 让 LLM 基于片段回答

#### 7.3 RAG 流程图

```
[文档准备阶段]
PDF/Word 文档 → 切分（chunk） → Embedding → 向量数据库

[问答阶段]
用户问题 → Embedding → 检索 TopK 相关片段 → 拼接 Prompt → LLM → 回答
```

#### 7.4 完整 RAG 代码（核心⭐）

```python
import chromadb
from openai import OpenAI

client_llm = OpenAI(api_key="...", base_url="...")
client_db = chromadb.PersistentClient(path="./db")
collection = client_db.get_or_create_collection("knowledge")

def embed(text):
    res = client_llm.embeddings.create(
        model="text-embedding-3-small",
        input=text
    )
    return res.data[0].embedding

# 1. 准备文档（已切分好）
documents = [
    "我们公司的休假政策：每年 15 天年假...",
    "出差报销标准：交通住宿全报...",
    "员工福利：节日福利、年终奖..."
]

# 2. 入库
for i, doc in enumerate(documents):
    collection.add(
        embeddings=[embed(doc)],
        documents=[doc],
        ids=[str(i)]
    )

# 3. RAG 问答
def rag_qa(question):
    # 检索
    q_emb = embed(question)
    results = collection.query(query_embeddings=[q_emb], n_results=3)
    context = "\n\n".join(results['documents'][0])

    # 构造 prompt
    prompt = f"""请根据以下信息回答问题：

参考信息：
{context}

问题：{question}

要求：仅基于上述信息回答，不知道就说不知道。
"""
    response = client_llm.chat.completions.create(
        model="deepseek-chat",
        messages=[{"role": "user", "content": prompt}]
    )
    return response.choices[0].message.content

print(rag_qa("公司年假多少天？"))
```

#### 7.5 文档切分策略

- **固定长度**：每 500 字一段（简单）
- **段落切分**：按段落 / 标题
- **重叠切分**：相邻片段有重叠（避免切断语义）
- **递归切分**：先按章节，再按段落

```python
def chunk_text(text, size=500, overlap=50):
    chunks = []
    i = 0
    while i < len(text):
        chunks.append(text[i:i+size])
        i += size - overlap
    return chunks
```

#### 7.6 进阶技巧

- **Hybrid 检索**：向量 + 关键词 BM25
- **Reranker**：重排序模型
- **Multi-query**：把问题改写成多个再检索
- **HyDE**：让 LLM 先假想答案再用答案去检索

**完全掌握标准：**
- ✅ 能讲清 RAG 的完整流程
- ✅ 能用 Chroma + LLM 实现简单 RAG
- ✅ 能写文档切分函数
- ✅ 能解释为什么 RAG 解决幻觉
- ✅ 知道 RAG 的进阶优化方向

---

### 8. Agent（智能体）（半天，下周深入）

#### 8.1 概念

**Agent = LLM + 工具 + 循环决策**

```
循环：
1. LLM 思考下一步
2. 决定调用哪个工具
3. 执行工具
4. 把结果给 LLM
5. 直到完成或退出
```

#### 8.2 简单实现（ReAct 模式）

```python
def react_agent(query, tools, max_iter=5):
    messages = [{"role": "user", "content": query}]
    for _ in range(max_iter):
        response = client.chat.completions.create(
            model="deepseek-chat",
            messages=messages,
            tools=tools
        )
        msg = response.choices[0].message
        if not msg.tool_calls:
            return msg.content
        messages.append(msg)
        for tc in msg.tool_calls:
            result = execute(tc)
            messages.append({"role": "tool",
                             "tool_call_id": tc.id,
                             "content": json.dumps(result)})
    return "迭代次数耗尽"
```

#### 8.3 应用

- 客服机器人（多轮对话 + 调用业务系统）
- 自动写代码（GPT Engineer）
- 浏览器 Agent（自动浏览网页）

---

### 9. MCP（模型上下文协议）（半天，了解）

#### 9.1 概念

**MCP (Model Context Protocol)** —— Anthropic 提出的标准协议，让 LLM 客户端连接到外部工具/资源。

**核心思想：** 标准化"模型如何获取上下文"。

#### 9.2 MCP 三种能力

- **Resources**：暴露文件/数据（文档、数据库表）
- **Tools**：可执行的函数（类似 Function Calling）
- **Prompts**：模板化的提示词

#### 9.3 应用

- Claude Desktop 通过 MCP 接入本地 SQL 数据库、文件系统
- 让 Agent 跨工具协同
- 标准化集成

**完全掌握标准（了解）：**
- ✅ 能解释 MCP 解决的问题（标准化上下文）
- ✅ 知道 MCP 三种能力
- ✅ 知道下周可能会用到 MCP

---

## 三、每日学习安排

| 天 | 学习内容 | 上机练习 | 时长 |
| --- | --- | --- | --- |
| **周一** | LLM 概览 + 申请 API + Token | 用 tiktoken 数 token | 4h |
| **周二** | 调 API + 多轮对话 + 流式 ⭐ | 写命令行版聊天机器人 | 5h |
| **周三** | Prompt Engineering ⭐ | 练 10 个不同场景 prompt | 5h |
| **周四** | Function Calling ⭐ | 实现天气/计算器 tool | 5h |
| **周五** | Embedding + Chroma | 文档相似度搜索 | 5h |
| **周六** | RAG ⭐⭐ | 实现私有知识库问答 | 7h |
| **周日** | Agent + MCP + 综合项目 | AI 聊天 Web 端 | 6h |

---

## 四、本周必做实战项目（2 个）

### 项目 1：AI 聊天机器人（命令行 + Web）

**功能：**
- 命令行版：循环对话，记录历史
- Web 版（FastAPI + 第 16 周的 React 前端）：
  - 流式输出（SSE）
  - 多轮对话
  - 切换会话

**后端（FastAPI）：**

```python
from fastapi import FastAPI
from fastapi.responses import StreamingResponse
from openai import OpenAI

app = FastAPI()
client = OpenAI(api_key="...", base_url="...")

@app.post("/api/chat/stream")
async def chat_stream(req: dict):
    messages = req["messages"]
    def gen():
        stream = client.chat.completions.create(
            model="deepseek-chat",
            messages=messages,
            stream=True
        )
        for chunk in stream:
            delta = chunk.choices[0].delta.content
            if delta:
                yield f"data: {delta}\n\n"
        yield "data: [DONE]\n\n"
    return StreamingResponse(gen(), media_type="text/event-stream")
```

**前端（React）：**

```jsx
async function send(message) {
    const res = await fetch('/api/chat/stream', {
        method: 'POST',
        body: JSON.stringify({ messages: [...history, {role: 'user', content: message}] })
    });
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value);
        // 解析 SSE 格式更新 UI
    }
}
```

**验收：**
- ✅ 命令行版能多轮对话
- ✅ Web 版有流式打字效果
- ✅ 提交 GitHub

---

### 项目 2：私有知识库问答（RAG）

**功能：**
- 上传 PDF / TXT / Markdown
- 自动切分 + 向量化 + 存 Chroma
- 用户提问 → 检索 → LLM 回答
- 返回引用来源

**接口：**
- `POST /api/kb/upload` 上传文档
- `POST /api/kb/ask` 提问

**核心代码：**

```python
@app.post("/api/kb/upload")
async def upload(file: UploadFile):
    text = parse_file(file)
    chunks = chunk_text(text)
    for i, chunk in enumerate(chunks):
        collection.add(
            embeddings=[embed(chunk)],
            documents=[chunk],
            metadatas=[{"filename": file.filename, "chunk": i}],
            ids=[f"{file.filename}_{i}"]
        )
    return {"chunks": len(chunks)}

@app.post("/api/kb/ask")
async def ask(req: dict):
    q = req["question"]
    results = collection.query(query_embeddings=[embed(q)], n_results=3)
    docs = results['documents'][0]
    sources = results['metadatas'][0]

    context = "\n\n".join(docs)
    prompt = f"参考信息：\n{context}\n\n问题：{q}\n\n请基于参考信息回答。"

    res = client.chat.completions.create(
        model="deepseek-chat",
        messages=[{"role": "user", "content": prompt}]
    )
    return {
        "answer": res.choices[0].message.content,
        "sources": sources
    }
```

**验收：**
- ✅ 上传 PDF 能成功向量化
- ✅ 问题能正确召回相关片段
- ✅ 回答引用了文档内容
- ✅ 提交 GitHub

---

## 五、完全掌握检查清单

### 基础
- [ ] 能解释 Token、上下文窗口
- [ ] 能用 tiktoken 数 token
- [ ] 有可用 API Key

### API 调用
- [ ] 能用 OpenAI SDK 调 LLM
- [ ] 能多轮对话
- [ ] 能流式输出
- [ ] 能强制 JSON 输出

### Prompt
- [ ] 能写结构化 prompt
- [ ] 能用 Few-shot
- [ ] 能用 CoT

### Function Calling
- [ ] 能定义工具 schema
- [ ] 能解析 tool_calls 并执行

### Embedding & RAG
- [ ] 能用 Chroma 存查向量
- [ ] 能实现完整 RAG 流程
- [ ] 知道文档切分策略

### 综合
- [ ] 完成 AI 聊天 + RAG 知识库 2 个项目并提交 GitHub

---

## 六、自测题

**Q1：** 为什么 1 万字中文输入 GPT，可能算 1.5 万 token？
**答案：** 中文 1 个字常被切成 1.5 个 token（不像英文一个 word 经常是 1 个 token）。

---

**Q2：** Temperature 调高会怎样？
**答案：** 输出更随机、更有创造性，但也更易出错。代码生成、规则任务用 0~0.3；创意写作用 0.7~1.2。

---

**Q3：** 为什么 RAG 能减少幻觉？
**答案：**
- 把权威信息塞进 prompt
- LLM 基于参考信息回答而不是凭记忆
- 可以让 LLM 在"找不到"时拒绝回答

---

**Q4：** Function Calling 和 Agent 是什么关系？
**答案：** Function Calling 是 Agent 的基础。Agent = LLM + Function Calling + 循环决策。

---

**Q5：** 流式输出（stream）的实现原理？
**答案：** 服务端用 SSE（Server-Sent Events）或 chunked transfer 持续推送 token。客户端边接收边渲染。LLM 输出本来就是逐 token 生成的，stream 把这个过程暴露给客户端。

---

**Q6：** Embedding 的向量维度有什么影响？
**答案：**
- 维度高（如 3072）：表达能力强，但存储和检索更慢
- 维度低（如 384）：更快但语义粒度粗
- 实际选 768 / 1536 较常用

---

## 七、常见坑与误区

| 坑 | 描述 | 解决 |
| --- | --- | --- |
| API Key 泄漏 | 写代码里被推 GitHub | 用 .env + .gitignore |
| 上下文爆 | 多轮对话累积超 token 上限 | 滑动窗口或摘要 |
| 流式响应在 Java 端难处理 | 默认 HTTP 客户端不支持 | 用 OkHttp / WebFlux |
| RAG 召回不准 | 切分不合理 | 调 chunk_size / overlap |
| 中文 embedding 效果差 | 模型不支持中文 | 用 BGE 等中文优化模型 |
| 幻觉 | LLM 编造 | RAG + 让模型说"不知道" |
| 成本失控 | 调用太多 | 缓存 + 流量监控 |
| Function 参数错 | LLM 生成的 args 不合规 | 用 Pydantic 校验后再调 |

---

## 八、推荐学习资源

### 视频
- 【B站】吴恩达《ChatGPT Prompt Engineering for Developers》（中字版）
- 【B站】Andrej Karpathy 系列（LLM 原理深入）

### 文章
- [OpenAI Cookbook](https://github.com/openai/openai-cookbook)
- [Prompt Engineering Guide](https://www.promptingguide.ai/zh)
- [LangChain 文档](https://python.langchain.com/)

### 官方
- [OpenAI API](https://platform.openai.com/docs)
- [DeepSeek API](https://platform.deepseek.com/api-docs)
- [Anthropic API](https://docs.anthropic.com/)
- [Chroma 文档](https://docs.trychroma.com/)

---

## 九、本周完成后的"自我画像"

> "我能用 OpenAI / DeepSeek SDK 调 LLM，懂 Token、上下文、流式、JSON 模式。
> 我能写好的 Prompt，让模型按要求输出。
> 我能用 Function Calling 让 LLM 调用我的代码。
> 我能用 Chroma + LLM 搭出一个简单 RAG 知识库。
> 我完成了 AI 聊天 + 私有知识库问答 2 个项目。
> 我开始有'AI 应用工程师'的雏形了。"

---

## 十、下周预告

第 19 周：**AI 框架（LangChain / LangGraph / Spring AI）**。
你会用上层框架替代手写 RAG 和 Agent 逻辑，开发效率提升 10 倍。

下周见！🚀
