# 第 10 周：SpringCloud（微服务）

> **本周学习目标**：从单体应用进入微服务，能用 Nacos + Gateway + OpenFeign + Sentinel 拆分一个简单服务。
>
> **本周关键词**：微服务、服务拆分、注册中心 Nacos、配置中心、网关 Gateway、远程调用 OpenFeign、熔断限流 Sentinel
>
> **预计投入时间**：35~45 小时

---

## 一、本周知识点详细分解

### 1. 微服务概念（半天）

#### 1.1 为什么需要微服务

**单体应用的痛：**
- 代码越来越庞大，编译慢
- 任何小改动要重新部署整个应用
- 一个 bug 整个挂掉
- 不同模块技术栈无法独立选择
- 扩展只能整体扩展

**微服务的好处：**
- 服务独立部署 → 改一处不影响其他
- 服务独立扩展 → 用户服务慢就只扩用户服务
- 技术栈灵活 → 可以混用 Java + Python
- 团队独立 → 一个团队负责一个服务

**微服务的坏处：**
- 复杂度爆炸（分布式事务、链路追踪、配置管理）
- 网络开销
- 部署运维成本高
- 强一致性难

**结论：** 用户量小、业务简单 → 单体；用户量大、团队多 → 微服务。

#### 1.2 微服务核心组件

| 组件 | 作用 | 主流实现 |
| --- | --- | --- |
| 注册中心 | 服务发现 | Nacos / Eureka / Consul |
| 配置中心 | 集中配置 | Nacos / Apollo |
| 网关 | 统一入口、鉴权、路由 | Spring Cloud Gateway / Zuul |
| 远程调用 | 服务间通信 | OpenFeign / Dubbo / RestTemplate |
| 负载均衡 | 多实例分摊 | LoadBalancer / Ribbon（已弃） |
| 熔断限流 | 容错 | Sentinel / Hystrix / Resilience4j |
| 链路追踪 | 跨服务追踪 | SkyWalking / Zipkin |
| 消息队列 | 解耦 / 异步 | RabbitMQ / Kafka |
| 分布式事务 | 跨服务一致性 | Seata |

#### 1.3 SpringCloud Alibaba vs SpringCloud Netflix

| | Netflix（老一代） | Alibaba（推荐） |
| --- | --- | --- |
| 注册中心 | Eureka | Nacos |
| 配置中心 | Spring Cloud Config | Nacos |
| 熔断 | Hystrix（停更） | Sentinel |
| 网关 | Zuul / Gateway | Gateway |
| 国内主流 | ❌ | ⭐⭐⭐ |

**本周用 SpringCloud Alibaba 套件。**

**完全掌握标准：**
- ✅ 能解释微服务的优缺点
- ✅ 能解释为什么选 Alibaba 套件
- ✅ 能列出 5+ 微服务核心组件

---

### 2. 服务拆分原则（半天）

#### 2.1 按业务领域拆

**电商示例：**
- 用户服务（user-service）
- 商品服务（product-service）
- 订单服务（order-service）
- 支付服务（pay-service）
- 库存服务（stock-service）

#### 2.2 拆分原则

- **高内聚低耦合**
- **单一职责**：一个服务做一件事
- **数据库独立**：每个服务有自己的库（数据隔离）
- **API 网关统一入口**
- **避免循环依赖**

#### 2.3 反例

❌ 把 service 层分到一个微服务（按技术层拆，不是按业务）
❌ 微服务直接访问其他服务的数据库
❌ 一个微服务依赖另一个微服务的内部细节

**完全掌握标准：**
- ✅ 能为电商场景设计 5+ 个服务并说明拆分理由
- ✅ 能解释"每个服务一个数据库"的原因
- ✅ 能识别错误的拆分方式

---

### 3. Nacos 注册中心 + 配置中心（⭐重点 1 天）

#### 3.1 Nacos 是什么

阿里开源，一个工具实现：
- **注册中心**：服务上报、发现
- **配置中心**：集中配置管理

#### 3.2 安装

**推荐 Docker：**
```bash
docker run -d --name nacos \
  -p 8848:8848 -p 9848:9848 \
  -e MODE=standalone \
  nacos/nacos-server:v2.3.0
```

访问：`http://localhost:8848/nacos`（账号密码：nacos / nacos）

#### 3.3 服务注册

**依赖：**
```xml
<dependency>
    <groupId>com.alibaba.cloud</groupId>
    <artifactId>spring-cloud-starter-alibaba-nacos-discovery</artifactId>
</dependency>
```

**配置：**
```yaml
spring:
  application:
    name: user-service
  cloud:
    nacos:
      discovery:
        server-addr: localhost:8848
        namespace: dev          # 命名空间
        group: DEFAULT_GROUP
```

**启动后**：服务自动注册到 Nacos，控制台可见。

#### 3.4 服务发现 + 调用

**用 RestTemplate（不推荐，太底层）：**
```java
@Bean
@LoadBalanced
RestTemplate restTemplate() { return new RestTemplate(); }

// 用 application name 替代 IP
String url = "http://order-service/api/orders/" + id;
Order o = restTemplate.getForObject(url, Order.class);
```

**用 OpenFeign（推荐，后面讲）。**

#### 3.5 Nacos 配置中心

**依赖：**
```xml
<dependency>
    <groupId>com.alibaba.cloud</groupId>
    <artifactId>spring-cloud-starter-alibaba-nacos-config</artifactId>
</dependency>
```

**bootstrap.yml**（注意是 bootstrap 不是 application）：
```yaml
spring:
  application:
    name: user-service
  profiles:
    active: dev
  cloud:
    nacos:
      config:
        server-addr: localhost:8848
        file-extension: yaml
```

在 Nacos 控制台创建配置：`user-service-dev.yaml`

**动态刷新：**
```java
@RestController
@RefreshScope
public class ConfigController {
    @Value("${app.title}")
    private String title;
}
```

修改 Nacos 配置 → 应用无需重启即可生效。

#### 3.6 命名空间、分组、Data ID

- **命名空间（Namespace）**：环境隔离（dev/test/prod）
- **分组（Group）**：业务模块分组
- **Data ID**：`${应用名}-${profile}.${后缀}`

**完全掌握标准：**
- ✅ 能装好 Nacos 并注册一个服务
- ✅ 能在 Nacos 控制台看到服务
- ✅ 能配置 Nacos 配置中心并读取配置
- ✅ 能用 @RefreshScope 动态刷新
- ✅ 能解释命名空间、分组、Data ID 三者关系

---

### 4. OpenFeign 远程调用（⭐重点 半天）

#### 4.1 为什么用 Feign

- RestTemplate 写起来啰嗦
- Feign 用接口 + 注解，像调本地方法
- 集成负载均衡

#### 4.2 用法

**依赖：**
```xml
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-openfeign</artifactId>
</dependency>
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-loadbalancer</artifactId>
</dependency>
```

**启动类：**
```java
@SpringBootApplication
@EnableFeignClients
public class OrderApp { ... }
```

**定义 Feign 接口：**
```java
@FeignClient(name = "user-service", path = "/api/users")
public interface UserFeignClient {

    @GetMapping("/{id}")
    Result<User> getById(@PathVariable Long id);

    @PostMapping
    Result<User> create(@RequestBody UserDTO dto);
}
```

**使用：**
```java
@Service
@RequiredArgsConstructor
public class OrderService {
    private final UserFeignClient userFeignClient;

    public Order createOrder(Long userId) {
        Result<User> res = userFeignClient.getById(userId);
        // ...
    }
}
```

#### 4.3 配置

```yaml
feign:
  client:
    config:
      default:
        connect-timeout: 3000
        read-timeout: 5000
  compression:
    request:
      enabled: true
      mime-types: application/json
```

#### 4.4 异常降级（Fallback）

```java
@FeignClient(name = "user-service", fallback = UserFallback.class)
public interface UserFeignClient { ... }

@Component
public class UserFallback implements UserFeignClient {
    @Override
    public Result<User> getById(Long id) {
        return Result.error(500, "用户服务不可用");
    }
}
```

**完全掌握标准：**
- ✅ 能用 Feign 调用另一个服务
- ✅ 能配置超时
- ✅ 能写 fallback 降级
- ✅ 能解释 Feign 底层是 HTTP 客户端 + 动态代理

---

### 5. Spring Cloud Gateway（⭐重点 1 天）

#### 5.1 Gateway 是什么

- **微服务统一入口**
- 路由、鉴权、限流、日志
- 基于 Spring WebFlux（响应式，性能好）

#### 5.2 依赖

```xml
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-gateway</artifactId>
</dependency>
```

**注意：** Gateway 不能引入 spring-boot-starter-web（响应式冲突）。

#### 5.3 路由配置

```yaml
spring:
  cloud:
    gateway:
      routes:
        - id: user-service
          uri: lb://user-service                  # lb 表示用负载均衡
          predicates:
            - Path=/api/users/**
        - id: order-service
          uri: lb://order-service
          predicates:
            - Path=/api/orders/**
            - Method=GET,POST
          filters:
            - StripPrefix=0
```

#### 5.4 Predicate（断言）

| 断言 | 含义 |
| --- | --- |
| `Path=/api/users/**` | 路径匹配 |
| `Method=GET,POST` | HTTP 方法 |
| `Header=X-Request-Id, \d+` | 请求头 |
| `Query=token, .+` | 查询参数 |
| `After=2024-01-01...` | 时间之后 |
| `Host=*.example.com` | Host 匹配 |

#### 5.5 Filter（过滤器）

| Filter | 作用 |
| --- | --- |
| `StripPrefix=1` | 转发时去掉前缀（如 /api/users → /users） |
| `AddRequestHeader=X-User, abc` | 加请求头 |
| `RewritePath=/api/(?<segment>.*), /$\{segment}` | 重写路径 |
| `RequestRateLimiter` | 限流 |

#### 5.6 全局过滤器（鉴权）

```java
@Component
public class AuthFilter implements GlobalFilter, Ordered {
    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        ServerHttpRequest req = exchange.getRequest();
        String path = req.getURI().getPath();
        if (path.contains("/login") || path.contains("/register")) {
            return chain.filter(exchange);
        }
        String token = req.getHeaders().getFirst("Authorization");
        if (token == null) {
            exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
            return exchange.getResponse().setComplete();
        }
        try {
            Long userId = JwtUtil.parse(token.substring(7));
            ServerHttpRequest mutated = req.mutate()
                .header("X-User-Id", userId.toString())
                .build();
            return chain.filter(exchange.mutate().request(mutated).build());
        } catch (Exception e) {
            exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
            return exchange.getResponse().setComplete();
        }
    }

    @Override
    public int getOrder() { return -100; }
}
```

#### 5.7 跨域配置

```java
@Configuration
public class CorsConfig {
    @Bean
    public CorsWebFilter corsFilter() {
        CorsConfiguration cfg = new CorsConfiguration();
        cfg.addAllowedOriginPattern("*");
        cfg.addAllowedMethod("*");
        cfg.addAllowedHeader("*");
        cfg.setAllowCredentials(true);
        UrlBasedCorsConfigurationSource src = new UrlBasedCorsConfigurationSource();
        src.registerCorsConfiguration("/**", cfg);
        return new CorsWebFilter(src);
    }
}
```

**完全掌握标准：**
- ✅ 能用 Gateway 路由到不同服务
- ✅ 能配置 Path 断言 + StripPrefix 过滤器
- ✅ 能写全局过滤器实现鉴权
- ✅ 能配置跨域
- ✅ 能解释 Gateway 与 Zuul 区别（响应式 vs 阻塞）

---

### 6. Sentinel 限流熔断（⭐重点 1 天）

#### 6.1 Sentinel 是什么

阿里出的流量控制组件，包括：
- 限流
- 熔断降级
- 系统负载保护
- 实时监控

#### 6.2 安装控制台

```bash
docker run -d --name sentinel -p 8858:8858 \
  bladex/sentinel-dashboard
```
访问：`http://localhost:8858`（账号密码：sentinel / sentinel）

#### 6.3 接入服务

**依赖：**
```xml
<dependency>
    <groupId>com.alibaba.cloud</groupId>
    <artifactId>spring-cloud-starter-alibaba-sentinel</artifactId>
</dependency>
```

**配置：**
```yaml
spring:
  cloud:
    sentinel:
      transport:
        dashboard: localhost:8858
        port: 8719
```

#### 6.4 资源定义

```java
@SentinelResource(value = "getUser",
                   blockHandler = "blockGetUser",
                   fallback = "fallbackGetUser")
public User getUser(Long id) {
    return userMapper.selectById(id);
}

// 限流/熔断时调用
public User blockGetUser(Long id, BlockException ex) {
    return new User(0L, "降级用户");
}

// 业务异常时调用
public User fallbackGetUser(Long id, Throwable t) {
    return new User(0L, "出错了");
}
```

#### 6.5 控制台配置规则

- **流控规则**：QPS / 线程数限制
- **熔断规则**：慢调用比例 / 异常比例 / 异常数
- **热点规则**：基于参数限流
- **系统规则**：基于 CPU、Load 整体保护

#### 6.6 限流算法

- **计数器**：每秒计数（简单但有临界问题）
- **滑动窗口**：精确
- **漏桶**：匀速
- **令牌桶**：允许突发

Sentinel 默认滑动窗口。

**完全掌握标准：**
- ✅ 能装好 Sentinel 控制台
- ✅ 能用 @SentinelResource 加保护
- ✅ 能在控制台配置 QPS 限流
- ✅ 能写 blockHandler 和 fallback
- ✅ 能区分限流和熔断（限流：太多请求；熔断：依赖服务不稳定）

---

### 7. 微服务通用规范（半天）

#### 7.1 API 路径规范

- 网关层：`/api/{service}/...`
- StripPrefix 后到服务：`/...`

#### 7.2 跨服务传递用户信息

- 网关解析 JWT → 加请求头 `X-User-Id`
- 业务服务从请求头读
- 用拦截器 + ThreadLocal 存

#### 7.3 公共依赖管理

抽出 `common` 子模块：
- Result / BusinessException / Constants
- 工具类
- DTO（被多服务依赖的）

---

## 二、每日学习安排

| 天 | 学习内容 | 上机练习 | 时长 |
| --- | --- | --- | --- |
| **周一** | 微服务概念 + 服务拆分 + 安装 Nacos | 把上周项目拆成 user-service + product-service | 5h |
| **周二** | Nacos 注册中心 + 配置中心 ⭐ | 两服务注册到 Nacos + 动态配置刷新 | 6h |
| **周三** | OpenFeign 远程调用 ⭐ | order-service 调用 user-service | 5h |
| **周四** | Gateway 路由 + 断言 + 过滤器 ⭐ | 加网关统一入口 | 6h |
| **周五** | Gateway 鉴权 + 跨域 + JWT 解析 | 网关层鉴权 + 透传用户 ID | 6h |
| **周六** | Sentinel 限流熔断 ⭐ | 加限流 + 降级 | 6h |
| **周日** | 综合实战 + 复盘 | 完成微服务版项目雏形 + 提交 GitHub | 6h |

---

## 三、本周必做实战项目

### 项目：微服务版用户 + 商品 + 订单系统（雏形）

**模块：**
- `gateway`：统一入口，端口 8080
- `user-service`：用户服务，端口 8081
- `product-service`：商品服务，端口 8082
- `order-service`：订单服务，端口 8083
- `common`：公共依赖

**业务：**
- 用户登录（user-service 返回 JWT）
- 用户查商品（gateway → product-service）
- 用户下单（gateway → order-service → user-service 查用户 + product-service 查商品 + 减库存）

**技术要点：**
- ✅ Nacos 作为注册 + 配置中心
- ✅ Gateway 统一鉴权 + 透传用户 ID
- ✅ Feign 跨服务调用
- ✅ Sentinel 给关键接口加限流
- ✅ 每个服务独立数据库（user_db / product_db / order_db）

**验收：**
- ✅ Nacos 控制台看到 3 个服务
- ✅ 通过网关访问各服务都正常
- ✅ 跨服务调用成功
- ✅ Sentinel 控制台能看到流量
- ✅ 关掉一个服务不影响其他
- ✅ docker-compose 一键启动 Nacos + Sentinel

---

## 四、完全掌握检查清单

### 微服务理论
- [ ] 能解释微服务的优缺点
- [ ] 能为电商场景设计服务拆分
- [ ] 能列出 5+ 核心组件

### Nacos
- [ ] 能注册服务到 Nacos
- [ ] 能用 Nacos 配置中心
- [ ] 能用 @RefreshScope 动态刷新
- [ ] 能解释命名空间 / 分组 / Data ID

### Feign
- [ ] 能写 Feign 客户端接口
- [ ] 能配置超时
- [ ] 能写 fallback 降级

### Gateway
- [ ] 能配置路由 + Path 断言
- [ ] 能用 StripPrefix
- [ ] 能写全局过滤器鉴权
- [ ] 能配置跨域

### Sentinel
- [ ] 能装控制台 + 接入服务
- [ ] 能用 @SentinelResource
- [ ] 能配置 QPS 限流
- [ ] 能区分限流和熔断

### 综合
- [ ] 完成微服务项目并提交 GitHub
- [ ] docker-compose 能一键启动所有依赖

---

## 五、自测题

**Q1：** 为什么 Nacos 既能做注册中心又能做配置中心？
**答案：** 两者都需要"集中存储 + 通知客户端"的能力，Nacos 在底层共享这套机制（一致性 + 推送）。

---

**Q2：** Feign 调用底层用什么？
**答案：** 默认 HttpURLConnection，可换 OkHttp 或 Apache HttpClient。Feign 通过动态代理把接口方法变成 HTTP 调用。

---

**Q3：** Gateway 用了什么核心技术？
**答案：** **Spring WebFlux + Reactor**（响应式编程，非阻塞）。比 Zuul 1.x（阻塞）性能高。

---

**Q4：** 限流和熔断的区别？
**答案：**
- 限流：请求量超过阈值，拒绝部分请求（保护自己）
- 熔断：依赖服务不稳定时，快速失败不再调用（保护下游）

---

**Q5：** 微服务怎么传递用户身份？
**答案：**
- 网关解析 JWT
- 写入请求头 X-User-Id
- 下游用拦截器读取 + ThreadLocal 存

---

**Q6：** Nacos 集群部署用什么协议？
**答案：** Raft（强一致）+ Distro（AP 模式，最终一致）。

---

## 六、常见坑与误区

| 坑 | 描述 | 解决 |
| --- | --- | --- |
| Gateway 引入了 spring-boot-starter-web | 启动报错 | 移除 web 依赖 |
| Feign 调用 404 | 路径不一致 | 注意 path 配置 |
| Feign 不识别注解 | 需 spring-cloud-loadbalancer | 引入正确依赖 |
| bootstrap 不生效 | SpringBoot 2.4+ 需引入 spring-cloud-starter-bootstrap | 加依赖 |
| 配置不刷新 | 漏 @RefreshScope | 加注解 |
| 服务间循环依赖 | 部署难 | 设计时避免 |
| 数据库不隔离 | 微服务失去意义 | 每服务独立库 |
| Sentinel 规则丢失 | 控制台重启规则没了 | 用 Nacos 持久化规则 |

---

## 七、推荐学习资源

### 视频
- 【B站】黑马程序员 SpringCloud + RabbitMQ + Docker + Redis + 搜索 + 分布式
- 【B站】尚硅谷 SpringCloud Alibaba

### 书籍
- 《Spring Cloud Alibaba 微服务原理与实战》

### 官方
- [Nacos 文档](https://nacos.io/zh-cn/docs/v2/quickstart/quick-start.html)
- [Spring Cloud Gateway](https://docs.spring.io/spring-cloud-gateway/docs/current/reference/html/)
- [Sentinel](https://sentinelguard.io/zh-cn/)

---

## 八、本周完成后的"自我画像"

> "我能用 Nacos + Gateway + Feign + Sentinel 搭建一个微服务系统。
> 我懂服务拆分原则，能为电商场景设计 5 个服务。
> 我能用 Gateway 实现统一鉴权和跨域。
> 我能用 Feign 实现跨服务调用 + 降级。
> 我能用 Sentinel 给关键接口加限流。
> 我完成了微服务版项目雏形。"

---

## 九、下周预告

第 11 周：**MQ 消息队列**。
你将学会 RabbitMQ 实现异步解耦、削峰填谷、可靠投递。
配合微服务，业务能力大幅升级。

下周见！💪
