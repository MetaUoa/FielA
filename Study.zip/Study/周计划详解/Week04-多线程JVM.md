# 第 4 周：多线程 + JVM

> **本周学习目标**：突破"单线程思维"，掌握并发编程；理解 JVM 内存与垃圾回收。本周内容是初/中级工程师的分水岭，也是面试的重头戏。
>
> **本周关键词**：Thread、Runnable、synchronized、Lock、volatile、线程池、CompletableFuture、JMM、堆栈、GC、类加载
>
> **预计投入时间**：40~50 小时（本周最难，多花时间值得）

---

## 一、本周知识点详细分解

### 1. 进程与线程基础（半天）

**核心概念：**
- 进程：程序运行的实例，独立内存空间
- 线程：进程内的执行单元，共享进程内存
- 并发 vs 并行：
  - 并发（Concurrency）：多任务交替执行（单核也可以并发）
  - 并行（Parallelism）：多任务同时执行（必须多核）

**Java 线程的状态（6 种）：**
```
NEW（新建）→ RUNNABLE（就绪 + 运行）
        ↓
    BLOCKED（阻塞，等 synchronized）
    WAITING（等待，wait/join 无超时）
    TIMED_WAITING（限时等待，sleep/wait(time)）
        ↓
    TERMINATED（终止）
```

**完全掌握标准：**
- ✅ 能解释进程 vs 线程的区别
- ✅ 能解释并发 vs 并行
- ✅ 能画出线程状态转换图
- ✅ 能解释 BLOCKED 和 WAITING 的区别

---

### 2. 创建线程的 4 种方式（半天）

#### 方式 1：继承 Thread

```java
class MyThread extends Thread {
    @Override
    public void run() {
        System.out.println("线程 " + Thread.currentThread().getName());
    }
}
new MyThread().start();
```

#### 方式 2：实现 Runnable（推荐）

```java
Runnable r = () -> System.out.println("hello");
new Thread(r).start();
```

#### 方式 3：实现 Callable（有返回值）

```java
Callable<Integer> c = () -> 42;
FutureTask<Integer> ft = new FutureTask<>(c);
new Thread(ft).start();
Integer result = ft.get();   // 阻塞获取结果
```

#### 方式 4：线程池（生产推荐）

```java
ExecutorService pool = Executors.newFixedThreadPool(4);
pool.submit(() -> System.out.println("task"));
pool.shutdown();
```

**完全掌握标准：**
- ✅ 能写出 4 种创建线程的方式
- ✅ 能解释为什么推荐 Runnable 而不是继承 Thread（单继承限制 + 解耦）
- ✅ 能解释 `start()` vs `run()` 的区别（start 启动新线程，run 普通方法调用）
- ✅ 能解释 Callable 和 Runnable 的区别（返回值 + 异常）

---

### 3. 线程基本操作（半天）

| 方法 | 作用 |
| --- | --- |
| `Thread.sleep(ms)` | 当前线程睡眠 |
| `t.join()` | 等待 t 线程结束 |
| `t.interrupt()` | 中断 t 线程（设置中断标志） |
| `Thread.currentThread()` | 获取当前线程 |
| `t.setDaemon(true)` | 设置为守护线程 |
| `t.setPriority(int)` | 设置优先级 |
| `Thread.yield()` | 让出 CPU（不一定生效） |

**完全掌握标准：**
- ✅ 能用 join 实现"主线程等待所有子线程完成"
- ✅ 能解释守护线程（如 GC 线程，所有非守护线程结束就退出）
- ✅ 能解释为什么不能用 `Thread.stop()`（强制停止可能导致数据不一致）
- ✅ 能用 `interrupt` 优雅停止线程

---

### 4. 线程安全与同步（⭐⭐重难点，1.5 天）

#### 4.1 线程不安全的例子

```java
class Counter {
    int count = 0;
    public void inc() {
        count++;   // 非原子操作：读 + 加 + 写
    }
}
// 多线程同时调用 inc()，最终 count 不等于预期
```

#### 4.2 synchronized 用法

```java
// 同步方法
public synchronized void inc() { count++; }      // 锁 this

// 同步静态方法
public static synchronized void inc() { ... }   // 锁 Class 对象

// 同步代码块
public void inc() {
    synchronized (this) {           // 锁任意对象
        count++;
    }
}
```

**synchronized 底层原理：**
- 锁存储在对象头（Mark Word）
- JDK 6+ 锁升级：无锁 → 偏向锁 → 轻量级锁 → 重量级锁
- 重量级锁基于 Monitor（操作系统互斥量）

#### 4.3 volatile 关键字

**作用：**
1. **保证可见性**：写入立即对其他线程可见（绕过 CPU 缓存）
2. **禁止指令重排序**：内存屏障
3. **不保证原子性**：`count++` 用 volatile 也不安全

**经典用法：**
```java
class Singleton {
    private static volatile Singleton instance;
    public static Singleton getInstance() {
        if (instance == null) {
            synchronized (Singleton.class) {
                if (instance == null) {
                    instance = new Singleton();  // volatile 防止指令重排
                }
            }
        }
        return instance;
    }
}
```

#### 4.4 Lock（JUC）

```java
import java.util.concurrent.locks.ReentrantLock;

Lock lock = new ReentrantLock();
lock.lock();
try {
    // 临界区
} finally {
    lock.unlock();          // 必须在 finally 释放
}
```

**Lock vs synchronized：**

| | synchronized | Lock |
| --- | --- | --- |
| 释放 | 自动 | 手动（必须 finally） |
| 中断 | 不可中断 | `lockInterruptibly()` |
| 超时 | 不支持 | `tryLock(time)` |
| 公平锁 | 非公平 | 可配置 |
| 条件变量 | wait/notify（1 个） | `newCondition()`（多个） |
| 性能 | JDK 6+ 优化后接近 | 灵活 |

#### 4.5 wait / notify / notifyAll

```java
synchronized (obj) {
    while (!condition) {
        obj.wait();          // 释放锁并等待
    }
    // 做事
    obj.notifyAll();          // 唤醒所有等待者
}
```

**完全掌握标准：**
- ✅ 能写一个线程安全的 Counter
- ✅ 能解释 synchronized 的 3 种用法及锁的对象
- ✅ 能解释 volatile 的 2 个作用，能解释为什么不保证原子性
- ✅ 能写出双重检查单例（DCL）并解释为什么 volatile 必要
- ✅ 能用 ReentrantLock 替代 synchronized
- ✅ 能解释 wait/notify 必须在 synchronized 块内
- ✅ 能解释**死锁**的 4 个必要条件（互斥、占有等待、不可剥夺、循环等待）

---

### 5. 原子类 & CAS（半天）

#### 5.1 原子类（java.util.concurrent.atomic）

```java
AtomicInteger count = new AtomicInteger(0);
count.incrementAndGet();    // ++count
count.getAndIncrement();    // count++
count.compareAndSet(0, 1);  // CAS
```

#### 5.2 CAS 原理

- **CAS = Compare And Swap**
- 三个参数：内存地址 V、期望值 E、新值 N
- 如果 V == E，则把 V 改为 N，否则什么都不做
- 硬件支持的原子指令

**ABA 问题：**
- 线程 1 读到 A
- 线程 2 把 A 改成 B 又改回 A
- 线程 1 CAS 成功，但中间发生了变化
- 解决：`AtomicStampedReference` 加版本号

**完全掌握标准：**
- ✅ 能用 AtomicInteger 实现计数器
- ✅ 能解释 CAS 原理
- ✅ 能解释 ABA 问题及解决方案
- ✅ 能解释 CAS 自旋的代价（CPU 浪费）

---

### 6. 线程池（⭐⭐重点，1 天）

#### 6.1 为什么用线程池？

- 减少线程创建/销毁开销
- 控制最大并发数（防止资源耗尽）
- 统一管理（监控、调优）

#### 6.2 ThreadPoolExecutor 7 个核心参数

```java
new ThreadPoolExecutor(
    int corePoolSize,           // 核心线程数
    int maximumPoolSize,        // 最大线程数
    long keepAliveTime,         // 非核心线程空闲存活时间
    TimeUnit unit,              // 时间单位
    BlockingQueue<Runnable> workQueue,  // 任务队列
    ThreadFactory threadFactory,        // 线程工厂
    RejectedExecutionHandler handler    // 拒绝策略
);
```

#### 6.3 工作流程（⭐高频面试）

1. 任务来了，看核心线程是否满？没满 → 创建核心线程执行
2. 核心线程满 → 进入任务队列
3. 队列满 → 创建非核心线程（直到 max）
4. max 也满 → 触发拒绝策略

#### 6.4 拒绝策略（4 种）

- `AbortPolicy`（默认）：抛 RejectedExecutionException
- `CallerRunsPolicy`：调用者线程执行
- `DiscardPolicy`：直接丢弃
- `DiscardOldestPolicy`：丢弃队列最老的任务

#### 6.5 Executors 提供的线程池（不推荐用！）

| 线程池 | 配置 | 缺点 |
| --- | --- | --- |
| `newFixedThreadPool` | 固定线程数，无界队列 | OOM 风险 |
| `newSingleThreadExecutor` | 单线程，无界队列 | OOM 风险 |
| `newCachedThreadPool` | 0~Integer.MAX_VALUE | OOM 风险 |
| `newScheduledThreadPool` | 定时任务 | - |

**阿里巴巴规范：** 禁止用 Executors 创建线程池，必须手动用 `ThreadPoolExecutor`，原因就是上面的 OOM 风险。

#### 6.6 推荐配置

```java
ThreadPoolExecutor executor = new ThreadPoolExecutor(
    10, 20, 60, TimeUnit.SECONDS,
    new LinkedBlockingQueue<>(100),
    new ThreadFactoryBuilder().setNameFormat("biz-pool-%d").build(),
    new ThreadPoolExecutor.CallerRunsPolicy()
);
```

**线程数怎么定？**
- CPU 密集型：`N + 1`（N = CPU 核数）
- IO 密集型：`2N` 或更多

**完全掌握标准：**
- ✅ 能背出 7 大参数及作用
- ✅ 能讲清楚线程池工作流程
- ✅ 能列出 4 种拒绝策略
- ✅ 能解释为什么阿里禁止 Executors
- ✅ 能根据 CPU/IO 密集型选择线程数

---

### 7. CompletableFuture（半天）

#### 7.1 异步编程

```java
CompletableFuture<String> cf = CompletableFuture.supplyAsync(() -> {
    // 异步任务
    return "result";
});

cf.thenApply(s -> s.toUpperCase())          // 转换
  .thenAccept(System.out::println)           // 消费
  .exceptionally(e -> { e.printStackTrace(); return null; });
```

#### 7.2 组合操作

- `thenApply`：转换结果
- `thenAccept`：消费结果，无返回值
- `thenRun`：执行 Runnable
- `thenCombine`：合并两个 future 的结果
- `allOf` / `anyOf`：等所有/任一完成

**完全掌握标准：**
- ✅ 能用 CompletableFuture 异步调用 3 个接口并合并结果
- ✅ 能用 `allOf` 等所有完成
- ✅ 能处理异常（`exceptionally`）

---

### 8. 并发工具类（半天）

#### 8.1 CountDownLatch

```java
CountDownLatch latch = new CountDownLatch(3);
new Thread(() -> { /*...*/ latch.countDown(); }).start();
new Thread(() -> { /*...*/ latch.countDown(); }).start();
new Thread(() -> { /*...*/ latch.countDown(); }).start();
latch.await();  // 等所有线程完成
```

#### 8.2 CyclicBarrier

```java
CyclicBarrier barrier = new CyclicBarrier(3, () -> System.out.println("齐了"));
// 所有线程都 barrier.await() 后一起继续
```

#### 8.3 Semaphore（信号量，限流）

```java
Semaphore sem = new Semaphore(5);   // 最多 5 个并发
sem.acquire();
try {
    // 临界区
} finally {
    sem.release();
}
```

#### 8.4 ConcurrentHashMap

- 线程安全的 HashMap
- JDK 7：分段锁（Segment）
- JDK 8：CAS + synchronized 桶级锁

**完全掌握标准：**
- ✅ 能用 CountDownLatch 实现"等所有线程完成"
- ✅ 能用 Semaphore 实现限流
- ✅ 能解释 CountDownLatch vs CyclicBarrier
- ✅ 能用 ConcurrentHashMap 替代 HashMap 在多线程环境

---

### 9. JVM 内存模型（⭐⭐⭐，1 天）

#### 9.1 运行时数据区（JDK 8+）

```
线程私有：
├── 程序计数器（PC Register）  —— 当前指令地址
├── 虚拟机栈（VM Stack）        —— 方法栈帧（局部变量、操作数栈）
└── 本地方法栈（Native Stack）  —— native 方法

线程共享：
├── 堆（Heap）                  —— 对象 + 数组（GC 主战场）
│   ├── 新生代（Young）
│   │   ├── Eden
│   │   ├── Survivor 0
│   │   └── Survivor 1
│   └── 老年代（Old）
└── 方法区（Method Area / Metaspace）
    ├── 类信息
    ├── 常量池
    └── 静态变量
```

#### 9.2 各区域作用

| 区域 | 存什么 | 异常 |
| --- | --- | --- |
| 程序计数器 | 当前线程执行的字节码行号 | 不会 OOM |
| 虚拟机栈 | 方法的栈帧（局部变量、操作数栈） | StackOverflowError / OOM |
| 本地方法栈 | native 方法的栈帧 | 同上 |
| 堆 | 对象、数组 | OOM |
| 方法区 | 类信息、常量池、静态变量 | OOM |

**完全掌握标准：**
- ✅ 能画出 JVM 内存结构图
- ✅ 能解释每个区域的作用
- ✅ 能解释**为什么 JDK 8 把永久代换成 Metaspace**（永久代容易 OOM，Metaspace 用本地内存）
- ✅ 能区分**堆 vs 栈**：
  - 栈：方法、局部变量、引用
  - 堆：对象本体
- ✅ 能解释 `new Student()` 时各部分内存如何分配

---

### 10. 垃圾回收（GC，⭐⭐⭐，1 天）

#### 10.1 判断对象是否存活

**引用计数法**（不用）：循环引用问题
**可达性分析**（Java 用）：从 GC Roots 出发能否到达

**GC Roots 包括：**
- 虚拟机栈中引用的对象
- 方法区中静态变量引用的对象
- 方法区中常量引用的对象
- 本地方法栈引用的对象

#### 10.2 引用类型（4 种）

| 类型 | 说明 | 应用 |
| --- | --- | --- |
| 强引用 | `Object o = new Object()` | 永不回收 |
| 软引用 | `SoftReference` | 内存不足时回收（缓存） |
| 弱引用 | `WeakReference` | 下次 GC 就回收（ThreadLocal 内部） |
| 虚引用 | `PhantomReference` | 跟踪对象被回收（很少用） |

#### 10.3 GC 算法

- **标记-清除**：碎片多
- **标记-复制**：用于新生代（Eden + 2 个 Survivor）
- **标记-整理**：用于老年代

#### 10.4 分代收集

**新生代（Young）：** 大部分对象朝生夕灭，用复制算法
- Eden : S0 : S1 = 8 : 1 : 1
- 对象先在 Eden 分配
- Minor GC：Eden 满了触发，存活对象进 Survivor
- 经过 N 次 GC（默认 15）还活着 → 进老年代

**老年代（Old）：** 长期存活的对象，用标记-整理
- Major GC（Full GC）：清理老年代（更耗时）

#### 10.5 常见垃圾收集器

| 收集器 | 适用 | 算法 |
| --- | --- | --- |
| Serial | 单线程 | 复制/标记整理 |
| Parallel | 多线程，吞吐量优先 | 复制/标记整理 |
| CMS（已废弃） | 低延迟 | 标记清除（并发） |
| **G1**（JDK 9+ 默认） | 平衡 | Region 化分代 |
| **ZGC** / Shenandoah | 超低延迟 | 染色指针 |

**完全掌握标准：**
- ✅ 能解释可达性分析和 GC Roots
- ✅ 能解释新生代的 Eden/Survivor 比例和复制算法
- ✅ 能解释 Minor GC vs Major GC vs Full GC
- ✅ 能解释什么时候触发 Full GC（老年代满、Metaspace 满、System.gc()）
- ✅ 能背出 4 种引用类型
- ✅ 能解释 G1 收集器是什么（先了解，第 13 周深入）

---

### 11. 类加载机制（半天）

#### 11.1 类加载过程（7 个阶段）

```
加载 → 验证 → 准备 → 解析 → 初始化 → 使用 → 卸载
       ↑___链接___↑
```

- **加载**：把 class 文件读入内存
- **验证**：验证字节码合法性
- **准备**：为静态变量分配内存并赋默认值（0/null）
- **解析**：符号引用 → 直接引用
- **初始化**：执行静态代码块、给静态变量赋初值

#### 11.2 类加载器（3 层）

```
Bootstrap ClassLoader （加载 JDK 核心类）
       ↑ 父
Extension ClassLoader （JDK 9+ 改为 PlatformClassLoader）
       ↑ 父
Application ClassLoader （加载 classpath）
       ↑ 父
自定义 ClassLoader
```

#### 11.3 双亲委派模型

加载类时**先委派父加载器**加载，父加载不了才自己加载。

**为什么需要？**
- 防止核心类被篡改（自己写 `java.lang.String` 会被 Bootstrap 加载真正的 String）
- 避免重复加载

**完全掌握标准：**
- ✅ 能背出类加载 7 个阶段
- ✅ 能解释双亲委派模型及其作用
- ✅ 能解释什么时候会触发类加载（new、调用静态方法、反射等）

---

### 12. JVM 调优基础（半天，了解）

#### 12.1 常用参数

```
-Xms512m         初始堆大小
-Xmx1024m        最大堆大小
-Xmn256m         新生代大小
-XX:MetaspaceSize=128m
-XX:MaxMetaspaceSize=256m
-XX:+UseG1GC     使用 G1
-XX:+PrintGCDetails  打印 GC 日志
```

#### 12.2 工具

- **jps**：列出 Java 进程
- **jstat**：监控 GC
- **jmap**：导出堆 dump
- **jstack**：导出线程栈
- **jconsole / JVisualVM / Arthas**：图形化工具

**完全掌握标准：**
- ✅ 能用 `jps + jstat -gc` 查看 GC 情况
- ✅ 能用 `jstack` 抓死锁
- ✅ 能设置 -Xms / -Xmx

---

## 二、每日学习安排

| 天 | 学习内容 | 上机练习 | 时长 |
| --- | --- | --- | --- |
| **周一** | 线程基础 + 4 种创建方式 + 基本操作 | 4 种方式都写一遍 | 5h |
| **周二** | synchronized + volatile + 线程安全 | Counter 例子，对比有无同步 | 6h |
| **周三** | Lock + 死锁 + 原子类 + CAS | 写 ReentrantLock 版 Counter + 模拟死锁 | 6h |
| **周四** | 线程池 + CompletableFuture ⭐ | 自定义线程池 + 异步聚合接口 | 7h |
| **周五** | 并发工具类（CountDownLatch 等） | 用 CountDownLatch 实现批量任务等待 | 5h |
| **周六** | JVM 内存模型 + GC | 看 Visual GC 实时监控 | 6h |
| **周日** | 类加载 + JVM 调优 + 复盘 | 用 jstack 抓周三的死锁 + 提交 GitHub | 6h |

---

## 三、本周必做实战项目（2 个）

### 项目 1：自定义线程池 Demo

**需求：**
- 用 ThreadPoolExecutor 自定义线程池
- 提交 100 个任务，每个任务 sleep 1 秒
- 观察：
  - 核心线程数
  - 队列堆积
  - 是否触发拒绝策略
- 自定义 ThreadFactory（带命名前缀）
- 用 jstack 查看线程状态

**进阶：**
- 监控线程池：当前活跃数、队列大小、已完成任务数
- 优雅关闭（shutdown vs shutdownNow）

**验收标准：**
- ✅ 能看到 4 种核心线程数变化
- ✅ 能触发拒绝策略并捕获
- ✅ README 详细解释每个参数

### 项目 2：异步任务系统（模拟接口聚合）

**场景：** 一个用户主页接口，需要调用 3 个服务（用户信息、订单列表、推荐商品），每个服务模拟耗时 500ms。

**对比：**
- 串行：1500ms+
- 并行（CompletableFuture）：约 500ms

**需求：**
- 用 `CompletableFuture.allOf` 并发调用 3 个模拟服务
- 处理超时（`orTimeout`）
- 处理异常（`exceptionally`）
- 合并结果

**验收标准：**
- ✅ 总耗时接近最慢的那个（~500ms）
- ✅ 一个服务超时不影响其他
- ✅ README 含串行 vs 并行对比

---

## 四、完全掌握检查清单

### 线程基础
- [ ] 能画出线程状态转换图
- [ ] 能写出 4 种创建线程的方式
- [ ] 能用 join 等待线程完成
- [ ] 能用 interrupt 优雅停止线程

### 同步
- [ ] 能写出 3 种 synchronized 用法并说明锁的对象
- [ ] 能解释 volatile 的 2 个作用，知道不保证原子性
- [ ] 能写双重检查单例（DCL）
- [ ] 能用 ReentrantLock 实现互斥
- [ ] 能用代码模拟死锁并用 jstack 分析
- [ ] 能用 AtomicInteger 实现计数器
- [ ] 能解释 CAS 原理和 ABA 问题

### 线程池
- [ ] 能背出 7 大参数
- [ ] 能讲清工作流程
- [ ] 能列出 4 种拒绝策略
- [ ] 能解释为什么禁用 Executors

### 异步
- [ ] 能用 CompletableFuture 并发调用接口
- [ ] 能用 CountDownLatch 同步多个线程

### JVM
- [ ] 能画出 JVM 内存结构图
- [ ] 能解释堆 vs 栈
- [ ] 能解释 Eden/Survivor 比例和复制算法
- [ ] 能解释 GC Roots
- [ ] 能解释双亲委派
- [ ] 能列出 4 种引用类型

### 综合
- [ ] 完成 2 个项目并提交 GitHub
- [ ] 写一篇 JVM 总结笔记

---

## 五、自测题

**Q1：** 一个线程 OOM，其他线程会怎样？
**答案：** 其他线程能继续运行。OOM 是线程级别的错误，不会终止 JVM。但如果是 StackOverflowError 在主线程，可能影响应用。

---

**Q2：** synchronized 锁的是什么？
**答案：**
- 同步方法 → 锁 this
- 同步静态方法 → 锁 Class
- 同步代码块 → 锁括号里的对象

---

**Q3：** volatile 能保证原子性吗？
**答案：** 不能。比如 `count++` 是 3 步操作（读、加、写），volatile 只保证可见性。原子性要用 synchronized 或 AtomicInteger。

---

**Q4：** 下面代码会发生什么？
```java
class A {
    public synchronized void m1() {
        m2();
    }
    public synchronized void m2() {
        System.out.println("m2");
    }
}
```
**答案：** 正常执行。synchronized 是**可重入锁**，同一个线程可以多次获得同一把锁。

---

**Q5：** 线程池的核心线程数怎么设置？
**答案：**
- CPU 密集型：`Ncpu + 1`
- IO 密集型：`2 * Ncpu` 或更多
- 具体根据业务测试调整

---

**Q6：** 一个 ArrayList 100 万元素，会进哪个 GC 区域？
**答案：** 进堆。如果对象大（如大数组），可能直接进老年代（大对象阈值由 `-XX:PretenureSizeThreshold` 控制）。

---

**Q7：** 为什么静态变量不会被 GC？
**答案：** 静态变量是 GC Root，本身就不会被回收。但它引用的对象如果换了引用，原对象可被回收。

---

**Q8：** 下面代码输出什么？
```java
public class Main {
    static {
        System.out.println("static block");
    }
    public static void main(String[] args) {
        System.out.println("main");
    }
}
```
**答案：** `static block` / `main`。静态块在类初始化时执行，先于 main。

---

## 六、常见坑与误区

| 坑 | 描述 | 解决方案 |
| --- | --- | --- |
| 直接调 run() | 没有新线程 | 必须 start() |
| 锁错对象 | 没起到同步作用 | 静态方法锁 .class，实例方法锁 this |
| 锁字符串 | 字符串常量被多处共享 | 避免锁字符串 |
| HashMap 多线程 | 死循环（JDK 7） | 用 ConcurrentHashMap |
| stop() | 数据不一致 | 用 interrupt + 标志位 |
| 没有 finally 释放锁 | 死锁 | Lock 必须 finally unlock |
| Executors 创建线程池 | OOM | 手动 ThreadPoolExecutor |
| 主线程提前结束 | 子线程被强制结束 | 用 join 等待 |
| try 内捕获 InterruptedException 后不处理 | 中断信号丢失 | 重新调 interrupt() |

---

## 七、推荐学习资源

### 视频
- 【B站】尚硅谷 周阳 JUC 并发编程（约 30 小时）
- 【B站】黑马程序员 JVM 完整教程

### 书籍
- 《Java 并发编程的艺术》（必读⭐）
- 《深入理解 Java 虚拟机（第 3 版）》周志明（JVM 圣经）
- 《Effective Java》第 11 章（并发）

### 工具
- VisualVM（监控 JVM）
- [Arthas](https://arthas.aliyun.com/)（阿里出的诊断神器）

---

## 八、本周完成后的"自我画像"

> "我能写多线程程序，懂 synchronized、volatile、Lock 的区别。
> 我会用线程池，能根据 CPU/IO 类型配置线程数，知道为什么禁用 Executors。
> 我能用 CompletableFuture 异步聚合多接口调用。
> 我能画出 JVM 内存结构图，解释 GC 的分代收集和复制算法。
> 我开始能看懂面试中的并发题目了。"

---

## 九、下周预告

第 5 周进入 **MySQL**——后端工程师最重要的工具之一。
你将学会 SQL、索引、事务，并掌握 explain 慢查询优化。
本周的多线程知识也会用上（数据库连接池）。

下周见！💪
