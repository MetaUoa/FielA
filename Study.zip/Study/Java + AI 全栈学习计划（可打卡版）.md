
> 目标岗位：Java / AI 应用开发工程师
> 
> 技术方向：Java + SpringBoot + SpringCloud + React/Vue + Python + AI Agent
> 
> 学习周期：6~12 个月
> 
> 使用方式：完成后将 `[ ]` 修改为 `[x]`

---

# 第一阶段：Java 基础（第 1 ~ 4 周）

学习目标：

- 掌握 Java 核心语法
    
- 理解面向对象
    
- 能独立编写小型项目
    
- 为 SpringBoot 打基础
    

---

# 第 1 周：Java 入门

## 基础语法

-  安装 JDK
    
-  配置环境变量
    
-  安装 IntelliJ IDEA
    
-  学习 Java 程序结构
    
-  学习变量与数据类型
    
-  学习运算符
    
-  学习条件语句 if/else
    
-  学习 switch
    
-  学习 for / while 循环
    
-  学习数组
    

## 实战

-  实现学生成绩管理系统（控制台版）
    
-  实现简单计算器
    
-  实现猜数字游戏
    

## 推荐资料

-  阅读《Java 核心技术》第一章
    
-  阅读 Java 官方文档
    

---

# 第 2 周：面向对象

## OOP 核心

-  类与对象
    
-  构造方法
    
-  this / super
    
-  封装
    
-  继承
    
-  多态
    
-  抽象类
    
-  接口
    
-  static
    
-  final
    

## 实战

-  实现用户管理系统
    
-  实现图书管理系统
    

## 进阶

-  理解面向对象设计思想
    
-  学习 UML 类图
    

---

# 第 3 周：集合 + 异常 + IO

## 集合框架

-  ArrayList
    
-  LinkedList
    
-  HashMap
    
-  HashSet
    
-  TreeMap
    
-  Collections 工具类
    

## 异常处理

-  try-catch
    
-  throws
    
-  自定义异常
    

## IO/NIO

-  文件读写
    
-  BufferedReader
    
-  BufferedWriter
    
-  NIO 基础
    

## 实战

-  文件备份工具
    
-  日志分析工具
    

---

# 第 4 周：多线程 + JVM

## 多线程

-  Thread
    
-  Runnable
    
-  Callable
    
-  synchronized
    
-  Lock
    
-  volatile
    
-  线程池
    
-  CompletableFuture
    

## JVM

-  JVM 内存模型
    
-  堆与栈
    
-  GC 基础
    
-  类加载机制
    

## 实战

-  实现线程池 Demo
    
-  实现异步任务系统
    

---

# 第二阶段：数据库 + Redis（第 5 ~ 6 周）

学习目标：

- 掌握数据库设计
    
- 理解缓存机制
    
- 能解决常见高并发问题
    

---

# 第 5 周：MySQL

## SQL 基础

-  CRUD
    
-  where
    
-  order by
    
-  group by
    
-  join
    
-  子查询
    

## 高级部分

-  索引
    
-  explain
    
-  事务
    
-  MVCC
    
-  SQL 优化
    
-  慢查询分析
    

## 实战

-  设计电商数据库
    
-  完成用户订单表设计
    
-  编写复杂 SQL 查询
    

---

# 第 6 周：Redis

## Redis 基础

-  String
    
-  Hash
    
-  List
    
-  Set
    
-  ZSet
    

## 高级部分

-  缓存穿透
    
-  缓存击穿
    
-  缓存雪崩
    
-  Redis 持久化
    
-  Redis 分布式锁
    
-  Lua 脚本
    

## 实战

-  登录验证码缓存
    
-  秒杀库存扣减
    
-  热点数据缓存
    

---

# 第三阶段：SpringBoot（第 7 ~ 9 周）

学习目标：

- 能独立开发 RESTful API
    
- 掌握企业级开发规范
    

---

# 第 7 周：SpringBoot 核心

## Spring 基础

-  IOC
    
-  AOP
    
-  Bean 生命周期
    
-  自动装配
    

## SpringBoot

-  Starter
    
-  配置文件
    
-  日志
    
-  Web 开发
    

## 实战

-  实现 REST API
    
-  实现统一返回结构
    

---

# 第 8 周：数据库整合

## ORM

-  MyBatis
    
-  MyBatis Plus
    
-  JPA（了解）
    

## 企业开发

-  参数校验
    
-  全局异常处理
    
-  JWT 登录
    
-  Swagger/OpenAPI
    

## 实战

-  用户登录系统
    
-  权限管理系统
    

---

# 第 9 周：项目实战

## 项目要求

-  用户模块
    
-  登录模块
    
-  权限模块
    
-  文件上传
    
-  Redis 缓存
    
-  日志记录
    

## 项目目标

-  独立完成一个 SpringBoot 后端项目
    
-  上传 GitHub
    
-  编写 README
    

---

# 第四阶段：微服务 + MQ（第 10 ~ 13 周）

学习目标：

- 理解分布式系统
    
- 能开发微服务项目
    

---

# 第 10 周：SpringCloud

## 微服务基础

-  服务拆分
    
-  注册中心
    
-  配置中心
    
-  网关
    
-  OpenFeign
    

## 推荐组件

-  Nacos
    
-  Gateway
    
-  Sentinel
    

## 实战

-  拆分用户服务
    
-  拆分订单服务
    

---

# 第 11 周：MQ 消息队列

## RabbitMQ

-  Exchange
    
-  Queue
    
-  RoutingKey
    
-  Topic
    
-  ACK
    

## Kafka（了解）

-  Producer
    
-  Consumer
    
-  Partition
    

## 企业重点

-  消息可靠性
    
-  幂等性
    
-  死信队列
    
-  延迟消息
    

## 实战

-  异步下单
    
-  订单超时取消
    

---

# 第 12 周：Docker + Linux

## Linux

-  文件命令
    
-  网络命令
    
-  vim
    
-  shell
    

## Docker

-  Docker 基础
    
-  镜像
    
-  容器
    
-  Dockerfile
    
-  docker-compose
    

## 实战

-  部署 SpringBoot
    
-  部署 Redis
    
-  部署 MySQL
    

---

# 第 13 周：微服务项目实战

## 项目功能

-  用户系统
    
-  商品系统
    
-  订单系统
    
-  支付系统
    
-  Redis 缓存
    
-  MQ 消息队列
    

## 项目要求

-  Docker 化部署
    
-  Git 管理
    
-  API 文档
    

---

# 第五阶段：前端（第 14 ~ 16 周）

学习目标：

- 能完成后台管理系统
    
- 能与后端联调
    

---

# Vue 路线（推荐 Java 后端）

## Vue3

-  Vue 基础
    
-  Composition API
    
-  路由
    
-  Pinia
    
-  Axios
    
-  Element Plus
    

## 实战

-  管理后台
    
-  登录页面
    
-  用户管理页面
    

---

# React 路线（推荐 AI 应用）

## React

-  JSX
    
-  Hooks
    
-  useEffect
    
-  Zustand/Redux
    
-  React Router
    
-  Ant Design
    

## 实战

-  AI Chat 页面
    
-  Markdown 渲染
    
-  文件上传
    

---

# 第六阶段：Python + AI（第 17 ~ 20 周）

学习目标：

- 能接入大模型
    
- 能开发 AI Agent
    
- 能做 AI 应用项目
    

---

# 第 17 周：Python 基础

## Python

-  语法基础
    
-  函数
    
-  类与对象
    
-  requests
    
-  asyncio
    

## FastAPI

-  API 开发
    
-  路由
    
-  中间件
    
-  异步接口
    

## 实战

-  Python REST API
    
-  文件解析服务
    

---

# 第 18 周：LLM 基础

## 必学概念

-  Token
    
-  Prompt Engineering
    
-  Function Calling
    
-  Embedding
    
-  RAG
    
-  MCP
    
-  Agent
    

## API 接入

-  OpenAI API
    
-  流式输出
    
-  多轮对话
    

## 实战

-  AI 聊天机器人
    
-  流式聊天页面
    

---

# 第 19 周：AI 框架

## LangChain

-  PromptTemplate
    
-  Memory
    
-  Tool
    
-  Agent
    

## LangGraph

-  StateGraph
    
-  Workflow
    
-  多 Agent
    

## Spring AI

-  ChatClient
    
-  RAG
    
-  MCP
    

## 实战

-  AI 文档问答系统
    
-  AI SQL Agent
    

---

# 第 20 周：AI 项目实战

## 项目推荐

### AI 知识库

-  文档上传
    
-  向量检索
    
-  AI 问答
    
-  历史记录
    

### Agent 系统

-  自动日报
    
-  自动代码审查
    
-  AI 客服
    

## 项目目标

-  GitHub 开源
    
-  编写项目文档
    
-  完成部署
    

---

# 第七阶段：算法 + 面试（长期）

学习目标：

- 提升面试能力
    
- 提升代码能力
    

---

# 算法

## 基础

-  数组
    
-  链表
    
-  栈
    
-  队列
    
-  哈希表
    

## 中级

-  二叉树
    
-  DFS/BFS
    
-  回溯
    
-  动态规划
    

## 刷题

-  LeetCode 100 题
    
-  热门面试题
    

---

# 八股文

## Java

-  HashMap
    
-  ConcurrentHashMap
    
-  JVM
    
-  GC
    
-  线程池
    

## Spring

-  IOC
    
-  AOP
    
-  Spring 生命周期
    

## 微服务

-  分布式事务
    
-  限流
    
-  熔断
    
-  MQ 可靠性
    

## Redis

-  Redis 为什么快
    
-  Redis 持久化
    
-  缓存一致性
    

## AI

-  RAG 原理
    
-  Agent 工作流
    
-  Prompt 注入
    
-  MCP
    

---

# 最终项目目标

## 至少完成以下项目

### Java 项目

-  SpringBoot 管理系统
    
-  微服务商城
    

### AI 项目

-  AI 知识库
    
-  AI Agent 系统
    

### 前端项目

-  React/Vue 管理后台
    
-  AI Chat UI
    

---

# GitHub 目标

-  每周至少提交 3 次代码
    
-  所有项目写 README
    
-  所有项目附带截图
    
-  学习笔记同步 GitHub
    

---

# 学习习惯

## 每日

-  学习 4~6 小时
    
-  写代码 2 小时以上
    
-  阅读技术文档
    
-  记录学习笔记
    

## 每周

-  完成一个小功能
    
-  总结问题
    
-  优化项目
    

---

# 推荐资源

## Java

- [https://docs.oracle.com/en/java/](https://docs.oracle.com/en/java/)
    
- [https://spring.io/projects/spring-boot](https://spring.io/projects/spring-boot)
    

## 前端

- [https://react.dev/](https://react.dev/)
    
- [https://cn.vuejs.org/](https://cn.vuejs.org/)
    

## AI

- [https://www.langchain.com/](https://www.langchain.com/)
    
- [https://spring.io/projects/spring-ai](https://spring.io/projects/spring-ai)
    
- [https://platform.openai.com/docs](https://platform.openai.com/docs)
    

---

# 学习完成标准

## 初级

-  能独立开发 SpringBoot 项目
    
-  能完成 CRUD 系统
    

## 中级

-  能完成微服务项目
    
-  能处理高并发问题
    
-  能独立部署系统
    

## AI 应用工程师

-  能接入大模型
    
-  能开发 RAG 系统
    
-  能开发 AI Agent
    
-  能将 AI 落地业务
    

---

# 最终目标

-  拥有 3~5 个完整项目
    
-  GitHub 有持续提交记录
    
-  能独立开发 AI 应用
    
-  达到中高级 Java/AI 工程师水平