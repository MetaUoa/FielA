﻿$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$Utf8Strict = New-Object -TypeName System.Text.UTF8Encoding -ArgumentList @($false, $true)

function Read-Utf8Text([string]$Path) { return [System.IO.File]::ReadAllText($Path, $script:Utf8Strict) }
function Test-PathWithin([string]$Path, [string]$RootPath) {
    $fullPath = [System.IO.Path]::GetFullPath($Path).TrimEnd([char[]]@('\','/'))
    $fullRoot = [System.IO.Path]::GetFullPath($RootPath).TrimEnd([char[]]@('\','/'))
    if ($fullPath.Equals($fullRoot, [System.StringComparison]::OrdinalIgnoreCase)) { return $true }
    return $fullPath.StartsWith($fullRoot + [System.IO.Path]::DirectorySeparatorChar, [System.StringComparison]::OrdinalIgnoreCase)
}
function Get-SafeChildPath([string]$RootPath, [string]$Relative) {
    $normalized = $Relative.Replace('/', '\')
    if ([System.IO.Path]::IsPathRooted($normalized) -or $normalized.Contains(':')) { throw "不安全清单路径：$Relative" }
    foreach ($segment in $normalized.Split([char[]]@('\'), [System.StringSplitOptions]::RemoveEmptyEntries)) {
        if ($segment -eq '.' -or $segment -eq '..') { throw "不安全清单路径：$Relative" }
    }
    $candidate = [System.IO.Path]::GetFullPath((Join-Path $RootPath $normalized))
    if (-not (Test-PathWithin $candidate $RootPath)) { throw "清单路径越界：$Relative" }
    return $candidate
}

$Version = (Read-Utf8Text (Join-Path $Root 'VERSION.txt')).Trim()
$ManifestPath = Join-Path $Root 'PACKAGE_MANIFEST.json'
$ManifestRaw = Read-Utf8Text $ManifestPath
$Manifest = $ManifestRaw | ConvertFrom-Json
if ([string]$Manifest.version -ne $Version) { throw 'VERSION.txt 与 PACKAGE_MANIFEST.json 版本不一致。' }

$TextExtensions = @('.md','.ps1','.cmd','.json','.txt')
$ControlPattern = '[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]'
if ([regex]::IsMatch($ManifestRaw, $ControlPattern)) { throw 'PACKAGE_MANIFEST.json 包含异常 C0 控制字符。' }
$ManifestSet = @{}
foreach ($entry in $Manifest.files) {
    $relative = ([string]$entry.path).Replace('\','/')
    $ManifestSet[$relative.ToLowerInvariant()] = $true
    $Path = Get-SafeChildPath $Root $relative
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { throw "缺少：$relative" }
    $Hash = (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($Hash -ne ([string]$entry.sha256).ToLowerInvariant()) { throw "哈希不一致：$relative" }
    if ((Get-Item -LiteralPath $Path -Force).Length -ne [int64]$entry.bytes) { throw "大小不一致：$relative" }
    if ($TextExtensions -contains [System.IO.Path]::GetExtension($Path).ToLowerInvariant()) {
        $rawText = Read-Utf8Text $Path
        if ([regex]::IsMatch($rawText, $ControlPattern)) { throw "文本文件包含异常 C0 控制字符：$relative" }
    }
}

foreach ($file in @(Get-ChildItem -LiteralPath (Join-Path $Root 'skills') -File -Recurse -Force)) {
    $relative = $file.FullName.Substring($Root.Length).TrimStart([char[]]@('\','/')).Replace('\','/')
    if (-not $ManifestSet.ContainsKey($relative.ToLowerInvariant())) { throw "Skills 目录含未登记文件：$relative" }
}

$PlatformRoot = Join-Path $Root 'platform'
$Refs = @(Get-ChildItem -LiteralPath $PlatformRoot -File -Recurse | Select-String -SimpleMatch '~/.agent-global' -ErrorAction SilentlyContinue)
if ($Refs.Count -gt 0) { throw '平台运行规则仍包含 ~/.agent-global 引用。' }

$ClaudePath = Join-Path $Root 'platform\claude\CLAUDE.md'
if (Select-String -LiteralPath $ClaudePath -SimpleMatch '~/.agents/skills' -Quiet) { throw 'Claude 平台规则仍引用非原生 ~/.agents/skills。' }
if (-not (Select-String -LiteralPath $ClaudePath -SimpleMatch '~/.claude/skills/' -Quiet)) { throw 'Claude 平台规则缺少原生 ~/.claude/skills/ 路径说明。' }

$PlatformFiles = @(
    (Join-Path $Root 'platform\pi\AGENTS.md'),
    (Join-Path $Root 'platform\codex\AGENTS.md'),
    (Join-Path $Root 'platform\claude\CLAUDE.md')
)
foreach ($file in $PlatformFiles) {
    $lineCount = (Get-Content -LiteralPath $file -Encoding UTF8).Count
    if ($lineCount -gt 125) { throw "平台全局规则过长（$lineCount 行）：$file" }
    if (Select-String -LiteralPath $file -SimpleMatch 'agentkit-debug-root-cause' -Quiet) { throw "平台规则不应重复内嵌 Skill 路由表：$file" }
}

$InstallPath = Join-Path $Root 'install.ps1'
$InstallRaw = Read-Utf8Text $InstallPath
if ($InstallRaw -match '\$Targets|ValidateSet\(|SkipIntegrityCheck') { throw '安装器不应保留 partial install / SkipIntegrityCheck 分支。' }
if ($InstallRaw -match '\$(?:script:)?KitVersion\s*=\s*["'']') { throw 'install.ps1 不应硬编码版本号，应读取 VERSION.txt。' }
foreach ($needle in @('Read-Utf8Text','Assert-ManagedMarkers','Get-SafeChildPath','Rollback-CurrentRun','finally')) {
    if ($InstallRaw -notmatch [regex]::Escape($needle)) { throw "install.ps1 缺少加固机制：$needle" }
}

$VerifyRaw = Read-Utf8Text (Join-Path $Root 'verify.ps1')
if ($VerifyRaw -match '\$(?:script:)?KitVersion\s*=\s*["'']') { throw 'verify.ps1 不应硬编码版本号，应读取 VERSION.txt。' }
if ($VerifyRaw -notmatch '备份指针范围') { throw 'verify.ps1 缺少备份指针范围校验。' }

$RestoreRaw = Read-Utf8Text (Join-Path $Root 'restore-latest.ps1')
foreach ($needle in @('restore-safety','Test-PathWithin $BackupRoot $BackupsRoot','Rollback-RestoreAttempt','finally')) {
    if ($RestoreRaw -notmatch [regex]::Escape($needle)) { throw "restore-latest.ps1 缺少事务/范围保护：$needle" }
}
if ($RestoreRaw -match 'Move-Item\s+-LiteralPath\s+\$backup\s+-Destination\s+\$target') { throw 'restore-latest.ps1 不应消耗原备份进行一次性恢复。' }

$PiTaskPath = Join-Path $Root 'platform\pi\prompts\agentkit-task.md'
$PiTaskRaw = Read-Utf8Text $PiTaskPath
if ($PiTaskRaw -match '\{\{[^}]+\}\}') { throw 'Pi task prompt 仍包含不支持的 Mustache 占位符。' }
if ($PiTaskRaw -notmatch '\$ARGUMENTS') { throw 'Pi task prompt 必须使用 $ARGUMENTS。' }

$PiPlatform = Read-Utf8Text (Join-Path $Root 'platform\pi\AGENTS.md')
$CodexPlatform = Read-Utf8Text (Join-Path $Root 'platform\codex\AGENTS.md')
$ClaudePlatform = Read-Utf8Text (Join-Path $Root 'platform\claude\CLAUDE.md')
if ($PiPlatform -notmatch '项目级 `AGENTS\.md` / `CLAUDE\.md`') { throw 'Pi 项目规则入口描述不正确。' }
if ($CodexPlatform -notmatch '项目级 `AGENTS\.md` / `AGENTS\.override\.md`') { throw 'Codex 项目规则入口描述不正确。' }
if ($ClaudePlatform -notmatch '项目级 `CLAUDE\.md` / `\.claude/rules/`') { throw 'Claude 项目规则入口描述不正确。' }

$SkillFiles = @(Get-ChildItem -LiteralPath (Join-Path $Root 'skills') -Filter 'SKILL.md' -File -Recurse)
foreach ($skillFile in $SkillFiles) {
    $raw = Read-Utf8Text $skillFile.FullName
    $name = [regex]::Match($raw, '(?m)^name:\s*(.+)$').Groups[1].Value.Trim()
    $desc = [regex]::Match($raw, '(?m)^description:\s*(.+)$').Groups[1].Value.Trim()
    if ([string]::IsNullOrWhiteSpace($name) -or [string]::IsNullOrWhiteSpace($desc)) { throw "Skill 缺少 name/description：$($skillFile.FullName)" }
    if ($desc.Length -gt 90) { throw "Skill description 过长（$($desc.Length)）：$name" }
}

foreach ($name in @('install-all.cmd','verify.cmd','restore-latest.cmd')) {
    $path = Join-Path $Root $name
    $bytes = [System.IO.File]::ReadAllBytes($path)
    foreach ($b in $bytes) { if ($b -gt 127) { throw "CMD 不是纯 ASCII：$name" } }
    for ($i = 0; $i -lt $bytes.Length; $i++) {
        if ($bytes[$i] -eq 10 -and ($i -eq 0 -or $bytes[$i-1] -ne 13)) { throw "CMD 存在非 CRLF 换行：$name" }
    }
    $cmd = [System.Text.Encoding]::ASCII.GetString($bytes)
    if ($cmd -notmatch '%SystemRoot%\\System32\\WindowsPowerShell\\v1\.0\\powershell\.exe') { throw "CMD 未固定系统 Windows PowerShell：$name" }
    if ($cmd -notmatch 'chcp 65001') { throw "CMD 未切换 UTF-8 code page：$name" }
    if ($cmd -notmatch 'AGENTKIT_NO_PAUSE') { throw "CMD 缺少可选 no-pause：$name" }
}

foreach ($name in @('install.ps1','verify.ps1','restore-latest.ps1','scripts\check-package.ps1')) {
    $path = Join-Path $Root $name
    $bytes = [System.IO.File]::ReadAllBytes($path)
    if ($bytes.Length -lt 3 -or $bytes[0] -ne 0xEF -or $bytes[1] -ne 0xBB -or $bytes[2] -ne 0xBF) { throw "PowerShell 脚本缺少 UTF-8 BOM：$name" }
    for ($i = 0; $i -lt $bytes.Length; $i++) {
        if ($bytes[$i] -eq 10 -and ($i -eq 0 -or $bytes[$i-1] -ne 13)) { throw "PowerShell 脚本存在非 CRLF 换行：$name" }
    }
}

Write-Host ("包自检通过：{0} 的治理正文未扩张，Windows 安装/验证/恢复脚本加固、原生路径、窄 Skill、渐进披露与完整性检查均符合要求。" -f $Version) -ForegroundColor Green
