﻿$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = New-Object -TypeName System.Text.UTF8Encoding -ArgumentList $false } catch {}

$SourceRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$HomeDir = [Environment]::GetFolderPath('UserProfile')
$LocalAppData = [Environment]::GetFolderPath('LocalApplicationData')
if ([string]::IsNullOrWhiteSpace($LocalAppData)) { $LocalAppData = Join-Path $HomeDir 'AppData\Local' }
$KitDataRoot = Join-Path $LocalAppData 'AgentKit'
$BackupsRoot = Join-Path $KitDataRoot 'backups'
$BeginMarker = '<!-- AGENTKIT:BEGIN -->'
$EndMarker = '<!-- AGENTKIT:END -->'
$Utf8Strict = New-Object -TypeName System.Text.UTF8Encoding -ArgumentList @($false, $true)
$Stamp = Get-Date -Format 'yyyyMMdd-HHmmss-fff'
$RunId = [guid]::NewGuid().ToString('N').Substring(0,8)
$BackupRoot = Join-Path $KitDataRoot ('backups\' + $Stamp + '-' + $PID + '-' + $RunId)
$ManifestPath = Join-Path $BackupRoot 'manifest.json'
$Pointer = Join-Path $KitDataRoot 'last-backup.txt'
$StatePath = Join-Path $KitDataRoot 'state.json'
$LegacyCanonicalRoot = Join-Path $HomeDir '.agent-global'
$LegacyPointer = Join-Path $HomeDir '.agent-global-last-backup.txt'
$LegacyBackupsRoot = Join-Path $HomeDir '.agent-global-backups'
$LegacyArchiveRoot = Join-Path $KitDataRoot 'legacy-v2-backups'
$script:ManifestEntries = @()
$script:Committed = $false
$script:FailureMessage = ''
$PointerExisted = $false
$PreviousPointer = ''

$KitSkills = @(
    'agentkit-debug-root-cause',
    'agentkit-test-verification',
    'agentkit-safe-refactor',
    'agentkit-dependency-upgrade',
    'agentkit-git-change-hygiene',
    'agentkit-schema-migration',
    'agentkit-release-readiness'
)

$LegacySkillHashes = @{
    'debug-root-cause' = '89ed197fe8fbd56eb36bcf48ab4621aaaf1de4bc73b2174d6bf02f6371fdce19'
    'test-verification' = '8f21d9aff20e58d0d6c65aef5bfd9e58113af76b8add30f61cc8d5cc2ec228ba'
    'safe-refactor' = '2d0abd056db8ed5c7caf2b14e10b36650627709ec5c2671ed94053ecf03e5bd0'
    'dependency-upgrade' = '8a86837c07a7c319b6c5a55e835a3757e88f1f58afcbe4df625694c1249b37c1'
    'git-change-hygiene' = '9602b2bf597874209ae940613cdaa7a3c4dfee20401ac6dded14cd6602c5ec69'
    'schema-migration' = '6351eebcaacfb32eff5fc2f4563cca08d04bcc12460bad460cc630bae0f3f5a8'
    'release-readiness' = '7b94fbf17bc67539ae515db34a848664f39f2361b3b2732d081f039ee1083e8b'
}

$LegacyManagedHashes = @{
    Pi = @('1b346a0b33e06a5a3814c9816dfb5bcef72e2ff7b74ce7fe0803188e1618ed9d')
    Codex = @('47b68a4d587f36937ee4916da1c8b0282a51736fa2253bce89fc3d5d75fc67b3')
    Claude = @('dd123cabfcc19e80b5c394387b276c185e31d42c22543902f0dbc54c85d14f29')
}

function Read-Utf8Text([string]$Path) {
    return [System.IO.File]::ReadAllText($Path, $script:Utf8Strict)
}

function Ensure-Dir([string]$Path) {
    if ([string]::IsNullOrWhiteSpace($Path)) { return }
    if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function Test-PathWithin([string]$Path, [string]$Root) {
    $fullPath = [System.IO.Path]::GetFullPath($Path).TrimEnd([char[]]@('\','/'))
    $fullRoot = [System.IO.Path]::GetFullPath($Root).TrimEnd([char[]]@('\','/'))
    if ($fullPath.Equals($fullRoot, [System.StringComparison]::OrdinalIgnoreCase)) { return $true }
    $prefix = $fullRoot + [System.IO.Path]::DirectorySeparatorChar
    return $fullPath.StartsWith($prefix, [System.StringComparison]::OrdinalIgnoreCase)
}

function Get-SafeChildPath([string]$Root, [string]$Relative, [string]$Label) {
    if ([string]::IsNullOrWhiteSpace($Relative)) { throw "$Label 路径为空。" }
    $normalized = $Relative.Replace('/', '\')
    if ([System.IO.Path]::IsPathRooted($normalized) -or $normalized.Contains(':')) { throw "$Label 不能是绝对路径：$Relative" }
    foreach ($segment in $normalized.Split([char[]]@('\'), [System.StringSplitOptions]::RemoveEmptyEntries)) {
        if ($segment -eq '.' -or $segment -eq '..') { throw "$Label 包含不安全路径段：$Relative" }
    }
    $candidate = [System.IO.Path]::GetFullPath((Join-Path $Root $normalized))
    if (-not (Test-PathWithin $candidate $Root)) { throw "$Label 越出允许目录：$Relative" }
    return $candidate
}

function Test-IsReparsePoint([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) { return $false }
    $item = Get-Item -LiteralPath $Path -Force
    return (($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0)
}

function Assert-NoReparseTree([string]$Path, [string]$Label) {
    if (-not (Test-Path -LiteralPath $Path)) { return }
    if (Test-IsReparsePoint $Path) { throw "$Label 是符号链接/junction/reparse point，安装器拒绝自动修改：$Path" }
    if (-not (Test-Path -LiteralPath $Path -PathType Container)) { return }
    $stack = New-Object System.Collections.Stack
    $stack.Push($Path)
    while ($stack.Count -gt 0) {
        $current = [string]$stack.Pop()
        foreach ($child in @(Get-ChildItem -LiteralPath $current -Force)) {
            if (($child.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
                throw "$Label 内含符号链接/junction/reparse point，安装器拒绝递归处理：$($child.FullName)"
            }
            if ($child.PSIsContainer) { $stack.Push($child.FullName) }
        }
    }
}

function Write-Utf8NoBomAtomic([string]$Path, [string]$Text) {
    $parent = Split-Path -Parent $Path
    Ensure-Dir $parent
    if (Test-Path -LiteralPath $Path -PathType Container) { throw "目标应为文件但实际是目录：$Path" }
    if (Test-Path -LiteralPath $Path) { Assert-NoReparseTree $Path '目标文件' }
    $tmp = Join-Path $parent ('.agentkit-' + [guid]::NewGuid().ToString('N') + '.tmp')
    try {
        [System.IO.File]::WriteAllText($tmp, $Text, $script:Utf8Strict)
        if (Test-Path -LiteralPath $Path) { Remove-Item -LiteralPath $Path -Force }
        Move-Item -LiteralPath $tmp -Destination $Path -Force
    } finally {
        if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue }
    }
}

function Copy-PathExact([string]$Source, [string]$Destination) {
    if (-not (Test-Path -LiteralPath $Source)) { throw "复制源不存在：$Source" }
    Assert-NoReparseTree $Source '复制源'
    if (Test-Path -LiteralPath $Destination) { throw "精确复制目标必须不存在：$Destination" }
    if (Test-Path -LiteralPath $Source -PathType Leaf) {
        Ensure-Dir (Split-Path -Parent $Destination)
        Copy-Item -LiteralPath $Source -Destination $Destination -Force
        return
    }
    Ensure-Dir $Destination
    foreach ($child in @(Get-ChildItem -LiteralPath $Source -Force)) {
        Copy-Item -LiteralPath $child.FullName -Destination $Destination -Recurse -Force
    }
}

function Save-Manifest {
    Ensure-Dir $BackupRoot
    $json = ConvertTo-Json -InputObject @($script:ManifestEntries) -Depth 8
    Write-Utf8NoBomAtomic $ManifestPath $json
}

function Assert-ManagedMarkers([string]$Text, [string]$Path) {
    $beginCount = [regex]::Matches($Text, [regex]::Escape($BeginMarker)).Count
    $endCount = [regex]::Matches($Text, [regex]::Escape($EndMarker)).Count
    if ($beginCount -eq 0 -and $endCount -eq 0) { return }
    if ($beginCount -ne 1 -or $endCount -ne 1) { throw "托管标记不成对或重复，拒绝自动写入：$Path" }
    if ($Text.IndexOf($BeginMarker, [System.StringComparison]::Ordinal) -gt $Text.IndexOf($EndMarker, [System.StringComparison]::Ordinal)) {
        throw "托管标记顺序异常，拒绝自动写入：$Path"
    }
}

function Test-ScriptCompatibility {
    if ($PSVersionTable.PSVersion.Major -lt 5) { throw '需要 Windows PowerShell 5.1 或更高版本。' }
    $psFiles = @(
        (Join-Path $SourceRoot 'install.ps1'),
        (Join-Path $SourceRoot 'verify.ps1'),
        (Join-Path $SourceRoot 'restore-latest.ps1'),
        (Join-Path $SourceRoot 'scripts\check-package.ps1')
    )
    foreach ($path in $psFiles) {
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "脚本预检失败，缺少：$path" }
        $tokens = $null
        $errors = $null
        [void][System.Management.Automation.Language.Parser]::ParseFile($path, [ref]$tokens, [ref]$errors)
        if ($errors.Count -gt 0) {
            $detail = ($errors | ForEach-Object { $_.Message }) -join '; '
            throw "PowerShell 语法预检失败：$path - $detail"
        }
    }
    foreach ($name in @('install-all.cmd','verify.cmd','restore-latest.cmd')) {
        $path = Join-Path $SourceRoot $name
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "脚本预检失败，缺少：$path" }
        $bytes = [System.IO.File]::ReadAllBytes($path)
        foreach ($b in $bytes) { if ($b -gt 127) { throw "CMD 兼容性预检失败，包含非 ASCII 字节：$name" } }
        for ($i = 0; $i -lt $bytes.Length; $i++) {
            if ($bytes[$i] -eq 10 -and ($i -eq 0 -or $bytes[$i - 1] -ne 13)) { throw "CMD 兼容性预检失败，存在非 CRLF 换行：$name" }
        }
    }
    Write-Host '脚本兼容性预检：通过' -ForegroundColor Green
}

function Test-PackageIntegrity {
    $versionPath = Join-Path $SourceRoot 'VERSION.txt'
    if (-not (Test-Path -LiteralPath $versionPath -PathType Leaf)) { throw "缺少版本文件：$versionPath" }
    $script:KitVersion = (Read-Utf8Text $versionPath).Trim()
    if ([string]::IsNullOrWhiteSpace($script:KitVersion)) { throw 'VERSION.txt 为空。' }

    $packageManifest = Join-Path $SourceRoot 'PACKAGE_MANIFEST.json'
    if (-not (Test-Path -LiteralPath $packageManifest -PathType Leaf)) { throw "缺少包清单：$packageManifest" }
    $manifestRaw = Read-Utf8Text $packageManifest
    $data = $manifestRaw | ConvertFrom-Json
    if ([string]$data.version -ne $script:KitVersion) { throw "包版本不一致：清单=$($data.version)，VERSION=$($script:KitVersion)" }

    $manifestSet = @{}
    $textExtensions = @('.md','.ps1','.cmd','.json','.txt')
    $controlPattern = '[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]'
    if ([regex]::IsMatch($manifestRaw, $controlPattern)) { throw 'PACKAGE_MANIFEST.json 含异常 C0 控制字符。' }

    foreach ($entry in $data.files) {
        $relative = ([string]$entry.path).Replace('\','/')
        $manifestSet[$relative.ToLowerInvariant()] = $true
        $path = Get-SafeChildPath $SourceRoot $relative '包清单'
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "完整性检查失败，缺少文件：$relative" }
        if (Test-IsReparsePoint $path) { throw "完整性检查失败，清单文件是 reparse point：$relative" }
        $actual = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actual -ne ([string]$entry.sha256).ToLowerInvariant()) { throw "完整性检查失败：$relative" }
        if ((Get-Item -LiteralPath $path -Force).Length -ne [int64]$entry.bytes) { throw "完整性检查失败，文件大小不一致：$relative" }
        if ($textExtensions -contains [System.IO.Path]::GetExtension($path).ToLowerInvariant()) {
            $rawText = Read-Utf8Text $path
            if ([regex]::IsMatch($rawText, $controlPattern)) { throw "文本控制字符检查失败：$relative" }
        }
    }

    # Only managed payload directories must be exact. Extra user notes next to the ZIP do not block installation.
    $skillsRoot = Join-Path $SourceRoot 'skills'
    Assert-NoReparseTree $skillsRoot 'Skills 源目录'
    foreach ($file in @(Get-ChildItem -LiteralPath $skillsRoot -File -Recurse -Force)) {
        $relative = $file.FullName.Substring($SourceRoot.Length).TrimStart([char[]]@('\','/')).Replace('\','/')
        if (-not $manifestSet.ContainsKey($relative.ToLowerInvariant())) { throw "Skills 目录含未登记文件：$relative" }
    }

    Write-Host '包完整性检查：通过' -ForegroundColor Green
    Write-Host 'UTF-8 / 文本控制字符检查：通过' -ForegroundColor Green
}

function Backup-Existing([string]$Path, [string]$Key) {
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    Assert-NoReparseTree $Path '待备份目标'
    $backupPath = Get-SafeChildPath $BackupRoot $Key '备份 key'
    if (Test-Path -LiteralPath $backupPath) { throw "备份目标意外已存在：$backupPath" }
    Copy-PathExact $Path $backupPath
    return $backupPath
}

function Register-Change([string]$Kind, [string]$Target, $Backup) {
    $script:ManifestEntries += [pscustomobject]@{ kind=$Kind; target=$Target; backup=$Backup }
    Save-Manifest
}

function Remove-ManagedBlock([string]$Text) {
    if ([string]::IsNullOrEmpty($Text)) { return '' }
    Assert-ManagedMarkers $Text '<memory>'
    $pattern = '(?s)' + [regex]::Escape($BeginMarker) + '.*?' + [regex]::Escape($EndMarker) + '(?:\r\n|\n|\r){0,2}'
    return [regex]::Replace($Text, $pattern, '', 1)
}

function Install-ManagedFile([string]$Source, [string]$Destination, [string]$Key, [string[]]$KnownLegacyHashes = @()) {
    $existing = ''
    if (Test-Path -LiteralPath $Destination -PathType Container) { throw "规则目标是目录而不是文件：$Destination" }
    if (Test-Path -LiteralPath $Destination -PathType Leaf) {
        Assert-NoReparseTree $Destination '规则目标'
        $legacyHash = (Get-FileHash -LiteralPath $Destination -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($KnownLegacyHashes -notcontains $legacyHash) {
            $existingRaw = Read-Utf8Text $Destination
            Assert-ManagedMarkers $existingRaw $Destination
            $existing = Remove-ManagedBlock $existingRaw
        }
    }
    $managed = (Read-Utf8Text $Source).Trim()
    $backup = Backup-Existing $Destination $Key
    $body = $BeginMarker + [Environment]::NewLine + $managed + [Environment]::NewLine + $EndMarker
    if (-not [string]::IsNullOrEmpty($existing)) {
        $tail = $existing.TrimStart([char[]]@([char]13,[char]10))
        if ($tail.Length -gt 0) { $body += [Environment]::NewLine + [Environment]::NewLine + $tail }
    }
    if (-not $body.EndsWith([Environment]::NewLine, [System.StringComparison]::Ordinal)) { $body += [Environment]::NewLine }
    Register-Change 'file' $Destination $backup
    Write-Utf8NoBomAtomic $Destination $body
    Write-Host "已接入全局规则：$Destination"
}

function Install-File([string]$Source, [string]$Destination, [string]$Key) {
    if (Test-Path -LiteralPath $Destination -PathType Container) { throw "文件目标实际是目录：$Destination" }
    if (Test-Path -LiteralPath $Destination) { Assert-NoReparseTree $Destination '文件目标' }
    $backup = Backup-Existing $Destination $Key
    Register-Change 'file' $Destination $backup
    if (Test-Path -LiteralPath $Destination) { Remove-Item -LiteralPath $Destination -Force -Recurse }
    Copy-PathExact $Source $Destination
    Write-Host "已安装：$Destination"
}

function Install-Directory([string]$Source, [string]$Destination, [string]$Key) {
    if (Test-Path -LiteralPath $Destination) { Assert-NoReparseTree $Destination '目录目标' }
    $backup = Backup-Existing $Destination $Key
    Register-Change 'directory' $Destination $backup
    if (Test-Path -LiteralPath $Destination) { Remove-Item -LiteralPath $Destination -Recurse -Force }
    Copy-PathExact $Source $Destination
    Write-Host "已安装：$Destination"
}

function Remove-PathTransactional([string]$Path, [string]$Key, [string]$Kind) {
    if (-not (Test-Path -LiteralPath $Path)) { return }
    Assert-NoReparseTree $Path '待移除旧版路径'
    $backup = Backup-Existing $Path $Key
    Register-Change $Kind $Path $backup
    Remove-Item -LiteralPath $Path -Recurse -Force
    Write-Host "已移除旧版运行项：$Path"
}

function Move-PathTransactional([string]$Source, [string]$Destination) {
    if (-not (Test-Path -LiteralPath $Source)) { return }
    Assert-NoReparseTree $Source '待归档旧版备份'
    if (Test-Path -LiteralPath $Destination) { throw "旧版备份归档目标已存在：$Destination" }
    Ensure-Dir (Split-Path -Parent $Destination)
    # 先复制完整归档；在此之前不修改用户原路径。复制被中断最多留下孤立归档，不破坏原数据。
    Copy-PathExact $Source $Destination
    try {
        Register-Change 'move' $Source $Destination
    } catch {
        if (Test-Path -LiteralPath $Destination) { Remove-Item -LiteralPath $Destination -Recurse -Force -ErrorAction SilentlyContinue }
        throw
    }
    Remove-Item -LiteralPath $Source -Recurse -Force
    Write-Host "已归档旧版备份：$Destination"
}

function Remove-LegacySkillIfOwned([string]$Name) {
    $target = Join-Path $HomeDir ('.agents\skills\' + $Name)
    $skillFile = Join-Path $target 'SKILL.md'
    if (-not (Test-Path -LiteralPath $skillFile -PathType Leaf)) { return }
    if (-not $LegacySkillHashes.ContainsKey($Name)) { return }
    $actual = (Get-FileHash -LiteralPath $skillFile -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actual -ne $LegacySkillHashes[$Name]) { return }
    Remove-PathTransactional $target ('legacy-skills\' + $Name) 'directory'
}

function Remove-LegacyPromptIfOwned([string]$Path, [string]$ExpectedHash, [string]$Key) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return }
    if (Test-IsReparsePoint $Path) { throw "旧 Prompt 是 reparse point，拒绝自动删除：$Path" }
    $actual = (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actual -ne $ExpectedHash) { return }
    Remove-PathTransactional $Path $Key 'file'
}

function Rollback-CurrentRun {
    if ($script:ManifestEntries.Count -eq 0) { return }
    for ($i = $script:ManifestEntries.Count - 1; $i -ge 0; $i--) {
        $entry = $script:ManifestEntries[$i]
        try {
            $target = [string]$entry.target
            $backup = if ($null -eq $entry.backup) { '' } else { [string]$entry.backup }
            if ([string]$entry.kind -eq 'move') {
                if ($backup -and (Test-Path -LiteralPath $backup)) {
                    if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Recurse -Force }
                    Copy-PathExact $backup $target
                    Remove-Item -LiteralPath $backup -Recurse -Force
                }
                continue
            }
            if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Recurse -Force }
            if ($backup -and (Test-Path -LiteralPath $backup)) { Copy-PathExact $backup $target }
        } catch { Write-Warning "自动回滚失败：$($entry.target) - $($_.Exception.Message)" }
    }
}

try {
    Test-ScriptCompatibility
    Test-PackageIntegrity

    if (Test-IsReparsePoint $KitDataRoot) { throw "AgentKit 数据根目录不能是 reparse point：$KitDataRoot" }
    if (Test-IsReparsePoint $BackupsRoot) { throw "AgentKit backups 目录不能是 reparse point：$BackupsRoot" }
    if (Test-IsReparsePoint $LegacyArchiveRoot) { throw "AgentKit legacy-v2-backups 目录不能是 reparse point：$LegacyArchiveRoot" }

    if (Test-Path -LiteralPath $Pointer -PathType Leaf) {
        Assert-NoReparseTree $Pointer '备份指针'
        $PointerExisted = $true
        $PreviousPointer = Read-Utf8Text $Pointer
        $previousBackup = $PreviousPointer.Trim()
        if ($previousBackup) {
            $previousBackup = [System.IO.Path]::GetFullPath($previousBackup)
            $backupsRootFull = [System.IO.Path]::GetFullPath($BackupsRoot).TrimEnd([char[]]@('\','/'))
            $previousFull = $previousBackup.TrimEnd([char[]]@('\','/'))
            if (-not (Test-PathWithin $previousBackup $BackupsRoot) -or $previousFull.Equals($backupsRootFull, [System.StringComparison]::OrdinalIgnoreCase)) {
                throw "现有 AgentKit 备份指针越出 backups 目录：$previousBackup"
            }
        }
    } elseif (Test-Path -LiteralPath $Pointer) {
        throw "备份指针路径不是普通文件：$Pointer"
    }

    Ensure-Dir $BackupRoot
    if ($PointerExisted) { Write-Utf8NoBomAtomic (Join-Path $BackupRoot 'previous-pointer.txt') $PreviousPointer }
    Save-Manifest

    Remove-PathTransactional $LegacyCanonicalRoot 'legacy-runtime\.agent-global' 'directory'
    Remove-PathTransactional $LegacyPointer 'legacy-runtime\.agent-global-last-backup.txt' 'file'
    if (Test-Path -LiteralPath $LegacyBackupsRoot -PathType Container) {
        $legacyArchive = Join-Path $LegacyArchiveRoot ($Stamp + '-' + $RunId)
        Move-PathTransactional $LegacyBackupsRoot $legacyArchive
    }

    $sharedSkillsRoot = Join-Path $HomeDir '.agents\skills'
    if (Test-IsReparsePoint $sharedSkillsRoot) { throw "共享 Skills 根目录不能是 reparse point：$sharedSkillsRoot" }
    Ensure-Dir $sharedSkillsRoot
    foreach ($legacy in $LegacySkillHashes.Keys) { Remove-LegacySkillIfOwned $legacy }
    foreach ($skill in $KitSkills) {
        Install-Directory (Join-Path $SourceRoot ('skills\' + $skill)) (Join-Path $HomeDir ('.agents\skills\' + $skill)) ('shared-skills\' + $skill)
    }

    $piRoot = Join-Path $HomeDir '.pi\agent'
    if (Test-IsReparsePoint $piRoot) { throw "Pi Agent 根目录不能是 reparse point：$piRoot" }
    Ensure-Dir $piRoot
    $piSource = Join-Path $SourceRoot 'platform\pi\AGENTS.md'
    Install-ManagedFile $piSource (Join-Path $piRoot 'AGENTS.md') 'pi\AGENTS.md' $LegacyManagedHashes.Pi
    $piOverride = Join-Path $piRoot 'AGENTS.override.md'
    if (Test-Path -LiteralPath $piOverride) {
        if (-not (Test-Path -LiteralPath $piOverride -PathType Leaf)) { throw "Pi AGENTS.override.md 不是普通文件：$piOverride" }
        Install-ManagedFile $piSource $piOverride 'pi\AGENTS.override.md'
    }
    $piPrompts = Join-Path $piRoot 'prompts'
    Ensure-Dir $piPrompts
    Remove-LegacyPromptIfOwned (Join-Path $piPrompts 'agent-task.md') '4b20f8f126cdc44aa9e7259c55e2d34370f5fdbb276e1856cb4354bd276dac28' 'pi\prompts\legacy-agent-task.md'
    Remove-LegacyPromptIfOwned (Join-Path $piPrompts 'agent-review.md') 'ac7126dbf6ee964b467542b32bcf561d84c70318161a59576a9cfd265bece72e' 'pi\prompts\legacy-agent-review.md'
    Install-File (Join-Path $SourceRoot 'platform\pi\prompts\agentkit-task.md') (Join-Path $piPrompts 'agentkit-task.md') 'pi\prompts\agentkit-task.md'
    Install-File (Join-Path $SourceRoot 'platform\pi\prompts\agentkit-review.md') (Join-Path $piPrompts 'agentkit-review.md') 'pi\prompts\agentkit-review.md'

    $codexRoot = if ($env:CODEX_HOME) { [System.IO.Path]::GetFullPath($env:CODEX_HOME) } else { Join-Path $HomeDir '.codex' }
    if (Test-IsReparsePoint $codexRoot) { throw "Codex 根目录不能是 reparse point：$codexRoot" }
    Ensure-Dir $codexRoot
    $codexSource = Join-Path $SourceRoot 'platform\codex\AGENTS.md'
    Install-ManagedFile $codexSource (Join-Path $codexRoot 'AGENTS.md') 'codex\AGENTS.md' $LegacyManagedHashes.Codex
    $codexOverride = Join-Path $codexRoot 'AGENTS.override.md'
    if (Test-Path -LiteralPath $codexOverride) {
        if (-not (Test-Path -LiteralPath $codexOverride -PathType Leaf)) { throw "Codex AGENTS.override.md 不是普通文件：$codexOverride" }
        Install-ManagedFile $codexSource $codexOverride 'codex\AGENTS.override.md'
    }

    $claudeRoot = Join-Path $HomeDir '.claude'
    if (Test-IsReparsePoint $claudeRoot) { throw "Claude 根目录不能是 reparse point：$claudeRoot" }
    Ensure-Dir $claudeRoot
    Install-ManagedFile (Join-Path $SourceRoot 'platform\claude\CLAUDE.md') (Join-Path $claudeRoot 'CLAUDE.md') 'claude\CLAUDE.md' $LegacyManagedHashes.Claude
    $claudeSkillsRoot = Join-Path $claudeRoot 'skills'
    Ensure-Dir $claudeSkillsRoot
    foreach ($skill in $KitSkills) {
        Install-Directory (Join-Path $SourceRoot ('skills\' + $skill)) (Join-Path $claudeSkillsRoot $skill) ('claude\skills\' + $skill)
    }

    $stateBackup = Backup-Existing $StatePath 'installer\state.json'
    Register-Change 'file' $StatePath $stateBackup
    $state = [pscustomobject]@{
        kit='global-agent-governance-kit'; version=$script:KitVersion; language='zh-CN'; architecture='native-direct-astra-optimized-frozen';
        installed_at=(Get-Date).ToString('o'); platforms=@('Pi','Codex','Claude'); skills=$KitSkills; skill_layout='native-per-harness'; managed_marker=$BeginMarker
    }
    Write-Utf8NoBomAtomic $StatePath (ConvertTo-Json $state -Depth 5)

    Ensure-Dir $KitDataRoot
    Write-Utf8NoBomAtomic $Pointer ($BackupRoot + [Environment]::NewLine)
    $script:Committed = $true
} catch {
    $script:FailureMessage = $_.Exception.Message
} finally {
    if (-not $script:Committed) {
        Rollback-CurrentRun
        try {
            if ($PointerExisted) { Write-Utf8NoBomAtomic $Pointer $PreviousPointer }
            elseif (Test-Path -LiteralPath $Pointer) { Remove-Item -LiteralPath $Pointer -Force -Recurse }
        } catch { Write-Warning "恢复旧备份指针失败：$($_.Exception.Message)" }
    }
}

if (-not $script:Committed) {
    Write-Host ''
    if ([string]::IsNullOrWhiteSpace($script:FailureMessage)) { $script:FailureMessage = '安装被中断或未提交。' }
    Write-Host "安装失败：$($script:FailureMessage)" -ForegroundColor Red
    Write-Host '本次已登记的变更已尝试自动回滚。'
    exit 1
}

Write-Host ''
Write-Host ("全局 Agent 治理套件 {0} 安装完成。" -f $script:KitVersion) -ForegroundColor Green
Write-Host "备份：$BackupRoot"
Write-Host '请运行 verify.cmd，验证通过后重新打开 Agent 会话；Pi 也可执行 /reload。'
exit 0
