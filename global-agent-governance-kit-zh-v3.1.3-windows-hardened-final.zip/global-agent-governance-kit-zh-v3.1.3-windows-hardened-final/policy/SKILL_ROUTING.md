# Skill 路由设计（包内设计参考）

运行时不再维护重复的 Skill 路由表。Skill 自己的 YAML `name` + `description` 是唯一触发描述，宿主只在描述清楚匹配时加载完整 `SKILL.md`。

设计要求：

- description 尽可能短，同时明确“什么时候使用”；
- 一个 Skill 只解决一个窄任务，不把相邻领域全部纳入触发范围；
- 根 `SKILL.md` 保持精简，多工作流通过 `references/` / `scripts/` 渐进披露；
- 不把普通 Agent 已能稳定完成的通用行为包装成常驻 Skill；
- Skill 不应复制全局验证、审批和沟通规则。
