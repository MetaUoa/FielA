﻿$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = New-Object -TypeName System.Text.UTF8Encoding -ArgumentList $false } catch {}

$SourceRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$HomeDir = [Environment]::GetFolderPath('UserProfile')
$LocalAppData = [Environment]::GetFolderPath('LocalApplicationData')
if ([string]::IsNullOrWhiteSpace($LocalAppData)) { $LocalAppData = Join-Path $HomeDir 'AppData\Local' }
$KitDataRoot = Join-Path $LocalAppData 'AgentKit'
$BackupsRoot = Join-Path $KitDataRoot 'backups'
$Pointer = Join-Path $KitDataRoot 'last-backup.txt'
$StatePath = Join-Path $KitDataRoot 'state.json'
$BeginMarker = '<!-- AGENTKIT:BEGIN -->'
$EndMarker = '<!-- AGENTKIT:END -->'
$Utf8Strict = New-Object -TypeName System.Text.UTF8Encoding -ArgumentList @($false, $true)
$Results = @()
$KitSkills = @('agentkit-debug-root-cause','agentkit-test-verification','agentkit-safe-refactor','agentkit-dependency-upgrade','agentkit-git-change-hygiene','agentkit-schema-migration','agentkit-release-readiness')

function Read-Utf8Text([string]$Path) {
    return [System.IO.File]::ReadAllText($Path, $script:Utf8Strict)
}

function Test-PathWithin([string]$Path, [string]$Root) {
    $fullPath = [System.IO.Path]::GetFullPath($Path).TrimEnd([char[]]@('\','/'))
    $fullRoot = [System.IO.Path]::GetFullPath($Root).TrimEnd([char[]]@('\','/'))
    if ($fullPath.Equals($fullRoot, [System.StringComparison]::OrdinalIgnoreCase)) { return $true }
    return $fullPath.StartsWith($fullRoot + [System.IO.Path]::DirectorySeparatorChar, [System.StringComparison]::OrdinalIgnoreCase)
}

function Get-SafeChildPath([string]$Root, [string]$Relative) {
    $normalized = $Relative.Replace('/', '\')
    if ([System.IO.Path]::IsPathRooted($normalized) -or $normalized.Contains(':')) { throw "不安全的清单路径：$Relative" }
    foreach ($segment in $normalized.Split([char[]]@('\'), [System.StringSplitOptions]::RemoveEmptyEntries)) {
        if ($segment -eq '.' -or $segment -eq '..') { throw "不安全的清单路径：$Relative" }
    }
    $candidate = [System.IO.Path]::GetFullPath((Join-Path $Root $normalized))
    if (-not (Test-PathWithin $candidate $Root)) { throw "清单路径越界：$Relative" }
    return $candidate
}

function Test-IsReparsePoint([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) { return $false }
    $item = Get-Item -LiteralPath $Path -Force
    return (($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0)
}

function Add-Result([string]$Status, [string]$Name, [string]$Path) {
    $script:Results += [pscustomobject]@{ 状态=$Status; 项目=$Name; 路径=$Path }
}

function Test-PackageIntegrity {
    $versionPath = Join-Path $SourceRoot 'VERSION.txt'
    if (-not (Test-Path -LiteralPath $versionPath -PathType Leaf)) { Add-Result 'FAIL' '版本文件' $versionPath; return $null }
    try { $script:KitVersion = (Read-Utf8Text $versionPath).Trim() } catch { Add-Result 'FAIL' '版本文件 UTF-8' $versionPath; return $null }

    $manifestPath = Join-Path $SourceRoot 'PACKAGE_MANIFEST.json'
    if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) { Add-Result 'FAIL' '安装包清单' $manifestPath; return $null }
    try {
        $manifestRaw = Read-Utf8Text $manifestPath
        $manifest = $manifestRaw | ConvertFrom-Json
        if ([string]$manifest.version -eq $script:KitVersion) { Add-Result 'OK' '安装包版本' $manifestPath } else { Add-Result 'FAIL' '安装包版本' $manifestPath }
        $bad = 0
        $manifestSet = @{}
        $textExtensions = @('.md','.ps1','.cmd','.json','.txt')
        $controlPattern = '[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]'
        if ([regex]::IsMatch($manifestRaw, $controlPattern)) { Add-Result 'FAIL' '包清单控制字符' $manifestPath; $bad++ }
        foreach ($entry in $manifest.files) {
            $relative = ([string]$entry.path).Replace('\','/')
            $manifestSet[$relative.ToLowerInvariant()] = $true
            $path = Get-SafeChildPath $SourceRoot $relative
            if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { Add-Result 'FAIL' ('包文件缺失: ' + $relative) $path; $bad++; continue }
            if (Test-IsReparsePoint $path) { Add-Result 'FAIL' ('包文件是 reparse point: ' + $relative) $path; $bad++; continue }
            $hash = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
            if ($hash -ne ([string]$entry.sha256).ToLowerInvariant() -or (Get-Item -LiteralPath $path -Force).Length -ne [int64]$entry.bytes) {
                Add-Result 'FAIL' ('包文件损坏: ' + $relative) $path; $bad++; continue
            }
            if ($textExtensions -contains [System.IO.Path]::GetExtension($path).ToLowerInvariant()) {
                try {
                    $rawText = Read-Utf8Text $path
                    if ([regex]::IsMatch($rawText, $controlPattern)) { Add-Result 'FAIL' ('异常控制字符: ' + $relative) $path; $bad++ }
                } catch { Add-Result 'FAIL' ('UTF-8 解码失败: ' + $relative) $path; $bad++ }
            }
        }
        $skillsRoot = Join-Path $SourceRoot 'skills'
        foreach ($file in @(Get-ChildItem -LiteralPath $skillsRoot -File -Recurse -Force)) {
            $relative = $file.FullName.Substring($SourceRoot.Length).TrimStart([char[]]@('\','/')).Replace('\','/')
            if (-not $manifestSet.ContainsKey($relative.ToLowerInvariant())) { Add-Result 'FAIL' ('Skills 未登记文件: ' + $relative) $file.FullName; $bad++ }
        }
        if ($bad -eq 0) {
            Add-Result 'OK' '安装包完整性' $manifestPath
            Add-Result 'OK' '包内 UTF-8 / 控制字符' $manifestPath
        }
        return $manifest
    } catch { Add-Result 'FAIL' '安装包完整性' $manifestPath; return $null }
}

function Get-ManagedBody([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $null }
    $text = Read-Utf8Text $Path
    $pattern = '(?s)' + [regex]::Escape($BeginMarker) + '\s*(.*?)\s*' + [regex]::Escape($EndMarker)
    $m = [regex]::Match($text, $pattern)
    if (-not $m.Success) { return $null }
    return $m.Groups[1].Value.Trim()
}

function Test-ManagedFile([string]$Source, [string]$Destination, [string]$Name, [bool]$Required) {
    if (-not (Test-Path -LiteralPath $Destination -PathType Leaf)) {
        if ($Required) { Add-Result 'FAIL' $Name $Destination } else { Add-Result 'SKIP' $Name $Destination }
        return
    }
    if (Test-IsReparsePoint $Destination) { Add-Result 'FAIL' ($Name + '（reparse point）') $Destination; return }
    try { $text = Read-Utf8Text $Destination } catch { Add-Result 'FAIL' ($Name + '（UTF-8 解码失败）') $Destination; return }
    $beginCount = [regex]::Matches($text, [regex]::Escape($BeginMarker)).Count
    $endCount = [regex]::Matches($text, [regex]::Escape($EndMarker)).Count
    if ($beginCount -ne 1 -or $endCount -ne 1 -or $text.IndexOf($BeginMarker) -gt $text.IndexOf($EndMarker)) { Add-Result 'FAIL' ($Name + '（托管标记异常）') $Destination; return }
    $actual = Get-ManagedBody $Destination
    if ($null -eq $actual) { Add-Result 'FAIL' ($Name + '（缺少托管标记）') $Destination; return }
    $expected = (Read-Utf8Text $Source).Trim()
    if ($actual -eq $expected) { Add-Result 'OK' $Name $Destination } else { Add-Result 'FAIL' ($Name + '（规则版本不一致）') $Destination }
}

function Test-ExactFile([string]$Source, [string]$Destination, [string]$Name) {
    if (-not (Test-Path -LiteralPath $Destination -PathType Leaf)) { Add-Result 'FAIL' $Name $Destination; return }
    if (Test-IsReparsePoint $Destination) { Add-Result 'FAIL' ($Name + '（reparse point）') $Destination; return }
    if ((Get-FileHash -LiteralPath $Source -Algorithm SHA256).Hash -eq (Get-FileHash -LiteralPath $Destination -Algorithm SHA256).Hash) { Add-Result 'OK' $Name $Destination }
    else { Add-Result 'FAIL' ($Name + '（内容不一致）') $Destination }
}

function Test-DirectoryMirror([string]$Source, [string]$Destination, [string]$Name) {
    if (-not (Test-Path -LiteralPath $Destination -PathType Container)) { Add-Result 'FAIL' $Name $Destination; return }
    if (Test-IsReparsePoint $Destination) { Add-Result 'FAIL' ($Name + '（reparse point）') $Destination; return }
    $sourceFiles = @(Get-ChildItem -LiteralPath $Source -File -Recurse -Force)
    $destFiles = @(Get-ChildItem -LiteralPath $Destination -File -Recurse -Force)
    if ($sourceFiles.Count -ne $destFiles.Count) { Add-Result 'FAIL' ($Name + '（文件数量不一致）') $Destination; return }
    foreach ($file in $sourceFiles) {
        $relative = $file.FullName.Substring($Source.Length).TrimStart([char[]]@('\','/'))
        $dest = Join-Path $Destination $relative
        if (-not (Test-Path -LiteralPath $dest -PathType Leaf)) { Add-Result 'FAIL' ($Name + '（缺少 ' + $relative + '）') $Destination; return }
        if (Test-IsReparsePoint $dest) { Add-Result 'FAIL' ($Name + '（包含 reparse point）') $dest; return }
        if ((Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath $dest -Algorithm SHA256).Hash) { Add-Result 'FAIL' ($Name + '（内容不一致）') $Destination; return }
    }
    Add-Result 'OK' $Name $Destination
}

$manifest = Test-PackageIntegrity

if (Test-IsReparsePoint $KitDataRoot) { Add-Result 'FAIL' 'AgentKit 数据根目录 reparse point' $KitDataRoot } else { Add-Result 'OK' 'AgentKit 数据根目录' $KitDataRoot }
if (Test-IsReparsePoint $BackupsRoot) { Add-Result 'FAIL' 'AgentKit backups reparse point' $BackupsRoot }

if (-not (Test-Path -LiteralPath $StatePath -PathType Leaf)) { Add-Result 'FAIL' '安装状态' $StatePath }
else {
    try {
        $state = (Read-Utf8Text $StatePath) | ConvertFrom-Json
        $platforms = @($state.platforms)
        $expectedPlatforms = @('Pi','Codex','Claude')
        $missingPlatforms = @($expectedPlatforms | Where-Object { $platforms -notcontains $_ })
        $platformsOk = ($platforms.Count -eq $expectedPlatforms.Count -and $missingPlatforms.Count -eq 0)
        if ([string]$state.version -eq $script:KitVersion -and [string]$state.architecture -eq 'native-direct-astra-optimized-frozen' -and $platformsOk) { Add-Result 'OK' '安装状态' $StatePath }
        else { Add-Result 'FAIL' '安装状态版本/架构/平台集合' $StatePath }
    } catch { Add-Result 'FAIL' '安装状态' $StatePath }
}

if (Test-Path -LiteralPath $Pointer -PathType Leaf) {
    try {
        $backupPointer = (Read-Utf8Text $Pointer).Trim()
        $backupsRootFull = [System.IO.Path]::GetFullPath($BackupsRoot).TrimEnd([char[]]@('\','/'))
        $pointerFull = if ($backupPointer) { [System.IO.Path]::GetFullPath($backupPointer).TrimEnd([char[]]@('\','/')) } else { '' }
        if ([string]::IsNullOrWhiteSpace($backupPointer) -or -not (Test-PathWithin $backupPointer $BackupsRoot) -or $pointerFull.Equals($backupsRootFull, [System.StringComparison]::OrdinalIgnoreCase)) { Add-Result 'FAIL' '备份指针范围' $Pointer }
        elseif (-not (Test-Path -LiteralPath $backupPointer -PathType Container)) { Add-Result 'FAIL' '备份指针目标' $backupPointer }
        elseif (Test-IsReparsePoint $backupPointer) { Add-Result 'FAIL' '备份指针目标 reparse point' $backupPointer }
        else { Add-Result 'OK' '备份指针范围' $backupPointer }
    } catch { Add-Result 'FAIL' '备份指针' $Pointer }
} else { Add-Result 'FAIL' '备份指针' $Pointer }

$legacyRoot = Join-Path $HomeDir '.agent-global'
if (Test-Path -LiteralPath $legacyRoot) { Add-Result 'FAIL' '旧 agent-global 已移除' $legacyRoot } else { Add-Result 'OK' '旧 agent-global 已移除' $legacyRoot }
$legacyPointer = Join-Path $HomeDir '.agent-global-last-backup.txt'
if (Test-Path -LiteralPath $legacyPointer) { Add-Result 'FAIL' '旧备份指针已移除' $legacyPointer } else { Add-Result 'OK' '旧备份指针已移除' $legacyPointer }
$legacyBackups = Join-Path $HomeDir '.agent-global-backups'
if (Test-Path -LiteralPath $legacyBackups) { Add-Result 'FAIL' '旧备份目录已归档' $legacyBackups } else { Add-Result 'OK' '旧备份目录已归档' $legacyBackups }

$sharedSkillsRoot = Join-Path $HomeDir '.agents\skills'
if (Test-IsReparsePoint $sharedSkillsRoot) { Add-Result 'FAIL' 'Pi/Codex Skills 根目录 reparse point' $sharedSkillsRoot }

foreach ($skill in $KitSkills) {
    Test-DirectoryMirror (Join-Path $SourceRoot ('skills\' + $skill)) (Join-Path $HomeDir ('.agents\skills\' + $skill)) ('Pi/Codex Skill: ' + $skill)
}

$piRoot = Join-Path $HomeDir '.pi\agent'
if (Test-IsReparsePoint $piRoot) { Add-Result 'FAIL' 'Pi Agent 根目录 reparse point' $piRoot }
$piSrc = Join-Path $SourceRoot 'platform\pi\AGENTS.md'
Test-ManagedFile $piSrc (Join-Path $piRoot 'AGENTS.md') 'Pi AGENTS' $true
$piOverride = Join-Path $piRoot 'AGENTS.override.md'
if (Test-Path -LiteralPath $piOverride) {
    if (Test-Path -LiteralPath $piOverride -PathType Leaf) { Test-ManagedFile $piSrc $piOverride 'Pi AGENTS.override' $true }
    else { Add-Result 'FAIL' 'Pi AGENTS.override（不是普通文件）' $piOverride }
}
Test-ExactFile (Join-Path $SourceRoot 'platform\pi\prompts\agentkit-task.md') (Join-Path $piRoot 'prompts\agentkit-task.md') 'Pi task prompt'
Test-ExactFile (Join-Path $SourceRoot 'platform\pi\prompts\agentkit-review.md') (Join-Path $piRoot 'prompts\agentkit-review.md') 'Pi review prompt'

$piTaskPrompt = Join-Path $SourceRoot 'platform\pi\prompts\agentkit-task.md'
$piTaskRaw = Read-Utf8Text $piTaskPrompt
if ($piTaskRaw -match '\{\{[^}]+\}\}') { Add-Result 'FAIL' 'Pi task prompt 不得包含 Mustache 占位符' $piTaskPrompt }
elseif ($piTaskRaw -notmatch '\$ARGUMENTS') { Add-Result 'FAIL' 'Pi task prompt 缺少 $ARGUMENTS' $piTaskPrompt }
else { Add-Result 'OK' 'Pi task prompt 参数语法' $piTaskPrompt }

$codexRoot = if ($env:CODEX_HOME) { [System.IO.Path]::GetFullPath($env:CODEX_HOME) } else { Join-Path $HomeDir '.codex' }
if (Test-IsReparsePoint $codexRoot) { Add-Result 'FAIL' 'Codex 根目录 reparse point' $codexRoot }
$codexSrc = Join-Path $SourceRoot 'platform\codex\AGENTS.md'
Test-ManagedFile $codexSrc (Join-Path $codexRoot 'AGENTS.md') 'Codex AGENTS' $true
$codexOverride = Join-Path $codexRoot 'AGENTS.override.md'
if (Test-Path -LiteralPath $codexOverride) {
    if (Test-Path -LiteralPath $codexOverride -PathType Leaf) { Test-ManagedFile $codexSrc $codexOverride 'Codex AGENTS.override' $true }
    else { Add-Result 'FAIL' 'Codex AGENTS.override（不是普通文件）' $codexOverride }
}

$claudeRoot = Join-Path $HomeDir '.claude'
if (Test-IsReparsePoint $claudeRoot) { Add-Result 'FAIL' 'Claude 根目录 reparse point' $claudeRoot }
Test-ManagedFile (Join-Path $SourceRoot 'platform\claude\CLAUDE.md') (Join-Path $claudeRoot 'CLAUDE.md') 'Claude CLAUDE' $true
foreach ($skill in $KitSkills) {
    Test-DirectoryMirror (Join-Path $SourceRoot ('skills\' + $skill)) (Join-Path $claudeRoot ('skills\' + $skill)) ('Claude Skill: ' + $skill)
}

$runtimeRefs = @(Get-ChildItem -LiteralPath (Join-Path $SourceRoot 'platform') -File -Recurse | Select-String -SimpleMatch '~/.agent-global' -ErrorAction SilentlyContinue)
if ($runtimeRefs.Count -eq 0) { Add-Result 'OK' '平台规则无 agent-global 运行依赖' (Join-Path $SourceRoot 'platform') }
else { Add-Result 'FAIL' '平台规则仍引用 agent-global' (Join-Path $SourceRoot 'platform') }

$claudeWrongSkillPath = @(Select-String -LiteralPath (Join-Path $SourceRoot 'platform\claude\CLAUDE.md') -SimpleMatch '~/.agents/skills' -ErrorAction SilentlyContinue)
if ($claudeWrongSkillPath.Count -eq 0) { Add-Result 'OK' 'Claude 使用原生 Skill 路径' (Join-Path $HomeDir '.claude\skills') }
else { Add-Result 'FAIL' 'Claude 仍引用非原生 Skill 路径' (Join-Path $SourceRoot 'platform\claude\CLAUDE.md') }

$Results | Format-Table -AutoSize
$failures = @($Results | Where-Object { $_.状态 -eq 'FAIL' })
Write-Host ''
if ($failures.Count -eq 0) { Write-Host ("验证通过：{0} 的原生平台规则、Skills、Pi Prompt、安装状态、备份指针与包完整性均正确。" -f $script:KitVersion) -ForegroundColor Green; exit 0 }
Write-Host "验证失败：发现 $($failures.Count) 项问题。" -ForegroundColor Red
exit 1
