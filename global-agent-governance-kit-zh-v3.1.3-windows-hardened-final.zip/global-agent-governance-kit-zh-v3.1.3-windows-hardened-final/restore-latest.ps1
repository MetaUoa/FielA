﻿$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = New-Object -TypeName System.Text.UTF8Encoding -ArgumentList $false } catch {}

$HomeDir = [Environment]::GetFolderPath('UserProfile')
$LocalAppData = [Environment]::GetFolderPath('LocalApplicationData')
if ([string]::IsNullOrWhiteSpace($LocalAppData)) { $LocalAppData = Join-Path $HomeDir 'AppData\Local' }
$KitDataRoot = Join-Path $LocalAppData 'AgentKit'
$BackupsRoot = Join-Path $KitDataRoot 'backups'
$LegacyArchiveRoot = Join-Path $KitDataRoot 'legacy-v2-backups'
$Pointer = Join-Path $KitDataRoot 'last-backup.txt'
$Utf8Strict = New-Object -TypeName System.Text.UTF8Encoding -ArgumentList @($false, $true)
$Stamp = Get-Date -Format 'yyyyMMdd-HHmmss-fff'
$RunId = [guid]::NewGuid().ToString('N').Substring(0,8)
$RestoreSafetyRoot = Join-Path $KitDataRoot ('restore-safety\' + $Stamp + '-' + $PID + '-' + $RunId)
$script:RestoreSnapshots = @()
$script:RestoreCommitted = $false
$script:FailureMessage = ''
$OriginalPointer = ''

function Read-Utf8Text([string]$Path) {
    return [System.IO.File]::ReadAllText($Path, $script:Utf8Strict)
}

function Ensure-Dir([string]$Path) {
    if ([string]::IsNullOrWhiteSpace($Path)) { return }
    if (-not (Test-Path -LiteralPath $Path -PathType Container)) { New-Item -ItemType Directory -Path $Path -Force | Out-Null }
}

function Test-PathWithin([string]$Path, [string]$Root) {
    $fullPath = [System.IO.Path]::GetFullPath($Path).TrimEnd([char[]]@('\','/'))
    $fullRoot = [System.IO.Path]::GetFullPath($Root).TrimEnd([char[]]@('\','/'))
    if ($fullPath.Equals($fullRoot, [System.StringComparison]::OrdinalIgnoreCase)) { return $true }
    return $fullPath.StartsWith($fullRoot + [System.IO.Path]::DirectorySeparatorChar, [System.StringComparison]::OrdinalIgnoreCase)
}

function Test-IsReparsePoint([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) { return $false }
    $item = Get-Item -LiteralPath $Path -Force
    return (($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0)
}

function Assert-NoReparseTree([string]$Path, [string]$Label) {
    if (-not (Test-Path -LiteralPath $Path)) { return }
    if (Test-IsReparsePoint $Path) { throw "$Label 是符号链接/junction/reparse point：$Path" }
    if (-not (Test-Path -LiteralPath $Path -PathType Container)) { return }
    $stack = New-Object System.Collections.Stack
    $stack.Push($Path)
    while ($stack.Count -gt 0) {
        $current = [string]$stack.Pop()
        foreach ($child in @(Get-ChildItem -LiteralPath $current -Force)) {
            if (($child.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) { throw "$Label 内含 reparse point：$($child.FullName)" }
            if ($child.PSIsContainer) { $stack.Push($child.FullName) }
        }
    }
}

function Write-Utf8NoBomAtomic([string]$Path, [string]$Text) {
    $parent = Split-Path -Parent $Path
    Ensure-Dir $parent
    if (Test-Path -LiteralPath $Path) { Assert-NoReparseTree $Path '写入目标' }
    $tmp = Join-Path $parent ('.agentkit-' + [guid]::NewGuid().ToString('N') + '.tmp')
    try {
        [System.IO.File]::WriteAllText($tmp, $Text, $script:Utf8Strict)
        if (Test-Path -LiteralPath $Path) { Remove-Item -LiteralPath $Path -Force -Recurse }
        Move-Item -LiteralPath $tmp -Destination $Path -Force
    } finally {
        if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue }
    }
}

function Copy-PathExact([string]$Source, [string]$Destination) {
    if (-not (Test-Path -LiteralPath $Source)) { throw "恢复源不存在：$Source" }
    Assert-NoReparseTree $Source '恢复源'
    if (Test-Path -LiteralPath $Destination) { throw "精确复制目标必须不存在：$Destination" }
    if (Test-Path -LiteralPath $Source -PathType Leaf) {
        Ensure-Dir (Split-Path -Parent $Destination)
        Copy-Item -LiteralPath $Source -Destination $Destination -Force
        return
    }
    Ensure-Dir $Destination
    foreach ($child in @(Get-ChildItem -LiteralPath $Source -Force)) {
        Copy-Item -LiteralPath $child.FullName -Destination $Destination -Recurse -Force
    }
}

function Save-RestoreSafetyManifest {
    Ensure-Dir $RestoreSafetyRoot
    $json = ConvertTo-Json -InputObject @($script:RestoreSnapshots) -Depth 6
    Write-Utf8NoBomAtomic (Join-Path $RestoreSafetyRoot 'manifest.json') $json
}

function Snapshot-CurrentTarget([string]$Target, [int]$Index) {
    $snapshot = $null
    $existed = Test-Path -LiteralPath $Target
    if ($existed) {
        Assert-NoReparseTree $Target '恢复前目标'
        $snapshot = Join-Path $RestoreSafetyRoot ('targets\' + $Index.ToString('D4'))
        Copy-PathExact $Target $snapshot
    }
    $script:RestoreSnapshots += [pscustomobject]@{ target=$Target; existed=[bool]$existed; snapshot=$snapshot }
    Save-RestoreSafetyManifest
}

function Rollback-RestoreAttempt {
    for ($i = $script:RestoreSnapshots.Count - 1; $i -ge 0; $i--) {
        $entry = $script:RestoreSnapshots[$i]
        try {
            $target = [string]$entry.target
            if (Test-Path -LiteralPath $target) {
                Assert-NoReparseTree $target '恢复失败后的回滚目标'
                Remove-Item -LiteralPath $target -Recurse -Force
            }
            if ([bool]$entry.existed -and $entry.snapshot -and (Test-Path -LiteralPath ([string]$entry.snapshot))) {
                Copy-PathExact ([string]$entry.snapshot) $target
            }
        } catch { Write-Warning "恢复失败后的自动回滚也失败：$($entry.target) - $($_.Exception.Message)" }
    }
    try { Write-Utf8NoBomAtomic $Pointer $OriginalPointer } catch { Write-Warning "恢复备份指针失败：$($_.Exception.Message)" }
}

try {
    if (Test-IsReparsePoint $KitDataRoot) { throw "AgentKit 数据根目录不能是 reparse point：$KitDataRoot" }
    if (Test-IsReparsePoint $BackupsRoot) { throw "AgentKit backups 目录不能是 reparse point：$BackupsRoot" }
    if (-not (Test-Path -LiteralPath $Pointer -PathType Leaf)) { throw '未找到最近一次成功安装的备份指针。' }
    if (Test-IsReparsePoint $Pointer) { throw "备份指针不能是 reparse point：$Pointer" }
    $OriginalPointer = Read-Utf8Text $Pointer
    $BackupRoot = $OriginalPointer.Trim()
    if ([string]::IsNullOrWhiteSpace($BackupRoot)) { throw '备份指针为空。' }
    $BackupRoot = [System.IO.Path]::GetFullPath($BackupRoot)
    if (-not (Test-PathWithin $BackupRoot $BackupsRoot) -or $BackupRoot.TrimEnd([char[]]@('\','/')).Equals([System.IO.Path]::GetFullPath($BackupsRoot).TrimEnd([char[]]@('\','/')), [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "拒绝恢复：备份目录不在 %LOCALAPPDATA%\AgentKit\backups 下：$BackupRoot"
    }
    if (-not (Test-Path -LiteralPath $BackupRoot -PathType Container)) { throw "备份目录不存在：$BackupRoot" }
    Assert-NoReparseTree $BackupRoot '备份目录'

    $ManifestPath = Join-Path $BackupRoot 'manifest.json'
    if (-not (Test-Path -LiteralPath $ManifestPath -PathType Leaf)) { throw "未找到备份清单：$ManifestPath" }
    $entries = @((Read-Utf8Text $ManifestPath) | ConvertFrom-Json)
    if ($entries.Count -eq 0) { throw '备份清单为空，没有可恢复的变更。' }

    $previousPointerFile = Join-Path $BackupRoot 'previous-pointer.txt'
    $previousPointerText = ''
    if (Test-Path -LiteralPath $previousPointerFile -PathType Leaf) {
        $previousPointerText = Read-Utf8Text $previousPointerFile
        $previousPointerPath = $previousPointerText.Trim()
        if ($previousPointerPath) {
            $previousPointerPath = [System.IO.Path]::GetFullPath($previousPointerPath)
            if (-not (Test-PathWithin $previousPointerPath $BackupsRoot)) { throw "previous-pointer.txt 指向 AgentKit 备份目录之外：$previousPointerPath" }
        }
    }

    foreach ($entry in $entries) {
        $kind = [string]$entry.kind
        $target = [string]$entry.target
        $backup = if ($null -eq $entry.backup) { '' } else { [string]$entry.backup }
        if ($kind -notin @('file','directory','move')) { throw "备份清单包含未知 kind：$kind" }
        if ([string]::IsNullOrWhiteSpace($target)) { throw '备份清单包含空目标路径。' }
        if ($backup) {
            $backupFull = [System.IO.Path]::GetFullPath($backup)
            if ($kind -eq 'move') {
                $legacyRootFull = [System.IO.Path]::GetFullPath($LegacyArchiveRoot).TrimEnd([char[]]@('\','/'))
                $candidateFull = $backupFull.TrimEnd([char[]]@('\','/'))
                if (-not (Test-PathWithin $backupFull $LegacyArchiveRoot) -or $candidateFull.Equals($legacyRootFull, [System.StringComparison]::OrdinalIgnoreCase)) { throw "move 备份越出或等于 legacy-v2-backups 根目录：$backupFull" }
            } else {
                $backupRootFull = $BackupRoot.TrimEnd([char[]]@('\','/'))
                $candidateFull = $backupFull.TrimEnd([char[]]@('\','/'))
                if (-not (Test-PathWithin $backupFull $BackupRoot) -or $candidateFull.Equals($backupRootFull, [System.StringComparison]::OrdinalIgnoreCase)) { throw "备份文件越出或等于当前备份根目录：$backupFull" }
            }
            if (-not (Test-Path -LiteralPath $backupFull)) { throw "备份缺失，尚未执行任何恢复：$backupFull" }
            Assert-NoReparseTree $backupFull '备份内容'
        }
    }

    Ensure-Dir $RestoreSafetyRoot
    Write-Utf8NoBomAtomic (Join-Path $RestoreSafetyRoot 'pointer-before.txt') $OriginalPointer
    for ($i = 0; $i -lt $entries.Count; $i++) { Snapshot-CurrentTarget ([string]$entries[$i].target) $i }

    for ($i = $entries.Count - 1; $i -ge 0; $i--) {
        $entry = $entries[$i]
        $target = [string]$entry.target
        $backup = if ($null -eq $entry.backup) { '' } else { [string]$entry.backup }
        if (Test-Path -LiteralPath $target) {
            Assert-NoReparseTree $target '恢复目标'
            Remove-Item -LiteralPath $target -Recurse -Force
        }
        if ($backup) {
            Copy-PathExact $backup $target
            Write-Host "已恢复：$target"
        } else {
            Write-Host "已移除本套件新建项：$target"
        }
    }

    if ($previousPointerText.Trim()) {
        $previousPointerPath = [System.IO.Path]::GetFullPath($previousPointerText.Trim())
        if (Test-Path -LiteralPath $previousPointerPath -PathType Container) { Write-Utf8NoBomAtomic $Pointer ($previousPointerPath + [Environment]::NewLine) }
        elseif (Test-Path -LiteralPath $Pointer) { Remove-Item -LiteralPath $Pointer -Force }
    } elseif (Test-Path -LiteralPath $Pointer) {
        Remove-Item -LiteralPath $Pointer -Force
    }

    $script:RestoreCommitted = $true
} catch {
    $script:FailureMessage = $_.Exception.Message
} finally {
    if (-not $script:RestoreCommitted -and $script:RestoreSnapshots.Count -gt 0) { Rollback-RestoreAttempt }
}

if (-not $script:RestoreCommitted) {
    Write-Host ''
    if ([string]::IsNullOrWhiteSpace($script:FailureMessage)) { $script:FailureMessage = '恢复被中断或未提交。' }
    Write-Host "恢复失败：$($script:FailureMessage)" -ForegroundColor Red
    Write-Host "恢复前安全快照保留在：$RestoreSafetyRoot"
    Write-Host '原备份指针已保留，可修复问题后重试。'
    exit 1
}

Write-Host ''
Write-Host "恢复完成：$BackupRoot" -ForegroundColor Green
Write-Host "恢复前安全快照保留在：$RestoreSafetyRoot"
Write-Host '原备份目录未被消耗；请重新打开 Agent 会话。'
exit 0
