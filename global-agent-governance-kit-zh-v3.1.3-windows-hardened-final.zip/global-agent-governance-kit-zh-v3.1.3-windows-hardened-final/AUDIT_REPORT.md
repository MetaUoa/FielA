# v3.1.3 Windows Hardened Frozen Final 审计报告

## 结论

v3.1.3 **不改治理正文**。`policy/`、`platform/`、`skills/`、`templates/` 与 v3.1.2 保持相同内容；本版只修复/加固 7 个 Windows 脚本，更新 `VERSION.txt`、README、审计报告并重算 `PACKAGE_MANIFEST.json`。

## 对外部审计意见的复核

外部审计指出的多数“脚本鲁棒性”问题成立并已加固，但其中两项严重结论并不准确：

1. PowerShell FileSystem provider 在 Windows 上允许使用反斜杠或正斜杠，因此 `pi/AGENTS.md` 本身并不会因为 `/` 就必然让 `Split-Path` 失效。v3.1.3 仍统一把备份 key 规范化为 Windows 相对路径，以消除歧义。
2. .NET Framework 的 `System.IO.File.ReadAllText(path)` 默认使用 UTF-8，而不是 Windows ANSI/GBK。v3.1.3 仍改为显式严格 UTF-8，避免依赖隐式默认并能对无效 UTF-8 直接报错。

## 已确认并修复/加固

- 备份 key 规范化、拒绝绝对路径/`..`/越界。
- 版本号从 `VERSION.txt` 单一读取，移除 install/verify 的硬编码版本。
- 受管文本显式严格 UTF-8 读取；用户规则 UTF-8 no-BOM 原子写入。
- 目录复制改为 exact-copy helper，消除已有目标目录时的嵌套语义不确定性。
- 托管 BEGIN/END 标记必须 0/0 或恰好 1/1 且顺序正确，否则拒绝修改。
- 控制字符扫描仅针对 manifest 登记文本；用户额外无关文本不再阻断安装。
- Skills 实际 payload 拒绝未登记文件，防止额外内容被复制进用户 Skill 目录。
- `.cmd` 固定系统 Windows PowerShell 5.1，切 UTF-8 code page，并支持 `/nopause` / `AGENTKIT_NO_PAUSE=1`。
- install 使用 `finally` 保证 `Ctrl+C` 也进入本次事务回滚路径。
- reparse point 防护覆盖将被递归处理的源/目标，避免 symlink/junction 越界。
- 旧备份归档改为 copy-then-remove；失败回滚不依赖跨卷 Move 的中间状态。
- restore 限制备份根目录、校验备份字段范围、恢复前创建安全快照、失败时反向恢复快照。
- restore 不再用一次性 Move 消耗 legacy archive，失败后可重试。

## 未做的“过度加固”

- 不自动执行 `Unblock-File`。启动器已经显式使用系统 Windows PowerShell + `-ExecutionPolicy Bypass`；AppLocker/WDAC/组织安全策略应继续生效，不应由本套件主动绕过。
- 不增加更多治理规则、Skill 或审批逻辑；本版是脚本层修复，不重新扩张 Astra 常驻上下文。

## 静态打包检查

最终包要求：

- `.cmd`：ASCII + CRLF；
- `.ps1`：UTF-8 BOM + CRLF；
- manifest 中每个文件 SHA-256 和大小匹配；
- manifest 文本文件均可按严格 UTF-8 解码且无异常 C0 控制字符；
- `skills/` 不含未登记文件；
- install/verify 不硬编码版本；
- install 含 marker guard、safe backup path、`finally` rollback；
- restore 含 backup-root containment、restore-safety、`finally` rollback；
- CMD 固定系统 Windows PowerShell 5.1，并支持 no-pause。

## 环境边界

当前打包环境不是 Windows，无法在此处真实启动 Windows PowerShell 5.1 或三个 Agent CLI。因此最终包仍在目标 Windows 上、任何用户配置修改之前使用 Windows PowerShell 自身 Parser 做语法预检；`verify.cmd` 用于安装后的实际一致性检查。
