# 全局 Agent 治理套件：中文 Windows Hardened Frozen Final v3.1.3

这是面向 Windows 10/11 的全局 Agent 治理包，统一 Pi、Codex、Claude Code 的默认工作方式。

**v3.1.3 不修改 v3.1.2 的治理规则、Skills 或平台入口正文。** 本版只加固 Windows 安装、验证与恢复脚本，并把版本号改为由 `VERSION.txt` 单一驱动。

## 最终运行结构

```text
~/.pi/agent/AGENTS.md                   Pi 全局规则
~/.pi/agent/prompts/agentkit-*.md      Pi 可选轻量 Prompt
$CODEX_HOME/AGENTS.md                  Codex 全局规则
~/.codex/AGENTS.md                     未设置 CODEX_HOME 时默认位置
~/.claude/CLAUDE.md                    Claude Code 全局规则
~/.agents/skills/agentkit-*/           Pi / Codex 用户级 Skills
~/.claude/skills/agentkit-*/           Claude Code 用户级 Skills
%LOCALAPPDATA%/AgentKit/               安装状态、备份和恢复安全快照
```

不会创建或依赖 `~/.agent-global/`。

## v3.1.3 脚本加固

- `install.ps1` / `verify.ps1` 不再硬编码版本号，统一读取 `VERSION.txt`。
- 文本读取显式使用严格 UTF-8；用户规则写入使用 UTF-8 no-BOM 原子替换。
- 备份 key 统一规范化为 Windows 相对路径，并限制在当前备份根目录内。
- 目录备份/恢复使用“精确复制”，不依赖 `Copy-Item -Recurse` 在已有目标上的容器语义。
- 写入 `AGENTKIT` 托管块前检查 BEGIN/END 是否成对、唯一且顺序正确；异常时拒绝自动改写。
- 文本控制字符检查只扫描 `PACKAGE_MANIFEST.json` 登记的包文件，不会因为用户在解压目录旁边放了无关 `.txt` 而阻断安装。
- `skills/` 是实际会被复制的受管 payload，因此拒绝未登记文件。
- 三个 `.cmd` 固定调用 `%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe`，先切换 code page 65001；不依赖 PATH 中可能被替换的 `powershell.exe`。
- `.cmd` 支持 `/nopause`，也支持环境变量 `AGENTKIT_NO_PAUSE=1`；双击时仍默认暂停，方便查看结果。
- 安装主事务使用 `finally`：PowerShell 在 `Ctrl+C` 时也会执行 `finally`，因此已登记修改会进入回滚路径。
- 对将被递归备份、删除或覆盖的目标检查 reparse point（符号链接/junction）；发现后拒绝自动处理，避免跨目录误操作。
- 文件覆盖采用“备份 -> 登记 -> 原子替换”，只读普通文件可由 `-Force` 删除后重新创建；不会跟随 reparse point。
- 旧版备份归档改为“复制成功后再删除源”，不再依赖跨卷 `Move-Item` 的部分移动语义。
- `restore-latest.ps1` 限制备份指针必须位于 `%LOCALAPPDATA%\AgentKit\backups\` 下，并校验 manifest 中普通备份/legacy archive 的允许范围。
- 恢复前先把当前目标做成 `%LOCALAPPDATA%\AgentKit\restore-safety\...` 安全快照；恢复失败或 `Ctrl+C` 时从该快照回滚。
- 恢复旧 `move` 项时使用复制，不消耗原归档备份，因此失败后可重试。

> `Zone.Identifier` 不会被自动清除。启动器使用 `-ExecutionPolicy Bypass` 解决普通 ExecutionPolicy/MOTW 场景，但不会尝试绕过 AppLocker、WDAC 或组织级安全策略。

## 安装 / 升级

无需先卸载 v3.0 / v3.1.x：

1. 完整解压本 ZIP 到一个新目录；
2. 双击 `install-all.cmd`；
3. 安装完成后双击 `verify.cmd`；
4. 验证通过后重新打开 Pi / Codex / Claude Code；Pi 也可以执行 `/reload`。

命令行无人值守时可使用：

```cmd
install-all.cmd /nopause
verify.cmd /nopause
```

或：

```cmd
set AGENTKIT_NO_PAUSE=1
install-all.cmd
verify.cmd
```

## 备份与恢复

安装状态与安装前备份：

```text
%LOCALAPPDATA%\AgentKit\state.json
%LOCALAPPDATA%\AgentKit\last-backup.txt
%LOCALAPPDATA%\AgentKit\backups\...
```

执行：

```text
restore-latest.cmd
```

恢复器会：

1. 验证 `last-backup.txt` 只能指向 AgentKit 自己的 `backups` 目录；
2. 预检所有备份；
3. 为当前状态创建 `restore-safety` 快照；
4. 执行恢复；
5. 若中途失败或被 `Ctrl+C` 中断，尝试恢复到执行恢复之前的状态。

原安装备份不会因恢复而被消费。

## 包内目录

```text
policy/                规则源码与设计参考；不安装为运行时目录
platform/              Pi / Codex / Claude 的精简原生入口
skills/                7 个 namespaced 窄触发 Skills
templates/             项目差异 / 任务 / Skill 模板
scripts/               包自检辅助脚本
install-all.cmd        一键完整安装
install.ps1            事务安装器
verify.cmd             一键完整验证
verify.ps1             验证器
restore-latest.cmd     一键恢复
restore-latest.ps1     事务恢复器
VERSION.txt            版本单一来源
PACKAGE_MANIFEST.json  SHA-256 / 大小清单
AUDIT_REPORT.md        本版审计报告
```

## 治理设计保持不变

- 常驻规则只保留目标、上下文、权限边界、最低充分验证与 Done；
- Skill 使用短、窄 description，并按需加载 `SKILL.md` / `references/`；
- 简单任务直接执行，复杂/高风险/确有并行收益时才规划或使用子 Agent；
- 低风险、本地、可逆操作默认自主；真实外部副作用和不可逆高风险操作再确认；
- 不为了流程完整而重复测试、重复读文档或强制 Review。

设计依据继续是 OpenAI《Rethinking skills and prompts for GPT-6 Astra》以及各平台当前原生规则/Skill 机制。
