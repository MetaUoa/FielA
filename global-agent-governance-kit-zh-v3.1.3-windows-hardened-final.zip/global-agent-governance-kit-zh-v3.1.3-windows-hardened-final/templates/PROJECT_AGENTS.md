# 项目差异规则

全局规则已生效。本文件只写当前项目与全局默认**真正不同**的内容；没有差异就不创建。

## 上下文路由

- 涉及服务/模块边界时：按需阅读 `<architecture-doc>`
- 涉及持久化 Schema 时：按需阅读 `<database-doc>`
- 准备发布/部署时：按需阅读 `<deployment-doc>`

删除无关条目；不要要求所有任务无条件读取全部文档。

## 项目命令

- Test：`<command>`
- Lint：`<command>`
- Type check：`<command>`
- Build：`<command>`

只保留项目真实存在的命令。

## 项目特有约束

- `<公共 API / generated 文件 / 支持运行时 / 禁区 / 特有安全边界>`

## 项目特有完成标准

- `<只写全局 Done 之外确实需要增加的标准>`
