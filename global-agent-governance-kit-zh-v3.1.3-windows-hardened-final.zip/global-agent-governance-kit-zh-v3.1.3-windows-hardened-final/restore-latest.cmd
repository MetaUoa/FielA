@echo off
setlocal
chcp 65001 >nul 2>&1
pushd "%~dp0"
set "PS51=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
set "NOPAUSE=0"
if /I "%~1"=="/nopause" set "NOPAUSE=1"
if "%AGENTKIT_NO_PAUSE%"=="1" set "NOPAUSE=1"
if not exist "%PS51%" (
  echo System Windows PowerShell 5.1 was not found: "%PS51%"
  set "RC=9009"
  goto :done
)
"%PS51%" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0restore-latest.ps1"
set "RC=%ERRORLEVEL%"
:done
popd
if not "%RC%"=="0" echo Restore failed. Error code: %RC%
if "%RC%"=="0" echo Restore completed.
if "%NOPAUSE%"=="0" pause
exit /b %RC%
