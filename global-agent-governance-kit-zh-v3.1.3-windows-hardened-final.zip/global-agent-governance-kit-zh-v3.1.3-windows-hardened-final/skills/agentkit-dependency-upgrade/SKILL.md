---
name: agentkit-dependency-upgrade
description: 升级依赖、运行时、编译器、SDK、锁文件或工具链并评估兼容性时使用。
---
# 依赖升级

目标：完成明确的版本升级，把兼容风险和无关变更控制在最小范围。

- 明确当前版本、目标版本和受影响依赖面。
- 非平凡升级时优先检查官方 release notes / migration guidance。
- 保持 manifest 与 lockfile 一致，检查被移除或弃用的 API。
- 根据影响选择必要的 build、type、test、startup/smoke 证据。
- 区分升级引入的问题与历史已有失败。

不要把一次定向升级悄悄扩展成“顺便更新全部依赖”。
