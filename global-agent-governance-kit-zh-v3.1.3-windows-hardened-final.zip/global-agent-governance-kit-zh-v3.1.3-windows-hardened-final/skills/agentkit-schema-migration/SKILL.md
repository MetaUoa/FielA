---
name: agentkit-schema-migration
description: 创建或评审持久化 Schema 迁移、回滚或前后版本兼容策略时使用。
---
# Schema / 数据迁移

持久化数据变更默认按高风险处理。根据当前迁移实际需要关注：兼容窗口、backfill/转换、锁与停机风险、幂等/重试、失败恢复和迁移后数据验证。

- 真正需要回滚设计时读取 `references/rollback.md`。
- 新旧应用版本可能并存时读取 `references/zero-downtime.md`。
- 不因“用了数据库”而预读这些参考资料。

未经当前请求明确授权，不对生产环境执行迁移。
