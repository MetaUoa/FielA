# 回滚判断

只在迁移确实需要回滚设计时读取。

判断：

- 旧应用能否安全读取新 Schema；
- 数据转换是否可逆，是否会丢失新写入；
- down migration 是否比 roll-forward 更危险；
- 回滚期间是否需要停止写入或双写；
- 回滚后如何验证数据和应用状态。

不要为了“必须有 rollback”而编造不可执行的 down migration。若安全策略是 roll-forward，明确触发条件、恢复路径和可观察证据。
