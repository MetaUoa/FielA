---
name: agentkit-git-change-hygiene
description: 准备提交/PR、处理脏工作区或保护已有本地修改时使用；仅因项目使用 Git 不触发。
---
# Git 变更保护

目标：让当前任务差异清晰、可交付，同时保护用户已有工作。

- 在可能覆盖或重写内容前检查相关 status / diff。
- 保留与任务无关的用户修改，不用 reset/clean 代替精确处理。
- 提交或 PR 差异保持内聚，避免夹带凭据、生成噪声和无关文件。
- hard reset、clean、force push、历史重写等高破坏操作遵循全局确认边界。

用户修改与任务修改真实冲突时，先尝试安全绕开；无法安全消解再请求决定。
