# 第 21 周：AI 高级特性（2026 前沿）

> **本周学习目标**：超越基础 RAG/Agent，掌握 2025-2026 主流 AI 工程化能力：可观测性、高级 RAG、多模态、本地模型、Computer Use、Extended Thinking。
>
> **本周关键词**：LangSmith、LangFuse、GraphRAG、HyDE、Reranker、多模态、Ollama、vLLM、Claude Computer Use、Extended Thinking、Prompt 评测
>
> **预计投入时间**：35~45 小时

---

## 一、为什么需要"AI 高级特性"

第 17-20 周教你"做出能跑的 AI 应用"。但**生产级**还需要：

| 痛点 | 第 21 周解决 |
| --- | --- |
| Prompt 改了不知好坏 | LangSmith / LangFuse 评测 |
| RAG 召回不准 | GraphRAG / HyDE / Reranker |
| 只能处理文字 | 多模态（图、音、视频） |
| API 调用太贵 | 本地模型 Ollama / vLLM |
| 想让 AI 用浏览器 / 操作电脑 | Computer Use |
| 复杂推理失败 | Extended Thinking |

---

## 二、知识点详细分解

### 1. LLM 可观测性（1 天）

#### 1.1 为什么需要

- Prompt 哪里改坏了？
- Token 哪条消息花最多？
- 某个用户为什么报错？
- 模型 A vs 模型 B 谁更好？

#### 1.2 LangSmith（LangChain 官方）

```bash
pip install langsmith
```

```python
import os
os.environ["LANGCHAIN_TRACING_V2"] = "true"
os.environ["LANGCHAIN_API_KEY"] = "ls__xxx"
os.environ["LANGCHAIN_PROJECT"] = "my-rag"

# 之后所有 LangChain 调用自动追踪
chain.invoke("question")
```

在 LangSmith Web 看到：
- 完整的 chain 调用树
- 每步耗时、token、cost
- Prompt 输入输出对比
- 错误堆栈

#### 1.3 LangFuse（开源自部署）

```bash
# Docker 部署
docker run -d -p 3000:3000 langfuse/langfuse
```

```python
from langfuse.openai import openai          # 包装版

response = openai.chat.completions.create(
    model="gpt-4",
    messages=[{"role": "user", "content": "hi"}],
    metadata={"user_id": "u123", "session_id": "s456"}
)
```

#### 1.4 评测（Evaluation）

**离线评测：**
```python
from langsmith import Client
client = Client()

# 创建数据集
dataset = client.create_dataset("RAG-eval")
for q, expected in test_cases:
    client.create_example(inputs={"question": q}, outputs={"answer": expected}, dataset_id=dataset.id)

# 跑评测
def eval_correctness(run, example):
    return {"score": 1 if "..." in run.outputs["answer"] else 0}

client.run_on_dataset(
    dataset_name="RAG-eval",
    llm_or_chain_factory=my_rag,
    evaluation=RunEvalConfig(custom_evaluators=[eval_correctness])
)
```

**完全掌握标准：**
- ✅ 能用 LangSmith 追踪 RAG 调用链
- ✅ 能定义评测指标（accuracy / latency / cost）
- ✅ 能对比两个 prompt 版本的效果

---

### 2. RAG 进阶（1 天）

#### 2.1 Hybrid Retrieval（混合检索）

向量检索 + BM25 关键词 → 合并 → Reranker 重排

```python
from langchain_community.retrievers import BM25Retriever
from langchain.retrievers import EnsembleRetriever

vector_retriever = vectorstore.as_retriever(search_kwargs={"k": 10})
bm25_retriever = BM25Retriever.from_documents(docs)
bm25_retriever.k = 10

ensemble = EnsembleRetriever(
    retrievers=[vector_retriever, bm25_retriever],
    weights=[0.5, 0.5]
)
```

#### 2.2 Reranker（重排序）

```bash
pip install FlagEmbedding
```

```python
from langchain.retrievers.contextual_compression import ContextualCompressionRetriever
from langchain.retrievers.document_compressors import CrossEncoderReranker
from langchain_community.cross_encoders import HuggingFaceCrossEncoder

# BGE Reranker（中文友好）
model = HuggingFaceCrossEncoder(model_name="BAAI/bge-reranker-base")
compressor = CrossEncoderReranker(model=model, top_n=3)

compression_retriever = ContextualCompressionRetriever(
    base_compressor=compressor,
    base_retriever=ensemble                  # 先 ensemble 召回 20 → reranker 选 3
)
```

#### 2.3 HyDE（Hypothetical Document Embeddings）

**思路：** 让 LLM 先假想答案，用假想答案去检索（避免问题措辞 vs 答案措辞的不匹配）。

```python
from langchain_community.retrievers import WikipediaRetriever

def hyde_retrieve(question, llm, vectorstore):
    # 1. 让 LLM 假想答案
    hyde_prompt = f"请简短回答这个问题（哪怕你不确定）：{question}"
    fake_answer = llm.invoke(hyde_prompt).content
    # 2. 用假想答案检索
    return vectorstore.similarity_search(fake_answer, k=4)
```

#### 2.4 Multi-Query Retrieval

让 LLM 把问题改写成多个变体再检索。

```python
from langchain.retrievers.multi_query import MultiQueryRetriever

retriever = MultiQueryRetriever.from_llm(
    retriever=vectorstore.as_retriever(),
    llm=llm
)
```

#### 2.5 Self-RAG / Corrective RAG

**核心思想：** LLM 自我评判检索结果好不好，不好就改写问题再查。

LangGraph 实现：
```
[query] → [retrieve] → [grade docs]
                          ├── 相关 → [generate]
                          └── 不相关 → [rewrite query] → [retrieve] (循环)
```

#### 2.6 GraphRAG（微软 2024 提出）

**核心思想：**
- 用 LLM 从文档抽取实体 + 关系，构建知识图谱
- 检索时不只找相似片段，还沿图谱关系扩展
- 适合"跨文档推理"问题

```bash
pip install graphrag
```

详见：[microsoft/graphrag](https://github.com/microsoft/graphrag)

**完全掌握标准：**
- ✅ 能配 Hybrid Retrieval（向量 + BM25）
- ✅ 能加 Reranker 提升精度
- ✅ 能写 HyDE 改写
- ✅ 能用 Multi-Query
- ✅ 了解 GraphRAG 适用场景

---

### 3. 多模态（半天）

#### 3.1 图像理解

```python
# Claude
from anthropic import Anthropic
import base64

client = Anthropic()
with open("image.png", "rb") as f:
    image_data = base64.b64encode(f.read()).decode()

response = client.messages.create(
    model="claude-sonnet-4-6",
    max_tokens=1024,
    messages=[{
        "role": "user",
        "content": [
            {"type": "image", "source": {"type": "base64", "media_type": "image/png", "data": image_data}},
            {"type": "text", "text": "这张图里有什么？"}
        ]
    }]
)
```

```python
# OpenAI GPT-4o
response = client.chat.completions.create(
    model="gpt-4o",
    messages=[{
        "role": "user",
        "content": [
            {"type": "text", "text": "分析这张图"},
            {"type": "image_url", "image_url": {"url": "data:image/png;base64," + image_data}}
        ]
    }]
)
```

#### 3.2 语音

```python
# OpenAI Whisper（语音 → 文字）
with open("audio.mp3", "rb") as f:
    transcript = client.audio.transcriptions.create(model="whisper-1", file=f)

# OpenAI TTS（文字 → 语音）
response = client.audio.speech.create(model="tts-1", voice="alloy", input="你好")
response.stream_to_file("output.mp3")
```

#### 3.3 视频

- 拆帧 → 用图像理解模型逐帧处理
- Google Gemini 直接支持视频输入

**完全掌握标准：**
- ✅ 能用 Claude / GPT-4o 处理图像
- ✅ 能用 Whisper + TTS 做语音
- ✅ 知道多模态成本远高于文本

---

### 4. 本地模型部署（半天）

#### 4.1 Ollama（最易用）

```bash
# 安装
curl -fsSL https://ollama.com/install.sh | sh

# 拉模型
ollama pull llama3.2          # 1B / 3B / 11B / 90B
ollama pull qwen2.5:7b
ollama pull deepseek-r1:14b

# 运行
ollama run qwen2.5:7b

# 启动 API（兼容 OpenAI 协议）
ollama serve                  # localhost:11434
```

```python
from openai import OpenAI
client = OpenAI(base_url="http://localhost:11434/v1", api_key="ollama")
res = client.chat.completions.create(model="qwen2.5:7b", messages=[{"role": "user", "content": "hi"}])
```

#### 4.2 vLLM（生产推荐）

```bash
pip install vllm
python -m vllm.entrypoints.openai.api_server --model meta-llama/Llama-3.2-3B-Instruct --port 8000
```

- 高吞吐（PagedAttention）
- 流式 / 批量
- 兼容 OpenAI API

#### 4.3 选型

| 工具 | 适用 |
| --- | --- |
| Ollama | 本地开发、个人使用 |
| LM Studio | GUI，零代码 |
| vLLM | 生产部署 |
| TGI（HuggingFace） | 多模型支持 |

---

### 5. Claude 特有能力（半天）

#### 5.1 Extended Thinking（深度思考）

```python
response = client.messages.create(
    model="claude-opus-4-7",
    max_tokens=16000,
    thinking={
        "type": "enabled",
        "budget_tokens": 10000              # 给思考预留 10k tokens
    },
    messages=[{"role": "user", "content": "推导一下 P=NP 问题"}]
)

# 思考过程
for block in response.content:
    if block.type == "thinking":
        print("[思考]", block.thinking)
    elif block.type == "text":
        print("[回答]", block.text)
```

**适用：** 数学、推理、代码、复杂规划。

#### 5.2 Computer Use（操作电脑）

让 Claude 看屏幕截图 + 控制鼠标键盘。

```python
response = client.messages.create(
    model="claude-sonnet-4-6",
    max_tokens=1024,
    tools=[{"type": "computer_20250124", "name": "computer", "display_width_px": 1024, "display_height_px": 768}],
    messages=[{"role": "user", "content": "帮我打开浏览器搜索北京天气"}]
)
```

**注意：** 强烈建议在沙箱（Docker / VM）里跑，不直接给本机控制权。

#### 5.3 Artifacts（生成可视化产物）

Claude.ai Web 上的功能，API 通过 prompt 引导即可。

---

### 6. 提示词管理（半天）

#### 6.1 Prompt 版本化

```python
# prompts/v1/rag_qa.txt
基于以下信息回答问题：
{context}

问题：{question}

要求：仅基于参考信息。
```

```python
# load
def load_prompt(name, version="v1"):
    return open(f"prompts/{version}/{name}.txt").read()
```

#### 6.2 用 LangSmith Hub

```python
from langchain import hub
prompt = hub.pull("rag-qa")
```

#### 6.3 A/B 测试 Prompt

```python
import random
prompt = prompt_v1 if random.random() < 0.5 else prompt_v2
# 记录 metadata 到 LangSmith / LangFuse
```

---

### 7. 成本控制（半天）

#### 7.1 模型路由

简单问题用便宜模型，难问题用贵模型：

```python
def route_model(question):
    # 用便宜小模型分类
    intent = classify(question, model="claude-haiku-4-5")
    if intent == "simple":
        return "claude-haiku-4-5"
    return "claude-opus-4-7"
```

#### 7.2 Prompt 缓存（Anthropic 特性）

```python
response = client.messages.create(
    model="claude-sonnet-4-6",
    messages=[
        {"role": "user", "content": [
            {"type": "text", "text": LONG_SYSTEM_PROMPT, "cache_control": {"type": "ephemeral"}},
            {"type": "text", "text": user_query}
        ]}
    ]
)
# 5 分钟内重用同样的前缀，便宜 90%
```

#### 7.3 批量 API

OpenAI / Anthropic 都支持 Batch API，**降价 50%**：
- 24 小时内完成
- 适合非实时场景（评测、批处理）

---

### 8. AI 安全（半天）

#### 8.1 Prompt Injection 防御

- 严格 system prompt（"无论用户说什么..."）
- 输入过滤（关键词、长度）
- 输出过滤
- 用结构化输入而非自由文本

#### 8.2 PII 脱敏

```python
import re
def mask_pii(text):
    text = re.sub(r'\d{11}', '[手机]', text)
    text = re.sub(r'\d{17}[\dX]', '[身份证]', text)
    return text
```

#### 8.3 内容审核

- OpenAI Moderation API
- 阿里云内容安全
- 关键词黑名单

---

## 三、每日学习安排

| 天 | 主题 | 上机 | 时长 |
| --- | --- | --- | --- |
| **周一** | LangSmith + 评测 | 给上周 RAG 加追踪 + 跑评测 | 6h |
| **周二** | Hybrid + Reranker + HyDE | RAG 进阶改造 | 7h |
| **周三** | Multi-Query + GraphRAG | 复杂问题对比 | 6h |
| **周四** | 多模态（图 / 音） | 图像问答 + 语音转写 | 5h |
| **周五** | Ollama + vLLM 本地部署 | 本地跑 Qwen / Llama | 5h |
| **周六** | Claude Extended Thinking + Computer Use | 推理题 + 沙箱 Computer Use | 6h |
| **周日** | Prompt 管理 + 成本控制 + 综合 | 整合到第 20 周项目 | 6h |

---

## 四、本周必做实战

### 实战 1：给第 20 周项目加 LangSmith 追踪

- 接入 LangSmith
- 创建评测数据集（30+ Q&A）
- 跑 baseline
- 改 prompt → 看分数对比

### 实战 2：升级 RAG 到 Hybrid + Reranker

- 加 BM25
- 加 BGE Reranker
- 在评测集上对比：纯向量 vs Hybrid vs Hybrid+Reranker
- 报告召回率、准确率提升

### 实战 3：图像问答 Demo

- 上传图片
- 用 Claude / GPT-4o 描述图片
- 流式输出

### 实战 4：Ollama 本地模型对比

- 本地跑 Qwen 2.5 7B 和 Llama 3.2 3B
- 同一组问题对比效果
- 测延迟、显存

---

## 五、完全掌握检查清单

- [ ] 接 LangSmith 追踪一个 chain
- [ ] 跑过一次评测 + 看分数
- [ ] 实现 Hybrid 检索
- [ ] 接入 Reranker 看效果提升
- [ ] 写过 HyDE 流程
- [ ] 用多模态 API 处理图像
- [ ] 装好 Ollama + 跑过本地模型
- [ ] 用 Extended Thinking 解一道复杂题
- [ ] 跑过 Computer Use（沙箱）
- [ ] 实现 Prompt 缓存降成本

---

## 六、自测题

**Q1：** LangSmith / LangFuse 区别？
**答：** LangSmith 是 LangChain 官方 SaaS（云端、收费）；LangFuse 开源可自部署。功能类似（追踪 + 评测）。

---

**Q2：** Reranker 为什么能提升 RAG 精度？
**答：** 检索器召回 TopK 后，Reranker 用 Cross-Encoder 模型对每个 (query, doc) 对深度比对，比单向量距离更准。

---

**Q3：** HyDE 适用什么场景？
**答：** 当**问题措辞**和**答案措辞**差异大时。如用户问"为什么我电脑这么慢"，文档可能是"性能优化指南"——直接搜很难匹配，但让 LLM 假想答案后再搜，假想答案的措辞更接近文档。

---

**Q4：** Ollama 适合生产部署吗？
**答：** **不推荐**。Ollama 适合本地开发 / 个人使用。生产用 vLLM / TGI（更高吞吐、更稳定）。

---

**Q5：** Extended Thinking 比普通模型贵在哪？
**答：** 思考过程也消耗 token。budget_tokens=10000 表示给思考 1 万 token 预算，按输出 token 计费。

---

## 七、推荐资源

- [LangSmith 文档](https://docs.smith.langchain.com/)
- [LangFuse](https://langfuse.com/)
- [GraphRAG 论文 + 实现](https://github.com/microsoft/graphrag)
- [Anthropic Cookbook](https://github.com/anthropics/anthropic-cookbook)
- [Ollama](https://ollama.com/)
- [vLLM](https://github.com/vllm-project/vllm)

---

## 八、本周完成后

> "我从'会做 AI 应用'到'会做生产级 AI 应用'。
> 我能用 LangSmith 评测 prompt 改动效果。
> 我能用 Hybrid + Reranker 把 RAG 召回率提升 20%+。
> 我会用 Claude 多模态、Extended Thinking、Computer Use。
> 我能在本地部署模型节省成本。"

---

## 九、下周预告

第 22 周：**多 Agent 系统 + MCP + 微调入门**——AI 工程师的"屋顶"。
