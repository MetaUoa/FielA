# 第 16 周：React + Ant Design + AI Chat

> **本周学习目标**：用 React 18 + Ant Design 做出 ChatGPT 风格的 AI 对话页面，为下个月接入 LLM 做前端准备。
>
> **本周关键词**：React 18、JSX、Hooks、Zustand、React Router、Ant Design、TanStack Query、流式 SSE、Markdown 渲染
>
> **预计投入时间**：35~45 小时

---

## 一、知识点详细分解

### 1. React 基础（1.5 天）

#### 1.1 创建项目

```bash
npm create vite@latest ai-chat -- --template react
cd ai-chat
pnpm install
pnpm add react-router-dom zustand axios antd @ant-design/icons
pnpm add react-markdown react-syntax-highlighter remark-gfm
pnpm add -D @types/react @types/react-dom    # TS 版本
pnpm dev
```

#### 1.2 JSX 语法

```jsx
function Hello({ name, age = 18 }) {
    return (
        <div className="hello">           {/* class → className */}
            <h1>Hello, {name}</h1>
            <p>Age: {age}</p>
            <button onClick={() => alert('hi')}>Click</button>
            {age >= 18 && <p>成年</p>}      {/* 条件渲染 */}
            {age >= 18 ? <Adult /> : <Child />}
            <ul>
                {[1, 2, 3].map(n => (
                    <li key={n}>{n}</li>     {/* 必须有 key */}
                ))}
            </ul>
        </div>
    );
}

export default Hello;
```

**JSX 规则：**
- `class` → `className`
- `for` → `htmlFor`
- 表达式用 `{}`
- 必须返回单个根元素（用 `<></>` Fragment）
- 列表必须 `key`
- 自闭合：`<img />` `<input />`

#### 1.3 Hooks 核心⭐⭐⭐

##### useState

```jsx
import { useState } from 'react';

function Counter() {
    const [count, setCount] = useState(0);
    const [user, setUser] = useState({ name: '', age: 0 });

    // 函数式更新（推荐，避免闭包陷阱）
    const inc = () => setCount(c => c + 1);

    // 更新对象要展开
    const updateName = (name) => setUser(prev => ({ ...prev, name }));

    return <button onClick={inc}>{count}</button>;
}
```

##### useEffect

```jsx
import { useEffect } from 'react';

function App() {
    const [users, setUsers] = useState([]);

    // 仅挂载时执行（空依赖数组）
    useEffect(() => {
        fetch('/api/users').then(r => r.json()).then(setUsers);
    }, []);

    // 依赖变化时执行
    useEffect(() => {
        console.log('count changed:', count);
    }, [count]);

    // 清理副作用
    useEffect(() => {
        const id = setInterval(() => console.log('tick'), 1000);
        return () => clearInterval(id);                  // 组件卸载或依赖变化前
    }, []);

    return <div>...</div>;
}
```

##### useRef

```jsx
import { useRef } from 'react';

function Form() {
    const inputRef = useRef(null);
    const countRef = useRef(0);                   // 不触发重渲染的"实例变量"

    const focus = () => inputRef.current.focus();

    return (
        <>
            <input ref={inputRef} />
            <button onClick={focus}>聚焦</button>
        </>
    );
}
```

##### useMemo + useCallback（性能优化）

```jsx
const filtered = useMemo(() => {
    return list.filter(x => x.age > 18);
}, [list]);

const handleClick = useCallback(() => {
    setCount(c => c + 1);
}, []);

// 配合 React.memo 防止子组件不必要的渲染
const MyComponent = React.memo(({ data }) => <div>{data}</div>);
```

##### 自定义 Hook

```jsx
// hooks/useFetch.js
import { useState, useEffect } from 'react';

export function useFetch(url) {
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        setLoading(true);
        fetch(url)
            .then(r => r.json())
            .then(setData)
            .catch(setError)
            .finally(() => setLoading(false));
    }, [url]);

    return { data, loading, error };
}

// 使用
function App() {
    const { data, loading } = useFetch('/api/users');
    if (loading) return <div>Loading...</div>;
    return <ul>{data.map(u => <li key={u.id}>{u.name}</li>)}</ul>;
}
```

##### 其他常用 Hook

- `useContext`：跨层数据
- `useReducer`：复杂状态（类似 Redux）
- `useLayoutEffect`：DOM 测量后同步执行
- `useId`：生成唯一 ID

**完全掌握标准：**
- ✅ 能用 useState / useEffect / useRef 写组件
- ✅ 能用 useMemo / useCallback 优化
- ✅ 能写自定义 Hook
- ✅ 知道 useState 是异步的（用函数式更新）
- ✅ 知道依赖数组的作用 + 闭包陷阱

---

### 2. React Router 6（半天）

```jsx
import {
    BrowserRouter, Routes, Route, Link, NavLink,
    useNavigate, useParams, useSearchParams, Outlet
} from 'react-router-dom';

function App() {
    return (
        <BrowserRouter>
            <Routes>
                <Route path="/" element={<Layout />}>
                    <Route index element={<Home />} />
                    <Route path="chat" element={<Chat />} />
                    <Route path="chat/:sessionId" element={<ChatDetail />} />
                    <Route path="settings/*" element={<Settings />} />
                </Route>
                <Route path="/login" element={<Login />} />
                <Route path="*" element={<NotFound />} />
            </Routes>
        </BrowserRouter>
    );
}

function Layout() {
    return (
        <div>
            <nav>
                <Link to="/">首页</Link>
                <NavLink to="/chat" className={({ isActive }) => isActive ? 'active' : ''}>对话</NavLink>
            </nav>
            <Outlet />     {/* 嵌套路由出口 */}
        </div>
    );
}

function ChatDetail() {
    const { sessionId } = useParams();
    const [params, setParams] = useSearchParams();
    const navigate = useNavigate();

    const goHome = () => navigate('/');
    const tab = params.get('tab');

    return <div>Session: {sessionId}, Tab: {tab}</div>;
}
```

**保护路由：**

```jsx
function ProtectedRoute({ children }) {
    const token = localStorage.getItem('token');
    return token ? children : <Navigate to="/login" />;
}

<Route path="/chat" element={<ProtectedRoute><Chat /></ProtectedRoute>} />
```

---

### 3. Zustand 状态管理（半天）

> 比 Redux 简单 10 倍，比 Context 性能好。

```js
// stores/chat.js
import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export const useChatStore = create(persist(
    (set, get) => ({
        messages: [],
        sessions: [],
        currentSessionId: null,

        addMessage: (msg) => set(state => ({
            messages: [...state.messages, msg]
        })),

        setMessages: (messages) => set({ messages }),

        appendToLastMessage: (delta) => set(state => {
            const messages = [...state.messages];
            const last = messages[messages.length - 1];
            messages[messages.length - 1] = { ...last, content: last.content + delta };
            return { messages };
        }),

        clearMessages: () => set({ messages: [] }),

        createSession: async (title) => {
            const session = await api.createSession(title);
            set(state => ({
                sessions: [session, ...state.sessions],
                currentSessionId: session.id,
                messages: []
            }));
        }
    }),
    { name: 'chat-storage' }                          // localStorage 持久化
));
```

```jsx
import { useChatStore } from '@/stores/chat';

function Chat() {
    // 选择性订阅（只订阅用到的，避免不必要渲染）
    const messages = useChatStore(s => s.messages);
    const addMessage = useChatStore(s => s.addMessage);

    // 也可以直接拿
    const { sessions, currentSessionId } = useChatStore();
}
```

---

### 4. Ant Design（半天）

```jsx
import {
    Button, Input, Space, Card, Avatar, Spin, Alert,
    Form, Select, message, Modal, Drawer, Dropdown, Menu,
    ConfigProvider, theme
} from 'antd';
import { SendOutlined, PlusOutlined } from '@ant-design/icons';

// 中文 + 暗黑主题
import zhCN from 'antd/locale/zh_CN';

function App() {
    return (
        <ConfigProvider
            locale={zhCN}
            theme={{
                algorithm: theme.defaultAlgorithm,    // 或 darkAlgorithm
                token: {
                    colorPrimary: '#10A37F'           // 自定义主色
                }
            }}
        >
            <Routes>...</Routes>
        </ConfigProvider>
    );
}

// 表单
function LoginForm() {
    const [form] = Form.useForm();
    const onFinish = (values) => {
        message.success('登录成功');
    };

    return (
        <Form form={form} onFinish={onFinish} layout="vertical">
            <Form.Item name="username" label="用户名" rules={[{ required: true }]}>
                <Input />
            </Form.Item>
            <Form.Item name="password" label="密码" rules={[{ required: true, min: 6 }]}>
                <Input.Password />
            </Form.Item>
            <Button type="primary" htmlType="submit" block>登录</Button>
        </Form>
    );
}

// 全局消息
message.success('保存成功');
Modal.confirm({
    title: '确认删除？',
    onOk: () => api.delete()
});
```

---

### 5. Markdown 渲染（核心⭐）

```jsx
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { oneDark } from 'react-syntax-highlighter/dist/esm/styles/prism';

function MarkdownView({ content }) {
    return (
        <ReactMarkdown
            remarkPlugins={[remarkGfm]}                       // 表格、待办列表等 GFM 扩展
            components={{
                code({ inline, className, children, ...props }) {
                    const match = /language-(\w+)/.exec(className || '');
                    return !inline && match ? (
                        <SyntaxHighlighter
                            style={oneDark}
                            language={match[1]}
                            PreTag="div"
                            {...props}
                        >
                            {String(children).replace(/\n$/, '')}
                        </SyntaxHighlighter>
                    ) : (
                        <code className={className} {...props}>{children}</code>
                    );
                }
            }}
        >
            {content}
        </ReactMarkdown>
    );
}
```

---

### 6. 流式输出（SSE，核心⭐⭐⭐）

```jsx
async function streamChat(message, onChunk, onDone, onError) {
    try {
        const res = await fetch('/api/chat/stream', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ message })
        });

        if (!res.ok) throw new Error('Network error');

        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n\n');
            buffer = lines.pop() || '';

            for (const line of lines) {
                if (!line.startsWith('data: ')) continue;
                const data = line.slice(6).trim();
                if (data === '[DONE]') { onDone(); return; }
                try {
                    const obj = JSON.parse(data);
                    onChunk(obj);
                } catch { /* 忽略解析失败 */ }
            }
        }
        onDone();
    } catch (err) {
        onError(err);
    }
}

// 使用
function ChatInput() {
    const { addMessage, appendToLastMessage } = useChatStore();
    const [input, setInput] = useState('');
    const [streaming, setStreaming] = useState(false);

    const send = async () => {
        const userMsg = { role: 'user', content: input };
        const aiMsg = { role: 'assistant', content: '' };
        addMessage(userMsg);
        addMessage(aiMsg);
        setInput('');
        setStreaming(true);

        await streamChat(
            input,
            (chunk) => {
                if (chunk.type === 'token') appendToLastMessage(chunk.data);
            },
            () => setStreaming(false),
            (err) => { console.error(err); setStreaming(false); }
        );
    };

    return (
        <div>
            <Input.TextArea value={input} onChange={e => setInput(e.target.value)}
                onPressEnter={(e) => { if (!e.shiftKey) { e.preventDefault(); send(); } }}
                disabled={streaming}
                autoSize={{ minRows: 1, maxRows: 6 }}
            />
            <Button type="primary" icon={<SendOutlined />} onClick={send} loading={streaming} />
        </div>
    );
}
```

---

### 7. TanStack Query（推荐，可选）

> 服务端状态管理神器，比手写 useFetch + loading + error 强多了。

```bash
pnpm add @tanstack/react-query
```

```jsx
import { useQuery, useMutation, QueryClient, QueryClientProvider } from '@tanstack/react-query';

const queryClient = new QueryClient();

function App() {
    return (
        <QueryClientProvider client={queryClient}>
            <Sessions />
        </QueryClientProvider>
    );
}

function Sessions() {
    // 自动缓存、自动重试、自动刷新
    const { data, isLoading, error } = useQuery({
        queryKey: ['sessions'],
        queryFn: () => api.listSessions()
    });

    const mutation = useMutation({
        mutationFn: (title) => api.createSession(title),
        onSuccess: () => queryClient.invalidateQueries({ queryKey: ['sessions'] })
    });

    if (isLoading) return <Spin />;
    if (error) return <Alert type="error" message={error.message} />;

    return (
        <div>
            {data.map(s => <div key={s.id}>{s.title}</div>)}
            <Button onClick={() => mutation.mutate('新会话')}>新建</Button>
        </div>
    );
}
```

---

## 二、每日学习安排

| 天 | 学习内容 | 上机练习 | 时长 |
| --- | --- | --- | --- |
| **周一** | JSX + 函数组件 + props | TodoList 入门 | 4h |
| **周二** | useState + useEffect + useRef ⭐ | 计数器 + 数据请求 | 6h |
| **周三** | useMemo / useCallback / 自定义 Hook | useFetch / useDebounce | 5h |
| **周四** | React Router 6 + Zustand | 路由 + 全局状态 | 6h |
| **周五** | Ant Design + Markdown 渲染 | 列表 / 表单 / Markdown 页 | 6h |
| **周六** | SSE 流式输出 ⭐⭐ | 对话 UI 雏形 | 7h |
| **周日** | 综合 + AI Chat 完整版 | 完成项目 + GitHub | 6h |

---

## 三、本周必做实战项目

### 项目：AI Chat 应用（ChatGPT 风格）

**功能：**
- 登录页（JWT）
- 主界面：左侧会话列表 + 中间对话区 + 右侧设置抽屉
- 多会话管理（新建 / 切换 / 删除 / 重命名）
- 消息列表（用户消息 + AI 消息，区分头像）
- **流式输出**（SSE，打字效果）
- Markdown 渲染（含表格、代码高亮）
- 复制 / 重新生成 / 编辑消息
- 模型切换（DeepSeek / Claude / GPT）
- 主题切换（明 / 暗）
- 响应式（PC / 平板）

**Mock 后端**：先用一个简单的 FastAPI / SpringBoot 接口（流式返回固定文本）。第 18-20 周接入真 LLM。

```python
# Mock 后端
@app.post("/api/chat/stream")
async def chat(req: dict):
    msg = req["message"]
    fake_reply = f"我收到了你的消息：『{msg}』。这是一段模拟回复，包含 **Markdown** 和代码：\n\n```python\nprint('hi')\n```"

    async def gen():
        for ch in fake_reply:
            await asyncio.sleep(0.02)
            yield f"data: {json.dumps({'type': 'token', 'data': ch})}\n\n"
        yield "data: [DONE]\n\n"

    return StreamingResponse(gen(), media_type="text/event-stream")
```

**技术要求：**
- ✅ React 18 + Vite + TypeScript（推荐）
- ✅ Zustand（持久化 sessions）
- ✅ Ant Design + 自定义主色
- ✅ react-markdown + 代码高亮
- ✅ SSE 流式
- ✅ TanStack Query（可选）

**验收：**
- ✅ UI 接近 ChatGPT 风格
- ✅ 流式打字效果流畅
- ✅ Markdown 表格 / 代码块正确渲染
- ✅ 多会话切换正常
- ✅ 响应式不崩
- ✅ 部署到 Vercel / GitHub Pages
- ✅ 提交 GitHub

---

## 四、完全掌握检查清单

- [ ] 能写函数组件 + JSX
- [ ] 能熟用 useState / useEffect / useRef
- [ ] 能用 useMemo / useCallback 优化
- [ ] 能写自定义 Hook
- [ ] 能用 React Router 6（嵌套 / 保护路由）
- [ ] 能用 Zustand 管理状态 + 持久化
- [ ] 能用 Ant Design 写表单 / 表格 / 弹窗
- [ ] 能渲染 Markdown + 代码高亮
- [ ] 能实现 SSE 流式输出
- [ ] 完成 AI Chat 项目并部署

---

## 五、自测题

**Q1：** 为什么 React 推荐函数组件 + Hooks？
**答：**
- 更简洁（无 class / this 困扰）
- 逻辑复用更优雅（自定义 Hook vs 高阶组件）
- 更好的 Tree-shaking
- 状态和副作用更清晰

---

**Q2：** useState 是同步还是异步？
**答：** 异步。多次 setState 会**批量合并**。要拿最新值用函数式：`setCount(c => c + 1)`。

---

**Q3：** useEffect 依赖数组的作用？
**答：**
- 不传：每次渲染都执行
- 空数组 `[]`：仅挂载时执行
- `[a, b]`：a 或 b 变化时执行

---

**Q4：** React.memo / useMemo / useCallback 区别？
**答：**
- React.memo：包组件，props 不变就不渲染
- useMemo：缓存计算结果
- useCallback：缓存函数引用

---

**Q5：** Vue 和 React 的核心差异？
**答：**
- Vue：模板 + 响应式（编译时优化）
- React：JSX + 不可变（运行时 diff）
- Vue 双向绑定 vs React 单向数据流
- 心智模型不同：Vue "声明式响应"、React "函数式渲染"

---

## 六、常见坑

| 坑 | 解决 |
| --- | --- |
| 列表无 key | 必须加唯一 key |
| useEffect 无限循环 | 检查依赖数组 |
| 闭包陷阱（旧值） | 用函数式更新 / useRef |
| useState 改对象不生效 | 必须返回新对象（不可变） |
| 图标导入错 | `import { Foo } from '@ant-design/icons'` |
| SSE 中断 | 加 try-catch + reconnect |
| 跨域 | Vite proxy |
| TS 类型错 | 用 React.FC 或显式 props 类型 |

---

## 七、推荐资源

- [React 官方文档](https://react.dev/)（写得超好）
- [Zustand](https://github.com/pmndrs/zustand)
- [Ant Design](https://ant-design.antgroup.com/index-cn)
- [TanStack Query](https://tanstack.com/query/latest)
- 视频：黑马 React 全套
- 项目参考：[chatgpt-next-web](https://github.com/Yidadaa/ChatGPT-Next-Web)

---

## 八、本周完成后的"自我画像"

> "我能用 React 18 + Hooks 写组件。
> 我能用 Zustand + React Router 搭项目。
> 我能用 Ant Design 完成现代 UI。
> 我做了 ChatGPT 风格的 AI Chat 页面，含流式输出、Markdown 渲染。
> 我准备好下个月接入 LLM 后端了。"

---

## 九、下周预告

第 17 周：**Python + FastAPI**——开始 AI 应用工程师之路。
