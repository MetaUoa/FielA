# 专题：MongoDB（文档型数据库）

> **建议学习时机**：第 9 周项目后了解，第 18 周存对话历史时实用。
>
> **核心定位**：**JSON 文档存储**。日志、对话历史、灵活 schema 数据首选。

---

## 一、MongoDB vs MySQL

| | MongoDB | MySQL |
| --- | --- | --- |
| 数据模型 | 文档（BSON） | 表（行列） |
| Schema | 动态 | 严格 |
| Join | 弱（$lookup） | 强 |
| 事务 | 4.0+ 支持 | 强 |
| 扩展性 | 水平易（分片） | 需中间件 |
| 适用 | 内容、日志、灵活数据 | 强关系、强一致 |

---

## 二、核心概念对照

| MongoDB | MySQL |
| --- | --- |
| Database | Database |
| Collection | Table |
| Document | Row |
| Field | Column |
| _id | Primary Key |

---

## 三、安装

```bash
docker run -d --name mongo -p 27017:27017 \
  -e MONGO_INITDB_ROOT_USERNAME=root \
  -e MONGO_INITDB_ROOT_PASSWORD=123456 \
  mongo:7

# GUI：MongoDB Compass
```

---

## 四、Shell 操作

```javascript
// 切换
use mydb

// 增
db.users.insertOne({ name: "Alice", age: 20, tags: ["a", "b"] })
db.users.insertMany([{...}, {...}])

// 查
db.users.find()
db.users.find({ age: { $gte: 18 } })
db.users.find({ "tags": "a" })                    // 数组包含
db.users.find({ name: /^A/ })                      // 正则
db.users.find({ $or: [{ age: 20 }, { age: 30 }] })
db.users.find({}).sort({ age: -1 }).limit(10).skip(20)

// 改
db.users.updateOne({ _id: ObjectId("...") }, { $set: { age: 21 } })
db.users.updateMany({ active: false }, { $set: { active: true } })
db.users.updateOne({ _id: ... }, { $inc: { views: 1 } })           // 自增
db.users.updateOne({ _id: ... }, { $push: { tags: "new" } })       // 数组追加

// 删
db.users.deleteOne({ _id: ... })
db.users.deleteMany({ active: false })

// 索引
db.users.createIndex({ name: 1 })
db.users.createIndex({ email: 1 }, { unique: true })
db.users.createIndex({ name: "text" })             // 全文索引

// 聚合
db.orders.aggregate([
    { $match: { status: "paid" } },
    { $group: { _id: "$userId", total: { $sum: "$amount" } } },
    { $sort: { total: -1 } },
    { $limit: 10 }
])
```

---

## 五、SpringBoot 集成

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-data-mongodb</artifactId>
</dependency>
```

```yaml
spring:
  data:
    mongodb:
      uri: mongodb://root:123456@localhost:27017/mydb?authSource=admin
```

### 实体

```java
@Document(collection = "users")
public class User {
    @Id
    private String id;
    private String name;
    private Integer age;
    @Indexed(unique = true)
    private String email;
    private List<String> tags;
    @CreatedDate
    private LocalDateTime createdAt;
}
```

### Repository

```java
public interface UserRepository extends MongoRepository<User, String> {
    List<User> findByAgeGreaterThan(int age);
    Optional<User> findByEmail(String email);
}
```

### MongoTemplate（复杂查询）

```java
@Autowired MongoTemplate template;

// 查
Query query = new Query();
query.addCriteria(Criteria.where("age").gte(18).lte(30));
query.with(Sort.by(Sort.Direction.DESC, "createdAt"));
query.limit(10);
List<User> users = template.find(query, User.class);

// 改
Update update = new Update().set("age", 21).inc("loginCount", 1);
template.updateFirst(query, update, User.class);

// 聚合
Aggregation agg = Aggregation.newAggregation(
    Aggregation.match(Criteria.where("active").is(true)),
    Aggregation.group("city").count().as("count"),
    Aggregation.sort(Sort.Direction.DESC, "count")
);
AggregationResults<CityCount> results = template.aggregate(agg, "users", CityCount.class);
```

---

## 六、典型应用

### 6.1 对话历史（AI Chat）

```javascript
{
    _id: ObjectId(...),
    userId: "u123",
    sessionId: "s456",
    title: "讨论 RAG",
    messages: [
        { role: "user", content: "...", timestamp: ISODate(...) },
        { role: "assistant", content: "...", tokens: 150 }
    ],
    createdAt: ISODate(...)
}
```

### 6.2 日志

```javascript
{
    _id: ObjectId(...),
    timestamp: ISODate(...),
    level: "ERROR",
    service: "order-service",
    traceId: "...",
    message: "...",
    stack: "...",
    context: { /* 任意结构 */ }
}
```

### 6.3 灵活配置

```javascript
{
    _id: "feature_flags",
    flags: {
        "new_login_page": { enabled: true, percentage: 50 },
        "ai_assistant": { enabled: false }
    }
}
```

---

## 七、推荐资源

- [MongoDB 文档](https://www.mongodb.com/docs/manual/)
- [Spring Data MongoDB](https://docs.spring.io/spring-data/mongodb/reference/)
- [MongoDB University](https://learn.mongodb.com/)（免费课）
