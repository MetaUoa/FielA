# 专题：DDD（领域驱动设计）

> **建议学习时机**：第 13 周（微服务）后看，工作 1~2 年后真正理解。
>
> **核心定位**：**复杂业务系统的设计方法论**。微服务化的理论基础。

---

## 一、DDD 解决的问题

### 传统贫血模型痛点

```java
// 贫血：Entity 只有 getter/setter
public class Order {
    private Long id;
    private OrderStatus status;
    // getter / setter
}

// Service 写所有业务
public class OrderService {
    public void cancel(Long orderId) {
        Order o = orderMapper.selectById(orderId);
        if (o.getStatus() != PENDING) throw new ...
        o.setStatus(CANCELLED);
        o.setCancelTime(now());
        orderMapper.update(o);
        // 50 行业务逻辑全在 Service
    }
}
```

**问题：**
- Service 变成"上帝类"
- 业务规则散落各处
- 测试难（Service 依赖一堆东西）
- 新人看不懂业务

### DDD 富血模型

```java
// 富血：业务行为在 Entity 里
public class Order {
    private OrderStatus status;

    public void cancel() {
        if (this.status != PENDING)
            throw new BusinessException("订单状态不允许取消");
        this.status = CANCELLED;
        this.cancelTime = LocalDateTime.now();
        DomainEventPublisher.publish(new OrderCancelledEvent(this.id));
    }
}

// Service 变薄
public class OrderService {
    public void cancel(Long orderId) {
        Order o = orderRepository.find(orderId);
        o.cancel();
        orderRepository.save(o);
    }
}
```

---

## 二、DDD 核心概念

### 战略设计

| 概念 | 含义 |
| --- | --- |
| **Bounded Context（限界上下文）** | 一个业务边界（≈ 微服务） |
| **Domain（领域）** | 整个业务领域（电商 / 教育） |
| **Subdomain（子域）** | 核心域 / 支撑域 / 通用域 |
| **Ubiquitous Language（通用语言）** | 业务方 + 开发用同一套术语 |

### 战术设计

| 概念 | 含义 | 示例 |
| --- | --- | --- |
| **Entity（实体）** | 有唯一标识，可变 | User、Order |
| **Value Object（值对象）** | 无标识，不可变 | Money、Address |
| **Aggregate（聚合）** | 一组相关 Entity，有 Aggregate Root | Order + OrderItem |
| **Repository** | 聚合的持久化抽象 | OrderRepository |
| **Domain Service** | 不属于单个实体的业务 | TransferService |
| **Domain Event** | 业务发生的事实 | OrderCancelled |
| **Factory** | 复杂对象创建 | OrderFactory |

---

## 三、项目分层

```
┌─────────────────────────┐
│   Interface（接口层）     │   Controller / API
├─────────────────────────┤
│  Application（应用层）    │   编排，事务，不含业务规则
├─────────────────────────┤
│   Domain（领域层）        │   业务核心，富血模型
├─────────────────────────┤
│ Infrastructure（基础设施）│   DB / MQ / 外部 API
└─────────────────────────┘
```

```
src/main/java/com/xxx/order/
├── interfaces/        Controller
├── application/       OrderApplicationService
├── domain/
│   ├── model/         Order / OrderItem / OrderStatus
│   ├── service/       领域服务
│   ├── event/         领域事件
│   └── repository/    Repository 接口
└── infrastructure/
    ├── persistence/   Repository 实现（MyBatis）
    ├── mq/
    └── external/
```

---

## 四、实战例子：订单聚合

```java
// 领域模型（Entity 即 Aggregate Root）
public class Order {
    private OrderId id;
    private CustomerId customerId;
    private List<OrderItem> items;          // 同聚合内
    private Money totalAmount;              // 值对象
    private OrderStatus status;

    // 工厂方法
    public static Order create(CustomerId customerId, List<OrderItem> items) {
        Order order = new Order();
        order.id = OrderId.next();
        order.customerId = customerId;
        order.items = items;
        order.totalAmount = items.stream().map(OrderItem::subtotal).reduce(Money.ZERO, Money::add);
        order.status = OrderStatus.PENDING;
        return order;
    }

    // 业务行为
    public void pay() {
        if (status != PENDING) throw new BusinessException(...);
        this.status = PAID;
        DomainEvents.publish(new OrderPaidEvent(this.id));
    }

    public void cancel(String reason) {
        if (status == COMPLETED) throw new BusinessException("已完成订单不能取消");
        this.status = CANCELLED;
        this.cancelReason = reason;
        DomainEvents.publish(new OrderCancelledEvent(this.id));
    }
}

// 值对象
public record Money(BigDecimal amount, String currency) {
    public Money add(Money other) {
        if (!currency.equals(other.currency)) throw new IllegalArgumentException();
        return new Money(this.amount.add(other.amount), currency);
    }
    public static final Money ZERO = new Money(BigDecimal.ZERO, "CNY");
}

// Repository 接口（领域层）
public interface OrderRepository {
    Order find(OrderId id);
    void save(Order order);
}

// Application Service
@Service
public class OrderApplicationService {
    @Transactional
    public void cancelOrder(Long orderId, String reason) {
        Order order = orderRepository.find(new OrderId(orderId));
        order.cancel(reason);                    // 业务逻辑在 Entity
        orderRepository.save(order);
    }
}
```

---

## 五、何时用 DDD

✅ 复杂业务（金融、电商、ERP）
✅ 长生命周期项目
✅ 团队 10+ 人
✅ 业务规则多变

❌ 简单 CRUD
❌ 小项目
❌ 团队没经验

---

## 六、推荐资源

- 书：《领域驱动设计》Eric Evans（圣经，难）
- 书：《实现领域驱动设计》Vernon（实战）
- 书：《领域驱动设计精粹》（薄，入门）
- [DDD-Sample](https://github.com/citerus/dddsample-core)
