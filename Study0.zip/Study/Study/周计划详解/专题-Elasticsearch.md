# 专题：Elasticsearch（全文搜索）

> **建议学习时机**：第 13 周（微服务实战）或第 20 周（AI 知识库）补。
>
> **核心定位**：**电商搜索、日志检索、知识库搜索** —— Java 工程师必会的搜索引擎。
>
> **预计投入**：6~8 小时

---

## 一、ES 是什么 / 解决什么问题

### MySQL 全文搜索的痛

```sql
SELECT * FROM articles WHERE content LIKE '%关键词%';
```

- 不走索引，慢
- 无法分词（"Java 编程"搜不到"Java 编程语言"）
- 无法按相关度排序
- 高亮、纠错全靠业务代码

### ES 提供

- **分布式全文检索**（百亿级数据毫秒响应）
- **倒排索引**（关键词 → 文档列表）
- **分词**（中文用 IK / hanlp）
- **相关度评分**（BM25 / TF-IDF）
- **高亮、纠错、推荐、聚合**

---

## 二、核心概念

| ES | RDBMS 类比 |
| --- | --- |
| Index（索引） | Database |
| Document（文档） | Row |
| Field（字段） | Column |
| Mapping | Schema |
| Shard（分片） | 分库 |
| Replica（副本） | 主从 |

**重要**：ES 7+ 移除了 `type`（一个 index 只有一种文档）。

---

## 三、快速上手（Docker）

```bash
docker run -d --name es -p 9200:9200 -p 9300:9300 \
  -e "discovery.type=single-node" \
  -e "xpack.security.enabled=false" \
  -e "ES_JAVA_OPTS=-Xms512m -Xmx512m" \
  docker.elastic.co/elasticsearch/elasticsearch:8.13.0

# Kibana（可视化）
docker run -d --name kibana --link es:elasticsearch -p 5601:5601 \
  docker.elastic.co/kibana/kibana:8.13.0
```

访问：
- ES：http://localhost:9200
- Kibana：http://localhost:5601

---

## 四、REST API 基础

### 4.1 创建索引

```bash
PUT /articles
{
    "settings": {
        "number_of_shards": 1,
        "number_of_replicas": 0
    },
    "mappings": {
        "properties": {
            "title": { "type": "text", "analyzer": "ik_max_word" },
            "content": { "type": "text", "analyzer": "ik_max_word" },
            "author": { "type": "keyword" },
            "tags": { "type": "keyword" },
            "publish_date": { "type": "date" },
            "view_count": { "type": "integer" }
        }
    }
}
```

**字段类型：**
- `text`：会分词，全文搜索
- `keyword`：不分词，精确匹配（标签、状态）
- `integer/long/float/double`：数值
- `date`：日期
- `boolean`
- `nested` / `object`：嵌套

### 4.2 文档 CRUD

```bash
# 增（指定 ID）
PUT /articles/_doc/1
{
    "title": "Spring Boot 入门",
    "content": "Spring Boot 是...",
    "author": "Alice",
    "tags": ["Java", "Spring"]
}

# 增（自动 ID）
POST /articles/_doc
{ ... }

# 查
GET /articles/_doc/1

# 改（全量）
PUT /articles/_doc/1
{ ... }

# 改（部分）
POST /articles/_update/1
{ "doc": { "view_count": 100 } }

# 删
DELETE /articles/_doc/1

# 批量
POST /_bulk
{ "index": { "_index": "articles", "_id": "1" } }
{ "title": "...", "content": "..." }
{ "index": { "_index": "articles", "_id": "2" } }
{ "title": "...", "content": "..." }
```

### 4.3 搜索（核心⭐）

```bash
# 简单搜索
GET /articles/_search?q=Spring

# DSL 搜索
POST /articles/_search
{
    "query": {
        "match": {
            "content": "Spring Boot"
        }
    },
    "from": 0, "size": 10,
    "sort": [{ "publish_date": "desc" }],
    "highlight": {
        "fields": {
            "content": {}
        }
    }
}
```

### 4.4 查询类型

```json
// 全文匹配（分词）
{ "match": { "content": "Spring Boot" } }

// 短语匹配（顺序）
{ "match_phrase": { "content": "Spring Boot" } }

// 多字段
{ "multi_match": {
    "query": "Spring",
    "fields": ["title^3", "content"]    // title 权重 3 倍
}}

// 精确匹配（keyword）
{ "term": { "author": "Alice" } }
{ "terms": { "tags": ["Java", "Python"] } }

// 范围
{ "range": { "publish_date": { "gte": "2026-01-01", "lte": "2026-12-31" } } }

// 是否存在
{ "exists": { "field": "publish_date" } }

// 前缀
{ "prefix": { "title": "spr" } }

// 通配符
{ "wildcard": { "title": "*boot*" } }

// 模糊（拼写错误）
{ "fuzzy": { "title": { "value": "spring", "fuzziness": "AUTO" } } }
```

### 4.5 组合查询（bool）

```json
{
    "query": {
        "bool": {
            "must":     [{ "match": { "content": "Spring" } }],    // AND，影响打分
            "filter":   [{ "term":  { "author": "Alice" } }],       // AND，不打分（快）
            "should":   [{ "match": { "tags": "Java" } }],          // OR，加分
            "must_not": [{ "term":  { "status": "deleted" } }],     // NOT
            "minimum_should_match": 1
        }
    }
}
```

**关键**：**filter 不打分，比 must 快很多**。能用 filter 就用。

### 4.6 聚合（Aggregation）

类似 GROUP BY：

```json
POST /articles/_search
{
    "size": 0,
    "aggs": {
        "by_author": {
            "terms": { "field": "author", "size": 10 },
            "aggs": {
                "avg_views": { "avg": { "field": "view_count" } },
                "by_year": {
                    "date_histogram": {
                        "field": "publish_date",
                        "calendar_interval": "year"
                    }
                }
            }
        }
    }
}
```

返回：
```json
{
    "aggregations": {
        "by_author": {
            "buckets": [
                { "key": "Alice", "doc_count": 5, "avg_views": { "value": 100 } }
            ]
        }
    }
}
```

---

## 五、中文分词（IK 分析器）

### 5.1 安装

```bash
# 进入容器
docker exec -it es bash
./bin/elasticsearch-plugin install https://release.infinilabs.com/analysis-ik/stable/elasticsearch-analysis-ik-8.13.0.zip
exit
docker restart es
```

### 5.2 两种模式

```bash
POST /_analyze
{
    "analyzer": "ik_smart",
    "text": "我是 Java 工程师"
}
# → ["我", "是", "Java", "工程师"]

POST /_analyze
{
    "analyzer": "ik_max_word",
    "text": "我是 Java 工程师"
}
# → ["我", "是", "Java", "工程师", "工程", "师"]
```

**选哪个？**
- 索引时用 `ik_max_word`（细粒度，召回多）
- 搜索时用 `ik_smart`（粗粒度，精确）

```json
"properties": {
    "content": {
        "type": "text",
        "analyzer": "ik_max_word",
        "search_analyzer": "ik_smart"
    }
}
```

### 5.3 自定义词典

`config/analysis-ik/IKAnalyzer.cfg.xml`：
```xml
<entry key="ext_dict">my_dict.dic</entry>
```

`my_dict.dic`：
```
中台
低代码
ChatGPT
```

---

## 六、Spring Data Elasticsearch（Java 接入）

### 6.1 依赖

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-data-elasticsearch</artifactId>
</dependency>
```

### 6.2 配置

```yaml
spring:
  elasticsearch:
    uris: http://localhost:9200
```

### 6.3 实体

```java
@Document(indexName = "articles")
public class Article {
    @Id
    private String id;

    @Field(type = FieldType.Text, analyzer = "ik_max_word", searchAnalyzer = "ik_smart")
    private String title;

    @Field(type = FieldType.Text, analyzer = "ik_max_word")
    private String content;

    @Field(type = FieldType.Keyword)
    private String author;

    @Field(type = FieldType.Keyword)
    private List<String> tags;

    @Field(type = FieldType.Date, format = DateFormat.date_hour_minute_second)
    private LocalDateTime publishDate;

    @Field(type = FieldType.Integer)
    private Integer viewCount;
}
```

### 6.4 Repository（简单查询）

```java
public interface ArticleRepository extends ElasticsearchRepository<Article, String> {
    Page<Article> findByTitleContaining(String keyword, Pageable pageable);
    List<Article> findByAuthor(String author);
}
```

### 6.5 ElasticsearchOperations（复杂查询）

```java
@Service
@RequiredArgsConstructor
public class ArticleSearchService {

    private final ElasticsearchOperations es;

    public SearchHits<Article> search(String keyword, String author, int page, int size) {
        NativeQuery query = NativeQuery.builder()
            .withQuery(q -> q
                .bool(b -> b
                    .must(m -> m.multiMatch(mm -> mm
                        .query(keyword)
                        .fields("title^3", "content")
                    ))
                    .filter(f -> f.term(t -> t.field("author").value(author)))
                )
            )
            .withSort(s -> s.field(f -> f.field("publishDate").order(SortOrder.Desc)))
            .withHighlightQuery(new HighlightQuery(
                Highlight.of(h -> h.fields("content", HighlightField.of(b -> b))),
                Article.class
            ))
            .withPageable(PageRequest.of(page, size))
            .build();

        return es.search(query, Article.class);
    }
}
```

### 6.6 高亮结果

```java
SearchHits<Article> hits = service.search(...);
for (SearchHit<Article> hit : hits) {
    Article article = hit.getContent();
    Map<String, List<String>> highlights = hit.getHighlightFields();
    String highlightedContent = highlights.getOrDefault("content", List.of()).stream()
        .findFirst().orElse(article.getContent());
}
```

---

## 七、MySQL 数据同步到 ES

### 7.1 应用层双写（最简）

```java
@Transactional
public void publishArticle(Article article) {
    articleMapper.insert(article);
    articleRepository.save(article);
}
```

**问题**：写 ES 失败怎么办？事务难保证。

### 7.2 MQ 异步同步（推荐）

```java
articleMapper.insert(article);
rabbitTemplate.convertAndSend("article.es.sync", article);
```

```java
@RabbitListener(queues = "article.es.sync")
public void onMessage(Article article) {
    articleRepository.save(article);
}
```

### 7.3 Canal + binlog（终极方案）

监听 MySQL binlog，自动同步到 ES：
```
MySQL → binlog → Canal → MQ → ES
```

业务无感知，最终一致。

---

## 八、性能优化

### 8.1 查询优化

- **能用 filter 别用 must**（不打分快）
- **分页深的用 search_after** 替代 from + size
- **避免 wildcard 前缀通配**（`*keyword` 慢）
- **聚合用 keyword 字段**（text 字段聚合需要 fielddata，慢）

### 8.2 索引优化

- **分片数量**：根据数据量定（每分片 30~50GB 最优）
- **副本数量**：生产至少 1
- **refresh_interval**：默认 1 秒，批量导入时设 -1 或 30s
- **批量写**：bulk API，不要单条写

### 8.3 内存调优

- JVM 堆：物理内存的 50%，最多 30GB（指针压缩）
- 剩下留给 OS 文件缓存（Lucene 依赖）

---

## 九、面试要点

### Q1：ES 为什么快？
**答：**
- 倒排索引（关键词 → 文档列表）
- 分片并行查询
- Lucene 引擎优化（FST、压缩）
- 文件系统缓存（mmap）

### Q2：ES 是实时的吗？
**答：** 近实时（NRT）。默认 1 秒后可查到（refresh_interval）。

### Q3：match vs term 区别？
**答：**
- match：会被分词器处理，全文搜索
- term：精确匹配，不分词

### Q4：filter 和 must 的区别？
**答：**
- must：影响相关度评分
- filter：不评分（缓存友好，更快）

### Q5：怎么实现 MySQL → ES 数据同步？
**答：**
- 双写（简单但不可靠）
- MQ 异步（推荐）
- Canal + binlog（业务无感知）

### Q6：分片设几个？副本设几个？
**答：**
- 分片：每片 30~50GB 最优。预估总量 / 50GB ≈ 分片数
- 副本：生产至少 1（防节点宕机）
- 分片数一旦定下不能改（要 reindex）

---

## 十、常见坑

| 坑 | 解决 |
| --- | --- |
| 中文搜不到 | 装 IK 分词器 |
| 字段不分词需要精确 | 用 keyword |
| 聚合慢 | 用 keyword 字段聚合 |
| 深分页慢 | 用 search_after / scroll |
| OOM | 增大 JVM 堆，限制 size |
| 数据不一致 | 用 MQ 重试 + 死信 |
| Mapping 改不了 | 只能 reindex |

---

## 十一、推荐资源

- [ES 官方文档](https://www.elastic.co/guide/en/elasticsearch/reference/current/index.html)
- [Spring Data Elasticsearch](https://docs.spring.io/spring-data/elasticsearch/reference/index.html)
- [IK 分词器](https://github.com/infinilabs/analysis-ik)
- 书：《Elasticsearch 权威指南》

---

## 十二、完成判定

- [ ] 能用 Docker 跑起 ES + Kibana
- [ ] 能装 IK 中文分词器
- [ ] 能用 DSL 写复杂搜索（bool / filter / highlight）
- [ ] 能用 Spring Data ES 在 SpringBoot 项目集成
- [ ] 能实现 MQ 异步同步 MySQL → ES
- [ ] 给博客 / 电商项目加全文搜索功能
