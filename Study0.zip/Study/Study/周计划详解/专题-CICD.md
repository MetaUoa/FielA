# 专题：CI/CD（GitHub Actions / Jenkins）

> **建议学习时机**：第 12 周（Docker）后立刻补，第 13 周微服务项目应用。
>
> **核心定位**：现代工程师标配。**让代码自动构建 / 测试 / 部署，告别手工操作。**
>
> **预计投入**：4~6 小时

---

## 一、CI/CD 是什么

| | 含义 | 触发 | 产出 |
| --- | --- | --- | --- |
| **CI**（持续集成） | 自动构建 + 测试 | 每次 push / PR | 通过 / 失败 |
| **CD**（持续交付 / 部署） | 自动部署到测试 / 生产 | CI 通过后 / 手动 | 运行中的服务 |

### 流水线（Pipeline）典型阶段

```
Push 代码
  ↓
[ Lint ]            代码风格检查
  ↓
[ Build ]           编译 + 打包
  ↓
[ Test ]            单元测试 + 集成测试
  ↓
[ Coverage ]        覆盖率统计
  ↓
[ Security ]        依赖漏洞扫描
  ↓
[ Docker Build ]    构建镜像
  ↓
[ Push Registry ]   推到镜像仓库
  ↓
[ Deploy Staging ]  部署测试环境
  ↓
[ E2E Test ]        端到端测试
  ↓
[ Approval ]        人工审批
  ↓
[ Deploy Prod ]     部署生产
```

---

## 二、GitHub Actions（推荐⭐⭐⭐）

### 2.1 为什么用 GitHub Actions

- **免费**：公开仓库无限分钟，私有也有 2000 分钟/月
- **跟 Repo 一体化**：不用维护服务器
- **生态丰富**：Marketplace 几万 Actions

### 2.2 基础结构

```
.github/
└── workflows/
    ├── ci.yml             ← 持续集成
    ├── deploy.yml         ← 部署
    └── nightly.yml        ← 定时任务
```

### 2.3 第一个 workflow

```yaml
# .github/workflows/ci.yml
name: CI

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  build:
    runs-on: ubuntu-latest

    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Set up JDK 21
        uses: actions/setup-java@v4
        with:
          java-version: '21'
          distribution: 'temurin'
          cache: maven

      - name: Build with Maven
        run: mvn -B clean package -DskipTests

      - name: Run Tests
        run: mvn test

      - name: Upload coverage to Codecov
        uses: codecov/codecov-action@v4
        with:
          token: ${{ secrets.CODECOV_TOKEN }}
```

### 2.4 完整 CI 例子（Java + Maven + Docker）

```yaml
name: CI/CD

on:
  push:
    branches: [main]
    tags: ['v*']
  pull_request:
    branches: [main]

env:
  IMAGE_NAME: my-app
  REGISTRY: ghcr.io

jobs:
  test:
    runs-on: ubuntu-latest
    services:
      mysql:
        image: mysql:8.0
        env:
          MYSQL_ROOT_PASSWORD: 123456
          MYSQL_DATABASE: test
        ports: ['3306:3306']
        options: --health-cmd="mysqladmin ping" --health-interval=10s
      redis:
        image: redis:7-alpine
        ports: ['6379:6379']

    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with: { java-version: '21', distribution: 'temurin', cache: maven }

      - name: Lint
        run: mvn -B checkstyle:check

      - name: Test
        run: mvn -B test
        env:
          SPRING_DATASOURCE_URL: jdbc:mysql://localhost:3306/test

      - name: Coverage
        run: mvn jacoco:report

      - name: Upload coverage
        uses: codecov/codecov-action@v4

  build-and-push:
    needs: test
    if: github.event_name == 'push' && github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    permissions:
      contents: read
      packages: write

    steps:
      - uses: actions/checkout@v4

      - name: Set up Docker Buildx
        uses: docker/setup-buildx-action@v3

      - name: Login to GitHub Container Registry
        uses: docker/login-action@v3
        with:
          registry: ${{ env.REGISTRY }}
          username: ${{ github.actor }}
          password: ${{ secrets.GITHUB_TOKEN }}

      - name: Extract metadata
        id: meta
        uses: docker/metadata-action@v5
        with:
          images: ${{ env.REGISTRY }}/${{ github.repository_owner }}/${{ env.IMAGE_NAME }}
          tags: |
            type=ref,event=branch
            type=ref,event=tag
            type=sha,format=short

      - name: Build and push
        uses: docker/build-push-action@v5
        with:
          context: .
          push: true
          tags: ${{ steps.meta.outputs.tags }}
          labels: ${{ steps.meta.outputs.labels }}
          cache-from: type=gha
          cache-to: type=gha,mode=max

  deploy:
    needs: build-and-push
    if: startsWith(github.ref, 'refs/tags/v')
    runs-on: ubuntu-latest
    environment: production

    steps:
      - name: Deploy via SSH
        uses: appleboy/ssh-action@v1
        with:
          host: ${{ secrets.SERVER_HOST }}
          username: ${{ secrets.SERVER_USER }}
          key: ${{ secrets.SSH_PRIVATE_KEY }}
          script: |
            docker pull ghcr.io/owner/my-app:latest
            docker-compose up -d
```

### 2.5 常用 Actions

| Action | 用途 |
| --- | --- |
| `actions/checkout` | 拉代码 |
| `actions/setup-java` | 装 JDK |
| `actions/setup-node` | 装 Node |
| `actions/cache` | 缓存依赖 |
| `actions/upload-artifact` | 上传构建产物 |
| `docker/build-push-action` | 构建 + 推镜像 |
| `codecov/codecov-action` | 覆盖率 |
| `softprops/action-gh-release` | 创建 Release |

### 2.6 矩阵构建（一次跑多版本）

```yaml
strategy:
  matrix:
    java: [17, 21]
    os: [ubuntu-latest, macos-latest]
steps:
  - uses: actions/setup-java@v4
    with:
      java-version: ${{ matrix.java }}
```

### 2.7 secrets 管理

- Repo → Settings → Secrets and variables → Actions
- 在 workflow 用 `${{ secrets.NAME }}`
- 敏感信息（数据库密码、API Key）必须放 secrets

### 2.8 触发方式

```yaml
on:
  push:                              # 推送
    branches: [main]
    paths: ['src/**']                # 只在 src 变化时触发
    tags: ['v*']

  pull_request:                      # PR
    types: [opened, synchronize]

  workflow_dispatch:                 # 手动触发（带参数）
    inputs:
      env:
        description: '环境'
        type: choice
        options: [staging, production]

  schedule:                          # 定时
    - cron: '0 2 * * *'              # 每天凌晨 2 点

  release:
    types: [published]
```

---

## 三、前端 CI/CD 示例

```yaml
name: Frontend CI

on:
  push:
    paths: ['frontend/**']

jobs:
  build:
    runs-on: ubuntu-latest
    defaults:
      run:
        working-directory: frontend

    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: '20', cache: 'pnpm' }

      - uses: pnpm/action-setup@v3
        with: { version: 8 }

      - run: pnpm install --frozen-lockfile
      - run: pnpm lint
      - run: pnpm test
      - run: pnpm build

      - name: Deploy to Vercel
        uses: amondnet/vercel-action@v25
        with:
          vercel-token: ${{ secrets.VERCEL_TOKEN }}
          vercel-args: '--prod'
```

---

## 四、Jenkins（传统但仍主流）

### 4.1 何时用 Jenkins

- 私有部署（不想数据出公司）
- 复杂流水线
- 需要插件生态（5000+ 插件）

### 4.2 Jenkinsfile（流水线即代码）

```groovy
pipeline {
    agent any
    tools {
        jdk 'JDK21'
        maven 'Maven3'
    }
    environment {
        DOCKER_IMAGE = "registry.example.com/my-app:${env.BUILD_NUMBER}"
    }
    stages {
        stage('Checkout') {
            steps { checkout scm }
        }
        stage('Build') {
            steps { sh 'mvn -B clean package -DskipTests' }
        }
        stage('Test') {
            steps { sh 'mvn test' }
            post {
                always { junit '**/target/surefire-reports/*.xml' }
            }
        }
        stage('SonarQube') {
            steps {
                withSonarQubeEnv('SonarQube') {
                    sh 'mvn sonar:sonar'
                }
            }
        }
        stage('Docker') {
            steps {
                sh "docker build -t ${DOCKER_IMAGE} ."
                sh "docker push ${DOCKER_IMAGE}"
            }
        }
        stage('Deploy') {
            when { branch 'main' }
            steps {
                sshagent(['prod-ssh']) {
                    sh "ssh deploy@prod 'docker pull ${DOCKER_IMAGE} && docker-compose up -d'"
                }
            }
        }
    }
    post {
        success { slackSend channel: '#deploy', message: "构建成功 ${env.BUILD_URL}" }
        failure { slackSend channel: '#deploy', color: 'danger', message: "构建失败 ${env.BUILD_URL}" }
    }
}
```

### 4.3 GitHub Actions vs Jenkins

| | GitHub Actions | Jenkins |
| --- | --- | --- |
| 部署 | 免维护 | 需自己装 |
| 配置 | YAML | Groovy / DSL |
| 触发 | 跟 GitHub 集成 | webhook |
| 插件 | 中等 | 极丰富 |
| 私有部署 | ❌（除非用 self-hosted runner） | ✅ |
| 适合 | 中小项目 / 开源 | 大公司 / 复杂场景 |

---

## 五、Docker Hub / Registry

### 5.1 公共镜像仓库

- **Docker Hub**：默认，免费
- **GitHub Container Registry (ghcr.io)**：免费 + 跟 Repo 集成
- **阿里云 ACR**：国内速度快

### 5.2 推镜像

```bash
# 登录
docker login ghcr.io -u USERNAME -p TOKEN

# 打标签
docker tag my-app:latest ghcr.io/user/my-app:v1.0

# 推送
docker push ghcr.io/user/my-app:v1.0
```

### 5.3 私有 Registry

```bash
docker run -d -p 5000:5000 --name registry registry:2
docker tag my-app localhost:5000/my-app
docker push localhost:5000/my-app
```

---

## 六、部署策略

### 6.1 蓝绿部署

两套环境（蓝 + 绿），切换路由：
```
旧版本 (蓝) ←── 用户
新版本 (绿)     ← 测试

切换：
旧版本 (蓝)     ← 备用
新版本 (绿) ←── 用户
```

### 6.2 滚动部署

逐步替换实例：
```
[v1][v1][v1][v1]
[v2][v1][v1][v1]
[v2][v2][v1][v1]
[v2][v2][v2][v2]
```

### 6.3 金丝雀部署

```
99% 流量 → v1
 1% 流量 → v2 (观察)
逐步加大 v2 流量
```

---

## 七、回滚

- **基础**：保留上一个镜像，docker pull 旧版重启
- **K8s**：`kubectl rollout undo`
- **数据库迁移**：必须可逆（Flyway / Liquibase）

---

## 八、CI/CD 最佳实践

### 8.1 每次 push 都跑 CI

不光是 main / develop，**所有分支都跑**。

### 8.2 PR 必须通过 CI 才能合并

GitHub → Settings → Branches → Branch protection rules

### 8.3 构建产物缓存

```yaml
- uses: actions/cache@v4
  with:
    path: ~/.m2/repository
    key: ${{ runner.os }}-maven-${{ hashFiles('**/pom.xml') }}
```

### 8.4 并行 jobs

```yaml
jobs:
  lint: ...
  test: ...                  # 这两个并行
  build:
    needs: [lint, test]      # 等两个完成再 build
```

### 8.5 失败通知

集成 Slack / 钉钉 / 邮件，失败时通知。

### 8.6 不在 main 分支直接开发

```
feature/xxx → PR → main
        ↑ CI 必须绿
```

---

## 九、SonarQube（代码质量）

```yaml
- name: SonarQube Scan
  uses: SonarSource/sonarqube-scan-action@v2
  env:
    SONAR_TOKEN: ${{ secrets.SONAR_TOKEN }}
    SONAR_HOST_URL: ${{ secrets.SONAR_HOST_URL }}
```

检查：
- 代码异味（Code Smell）
- Bug
- 安全漏洞
- 重复代码
- 复杂度
- 覆盖率

---

## 十、依赖漏洞扫描

```yaml
- name: Dependency Scan
  uses: snyk/actions/maven@master
  env:
    SNYK_TOKEN: ${{ secrets.SNYK_TOKEN }}
```

或用 **GitHub Dependabot**（免费，自动）：
```yaml
# .github/dependabot.yml
version: 2
updates:
  - package-ecosystem: "maven"
    directory: "/"
    schedule:
      interval: "weekly"
```

---

## 十一、面试要点

### Q1：CI 和 CD 区别？
**答：**
- CI：持续集成，自动构建 + 测试
- CD：持续交付（自动到测试环境）/ 持续部署（自动到生产）

### Q2：你们的 CI/CD 流水线长什么样？
**答：** 6 个阶段：lint → build → test → docker build → push → deploy。每个 PR 必须通过 CI 才能合并。生产部署需人工审批。

### Q3：怎么保证部署不影响线上？
**答：**
- 蓝绿 / 滚动 / 金丝雀部署
- 健康检查（健康才接流量）
- 数据库迁移可逆
- 回滚方案（一键回滚）

### Q4：CI 太慢怎么优化？
**答：**
- 并行 jobs
- 缓存依赖（Maven / npm）
- Docker buildx 缓存
- 矩阵构建只跑差异化部分
- 单元测试不连真数据库

---

## 十二、推荐资源

- [GitHub Actions 文档](https://docs.github.com/en/actions)
- [GitHub Actions Marketplace](https://github.com/marketplace?type=actions)
- [Awesome Actions](https://github.com/sdras/awesome-actions)
- [Jenkins 文档](https://www.jenkins.io/doc/)
- 书：《持续交付》Jez Humble

---

## 十三、完成判定

- [ ] 能给一个 Java 项目写 `.github/workflows/ci.yml`
- [ ] CI 至少包含：build / test / lint / coverage
- [ ] 配置 Docker 镜像自动构建 + 推送
- [ ] 配置 main 分支保护（PR 必须过 CI）
- [ ] 给前端项目配自动部署到 Vercel
- [ ] 接入 Dependabot 漏洞扫描
- [ ] 给你的项目加 CI 徽章到 README
