# 专题：Java 21 虚拟线程（Virtual Threads）

> **建议学习时机**：第 4 周（多线程）完成后立刻补，或第 9 周项目实战中应用。
>
> **核心定位**：JDK 21 最重磅特性。**百万级并发 + 同步代码风格**，颠覆传统线程池模型。
>
> **预计投入**：4~6 小时

---

## 一、为什么需要虚拟线程

### 传统平台线程（Platform Thread）的痛

```java
// 一个 platform thread ≈ 一个 OS thread ≈ 1~2 MB 栈
// 一台 8GB 的机器最多开几千个线程
ExecutorService pool = Executors.newFixedThreadPool(200);
```

- 线程数限制（OS 线程是稀缺资源）
- 线程切换开销大（内核态切换）
- 阻塞调用浪费线程（线程等 IO 时啥也干不了）

### 虚拟线程的承诺

- **轻量**：一个虚拟线程几 KB 内存
- **百万级**：单 JVM 跑百万虚拟线程没问题
- **同步代码 + 异步性能**：写法像传统阻塞代码，性能像 Reactor
- **JVM 管理**：阻塞时自动让出 carrier thread

---

## 二、原理（懂这个就够面试用）

### 2.1 Carrier Thread + Virtual Thread

```
平台线程 (Carrier Thread, 几百个) ←── JVM 调度
    │
    └─→ 挂载虚拟线程执行
        │
        └─→ 遇到阻塞（IO / sleep / lock）
            │
            ├─→ 虚拟线程 unmount
            └─→ Carrier 可以挂载其他虚拟线程
```

- 虚拟线程**挂载（mount）**到 carrier thread 才能执行
- 遇到阻塞操作时**卸载（unmount）**，carrier 立刻去服务其他虚拟线程
- 实际 IO 由 JVM 接管（基于 NIO）

### 2.2 哪些操作会让出 carrier？

- 几乎所有 IO（HTTP、JDBC、Socket）
- `Thread.sleep()`
- `Object.wait()` / Lock 等待
- `BlockingQueue` 操作

**关键**：JDK 已经全面适配了大部分阻塞 API。

### 2.3 哪些操作 **不会** 让出（陷阱⭐）

- **synchronized 块内的阻塞**（JDK 21）：虚拟线程被"钉"（pinned）在 carrier 上，carrier 不能服务其他虚拟线程 → 退化为传统线程
- **JNI / native 方法**
- **JDK 24** 修复了 synchronized 钉的问题

**生产建议**：用 `ReentrantLock` 替代 `synchronized` 配合虚拟线程。

---

## 三、用法

### 3.1 创建虚拟线程

```java
// 方式 1：直接启动
Thread vt = Thread.ofVirtual().start(() -> {
    System.out.println("Hello from virtual thread");
});

// 方式 2：未启动
Thread vt = Thread.ofVirtual().name("my-vt").unstarted(() -> { });
vt.start();

// 方式 3：判断
Thread.currentThread().isVirtual();
```

### 3.2 虚拟线程执行器（推荐）

```java
// 每个任务一个虚拟线程，无限制
try (ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor()) {
    for (int i = 0; i < 10000; i++) {
        executor.submit(() -> {
            Thread.sleep(Duration.ofSeconds(1));
            return fetchData();
        });
    }
}     // 自动等所有任务完成 + 关闭
```

### 3.3 与 CompletableFuture 配合

```java
ExecutorService vtExecutor = Executors.newVirtualThreadPerTaskExecutor();

CompletableFuture<User> userFuture = CompletableFuture.supplyAsync(this::getUser, vtExecutor);
CompletableFuture<Order> orderFuture = CompletableFuture.supplyAsync(this::getOrder, vtExecutor);

CompletableFuture.allOf(userFuture, orderFuture).join();
```

### 3.4 SpringBoot 中开启（3.2+）

```yaml
# application.yml
spring:
  threads:
    virtual:
      enabled: true       # ⭐ Tomcat / Jetty 改用虚拟线程处理请求
```

或显式配 Bean：

```java
@Bean
public TomcatProtocolHandlerCustomizer<?> protocolHandlerVirtualThreadExecutorCustomizer() {
    return protocolHandler -> {
        protocolHandler.setExecutor(Executors.newVirtualThreadPerTaskExecutor());
    };
}
```

### 3.5 @Async 配合

```java
@Configuration
@EnableAsync
public class AsyncConfig {
    @Bean
    public TaskExecutor virtualThreadExecutor() {
        return new TaskExecutorAdapter(Executors.newVirtualThreadPerTaskExecutor());
    }
}

@Async
public CompletableFuture<String> doSomething() { ... }
```

---

## 四、虚拟线程 vs 平台线程 vs Reactor

| | 平台线程池 | 虚拟线程 | Reactor (WebFlux) |
| --- | --- | --- | --- |
| 编程模型 | 同步阻塞 | **同步阻塞** | 异步非阻塞（链式 / Flux） |
| 并发数 | 几百 | **百万** | 百万 |
| 学习成本 | 低 | **低** | 高 |
| 调试 | 简单 | **简单** | 难（栈被打散） |
| 现有代码改造 | - | **几乎不改** | 大改 |
| 适合 | 简单 / 老项目 | **大部分新项目** ⭐ | 极致性能场景 |

**结论**：JDK 21+ 项目大多数场景用虚拟线程，Reactor 留给特殊场景。

---

## 五、实战示例

### 5.1 高并发 HTTP 调用

```java
public List<User> fetchUsers(List<Long> ids) {
    try (var executor = Executors.newVirtualThreadPerTaskExecutor()) {
        List<Future<User>> futures = ids.stream()
            .map(id -> executor.submit(() -> {
                // 同步阻塞调用，看起来像传统代码
                return httpClient.send(
                    HttpRequest.newBuilder(URI.create("/api/users/" + id)).build(),
                    BodyHandlers.ofString()
                ).body();
            }))
            .toList();

        return futures.stream().map(f -> {
            try { return f.get(); }
            catch (Exception e) { throw new RuntimeException(e); }
        }).toList();
    }
}
```

**1 万个 id？没问题，1 万个虚拟线程并发跑。**

### 5.2 结构化并发（Structured Concurrency，预览特性）

```java
try (var scope = new StructuredTaskScope.ShutdownOnFailure()) {
    Subtask<User> userTask = scope.fork(() -> fetchUser(id));
    Subtask<Order> orderTask = scope.fork(() -> fetchOrder(id));

    scope.join();              // 等所有完成
    scope.throwIfFailed();     // 任一失败就抛

    return new UserProfile(userTask.get(), orderTask.get());
}
```

**优势**：任一子任务失败，自动取消其他兄弟任务。

---

## 六、坑点与避坑（⭐必看）

### 6.1 synchronized 钉住（pinning）

```java
public synchronized void process() {        // ❌ 虚拟线程会被钉
    httpClient.send(...);                    // 阻塞期间 carrier 不能服务其他 VT
}
```

**改进：**
```java
private final Lock lock = new ReentrantLock();
public void process() {
    lock.lock();
    try {
        httpClient.send(...);                // ✅ 阻塞时 unmount
    } finally {
        lock.unlock();
    }
}
```

**检测钉住：** JVM 启动参数 `-Djdk.tracePinnedThreads=full`

### 6.2 ThreadLocal 的成本

每个虚拟线程都有自己的 ThreadLocal → 百万 ThreadLocal 内存炸。

**解决：** 用 `ScopedValue`（JDK 21 预览，22 正式）：

```java
static final ScopedValue<String> USER_ID = ScopedValue.newInstance();

ScopedValue.where(USER_ID, "user123").run(() -> {
    // 内部任何地方 USER_ID.get() = "user123"
    process();
});
```

### 6.3 不要池化虚拟线程

**虚拟线程是"用完即弃"的**。不要像传统线程一样池化复用。

```java
// ❌ 错
Executors.newFixedThreadPool(100, Thread.ofVirtual().factory());

// ✅ 对
Executors.newVirtualThreadPerTaskExecutor();
```

### 6.4 CPU 密集型不适合

虚拟线程优势在 IO 阻塞场景。CPU 密集（计算）用平台线程池更合适：

```java
// CPU 密集：核数 + 1
Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors() + 1);
```

---

## 七、性能对比（真实数据）

测试：每个请求 sleep 100ms 模拟 IO

| 方案 | 1 万并发请求耗时 | 内存峰值 |
| --- | --- | --- |
| 平台线程池 (200 线程) | 5 秒 | 500MB |
| **虚拟线程** | **130ms** | **300MB** |
| WebFlux | 110ms | 280MB |

**虚拟线程性能接近 Reactor，代码却像传统同步。**

---

## 八、面试要点

### Q1：虚拟线程和传统线程的区别？
**答：**
- 平台线程 1:1 映射 OS 线程
- 虚拟线程 N:M 映射，JVM 调度，几 KB 内存
- 阻塞时虚拟线程 unmount，carrier 服务其他 VT

### Q2：什么时候用虚拟线程？
**答：** IO 密集 + 高并发场景（HTTP、JDBC、外部 API）。CPU 密集不要用。

### Q3：synchronized 配合虚拟线程有问题吗？
**答：**
- JDK 21 有"钉住"问题，整个 carrier 被阻塞
- 用 ReentrantLock 替代
- JDK 24 已修复

### Q4：ThreadLocal 在虚拟线程下要注意什么？
**答：** 百万 VT 会消耗大量内存。改用 ScopedValue。

### Q5：虚拟线程能完全替代 Reactor 吗？
**答：** 不能。Reactor 在背压、流式处理、复杂组合上仍有优势。但 80% 业务场景虚拟线程已经够好。

---

## 九、迁移建议

### 老项目（JDK 8 / 11 / 17）→ JDK 21

1. **升级 JDK**：先升级到 JDK 21，能正常跑就成功一半
2. **开启虚拟线程**：SpringBoot 3.2+ 加 `spring.threads.virtual.enabled=true`
3. **逐步迁移**：先把对外 HTTP 调用、JDBC 这些 IO 阻塞场景换成虚拟线程
4. **替换 synchronized**：性能关键路径上用 ReentrantLock
5. **监控**：开启 pinning 检测

### 新项目（JDK 21+）

- 默认开启虚拟线程
- @Async 配虚拟线程执行器
- HTTP Client 用 JDK 自带的 `HttpClient`（已适配虚拟线程）
- 数据库连接池用 HikariCP（已适配）

---

## 十、推荐资源

- [JEP 444: Virtual Threads](https://openjdk.org/jeps/444)
- [JEP 462: Structured Concurrency](https://openjdk.org/jeps/462)
- [JEP 446: Scoped Values](https://openjdk.org/jeps/446)
- Inside Java 频道（YouTube）
- Spring Blog: "Virtual Threads in Spring Boot 3.2"

---

## 十一、完成判定

- [ ] 能解释虚拟线程 vs 平台线程
- [ ] 能用 `newVirtualThreadPerTaskExecutor()` 写并发代码
- [ ] 能在 SpringBoot 项目中开启虚拟线程
- [ ] 知道 synchronized 钉住问题 + 替代方案
- [ ] 写过一个对比 demo（平台线程 vs 虚拟线程）并测性能
