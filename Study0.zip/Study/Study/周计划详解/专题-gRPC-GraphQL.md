# 专题：gRPC + Protobuf / GraphQL（了解级别）

> **建议学习时机**：第 13 周（微服务）后简单了解，工作中按需深入。
>
> **核心定位**：**了解 REST 之外的方案**，知道何时该用。

---

# 一、gRPC + Protobuf

## 1. 是什么

- **gRPC**：Google 出品的高性能 RPC 框架
- **Protobuf**：序列化协议（比 JSON 快、小）
- 基于 **HTTP/2**：多路复用、流式

## 2. vs REST

| | REST + JSON | gRPC + Protobuf |
| --- | --- | --- |
| 协议 | HTTP/1.1 | HTTP/2 |
| 数据格式 | JSON（文本） | Protobuf（二进制） |
| 性能 | 一般 | **快 5~10 倍** |
| 浏览器支持 | ✅ | ⚠️ 需要 grpc-web |
| 流式 | SSE / WebSocket | 原生 4 种流模式 |
| 工具链 | Swagger | proto 文件生成 |
| 适用 | 对外 API | **微服务内部通信** |

## 3. 定义 proto

```protobuf
// user.proto
syntax = "proto3";

package com.xxx.user;
option java_multiple_files = true;
option java_package = "com.xxx.user.proto";

service UserService {
    rpc GetUser(GetUserRequest) returns (User);
    rpc ListUsers(ListUsersRequest) returns (stream User);     // 服务端流
    rpc CreateUsers(stream CreateUserRequest) returns (CreateUsersResponse);  // 客户端流
    rpc Chat(stream ChatMessage) returns (stream ChatMessage); // 双向流
}

message GetUserRequest {
    int64 id = 1;
}

message User {
    int64 id = 1;
    string name = 2;
    int32 age = 3;
    repeated string tags = 4;
    map<string, string> metadata = 5;
}

message ListUsersRequest {
    int32 page = 1;
    int32 size = 2;
}
```

## 4. Java 服务端

```xml
<dependency>
    <groupId>io.grpc</groupId>
    <artifactId>grpc-netty-shaded</artifactId>
    <version>1.62.2</version>
</dependency>
<dependency>
    <groupId>io.grpc</groupId>
    <artifactId>grpc-protobuf</artifactId>
</dependency>
<dependency>
    <groupId>io.grpc</groupId>
    <artifactId>grpc-stub</artifactId>
</dependency>
```

Maven 插件：
```xml
<plugin>
    <groupId>org.xolstice.maven.plugins</groupId>
    <artifactId>protobuf-maven-plugin</artifactId>
    <configuration>
        <protocArtifact>com.google.protobuf:protoc:3.25.0:exe:${os.detected.classifier}</protocArtifact>
        <pluginId>grpc-java</pluginId>
        <pluginArtifact>io.grpc:protoc-gen-grpc-java:1.62.2:exe:${os.detected.classifier}</pluginArtifact>
    </configuration>
</plugin>
```

实现：
```java
public class UserServiceImpl extends UserServiceGrpc.UserServiceImplBase {
    @Override
    public void getUser(GetUserRequest req, StreamObserver<User> responseObserver) {
        User user = User.newBuilder()
            .setId(req.getId())
            .setName("Alice")
            .setAge(20)
            .build();
        responseObserver.onNext(user);
        responseObserver.onCompleted();
    }
}

Server server = ServerBuilder.forPort(50051)
    .addService(new UserServiceImpl())
    .build()
    .start();
```

## 5. Java 客户端

```java
ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 50051)
    .usePlaintext()
    .build();

UserServiceGrpc.UserServiceBlockingStub stub = UserServiceGrpc.newBlockingStub(channel);
User user = stub.getUser(GetUserRequest.newBuilder().setId(1L).build());
```

## 6. Spring Boot 集成

用 `grpc-spring-boot-starter`：
```xml
<dependency>
    <groupId>net.devh</groupId>
    <artifactId>grpc-server-spring-boot-starter</artifactId>
    <version>3.1.0.RELEASE</version>
</dependency>
```

```java
@GrpcService
public class UserServiceImpl extends UserServiceGrpc.UserServiceImplBase { ... }

@GrpcClient("user-service")
private UserServiceGrpc.UserServiceBlockingStub stub;
```

## 7. 适用场景

✅ 微服务内部高频通信
✅ 移动端到后端（流量敏感）
✅ 流式数据（实时推送）

❌ 浏览器直连（需要 grpc-web 代理）
❌ 简单 CRUD（REST 够用）

---

# 二、GraphQL

## 1. 是什么

Facebook 出品的查询语言。**前端按需取数据，后端只暴露一个 endpoint**。

## 2. vs REST

| | REST | GraphQL |
| --- | --- | --- |
| Endpoint | 多个 | 一个 (/graphql) |
| 数据获取 | 服务端定义 | 客户端按需选 |
| 过/欠取数据 | 常有 | 没有 |
| 学习成本 | 低 | 中 |
| 缓存 | HTTP 自带 | 需自己做 |
| 调试 | 简单 | GraphiQL |

## 3. 例子

### 3.1 后端 Schema

```graphql
type User {
    id: ID!
    name: String!
    age: Int
    orders: [Order!]!
}

type Order {
    id: ID!
    amount: Float!
    items: [OrderItem!]!
}

type Query {
    user(id: ID!): User
    users(page: Int = 1): [User!]!
}

type Mutation {
    createUser(name: String!, age: Int): User!
}

type Subscription {
    onNewMessage: Message!
}
```

### 3.2 客户端查询

```graphql
# 只要 id 和 name
query {
    user(id: 1) {
        id
        name
    }
}

# 嵌套查询（一次拿用户 + 订单 + 明细）
query {
    user(id: 1) {
        name
        orders {
            id
            amount
            items {
                name
                price
            }
        }
    }
}

# Mutation
mutation {
    createUser(name: "Alice", age: 20) {
        id
    }
}
```

### 3.3 Spring Boot GraphQL

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-graphql</artifactId>
</dependency>
```

`src/main/resources/graphql/schema.graphqls`：
```graphql
type Query {
    user(id: ID!): User
}
type User {
    id: ID!
    name: String
}
```

```java
@Controller
public class UserGraphQLController {

    @QueryMapping
    public User user(@Argument Long id) {
        return userService.getById(id);
    }

    @MutationMapping
    public User createUser(@Argument String name, @Argument Integer age) { ... }

    @SchemaMapping(typeName = "User", field = "orders")        // 字段解析器
    public List<Order> orders(User user) {
        return orderService.findByUserId(user.getId());
    }
}
```

## 4. 何时用 GraphQL

✅ 前端复杂、查询多变（社交、电商首页）
✅ 多端共用 API（Web / 移动 / 平板）
✅ 减少前后端联调成本

❌ 简单 CRUD（杀鸡用牛刀）
❌ 强缓存场景（REST + CDN 更好）
❌ 团队没经验

---

# 三、对比总结

```
                    简单            复杂
                    │                │
                    │                │
对外 API   ────────  REST            REST + GraphQL
                    │                │
微服务内部 ────────  REST            gRPC ⭐
                    │                │
高频实时   ────────  WebSocket / SSE  gRPC streaming
```

**国内现状（2026 年）：**
- **REST**：90% 项目主力
- **gRPC**：大厂微服务标配
- **GraphQL**：少数前端复杂项目用
- **Dubbo**：阿里系还在用，逐步被 gRPC 取代

---

## 四、推荐资源

### gRPC
- [grpc.io 官方](https://grpc.io/)
- [Protocol Buffers](https://protobuf.dev/)
- [grpc-spring-boot-starter](https://github.com/yidongnan/grpc-spring-boot-starter)

### GraphQL
- [graphql.org](https://graphql.org/)
- [Spring for GraphQL](https://docs.spring.io/spring-graphql/reference/)
- [Apollo Client](https://www.apollographql.com/docs/react/)

---

## 完成判定

- [ ] 知道 gRPC vs REST 各自适用场景
- [ ] 能写一个简单 proto + Spring Boot gRPC 服务
- [ ] 知道 GraphQL 的 Query / Mutation / Subscription
- [ ] 能选型（什么时候用哪个）
