# 第 14 周：前端基础（HTML / CSS / JS / ES6+）

> **本周学习目标**：作为 Java 后端工程师，1 周内打通前端基础——能看懂 HTML/CSS、能写现代 JS、理解前端工程化，为下周 Vue3 + 后台管理打底。
>
> **本周关键词**：HTML、CSS、Flex、Grid、JS、ES6、Promise、async/await、模块、Node.js、npm、Vite、TypeScript（基础）
>
> **预计投入时间**：30~40 小时

---

## 一、本周知识点详细分解

### 1. HTML 基础（半天）

#### 1.1 HTML 文档结构

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>页面标题</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>...</header>
    <main>...</main>
    <footer>...</footer>
    <script src="app.js"></script>
</body>
</html>
```

#### 1.2 必会标签清单

| 类别 | 标签 |
| --- | --- |
| 容器 | `<div>` `<span>` `<section>` `<article>` |
| 语义化 | `<header>` `<nav>` `<main>` `<aside>` `<footer>` |
| 标题 | `<h1>` ~ `<h6>` |
| 文本 | `<p>` `<strong>` `<em>` `<br>` |
| 列表 | `<ul>` `<ol>` `<li>` `<dl>` `<dt>` `<dd>` |
| 链接图片 | `<a href>` `<img src alt>` |
| 表格 | `<table>` `<thead>` `<tbody>` `<tr>` `<td>` |
| 表单 | `<form>` `<input>` `<select>` `<textarea>` `<button>` |
| 媒体 | `<video>` `<audio>` `<canvas>` `<iframe>` |

#### 1.3 表单元素

```html
<form action="/api/login" method="POST">
    <input type="text" name="username" required>
    <input type="password" name="password" minlength="6">
    <input type="email" name="email">
    <input type="number" name="age" min="0" max="150">
    <input type="checkbox" name="agree">
    <input type="radio" name="gender" value="male">
    <input type="file" name="avatar" accept="image/*">
    <select name="city">
        <option value="bj">北京</option>
    </select>
    <textarea name="bio" rows="4"></textarea>
    <button type="submit">提交</button>
</form>
```

**完全掌握标准：**
- ✅ 能写出包含表单、表格、列表的完整 HTML
- ✅ 知道语义化标签的意义（SEO + 可访问性）
- ✅ 知道 input 的常见 type
- ✅ 能用 form 写注册页

---

### 2. CSS 基础（1.5 天）

#### 2.1 选择器（核心⭐）

```css
/* 基础 */
div { }                    /* 标签 */
.btn { }                   /* 类 */
#header { }                /* ID */
* { }                      /* 通用 */

/* 组合 */
.list .item { }            /* 后代 */
.list > .item { }          /* 直接子 */
.btn + p { }               /* 相邻兄弟 */
.btn ~ p { }               /* 后续兄弟 */
.btn.primary { }           /* 同时满足 */

/* 属性 */
[type="text"] { }
[href^="https"] { }        /* 以 https 开头 */
[href$=".pdf"] { }         /* 以 .pdf 结尾 */
[class*="btn"] { }         /* 包含 btn */

/* 伪类 */
a:hover { }
input:focus { }
input:disabled { }
li:first-child { }
li:last-child { }
li:nth-child(odd) { }
li:nth-child(2n+1) { }
li:not(.active) { }

/* 伪元素 */
p::before { content: "▶"; }
p::after { content: ""; }
p::first-line { }
input::placeholder { color: #999; }
```

#### 2.2 盒模型

```
┌──────────── margin ────────────┐
│  ┌────────── border ─────────┐ │
│  │  ┌──────── padding ─────┐ │ │
│  │  │  ┌──── content ────┐ │ │ │
│  │  │  │                  │ │ │ │
│  │  │  └──────────────────┘ │ │ │
│  │  └────────────────────────┘ │ │
│  └──────────────────────────────┘ │
└────────────────────────────────────┘
```

```css
.box {
    width: 200px;
    padding: 20px;
    border: 2px solid #333;
    margin: 10px;
    box-sizing: border-box;     /* ⭐ 必加：让 width 包含 padding+border */
}

/* 全局重置 */
* { box-sizing: border-box; margin: 0; padding: 0; }
```

#### 2.3 单位

| 单位 | 含义 | 应用 |
| --- | --- | --- |
| `px` | 像素 | 边框、固定尺寸 |
| `%` | 父元素百分比 | 流式布局 |
| `em` | 父字号倍数 | 嵌套时小心 |
| `rem` | 根字号倍数 | 推荐字号 / 间距 |
| `vw` / `vh` | 视口宽/高 1% | 全屏 |
| `vmin` / `vmax` | 视口最小/大边 | 响应式 |

#### 2.4 Flex 布局（必会⭐⭐⭐）

```css
.parent {
    display: flex;
    flex-direction: row;          /* row | row-reverse | column | column-reverse */
    justify-content: center;       /* 主轴：flex-start | center | flex-end | space-between | space-around | space-evenly */
    align-items: center;           /* 交叉轴：flex-start | center | flex-end | stretch | baseline */
    flex-wrap: wrap;               /* 是否换行 */
    gap: 10px;                     /* 间距（推荐 ⭐） */
}

.child {
    flex: 1;                       /* = flex: 1 1 0%，占满剩余空间 */
    flex: 0 0 200px;               /* 不伸缩，固定 200px */
    align-self: flex-end;          /* 单独控制对齐 */
    order: 2;                      /* 排序 */
}
```

**经典布局：**

```css
/* 居中 */
.center { display: flex; justify-content: center; align-items: center; }

/* 两端对齐 */
.between { display: flex; justify-content: space-between; }

/* 等分三栏 */
.row > * { flex: 1; }

/* 圣杯：两侧固定，中间自适应 */
.layout { display: flex; }
.layout .left { flex: 0 0 200px; }
.layout .main { flex: 1; }
.layout .right { flex: 0 0 200px; }
```

#### 2.5 Grid 布局

```css
.grid {
    display: grid;
    grid-template-columns: 1fr 2fr 1fr;     /* 三列 */
    grid-template-columns: repeat(3, 1fr);  /* 三等分 */
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));  /* 响应式 ⭐ */
    grid-template-rows: 80px 1fr 60px;
    gap: 20px;
}

.item {
    grid-column: 1 / 3;            /* 跨 1~2 列 */
    grid-row: 1 / 4;
}
```

#### 2.6 定位

```css
position: static;       /* 默认 */
position: relative;     /* 相对自己 */
position: absolute;     /* 相对最近的非 static 父 */
position: fixed;        /* 相对视口 */
position: sticky;       /* 滚动到阈值后固定（导航栏常用） */

z-index: 100;          /* 层级（仅对非 static 生效） */
```

#### 2.7 常用 CSS 属性速查

```css
/* 文本 */
color: #333;
font-size: 14px;
font-weight: 700;       /* 100~900 */
line-height: 1.5;
text-align: center;
text-decoration: underline;
text-overflow: ellipsis;
white-space: nowrap;
word-break: break-word;

/* 背景 */
background-color: #f5f5f5;
background-image: url('bg.jpg');
background-size: cover;
background-position: center;
background: linear-gradient(45deg, red, blue);

/* 边框 */
border: 1px solid #ccc;
border-radius: 8px;
box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);

/* 显隐 */
display: none;
visibility: hidden;     /* 占位但不显示 */
opacity: 0;             /* 透明 */

/* 溢出 */
overflow: hidden | auto | scroll;

/* 变换 */
transform: translate(10px, 20px) rotate(45deg) scale(1.2);
transition: all 0.3s ease;

/* 光标 */
cursor: pointer | default | not-allowed;

/* 用户选择 */
user-select: none;
```

#### 2.8 响应式设计（媒体查询）

```css
/* PC 默认 */
.container { max-width: 1200px; margin: 0 auto; }

/* 平板 */
@media (max-width: 768px) {
    .container { padding: 0 20px; }
}

/* 手机 */
@media (max-width: 480px) {
    .nav { flex-direction: column; }
}
```

**完全掌握标准：**
- ✅ 能用 flex 实现居中、两端对齐、等分、圣杯布局
- ✅ 能用 grid 实现 N 列响应式布局
- ✅ 能用 position 做悬浮按钮、固定导航
- ✅ 知道 box-sizing 的作用 + 全局 reset
- ✅ 能用媒体查询做响应式

---

### 3. JavaScript 基础（1 天）

#### 3.1 变量与作用域

```js
// 推荐
const PI = 3.14;            // 不可变
let count = 0;              // 可变
// var 已废弃，不要用（变量提升 + 函数作用域容易出 bug）
```

#### 3.2 数据类型

- 基本类型 7 种：`number` `string` `boolean` `null` `undefined` `symbol` `bigint`
- 引用类型：`object`（含 array、function、date）

```js
typeof 123;          // "number"
typeof "hi";         // "string"
typeof null;         // "object"  ⚠️ JS 历史 bug
typeof undefined;    // "undefined"
typeof [];           // "object"
typeof function(){}; // "function"

Array.isArray([]);   // true，判断数组
```

#### 3.3 字符串

```js
// 模板字符串⭐
const name = "Alice";
const msg = `Hello ${name}, age: ${20 + 1}`;

// 多行
const html = `
  <div>
    <p>Hello</p>
  </div>
`;

// 常用方法
"Hello".length;
"Hello".toUpperCase();
"  hi  ".trim();
"a,b,c".split(",");
"hello".includes("ell");
"hello".startsWith("he");
"hello".endsWith("lo");
"hello".replace("l", "L");
"hello".replaceAll("l", "L");
"5".padStart(3, "0");        // "005"
String(123);
```

#### 3.4 数字

```js
Number("123");
parseInt("123.45");          // 123
parseFloat("123.45");        // 123.45
(3.14).toFixed(2);           // "3.14"
Math.max(1, 2, 3);
Math.random();
Math.floor(3.7);
Math.ceil(3.2);
Math.round(3.5);
```

#### 3.5 数组

```js
const arr = [1, 2, 3];

// 基础
arr.push(4);                 // 尾插
arr.pop();                   // 尾删
arr.shift();                 // 头删
arr.unshift(0);              // 头插
arr.length;
arr.indexOf(2);
arr.includes(2);

// 切片
arr.slice(1, 3);             // [2, 3]，不改原数组
arr.splice(1, 2);            // 删除索引 1 起 2 个，改原数组

// 合并
arr.concat([4, 5]);
[...arr, 4, 5];              // 扩展运算符

// 排序
arr.sort();                  // ⚠️ 默认按字符串
arr.sort((a, b) => a - b);   // 升序
arr.sort((a, b) => b - a);   // 降序

// 高阶函数⭐⭐⭐
arr.map(x => x * 2);                       // 转换
arr.filter(x => x > 1);                    // 过滤
arr.reduce((sum, x) => sum + x, 0);        // 累加
arr.find(x => x > 1);                      // 找第一个
arr.findIndex(x => x > 1);
arr.some(x => x > 2);                      // 至少一个满足
arr.every(x => x > 0);                     // 全部满足
arr.forEach(x => console.log(x));
arr.flat();                                // 拍平一层
arr.flatMap(x => [x, x * 2]);

// 解构
const [a, b, c] = arr;
const [first, ...rest] = arr;
```

#### 3.6 对象

```js
const user = { name: "Alice", age: 20 };

// 解构
const { name, age } = user;
const { name: userName } = user;     // 重命名
const { city = "北京" } = user;       // 默认值

// 简写
const x = 10;
const obj = { x, y: 20 };

// 计算属性名
const key = "id";
const o = { [key]: 1 };

// 扩展
const u2 = { ...user, age: 21 };

// 常用方法
Object.keys(user);
Object.values(user);
Object.entries(user);
Object.assign({}, user, { age: 21 });
JSON.stringify(user);
JSON.parse('{"name":"Alice"}');

// 链式可选（?.，避免 null 报错）⭐
user?.address?.city;
user?.greet?.();
```

#### 3.7 函数

```js
// 普通函数（有 this，可作构造函数）
function add(a, b) { return a + b; }

// 箭头函数⭐（无自己的 this）
const add = (a, b) => a + b;
const square = x => x * x;
const greet = () => "Hello";
const log = msg => { console.log(msg); };

// 默认参数
const greet = (name = "World") => `Hello ${name}`;

// 剩余参数
const sum = (...nums) => nums.reduce((s, n) => s + n, 0);

// 立即执行函数（IIFE）
(function() { console.log("立即执行"); })();
```

#### 3.8 Promise + async/await（⭐⭐⭐）

```js
// Promise 基础
const p = new Promise((resolve, reject) => {
    setTimeout(() => resolve("ok"), 1000);
});

p.then(v => console.log(v))           // ok
 .catch(e => console.error(e))
 .finally(() => console.log("done"));

// 串联
fetch("/api/users")
  .then(res => res.json())
  .then(data => console.log(data));

// async/await（推荐⭐）
async function loadUsers() {
    try {
        const res = await fetch("/api/users");
        const data = await res.json();
        return data;
    } catch (err) {
        console.error(err);
        throw err;
    }
}

// 并发
const [users, posts] = await Promise.all([
    fetch("/api/users").then(r => r.json()),
    fetch("/api/posts").then(r => r.json())
]);

// 任一成功
const fastest = await Promise.race([p1, p2]);

// 全部完成（不管成功失败）
const results = await Promise.allSettled([p1, p2]);
```

#### 3.9 ES Module

```js
// utils.js
export const PI = 3.14;
export function add(a, b) { return a + b; }
export default function multiply(a, b) { return a * b; }

// main.js
import multiply, { add, PI } from "./utils.js";
import * as utils from "./utils.js";
import { add as plus } from "./utils.js";

// 动态 import
const module = await import("./utils.js");
```

**完全掌握标准：**
- ✅ 能熟用 map / filter / reduce / find
- ✅ 能用解构 + 扩展运算符
- ✅ 能用 async / await 处理异步
- ✅ 能用 Promise.all 并发
- ✅ 能用 import / export 模块化
- ✅ 知道箭头函数 vs 普通函数（this 不同）
- ✅ 知道 `==` 和 `===` 的区别（前者隐式转换）
- ✅ 能用可选链 `?.` 和空值合并 `??`

---

### 4. DOM 操作（半天）

> 实际开发用 Vue/React，但要懂基础。

```js
// 选择
document.querySelector("#app");
document.querySelectorAll(".item");

// 内容
el.innerText = "hi";
el.innerHTML = "<b>hi</b>";

// 属性
el.setAttribute("data-id", "1");
el.getAttribute("data-id");
el.dataset.id;                  // data-* 属性

// 类
el.classList.add("active");
el.classList.remove("active");
el.classList.toggle("active");
el.classList.contains("active");

// 样式
el.style.color = "red";

// 事件
el.addEventListener("click", e => {
    e.preventDefault();
    e.stopPropagation();
});

// 创建/插入
const div = document.createElement("div");
div.textContent = "Hello";
document.body.appendChild(div);
el.remove();
```

---

### 5. fetch + AJAX（半天）

```js
// GET
const res = await fetch("/api/users");
const data = await res.json();

// POST
const res = await fetch("/api/users", {
    method: "POST",
    headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer xxx"
    },
    body: JSON.stringify({ name: "Alice" })
});

// 文件上传
const formData = new FormData();
formData.append("file", fileInput.files[0]);
await fetch("/api/upload", { method: "POST", body: formData });

// SSE（流式，AI Chat 用）
const res = await fetch("/api/chat/stream");
const reader = res.body.getReader();
const decoder = new TextDecoder();
while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    console.log(decoder.decode(value));
}
```

---

### 6. 前端工程化基础（半天）

#### 6.1 Node.js + npm

```bash
node -v                    # 验证
npm -v

npm init -y                # 初始化
npm install axios          # 装生产依赖
npm install -D eslint      # 装开发依赖
npm install -g typescript  # 全局安装

npm run dev
npm run build
```

#### 6.2 用 pnpm（推荐⭐）

```bash
npm install -g pnpm
pnpm install
pnpm add axios
pnpm dev
```

**优点**：磁盘节省（symlink 共享）、安装快、严格依赖。

#### 6.3 国内镜像加速

```bash
npm config set registry https://registry.npmmirror.com
# 或用 nrm 切换
npm install -g nrm
nrm use taobao
```

#### 6.4 Vite 构建工具⭐

```bash
# 创建 Vue 项目
npm create vite@latest my-app -- --template vue
# 创建 React 项目
npm create vite@latest my-app -- --template react
# TypeScript 版本
npm create vite@latest my-app -- --template vue-ts
```

```javascript
// vite.config.js
import { defineConfig } from 'vite';
import vue from '@vitejs/plugin-vue';

export default defineConfig({
    plugins: [vue()],
    server: {
        port: 5173,
        proxy: {                            // ⭐ 跨域代理
            '/api': {
                target: 'http://localhost:8080',
                changeOrigin: true
            }
        }
    }
});
```

---

### 7. TypeScript 入门（半天，可选但推荐）

```ts
// 基础类型
let name: string = "Alice";
let age: number = 20;
let active: boolean = true;
let arr: number[] = [1, 2, 3];
let arr2: Array<string> = ["a", "b"];
let tuple: [string, number] = ["A", 1];

// 接口
interface User {
    id: number;
    name: string;
    age?: number;             // 可选
    readonly email: string;   // 只读
}

const u: User = { id: 1, name: "Alice", email: "a@b.com" };

// 类型别名
type Status = "pending" | "success" | "error";
type ID = number | string;

// 函数
function add(a: number, b: number): number {
    return a + b;
}

const greet = (name: string): string => `Hello ${name}`;

// 泛型
function first<T>(arr: T[]): T {
    return arr[0];
}

// 工具类型
type PartialUser = Partial<User>;          // 全部可选
type ReqUser = Required<User>;             // 全部必填
type PickUser = Pick<User, "id" | "name">;
type OmitUser = Omit<User, "email">;
```

**完全掌握标准（基础级）：**
- ✅ 能用 interface 定义对象类型
- ✅ 能为函数加类型
- ✅ 能用泛型
- ✅ 能用 union 类型 `A | B`
- ✅ 知道用 `npm install -D typescript @types/node`

---

## 二、每日学习安排

| 天 | 学习内容 | 上机练习 | 时长 |
| --- | --- | --- | --- |
| **周一** | HTML 基础 + 表单 + 语义化 | 写一个完整的注册页面（HTML） | 4h |
| **周二** | CSS 选择器 + 盒模型 + Flex | 用 Flex 实现常见布局（导航/卡片） | 6h |
| **周三** | CSS Grid + 定位 + 响应式 | 实现响应式 3 栏 / 移动端适配 | 5h |
| **周四** | JS 数据类型 + 字符串 + 数组高阶 ⭐ | 写 20 道数组练习题 | 6h |
| **周五** | Promise + async/await + fetch ⭐ | 调用真实 API（如和风天气） | 5h |
| **周六** | ES Module + Node.js + npm + Vite | 创建 Vite 项目 + 一个组件 | 5h |
| **周日** | TypeScript 入门 + 综合复盘 | 一个静态页项目 + 提交 GitHub | 5h |

---

## 三、本周必做实战项目

### 项目：个人主页（纯 HTML/CSS/JS）

**需求：**
- 顶部导航（响应式，移动端汉堡菜单）
- Hero 区（含个人信息 + 头像）
- 项目展示（Grid 布局，3 列响应式）
- 技能展示（进度条 + 动画）
- 联系方式 + 友链
- 底部 footer

**技术要点：**
- ✅ 语义化 HTML
- ✅ Flex + Grid 布局
- ✅ 响应式（PC / 平板 / 手机）
- ✅ JS 实现菜单切换、回到顶部按钮
- ✅ fetch 请求 GitHub API 显示自己的项目
- ✅ 部署到 GitHub Pages

**验收：**
- ✅ 三端响应式正确
- ✅ 无 console 报错
- ✅ Lighthouse 性能 ≥ 80
- ✅ 上线 GitHub Pages 可访问
- ✅ 提交 GitHub

---

## 四、完全掌握检查清单

### HTML
- [ ] 能写完整 HTML 文档结构
- [ ] 能用语义化标签
- [ ] 能写完整表单（含校验属性）

### CSS
- [ ] 能写各种选择器
- [ ] 能用 box-sizing 重置
- [ ] 能用 Flex 实现居中 / 两端 / 等分 / 圣杯
- [ ] 能用 Grid 实现 N 列响应式
- [ ] 能用 position 做固定导航
- [ ] 能用媒体查询做响应式

### JS
- [ ] 能熟用 map / filter / reduce
- [ ] 能用解构 + 扩展运算符
- [ ] 能用 async / await + Promise.all
- [ ] 能用 ES Module
- [ ] 能用可选链 `?.` 和空值合并 `??`
- [ ] 知道 `==` vs `===`、箭头函数 vs 普通函数

### 工程化
- [ ] 能用 npm / pnpm 装包
- [ ] 能用 Vite 创建项目
- [ ] 能配 Vite proxy 跨域

### 综合
- [ ] 完成个人主页项目并部署 GitHub Pages

---

## 五、自测题

**Q1：** `null` 和 `undefined` 区别？
**答：** undefined 是变量"未赋值"，null 是显式赋的"空"。`typeof null === "object"`（历史 bug），`typeof undefined === "undefined"`。

---

**Q2：** `==` 和 `===` 区别？
**答：** `==` 隐式类型转换比较，`===` 严格相等。**永远用 `===`**。

---

**Q3：** 下面输出什么？
```js
console.log([1, 2, 3].map(parseInt));
```
**答：** `[1, NaN, NaN]`。
**原因：** map 传 3 参数 `(item, index, array)`，parseInt 接 `(string, radix)`。
- `parseInt(1, 0)` = 1
- `parseInt(2, 1)` = NaN（基数 1 非法）
- `parseInt(3, 2)` = NaN（3 不是 2 进制数字）

---

**Q4：** `var` 和 `let` 区别？
**答：**
- var：函数作用域、变量提升、可重复声明
- let：块作用域、暂时性死区、不可重复声明
- **永远用 let / const**

---

**Q5：** 箭头函数 vs 普通函数？
**答：**
- 箭头函数没有自己的 `this`（继承外层）
- 不能用 `new`
- 没有 `arguments`
- 不能作为 generator

---

**Q6：** Promise 三种状态？
**答：** pending / fulfilled / rejected。一旦确定不可逆。

---

## 六、常见坑

| 坑 | 解决 |
| --- | --- |
| `0.1 + 0.2 !== 0.3` | 浮点精度，用差值阈值 |
| `[] == false` 为 true | 永远用 === |
| this 指向错乱 | 箭头函数继承外层 |
| 异步函数没 await | 必须 await 或 .then |
| 跨域 | 后端配 CORS 或 Vite proxy |
| 中文乱码 | meta charset="UTF-8" |
| HTML 不渲染样式 | link 标签放 head |

---

## 七、推荐资源

- **MDN**：[developer.mozilla.org](https://developer.mozilla.org/zh-CN/)（前端圣经）
- 视频：黑马 Web 前端基础
- 书：《JavaScript 高级程序设计（第 4 版）》（红宝书）
- 工具：Chrome DevTools、Vite、ESLint

---

## 八、本周完成后的"自我画像"

> "我能写语义化 HTML，能用 Flex+Grid 做响应式布局。
> 我能用现代 JS（ES6+、async/await、fetch、模块化）写应用。
> 我懂 Node.js + npm + Vite 的前端工程化基础。
> 我做了一个个人主页并部署到 GitHub Pages。
> 下周开始真正学 Vue3 做后台管理系统。"

---

## 九、下周预告

第 15 周：**Vue3 + Element Plus + 后台管理系统**——把这一周的前端基础用到企业级开发。
