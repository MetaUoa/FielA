# 专题：Kubernetes 基础

> **建议学习时机**：第 12 周（Docker）后补，或工作 1 年后深入。
>
> **核心定位**：**容器编排事实标准**。简历"了解 K8s"几乎是 2026 年招聘标配。
>
> **预计投入**：6~10 小时（先掌握 Pod / Deployment / Service 三大核心，进阶慢慢学）

---

## 一、为什么需要 K8s

### Docker Compose 的局限

- 单机（一台服务器挂了应用全挂）
- 没有自动扩缩容
- 没有滚动升级 / 回滚
- 没有自我修复

### K8s 解决

- **集群管理**（多节点）
- **自愈**（容器挂了自动重启 / 调度到其他节点）
- **滚动升级 / 回滚**
- **自动扩缩容**（根据 CPU / QPS）
- **服务发现 + 负载均衡**
- **配置 / 密钥管理**

---

## 二、核心概念（懂这 7 个就懂 80%）

```
┌─────────────────────────────────────────────────────┐
│                  K8s Cluster                         │
│  ┌──────────────┐  ┌──────────────┐  ┌────────────┐│
│  │   Node 1     │  │   Node 2     │  │   Node N   ││
│  │ ┌──────────┐ │  │ ┌──────────┐ │  │            ││
│  │ │   Pod    │ │  │ │   Pod    │ │  │  ...       ││
│  │ │┌────────┐│ │  │ │┌────────┐│ │  │            ││
│  │ ││Container││ │  │ ││Container││ │  │            ││
│  │ │└────────┘│ │  │ │└────────┘│ │  │            ││
│  │ └──────────┘ │  │ └──────────┘ │  │            ││
│  └──────────────┘  └──────────────┘  └────────────┘│
└─────────────────────────────────────────────────────┘
```

### 1. Cluster（集群）

一组机器（Node）。

### 2. Node（节点）

一台机器（物理 / VM）。分两种：
- **Master / Control Plane**：管理（API Server、Scheduler、Controller、etcd）
- **Worker**：跑业务

### 3. Pod（最小调度单位）⭐

**1 个 Pod = 1 个或多个紧密耦合的 Container**。
- 同 Pod 共享网络、存储
- Pod 是临时的（重启后 IP 变）

### 4. Deployment（部署）⭐

管理一组相同的 Pod。提供：
- 副本数控制
- 滚动升级
- 回滚

### 5. Service（服务）⭐

**给一组 Pod 一个稳定的网络入口**（解决 Pod IP 变化问题）。
- ClusterIP：集群内访问
- NodePort：暴露端口到节点
- LoadBalancer：云厂商负载均衡

### 6. Ingress

HTTP 路由（把 example.com/api → service-a，example.com/web → service-b）。

### 7. ConfigMap / Secret

配置 / 敏感信息管理。

---

## 三、本地学习环境

| 工具 | 用途 |
| --- | --- |
| **Docker Desktop** 内置 K8s | 最简单，Mac/Win 一键开启 |
| **Minikube** | 跨平台单节点 |
| **Kind**（K8s in Docker） | 多节点集群 |
| **K3s** | 轻量级（边缘 / IoT） |
| **OrbStack** | Mac 上更快的 K8s |

推荐：先用 **Docker Desktop 内置 K8s**。

---

## 四、kubectl 必会命令

```bash
# 集群信息
kubectl cluster-info
kubectl get nodes
kubectl describe node <name>

# Pod
kubectl get pods                     # 当前 namespace
kubectl get pods -A                  # 所有 namespace
kubectl get pods -o wide
kubectl describe pod <name>
kubectl logs <pod>
kubectl logs -f <pod>                # 实时
kubectl logs <pod> -c <container>    # 指定容器
kubectl exec -it <pod> -- bash       # 进入

# Deployment
kubectl get deployments
kubectl scale deployment <name> --replicas=5
kubectl rollout status deployment <name>
kubectl rollout undo deployment <name>
kubectl rollout history deployment <name>

# Service
kubectl get services
kubectl get svc

# 应用 / 删除 yaml
kubectl apply -f deployment.yaml
kubectl delete -f deployment.yaml

# Namespace
kubectl get ns
kubectl create ns my-app
kubectl config set-context --current --namespace=my-app

# 端口转发（本地测试）
kubectl port-forward svc/my-service 8080:80

# 调试
kubectl get events --sort-by='.lastTimestamp'
kubectl top pod                      # CPU / 内存（需要 metrics-server）
```

---

## 五、第一个 Deployment（核心⭐）

### 5.1 deployment.yaml

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: my-app
  labels:
    app: my-app
spec:
  replicas: 3                          # ⭐ 3 个副本
  selector:
    matchLabels:
      app: my-app
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxSurge: 1
      maxUnavailable: 0
  template:                            # Pod 模板
    metadata:
      labels:
        app: my-app
    spec:
      containers:
      - name: app
        image: my-app:v1
        ports:
        - containerPort: 8080
        env:
        - name: SPRING_PROFILES_ACTIVE
          value: prod
        resources:
          requests:                    # 调度时保证的资源
            cpu: 100m
            memory: 256Mi
          limits:                      # 上限（超了会被杀）
            cpu: 500m
            memory: 512Mi
        livenessProbe:                 # 存活探针（挂了重启）
          httpGet:
            path: /actuator/health/liveness
            port: 8080
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:                # 就绪探针（不就绪不接流量）
          httpGet:
            path: /actuator/health/readiness
            port: 8080
          initialDelaySeconds: 10
          periodSeconds: 5
```

### 5.2 service.yaml

```yaml
apiVersion: v1
kind: Service
metadata:
  name: my-app
spec:
  type: ClusterIP                      # 集群内访问
  selector:
    app: my-app                        # 关联标签为 app=my-app 的 Pod
  ports:
  - port: 80                           # Service 端口
    targetPort: 8080                   # Pod 端口
```

### 5.3 应用

```bash
kubectl apply -f deployment.yaml
kubectl apply -f service.yaml
kubectl get pods                       # 看到 3 个 Pod
kubectl get svc                        # 看到 service
kubectl port-forward svc/my-app 8080:80   # 本地测试
```

---

## 六、Ingress（HTTP 路由）

### 6.1 安装 Ingress Controller

```bash
# Nginx Ingress
kubectl apply -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/main/deploy/static/provider/cloud/deploy.yaml
```

### 6.2 ingress.yaml

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: my-app-ingress
  annotations:
    nginx.ingress.kubernetes.io/rewrite-target: /
spec:
  ingressClassName: nginx
  rules:
  - host: api.example.com
    http:
      paths:
      - path: /api
        pathType: Prefix
        backend:
          service:
            name: my-app
            port:
              number: 80
```

---

## 七、ConfigMap + Secret

### 7.1 ConfigMap（明文配置）

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: app-config
data:
  DB_HOST: mysql.default.svc.cluster.local
  DB_PORT: "3306"
  application.yml: |
    spring:
      application:
        name: my-app
      datasource:
        url: jdbc:mysql://mysql:3306/db
```

```yaml
# 在 Deployment 里使用
spec:
  containers:
  - name: app
    envFrom:
    - configMapRef:
        name: app-config
    volumeMounts:
    - name: config
      mountPath: /app/config
  volumes:
  - name: config
    configMap:
      name: app-config
```

### 7.2 Secret（敏感信息）

```bash
# 创建
kubectl create secret generic db-secret \
  --from-literal=password='mySecret123'

# 或从文件
kubectl create secret generic db-secret \
  --from-file=./password.txt
```

```yaml
# 使用
spec:
  containers:
  - name: app
    env:
    - name: DB_PASSWORD
      valueFrom:
        secretKeyRef:
          name: db-secret
          key: password
```

---

## 八、StatefulSet（有状态应用）

适合：MySQL、Redis、Elasticsearch、Kafka

```yaml
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: mysql
spec:
  serviceName: mysql
  replicas: 1
  selector:
    matchLabels:
      app: mysql
  template:
    metadata:
      labels:
        app: mysql
    spec:
      containers:
      - name: mysql
        image: mysql:8.0
        env:
        - name: MYSQL_ROOT_PASSWORD
          valueFrom:
            secretKeyRef: { name: mysql-secret, key: password }
        volumeMounts:
        - name: data
          mountPath: /var/lib/mysql
  volumeClaimTemplates:               # 每个 Pod 自动有持久化卷
  - metadata:
      name: data
    spec:
      accessModes: ["ReadWriteOnce"]
      resources:
        requests:
          storage: 10Gi
```

---

## 九、HPA（水平自动扩缩容）

```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: my-app
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: my-app
  minReplicas: 2
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70           # CPU 超 70% 就扩
```

---

## 十、Helm（包管理）

K8s 的"npm / Maven"。

```bash
# 安装 Helm
brew install helm
# 添加官方 repo
helm repo add bitnami https://charts.bitnami.com/bitnami

# 装 MySQL
helm install my-mysql bitnami/mysql

# 装 Redis
helm install my-redis bitnami/redis

# 自己写 Chart
helm create my-app
# 修改 my-app/values.yaml + templates/
helm install my-app ./my-app
helm upgrade my-app ./my-app
helm uninstall my-app
```

---

## 十一、生产部署示例：SpringBoot 微服务

### 11.1 镜像

```dockerfile
FROM eclipse-temurin:21-jre-alpine
COPY target/app.jar /app/app.jar
EXPOSE 8080
ENTRYPOINT ["java", "-jar", "/app/app.jar"]
```

```bash
docker build -t my-app:v1 .
# 推到私有仓库
docker tag my-app:v1 registry.example.com/my-app:v1
docker push registry.example.com/my-app:v1
```

### 11.2 完整部署 yaml

```yaml
# secret.yaml
apiVersion: v1
kind: Secret
metadata:
  name: app-secret
type: Opaque
stringData:
  DB_PASSWORD: 123456
  JWT_SECRET: my-jwt-secret

---
# configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: app-config
data:
  DB_HOST: mysql
  REDIS_HOST: redis
  SPRING_PROFILES_ACTIVE: prod

---
# deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: my-app
spec:
  replicas: 3
  selector:
    matchLabels:
      app: my-app
  template:
    metadata:
      labels:
        app: my-app
    spec:
      containers:
      - name: app
        image: registry.example.com/my-app:v1
        ports: [{ containerPort: 8080 }]
        envFrom:
        - configMapRef: { name: app-config }
        - secretRef: { name: app-secret }
        resources:
          requests: { cpu: 200m, memory: 512Mi }
          limits:   { cpu: 1000m, memory: 1Gi }
        livenessProbe:
          httpGet: { path: /actuator/health, port: 8080 }
          initialDelaySeconds: 60
        readinessProbe:
          httpGet: { path: /actuator/health, port: 8080 }
          initialDelaySeconds: 30

---
# service.yaml
apiVersion: v1
kind: Service
metadata:
  name: my-app
spec:
  selector:
    app: my-app
  ports:
  - port: 80
    targetPort: 8080

---
# ingress.yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: my-app
spec:
  ingressClassName: nginx
  rules:
  - host: api.example.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service: { name: my-app, port: { number: 80 } }
```

```bash
kubectl apply -f .
```

---

## 十二、面试要点

### Q1：K8s 解决什么问题？
**答：** 容器编排。Docker 解决"怎么跑一个容器"，K8s 解决"怎么管几百个容器在多台机器上"——调度、扩缩容、自愈、滚动升级。

### Q2：Pod 和 Container 区别？
**答：** Pod 是 K8s 最小调度单位，可包含多个 Container（共享网络和存储）。一般 1 Pod 1 Container。

### Q3：Service 的作用？
**答：** Pod 的 IP 不稳定（重启会变）。Service 提供稳定 DNS 名 + 负载均衡。

### Q4：滚动升级怎么实现？
**答：** Deployment 默认策略。新建 maxSurge 个新 Pod → 等就绪 → 干掉 maxUnavailable 个旧 Pod → 循环。

### Q5：Liveness 和 Readiness 区别？
**答：**
- Liveness：探针失败 → 重启 Pod
- Readiness：探针失败 → 不接流量（但不重启）

### Q6：怎么处理 Pod 间通信？
**答：**
- 同 namespace：直接用 service 名（如 `mysql:3306`）
- 跨 namespace：`mysql.default.svc.cluster.local`

---

## 十三、常见坑

| 坑 | 解决 |
| --- | --- |
| Pod 一直 Pending | kubectl describe pod 看事件（资源不够 / 镜像拉不下来） |
| ImagePullBackOff | 镜像名错 / 私有仓库未配 imagePullSecrets |
| CrashLoopBackOff | 看 logs 找原因（应用启动失败） |
| Service 访问不通 | 检查 selector 标签是否匹配 |
| OOM killed | 调整 resources.limits |
| 配置改了不生效 | ConfigMap 改了要重启 Pod |

---

## 十四、推荐资源

- [K8s 官方文档](https://kubernetes.io/zh-cn/docs/)
- [K8s 中文社区](https://www.kubernetes.org.cn/)
- 视频：尚硅谷 K8s 全集
- 书：《Kubernetes in Action》
- [Killercoda](https://killercoda.com/)（在线交互式实验）
- [K8s Dashboard](https://kubernetes.io/zh-cn/docs/tasks/access-application-cluster/web-ui-dashboard/)

---

## 十五、完成判定

- [ ] 能本地装 K8s（Docker Desktop / Minikube）
- [ ] 能写 Deployment + Service + Ingress
- [ ] 能用 ConfigMap + Secret 管理配置
- [ ] 能用 livenessProbe / readinessProbe
- [ ] 能用 kubectl 排查 Pod 问题
- [ ] 知道滚动升级 + 回滚
- [ ] 把第 13 周微服务部署到 K8s（学习用，不强求生产级）
