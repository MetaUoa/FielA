# 专题：RESTful API 设计规范

> **建议学习时机**：第 7~9 周做 SpringBoot 项目时立即应用。
>
> **核心定位**：**写出"专业感"接口**，区别于学生作品的关键。

---

## 一、什么是 REST

REST = Representational State Transfer。核心思想：
- **资源**（Resource）为中心
- 用 HTTP 方法表达操作
- 用 URI 表达资源
- 无状态

---

## 二、URI 设计规范

### 2.1 用名词，复数

```
✅ GET    /api/users           列出用户
✅ GET    /api/users/123       某个用户
✅ POST   /api/users           创建用户
✅ PUT    /api/users/123       全量更新
✅ PATCH  /api/users/123       部分更新
✅ DELETE /api/users/123       删除

❌ GET /api/getUsers           （动词）
❌ GET /api/user               （单数）
❌ POST /api/createUser
```

### 2.2 嵌套资源

```
GET /api/users/123/orders          某用户的订单
GET /api/orders/456/items          某订单的明细
GET /api/users/123/orders/456      （建议最多 2 层嵌套）
```

### 2.3 操作不是 CRUD 时

允许动词，但用子资源：

```
POST /api/users/123/lock           锁定
POST /api/orders/456/cancel        取消
POST /api/users/123/password/reset  重置密码
```

### 2.4 查询参数

```
GET /api/users?page=1&size=20&sort=createdAt,desc&status=active&keyword=alice
```

- **分页**：`page` + `size`（或 `offset` + `limit`）
- **排序**：`sort=field,asc|desc`
- **过滤**：用字段名 `?status=active`
- **搜索**：用 `q` 或 `keyword`
- **字段过滤**：`?fields=id,name`（GraphQL 风格）

### 2.5 命名风格

- 小写 + 短横线：`/api/user-profiles`（推荐）
- 或全小写：`/api/userprofiles`
- ❌ 不用驼峰 / 下划线

---

## 三、HTTP 方法语义

| 方法 | 含义 | 幂等 | 安全 |
| --- | --- | --- | --- |
| GET | 查 | ✅ | ✅ |
| POST | 增（也可以触发动作） | ❌ | ❌ |
| PUT | 全量更新 / 创建（带 ID） | ✅ | ❌ |
| PATCH | 部分更新 | ❌（标准）/ ✅（实践） | ❌ |
| DELETE | 删 | ✅ | ❌ |
| HEAD | 只看头 | ✅ | ✅ |
| OPTIONS | 看支持什么方法（CORS 预检） | ✅ | ✅ |

**幂等**：重复执行结果相同。
**安全**：不改变服务端状态。

---

## 四、状态码

### 4.1 常用状态码

| 类别 | 码 | 含义 |
| --- | --- | --- |
| 2xx 成功 | 200 OK | 通用成功 |
| | 201 Created | 创建成功 |
| | 204 No Content | 成功但无返回（DELETE） |
| 3xx 重定向 | 301 / 302 | 永久 / 临时重定向 |
| | 304 Not Modified | 缓存有效 |
| 4xx 客户端错 | 400 Bad Request | 参数错 |
| | 401 Unauthorized | 未登录 |
| | 403 Forbidden | 已登录但无权限 |
| | 404 Not Found | 资源不存在 |
| | 405 Method Not Allowed | 方法不支持 |
| | 409 Conflict | 冲突（如重复创建） |
| | 422 Unprocessable Entity | 参数格式对但语义错 |
| | 429 Too Many Requests | 限流 |
| 5xx 服务端错 | 500 Internal Server Error | 通用错 |
| | 502 Bad Gateway | 网关错 |
| | 503 Service Unavailable | 服务不可用 |
| | 504 Gateway Timeout | 网关超时 |

### 4.2 国内业务的折中做法

很多国内项目**HTTP 永远返回 200**，在 body 里用业务 code：

```json
{
    "code": 200,
    "message": "success",
    "data": { ... }
}
{
    "code": 40001,
    "message": "用户不存在",
    "data": null
}
```

**优点**：前端处理统一，不用看 HTTP 状态
**缺点**：违反 HTTP 语义、CDN / 监控 / 网关无法区分错误

**两派之争**，跟团队规范走即可。

---

## 五、响应结构

### 5.1 统一返回

```json
{
    "code": 200,
    "message": "success",
    "data": {
        "id": 1,
        "name": "Alice"
    }
}
```

### 5.2 分页

```json
{
    "code": 200,
    "data": {
        "items": [...],
        "total": 100,
        "page": 1,
        "size": 20,
        "totalPages": 5
    }
}
```

### 5.3 错误响应

```json
{
    "code": 40001,
    "message": "参数错误",
    "errors": [
        { "field": "email", "message": "邮箱格式错误" },
        { "field": "age", "message": "年龄非法" }
    ],
    "timestamp": "2026-05-14T10:00:00Z",
    "path": "/api/users",
    "traceId": "abc123"
}
```

---

## 六、错误码设计

### 6.1 分段法

```
1xxxx - 通用错（10001 参数错、10002 token 过期...）
2xxxx - 用户模块
3xxxx - 订单模块
4xxxx - 支付模块
5xxxx - ...
```

### 6.2 用枚举（强烈推荐）

```java
public enum ErrorCode {
    SUCCESS(200, "success"),
    PARAM_INVALID(10001, "参数错误"),
    UNAUTHORIZED(10002, "未登录"),
    USER_NOT_FOUND(20001, "用户不存在"),
    ORDER_STATUS_INVALID(30001, "订单状态不允许");

    private final int code;
    private final String message;

    ErrorCode(int code, String message) {
        this.code = code;
        this.message = message;
    }
}
```

```java
throw new BusinessException(ErrorCode.USER_NOT_FOUND);
```

---

## 七、版本管理

### 7.1 三种方式

```
1. URI 版本（最常用）
   /api/v1/users
   /api/v2/users

2. Header 版本
   X-API-Version: 1

3. Accept Header
   Accept: application/vnd.myapp.v1+json
```

**推荐 URI 版本**：简单直观，CDN 友好。

### 7.2 何时升版本

**Breaking Change** 才升版本：
- 删字段
- 改字段语义
- 改 URL 结构

非 breaking 改动（加字段、加接口）不需要新版本。

---

## 八、安全

### 8.1 HTTPS 强制

生产环境必须 HTTPS。

### 8.2 鉴权

- Bearer Token（JWT）放 `Authorization` Header
- API Key 放 Header 或 query（query 不推荐）
- OAuth 2.0

### 8.3 限流

```
X-RateLimit-Limit: 100         每分钟限制
X-RateLimit-Remaining: 95      剩余
X-RateLimit-Reset: 60          重置时间
```

### 8.4 防 CSRF（Session 模式）

CSRF Token。
JWT 模式不需要（每次请求都带 token）。

### 8.5 输入校验

- 长度
- 类型
- 范围
- 业务规则
- SQL 注入（用 ORM）
- XSS（输出转义）

---

## 九、性能

### 9.1 ETag / 304

```
Request:   If-None-Match: "abc123"
Response:  304 Not Modified（资源没变）
```

### 9.2 GZip 压缩

```
Request:   Accept-Encoding: gzip
Response:  Content-Encoding: gzip
```

### 9.3 缓存

```
Cache-Control: public, max-age=3600
ETag: "abc123"
Last-Modified: ...
```

### 9.4 分页 vs 游标

- 小数据：`page + size`
- 大数据 / 实时流：`cursor`（游标，避免深分页）

```
GET /api/messages?cursor=eyJpZCI6MTIzNH0&size=20
```

---

## 十、文档

### 10.1 OpenAPI（Swagger）

```java
@Operation(summary = "创建用户")
@ApiResponses({
    @ApiResponse(responseCode = "200", description = "创建成功"),
    @ApiResponse(responseCode = "400", description = "参数错误")
})
@PostMapping
public Result<User> create(@RequestBody @Valid UserDTO dto) { ... }
```

### 10.2 在线工具

- **Swagger UI** / **Redoc**
- **Apifox** / **Postman**（也能管理文档）
- **Stoplight** / **ReadMe**

---

## 十一、命名风格

### 11.1 JSON 字段

```
✅ 驼峰：  { "userName": "alice", "createdAt": "2026-05-14" }
   或下划线：{ "user_name": "alice", "created_at": "2026-05-14" }
```

团队统一即可。前端通常用驼峰。

### 11.2 时间格式

**ISO 8601 标准**：`2026-05-14T10:00:00Z`（推荐）

不要用：
- ❌ `2026/5/14 10:00`
- ❌ 时间戳数字（人不友好）

### 11.3 布尔字段

```
✅ "active": true
✅ "isActive": true
❌ "status": 1                  // 含糊
```

---

## 十二、Idempotency Key（幂等键）

防止重复提交：

```
POST /api/orders
X-Idempotency-Key: random-uuid-123
```

服务端用 Redis 记录这个 key，重复请求返回上次结果。

---

## 十三、面试要点

### Q1：REST 和 RPC 区别？
**答：**
- REST：资源 + HTTP 方法，文本协议，通用
- RPC：方法调用风格，二进制协议（gRPC / Dubbo），高性能
- 内部服务 RPC、对外 API REST

### Q2：PUT 和 PATCH 区别？
**答：**
- PUT：全量替换（送整个对象）
- PATCH：部分更新（只送变化的字段）

### Q3：POST 用了，PUT 还有什么用？
**答：**
- POST 不幂等（重复创建多个）
- PUT 幂等（用指定 ID 更新 / 创建，重复结果一样）

### Q4：HTTP 状态码用 200 + 业务码 vs 用 4xx/5xx？
**答：**
- 200 + 业务码：前端处理统一、灵活
- 4xx/5xx：符合 HTTP 语义、网关 / 监控友好
- 看团队规范，**统一最重要**

---

## 十四、Checklist

- [ ] URI 用名词复数
- [ ] HTTP 方法语义正确
- [ ] 统一返回结构
- [ ] 错误码枚举管理
- [ ] 版本化（v1 / v2）
- [ ] HTTPS
- [ ] 鉴权 + 限流
- [ ] OpenAPI 文档
- [ ] 时间用 ISO 8601
- [ ] 字段命名团队统一
