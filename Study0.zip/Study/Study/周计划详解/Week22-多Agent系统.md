# 第 22 周：多 Agent 系统 + MCP + 微调入门

> **本周学习目标**：站到 AI 工程师的"屋顶"——多 Agent 协作、自己写 MCP Server、了解微调与对齐。
>
> **本周关键词**：AutoGen、CrewAI、Swarm、MCP Server、Function Tools、A2A、SFT、LoRA、DPO、对齐
>
> **预计投入时间**：35~45 小时

---

## 一、多 Agent 框架对比（半天）

| 框架 | 出品方 | 特点 | 适用 |
| --- | --- | --- | --- |
| **LangGraph** | LangChain | 状态图，最灵活 | 复杂工作流 |
| **AutoGen** | Microsoft | 对话式多 Agent | 协作讨论 |
| **CrewAI** | 社区 | 角色驱动 | 团队任务分配 |
| **Swarm** | OpenAI | 极简（实验性） | 学习概念 |
| **Anthropic 多 Agent 模式** | Anthropic | Orchestrator-Worker | 大任务并行 |
| **AGNO / smolagents** | 新兴 | 轻量 | 快速原型 |

**选哪个？**
- 学习概念：Swarm（最简）
- 生产复杂：LangGraph
- 多角色团队：CrewAI / AutoGen

---

## 二、AutoGen（微软）（1 天）

### 2.1 安装

```bash
pip install "autogen-agentchat" "autogen-ext[openai]"
```

### 2.2 基础对话

```python
from autogen_agentchat.agents import AssistantAgent, UserProxyAgent
from autogen_ext.models.openai import OpenAIChatCompletionClient

model = OpenAIChatCompletionClient(
    model="deepseek-chat",
    base_url="https://api.deepseek.com/v1",
    api_key="..."
)

assistant = AssistantAgent("assistant", model_client=model, system_message="你是 Python 老师")
user_proxy = UserProxyAgent("user", human_input_mode="ALWAYS")

await user_proxy.initiate_chat(assistant, message="请帮我写一个冒泡排序")
```

### 2.3 Group Chat（多 Agent 协作）

```python
from autogen_agentchat.teams import RoundRobinGroupChat

researcher = AssistantAgent("researcher", model_client=model,
    system_message="你是研究员，调研主题")
writer = AssistantAgent("writer", model_client=model,
    system_message="基于研究写文章")
critic = AssistantAgent("critic", model_client=model,
    system_message="批评文章并提建议")

team = RoundRobinGroupChat([researcher, writer, critic], max_turns=6)
await team.run(task="写一篇 2026 年 AI 趋势的文章")
```

---

## 三、CrewAI（角色驱动）（1 天）

```bash
pip install crewai crewai-tools
```

```python
from crewai import Agent, Task, Crew, Process

researcher = Agent(
    role='市场研究员',
    goal='调研 AI Agent 市场',
    backstory='你是 10 年经验的资深研究员',
    tools=[search_tool],
    llm=llm
)

writer = Agent(
    role='技术写作',
    goal='把研究写成博客',
    backstory='擅长把复杂技术写给小白看',
    llm=llm
)

research_task = Task(
    description='调研 2026 年 AI Agent 框架，包括 LangGraph、AutoGen、CrewAI',
    expected_output='3 个框架的对比分析',
    agent=researcher
)

write_task = Task(
    description='把研究写成 1500 字博客',
    expected_output='博客全文 Markdown',
    agent=writer,
    context=[research_task]                          # 依赖前一个任务的输出
)

crew = Crew(
    agents=[researcher, writer],
    tasks=[research_task, write_task],
    process=Process.sequential                       # 或 Process.hierarchical（有 manager）
)

result = crew.kickoff()
```

**特点：**
- 比 AutoGen 更"组织化"（明确角色 / 目标 / 任务）
- 适合"团队任务"心智模型
- 内置常用工具

---

## 四、OpenAI Swarm（极简，学概念）（半天）

```bash
pip install git+https://github.com/openai/swarm.git
```

```python
from swarm import Swarm, Agent

client = Swarm()

def transfer_to_billing():
    return billing_agent

triage_agent = Agent(
    name="客服分诊",
    instructions="判断用户问题：技术 / 账单。账单转给 billing_agent",
    functions=[transfer_to_billing]
)

billing_agent = Agent(
    name="账单专员",
    instructions="处理用户账单问题"
)

response = client.run(
    agent=triage_agent,
    messages=[{"role": "user", "content": "我的账单有问题"}]
)
print(response.messages[-1]["content"])
```

**核心概念：**
- **Handoff（移交）**：一个 Agent 调用函数返回另一个 Agent
- **Context Variables**：跨 Agent 共享状态
- **极简**（< 1000 行代码）

---

## 五、Anthropic 多 Agent 模式（半天）

Anthropic 提出的 "Orchestrator-Worker" 模式（用 Claude）：

```
Orchestrator（总管）
   ├─ 拆解任务
   ├─ 分发给 Worker
   └─ 汇总结果

Worker A、B、C（并行执行）
   └─ 各自调用工具
```

```python
def orchestrator(task):
    # Claude 拆解任务
    subtasks = claude.messages.create(...).extract_subtasks()

    # 并行 Worker
    results = await asyncio.gather(*[worker(s) for s in subtasks])

    # Claude 汇总
    return claude.messages.create(...).synthesize(results)
```

参考：[Anthropic Engineering Blog - Building multi-agent systems](https://www.anthropic.com/engineering)

---

## 六、写一个 MCP Server（核心⭐⭐⭐）（1.5 天）

### 6.1 MCP 是什么（回顾）

**Model Context Protocol** —— Anthropic 提的标准协议，让 LLM 客户端连接到外部工具/资源。

**架构：**
```
Client（Claude Desktop / Cursor / 你的应用）
   ↕ JSON-RPC over stdio / SSE
Server（你写的 MCP Server）
   ├─ Resources（暴露文件/数据）
   ├─ Tools（可执行的函数）
   └─ Prompts（模板提示词）
```

### 6.2 安装 SDK

```bash
pip install mcp
```

或 Node.js：
```bash
npm install @modelcontextprotocol/sdk
```

### 6.3 第一个 MCP Server（Python）

```python
# my_mcp_server.py
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("my-tools")

@mcp.tool()
def add(a: int, b: int) -> int:
    """两数相加"""
    return a + b

@mcp.tool()
def query_db(sql: str) -> str:
    """执行只读 SQL 查询"""
    if not sql.strip().lower().startswith("select"):
        return "只允许 SELECT"
    # 执行 SQL
    return str(result)

@mcp.resource("file://docs/{name}")
def read_doc(name: str) -> str:
    """读取文档"""
    return open(f"docs/{name}.md").read()

@mcp.prompt()
def code_review(code: str) -> str:
    """代码审查 prompt 模板"""
    return f"请审查这段代码，找出问题：\n\n{code}"

if __name__ == "__main__":
    mcp.run()
```

### 6.4 配置 Claude Desktop 使用

```json
// ~/Library/Application Support/Claude/claude_desktop_config.json (Mac)
// 或 %APPDATA%\Claude\claude_desktop_config.json (Windows)
{
    "mcpServers": {
        "my-tools": {
            "command": "python",
            "args": ["/path/to/my_mcp_server.py"]
        }
    }
}
```

重启 Claude Desktop → 在对话框里看到工具图标 → Claude 可以调用你的 tools/resources。

### 6.5 进阶：异步 + 数据库

```python
import asyncio
import asyncpg

@mcp.tool()
async def query_users(name: str) -> str:
    conn = await asyncpg.connect("postgresql://...")
    rows = await conn.fetch("SELECT * FROM users WHERE name LIKE $1", f"%{name}%")
    await conn.close()
    return str(rows)
```

### 6.6 生产级注意

- **安全**：MCP 给 LLM 控制权，必须限权
  - SQL：只允许 SELECT
  - 文件：只允许特定目录
  - 网络：白名单
- **审计**：记录所有 tool 调用日志
- **超时**：防止长任务卡死
- **错误处理**：不要把异常细节泄漏给 LLM

### 6.7 已有的 MCP Server 资源

- [github.com/modelcontextprotocol/servers](https://github.com/modelcontextprotocol/servers)
- 官方提供：filesystem、git、postgres、slack、sentry…

---

## 七、Agent 评测与对齐（半天）

### 7.1 Agent 评测难点

- 不是 "对错二分"，是 "任务完成度"
- 多步骤、多工具，错误可能在中间任何步
- 需要"执行评测"而非"答案评测"

### 7.2 评测方法

- **AgentBench**：开源 benchmark
- **自建**：定义任务 + 成功标准 + 用 GPT-4 当评委
- **A/B 对比**：人工标注

### 7.3 输出结构化

让 Agent 每步输出 JSON：
```json
{
    "thought": "我需要先查表结构",
    "action": "get_schema",
    "args": {"table": "user"},
    "observation": "..."
}
```

便于日志和评测。

---

## 八、微调入门（1 天，了解为主）

### 8.1 何时考虑微调

| 场景 | RAG | 微调 |
| --- | --- | --- |
| 增加私有知识 | ✅ | ❌（贵） |
| 改变模型风格 / 语气 | ❌ | ✅ |
| 让小模型在特定任务超 GPT | ❌ | ✅ |
| 减少 prompt 长度 | ❌ | ✅ |
| 数据频繁变 | ✅ | ❌ |

**90% 场景先用 RAG，效果不够再微调。**

### 8.2 微调技术阶梯

```
预训练（Pretrain）       ← 从 0 训练，需要万亿 tokens（不可能自己做）
       ↓
继续预训练（CPT）        ← 用领域数据继续训练
       ↓
监督微调（SFT）          ← 用 Q-A pair 教模型，最常见 ⭐
       ↓
偏好对齐（DPO / RLHF）  ← 用偏好数据让模型"懂礼貌"
       ↓
LoRA（参数高效微调）    ← 只训练少量参数，便宜 ⭐
```

### 8.3 LoRA 微调（最实用）

**核心思想：** 冻结原模型，只训练旁挂的小矩阵（低秩分解）。

参数量：百分之一甚至千分之一。

**工具：**
- HuggingFace TRL（最易用）
- Axolotl
- LLaMA-Factory（国产，中文友好⭐）

### 8.4 LLaMA-Factory 实操（推荐）

```bash
git clone https://github.com/hiyouga/LLaMA-Factory
cd LLaMA-Factory
pip install -e .

# Web UI
llamafactory-cli webui
```

数据格式（alpaca）：
```json
[
    {
        "instruction": "请帮我写一首关于秋天的诗",
        "input": "",
        "output": "秋风萧瑟天气凉..."
    }
]
```

WebUI 选 → 模型（如 Qwen2.5-7B）→ LoRA → 数据集 → 开始训练。

GPU 要求：
- 7B 模型 LoRA：单卡 16GB 显存
- 推荐租云 GPU（autodl / featurize / colab pro）

### 8.5 评测微调效果

- BLEU / ROUGE（自动指标）
- 人工评估（让人对比）
- 用 GPT-4 当评委

---

## 九、安全与对齐（半天）

### 9.1 LLM 安全风险

- **Prompt Injection**（用户篡改 system prompt）
- **越狱（Jailbreak）**（绕过安全限制）
- **数据泄漏**（system prompt 被套出来）
- **幻觉**（编造事实）
- **偏见**（性别 / 种族 / 政治）

### 9.2 防御措施

| 风险 | 防御 |
| --- | --- |
| Injection | 严格 system + 输入过滤 + 用结构化字段 |
| 越狱 | 输出审核 + 关键词黑名单 |
| 泄漏 | 不在 system 放敏感信息 |
| 幻觉 | RAG + 让模型说"不知道" |
| 偏见 | 多样化数据 + 评测 |

### 9.3 输出审核

```python
# OpenAI Moderation
mod = client.moderations.create(input=user_input)
if mod.results[0].flagged:
    return "内容不合规"

# 自己加关键词
BLACKLIST = ["敏感词1", "敏感词2"]
if any(w in user_input for w in BLACKLIST):
    return "..."
```

---

## 十、每日学习安排

| 天 | 主题 | 上机 | 时长 |
| --- | --- | --- | --- |
| **周一** | 多 Agent 概念 + AutoGen | 3 Agent 协作写文章 | 6h |
| **周二** | CrewAI + Swarm | CrewAI 复刻周一的项目 | 6h |
| **周三** | MCP 概念 + 写第一个 MCP Server ⭐ | 工具 + 资源 + 提示词都写 | 7h |
| **周四** | MCP 接入 Claude Desktop + 真实 DB | 数据库 MCP Server | 6h |
| **周五** | Agent 评测 + 安全 | 评测 + 防注入 | 5h |
| **周六** | 微调入门 + LLaMA-Factory | LoRA 微调小模型 | 6h |
| **周日** | 综合项目 + 复盘 | "AI 团队"系统 + 提交 | 6h |

---

## 十一、本周必做实战

### 实战 1：MCP Server for SpringBoot 项目

把你前面做的 SpringBoot 项目（如博客系统）暴露成 MCP Server：

```python
@mcp.tool()
async def search_articles(keyword: str) -> str:
    """搜索博客文章"""
    res = await httpx.AsyncClient().get(
        "http://localhost:8080/api/articles",
        params={"keyword": keyword}
    )
    return res.text

@mcp.tool()
async def get_article(id: int) -> str:
    """获取文章详情"""
    res = await httpx.AsyncClient().get(f"http://localhost:8080/api/articles/{id}")
    return res.text
```

接入 Claude Desktop → 在 Claude 里问"帮我搜下我博客里关于 Spring 的文章"。

**验收：**
- ✅ Claude Desktop 能调用你的 MCP
- ✅ 至少 3 个工具
- ✅ 有审计日志
- ✅ 录制演示视频
- ✅ 提交 GitHub

### 实战 2：多 Agent 写作系统

用 CrewAI 实现：
1. **调研员**：搜索 / 阅读资料
2. **大纲师**：写大纲
3. **作者**：写正文
4. **编辑**：校对

跑一个主题端到端。

### 实战 3（可选）：LoRA 微调

用 LLaMA-Factory 微调 Qwen2.5-7B：
- 数据：自己整理的 100 个 Q-A（如客服问答）
- LoRA 训练 1 小时
- 对比微调前后效果
- 写一篇博客记录过程

---

## 十二、完全掌握检查清单

- [ ] 能用 AutoGen / CrewAI 跑一个多 Agent 团队
- [ ] 能解释 LangGraph / AutoGen / CrewAI 的差异
- [ ] 能写一个 MCP Server（Python 或 Node）
- [ ] 能让 Claude Desktop 调用自己的 MCP
- [ ] 能讲清 MCP 的 Resources / Tools / Prompts
- [ ] 能列出 LLM 5+ 安全风险 + 对应防御
- [ ] 能讲清 RAG / 微调 / LoRA 的适用场景
- [ ] 用 LLaMA-Factory 跑过一次 LoRA（可选）
- [ ] 实战项目 1 + 2 完成并提交 GitHub

---

## 十三、自测题

**Q1：** 多 Agent 比单 Agent 优势在哪？什么时候用？
**答：**
- 优势：分工明确、各自专注、并行
- 用：复杂任务（研究 + 写作 + 审核）、需要不同角色（医生 vs 律师 vs 工程师）
- 坑：成本高、协调难、调试复杂。不复杂别用。

---

**Q2：** MCP vs Function Calling 区别？
**答：**
- Function Calling：API 调用，**模型层**集成
- MCP：标准协议，**客户端**层集成
- MCP 让一份工具被 Claude / Cursor / 其他客户端复用
- MCP 还有 Resources / Prompts，不只是 Tools

---

**Q3：** 微调比 RAG 好在哪？
**答：**
- 改变模型行为（风格、语气、格式）
- 缩短 prompt 长度
- 小模型超大模型的可能（垂直领域）
- 长尾低频知识

---

**Q4：** LoRA 为什么便宜？
**答：** 不训练完整模型，只训练旁挂小矩阵（rank=8/16）。参数量从 7B 降到几 M，显存和算力需求降一个量级。

---

## 十四、推荐资源

### 文档
- [AutoGen](https://microsoft.github.io/autogen/)
- [CrewAI](https://docs.crewai.com/)
- [OpenAI Swarm](https://github.com/openai/swarm)
- [MCP 官方](https://modelcontextprotocol.io/)
- [MCP Servers 集合](https://github.com/modelcontextprotocol/servers)

### 微调
- [LLaMA-Factory](https://github.com/hiyouga/LLaMA-Factory)
- [Axolotl](https://github.com/axolotl-ai-cloud/axolotl)
- [HuggingFace TRL](https://github.com/huggingface/trl)

### 阅读
- Anthropic 工程博客（多 Agent 模式）
- HuggingFace Course（微调 NLP）

---

## 十五、本周完成后

> "我能用 AutoGen / CrewAI 设计多 Agent 协作。
> 我写过自己的 MCP Server，接入 Claude Desktop 当工具。
> 我懂 LLM 安全风险和防御。
> 我了解微调 / LoRA / DPO 的选型逻辑。
> 我达到了'AI 应用工程师'的天花板能力。"

---

## 十六、之后

22 周完整结束后：
- **持续学习**：跟进 Claude / GPT 新版本、新 MCP Server、新 Agent 框架
- **找工作**：见 [简历模板](./简历模板.md) + [面试八股专题](./面试八股专题.md)
- **造轮子**：开源一个 MCP / Agent 项目（最强简历）

🎉 **22 周 + 长期 = 你已经走在 AI 时代前列。**
