# 专题：WebSocket / SSE（实时通信）

> **建议学习时机**：第 16 周（AI Chat）应用 SSE，第 13/20 周可应用 WebSocket。
>
> **核心定位**：实时聊天、通知推送、协作编辑、AI 流式输出都靠它。
>
> **预计投入**：3~5 小时

---

## 一、对比 4 种实时方案

| 方案 | 双向 | 服务推送 | 复杂度 | 适用 |
| --- | --- | --- | --- | --- |
| **轮询**（Polling） | ✗ | ✗（定时拉） | 低 | 简单刷新 |
| **长轮询**（Long Polling） | ✗ | 模拟 | 中 | 兼容老浏览器 |
| **SSE**（Server-Sent Events） | ✗（服务→客户端单向） | ✅ | 低 | **AI 流式、通知、推送** |
| **WebSocket** | ✅ | ✅ | 中 | **聊天、协作、游戏** |

**经验法则**：
- 服务端推送 + 不需要客户端发消息 → **SSE**（简单、HTTP 协议、自动重连）
- 双向高频通信 → **WebSocket**

---

## 二、SSE（Server-Sent Events）

### 2.1 协议

服务端响应头：
```
Content-Type: text/event-stream
Cache-Control: no-cache
Connection: keep-alive
```

数据格式：
```
data: hello\n\n
data: world\n\n
event: ping\ndata: 1\n\n
```

### 2.2 后端实现

#### Spring MVC（同步）

```java
@GetMapping(value = "/sse", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
public SseEmitter sse() {
    SseEmitter emitter = new SseEmitter(0L);  // 0L = 不超时

    new Thread(() -> {
        try {
            for (int i = 0; i < 10; i++) {
                emitter.send(SseEmitter.event()
                    .name("message")
                    .id(String.valueOf(i))
                    .data("tick " + i));
                Thread.sleep(1000);
            }
            emitter.complete();
        } catch (Exception e) {
            emitter.completeWithError(e);
        }
    }).start();

    return emitter;
}
```

#### Spring WebFlux（响应式，推荐流式 LLM）

```java
@GetMapping(value = "/chat/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
public Flux<String> chatStream(@RequestParam String message) {
    return chatService.streamReply(message)
        .map(token -> "data: " + token + "\n\n");
}
```

#### Spring AI 流式（最实用）

```java
@GetMapping(value = "/chat/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
public Flux<String> stream(@RequestParam String q) {
    return chatClient.prompt().user(q).stream().content();
}
```

#### FastAPI（Python）

```python
from fastapi.responses import StreamingResponse
import asyncio, json

@app.get("/chat/stream")
async def stream(q: str):
    async def gen():
        for ch in "Hello World":
            await asyncio.sleep(0.05)
            yield f"data: {json.dumps({'type': 'token', 'data': ch})}\n\n"
        yield "data: [DONE]\n\n"
    return StreamingResponse(gen(), media_type="text/event-stream")
```

### 2.3 前端实现

#### 标准 EventSource

```js
const es = new EventSource('/api/sse');

es.onmessage = (e) => {
    console.log('收到', e.data);
};

es.addEventListener('custom-event', (e) => {
    console.log('自定义事件', e.data);
});

es.onerror = (e) => {
    console.error('错误', e);
    // 自动重连，不用自己写
};

// 主动关闭
es.close();
```

**问题**：EventSource **不支持 POST 和 自定义 headers**。

#### 用 fetch 实现 POST + Header（推荐⭐）

```js
async function streamChat(message, onChunk, onDone) {
    const res = await fetch('/api/chat/stream', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ message })
    });

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const events = buffer.split('\n\n');
        buffer = events.pop() || '';

        for (const event of events) {
            const lines = event.split('\n');
            for (const line of lines) {
                if (!line.startsWith('data: ')) continue;
                const data = line.slice(6);
                if (data === '[DONE]') { onDone(); return; }
                try {
                    onChunk(JSON.parse(data));
                } catch {
                    onChunk(data);
                }
            }
        }
    }
    onDone();
}
```

### 2.4 SSE 完整 AI Chat 示例

后端（Spring AI）：
```java
@PostMapping(value = "/api/chat", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
public Flux<ServerSentEvent<String>> chat(@RequestBody ChatRequest req) {
    return chatService.stream(req.getMessages())
        .map(token -> ServerSentEvent.<String>builder()
            .event("token")
            .data(token)
            .build())
        .concatWith(Flux.just(
            ServerSentEvent.<String>builder().event("done").data("[DONE]").build()
        ));
}
```

前端（React）：
```jsx
const [content, setContent] = useState('');

async function send(message) {
    setContent('');
    await streamChat(message,
        (chunk) => setContent(c => c + chunk),
        () => console.log('done')
    );
}
```

---

## 三、WebSocket（双向）

### 3.1 后端：Spring WebSocket + STOMP

#### 依赖

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-websocket</artifactId>
</dependency>
```

#### 配置

```java
@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {

    @Override
    public void configureMessageBroker(MessageBrokerRegistry config) {
        config.enableSimpleBroker("/topic", "/queue");
        config.setApplicationDestinationPrefixes("/app");
        config.setUserDestinationPrefix("/user");
    }

    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        registry.addEndpoint("/ws").setAllowedOriginPatterns("*").withSockJS();
    }
}
```

#### Controller

```java
@Controller
public class ChatController {

    @MessageMapping("/chat.send")              // 客户端发到 /app/chat.send
    @SendTo("/topic/messages")                  // 广播到 /topic/messages
    public ChatMessage send(ChatMessage message) {
        message.setTime(System.currentTimeMillis());
        return message;
    }

    @MessageMapping("/chat.private")
    public void sendPrivate(ChatMessage message, SimpMessageHeaderAccessor headers) {
        // 单发给某个用户
        messagingTemplate.convertAndSendToUser(message.getTo(), "/queue/private", message);
    }
}
```

#### 主动推送（不依赖客户端请求）

```java
@Service
@RequiredArgsConstructor
public class NotificationService {
    private final SimpMessagingTemplate messaging;

    public void notify(Long userId, String content) {
        messaging.convertAndSendToUser(
            userId.toString(),
            "/queue/notification",
            Map.of("content", content)
        );
    }
}
```

### 3.2 前端

#### 原生 WebSocket

```js
const ws = new WebSocket('ws://localhost:8080/ws');

ws.onopen = () => {
    ws.send(JSON.stringify({ type: 'login', user: 'Alice' }));
};

ws.onmessage = (e) => {
    const msg = JSON.parse(e.data);
    console.log('收到', msg);
};

ws.onerror = (e) => console.error(e);
ws.onclose = () => console.log('断开');

ws.send(JSON.stringify({ type: 'chat', content: 'hi' }));
ws.close();
```

#### STOMP 客户端（配合 Spring）

```bash
pnpm add @stomp/stompjs sockjs-client
```

```js
import { Client } from '@stomp/stompjs';
import SockJS from 'sockjs-client';

const client = new Client({
    webSocketFactory: () => new SockJS('http://localhost:8080/ws'),
    connectHeaders: { Authorization: `Bearer ${token}` },
    onConnect: () => {
        // 订阅
        client.subscribe('/topic/messages', (msg) => {
            console.log('收到', JSON.parse(msg.body));
        });
        client.subscribe('/user/queue/private', (msg) => {
            console.log('私信', JSON.parse(msg.body));
        });

        // 发送
        client.publish({
            destination: '/app/chat.send',
            body: JSON.stringify({ content: 'hi', from: 'Alice' })
        });
    }
});

client.activate();
```

---

## 四、实战：在线聊天室

### 4.1 业务功能

- 多人聊天室
- 用户上线 / 下线通知
- 私聊 / 群聊
- 历史消息（前 50 条）
- 消息持久化（MongoDB / MySQL）

### 4.2 关键设计

```
[Frontend] ←─ STOMP/WS ─→ [Backend]
                              ↓
                     ┌──────┴──────┐
                     ▼             ▼
              [Redis]        [MongoDB]
              在线用户       历史消息
                     ↓
                ┌──────┐
                │ MQ  │   多实例时同步消息
                └──────┘
```

### 4.3 多实例下的消息同步

单实例：内存广播
多实例：用 Redis Pub/Sub 或 MQ 广播

```java
@EventListener
public void handle(ChatMessage msg) {
    // 本地广播
    messagingTemplate.convertAndSend("/topic/messages", msg);
    // 跨实例广播
    redisTemplate.convertAndSend("chat:broadcast", msg);
}

@Bean
public MessageListenerAdapter listenerAdapter() {
    return new MessageListenerAdapter((msg, pattern) -> {
        ChatMessage cm = deserialize(msg);
        messagingTemplate.convertAndSend("/topic/messages", cm);
    });
}
```

---

## 五、SSE vs WebSocket 选型

### 选 SSE

- 服务端 → 客户端单向
- AI 流式输出
- 通知推送
- 实时日志展示
- 简单、走 HTTP（穿透代理友好）

### 选 WebSocket

- 双向高频
- 聊天室
- 协作编辑
- 游戏
- 多端同步

---

## 六、连接管理与可靠性

### 6.1 心跳

```js
// 前端
setInterval(() => {
    if (ws.readyState === WebSocket.OPEN) {
        ws.send('ping');
    }
}, 30000);
```

```java
// 后端响应 pong
@MessageMapping("/ping")
@SendTo("/topic/pong")
public String pong() { return "pong"; }
```

### 6.2 断线重连

EventSource 自动重连。
WebSocket 需要手动：

```js
function connect() {
    const ws = new WebSocket('ws://...');
    ws.onclose = () => {
        setTimeout(connect, 3000);  // 3 秒后重连
    };
}
```

### 6.3 鉴权

- SSE：URL query 带 token 或 fetch headers
- WebSocket：connectHeaders（STOMP）或 query string

---

## 七、性能与限制

| 指标 | 单机参考 |
| --- | --- |
| WebSocket 连接数 | 几万~十几万（看内存） |
| SSE 连接数 | 同 WebSocket（也是 HTTP keep-alive） |
| 消息吞吐 | 万级 QPS |

**优化：**
- 用 Reactor / WebFlux（非阻塞）
- 文件描述符调优（ulimit）
- 用 Netty 直接（极致性能）

---

## 八、面试要点

### Q1：SSE 和 WebSocket 区别？
**答：**
- SSE 单向（服务端→客户端），WebSocket 双向
- SSE 走 HTTP，自动重连，简单
- WebSocket 走 ws/wss 协议，需要自己处理重连
- 服务端推送选 SSE，双向交互选 WebSocket

### Q2：WebSocket 怎么和 HTTP 建立的？
**答：** **HTTP 协议升级（Upgrade）**。客户端发 `Upgrade: websocket` 请求，服务端 101 Switching Protocols 响应，之后切换到 WS 协议。

### Q3：多个 SpringBoot 实例下 WebSocket 怎么广播给所有用户？
**答：** 用 **Redis Pub/Sub** 或 **MQ** 把消息同步到所有实例，再各自推给本实例的 WS 连接。

### Q4：SSE 为什么适合 LLM 流式？
**答：**
- LLM 是 token 流式输出
- 服务端推送即可，不需要客户端反向通信
- 走 HTTP 协议兼容性好
- 自动重连不丢消息

### Q5：WebSocket 怎么做权限？
**答：**
- 连接时：URL query 带 token，握手时验证
- STOMP：connectHeaders 带 Authorization
- 消息级：Spring Security WebSocket 拦截器

---

## 九、常见坑

| 坑 | 解决 |
| --- | --- |
| EventSource 不能 POST | 用 fetch 实现 SSE |
| WS 跨域 | setAllowedOriginPatterns("*") |
| 多实例消息只广播给当前实例 | Redis Pub/Sub 同步 |
| Nginx 反代 WS 失败 | 加 `proxy_set_header Upgrade $http_upgrade;` |
| 连接数受限 | 调 ulimit、用 NIO |
| 浏览器 6 个 SSE 限制 | 用 HTTP/2 |
| token 过期连接还在 | 服务端定期校验 |

---

## 十、推荐资源

- [MDN: SSE](https://developer.mozilla.org/zh-CN/docs/Web/API/Server-sent_events)
- [MDN: WebSocket](https://developer.mozilla.org/zh-CN/docs/Web/API/WebSocket)
- [Spring WebSocket](https://docs.spring.io/spring-framework/reference/web/websocket.html)
- [Spring WebFlux 流式](https://docs.spring.io/spring-framework/reference/web/webflux/reactive-spring.html)

---

## 十一、完成判定

- [ ] 能用 SSE 实现服务端推送
- [ ] 能用 fetch + ReadableStream 在前端处理 SSE
- [ ] 能用 Spring AI 流式输出 LLM
- [ ] 能用 Spring WebSocket + STOMP 写聊天室
- [ ] 能用 Redis Pub/Sub 实现跨实例 WS 广播
- [ ] 给 AI Chat 项目接入真正的流式 LLM
