# 第 15 周：Vue3 + Element Plus + 后台管理系统

> **本周学习目标**：用 Vue3 + Element Plus 完成一个能联调微服务后端的"后台管理系统"，作为简历上的前端项目。
>
> **本周关键词**：Vue3、Composition API、`<script setup>`、Vue Router、Pinia、Axios、Element Plus、权限路由、动态菜单
>
> **预计投入时间**：35~45 小时

---

## 一、知识点详细分解

### 1. Vue3 基础（1 天）

#### 1.1 创建项目

```bash
npm create vite@latest admin -- --template vue
cd admin
pnpm install
pnpm add vue-router pinia axios element-plus @element-plus/icons-vue
pnpm add -D unplugin-vue-components unplugin-auto-import
pnpm dev
```

#### 1.2 单文件组件（SFC）结构

```vue
<template>
  <div class="hello">
    <h1>{{ title }}</h1>
    <button @click="onClick">点击 {{ count }}</button>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue';

const title = ref('Hello Vue3');
const count = ref(0);

const onClick = () => count.value++;

onMounted(() => console.log('挂载'));
</script>

<style scoped>
.hello { padding: 20px; }
h1 { color: #409eff; }
</style>
```

#### 1.3 模板语法

```vue
<template>
  <!-- 文本 -->
  <p>{{ message }}</p>
  <p v-text="message"></p>
  <p v-html="rawHtml"></p>

  <!-- 属性绑定 -->
  <img :src="imgUrl" :alt="alt" />
  <a :href="`/user/${id}`">链接</a>
  <div :class="{ active: isActive, error: hasError }"></div>
  <div :class="['card', isActive && 'active']"></div>
  <div :style="{ color: textColor, fontSize: size + 'px' }"></div>

  <!-- 条件 -->
  <p v-if="show">显示</p>
  <p v-else-if="other">其他</p>
  <p v-else>隐藏</p>
  <p v-show="visible">v-show 用 display 控制</p>

  <!-- 列表 -->
  <li v-for="(item, index) in list" :key="item.id">
    {{ index }} - {{ item.name }}
  </li>

  <!-- 双向绑定 -->
  <input v-model="name" />
  <input v-model.number="age" />        <!-- 转 number -->
  <input v-model.trim="text" />          <!-- 去空格 -->
  <input v-model.lazy="text" />          <!-- 失焦才同步 -->

  <!-- 事件 -->
  <button @click="onClick">click</button>
  <button @click="onClick($event, 'arg')">带参</button>
  <button @click.stop="onClick">阻止冒泡</button>
  <button @click.prevent="onClick">阻止默认</button>
  <input @keyup.enter="onSubmit" />
</template>
```

#### 1.4 响应式 API（核心⭐）

```js
import { ref, reactive, computed, watch, watchEffect } from 'vue';

// ref：基本类型/对象都可，访问要 .value
const count = ref(0);
count.value++;

// reactive：仅对象，直接访问
const state = reactive({ name: 'Alice', age: 20 });
state.age++;

// 注意：reactive 解构会失去响应性，要用 toRefs
const { name, age } = toRefs(state);

// computed
const double = computed(() => count.value * 2);
const fullName = computed({
    get: () => state.firstName + ' ' + state.lastName,
    set: (v) => { [state.firstName, state.lastName] = v.split(' '); }
});

// watch
watch(count, (newVal, oldVal) => {
    console.log(`${oldVal} → ${newVal}`);
});

// 多源 watch
watch([count, () => state.age], ([newCount, newAge]) => { });

// 深度监听
watch(state, (val) => { }, { deep: true, immediate: true });

// watchEffect：自动追踪依赖
watchEffect(() => console.log(count.value));
```

#### 1.5 生命周期

```js
import {
    onBeforeMount, onMounted,
    onBeforeUpdate, onUpdated,
    onBeforeUnmount, onUnmounted
} from 'vue';

onMounted(() => console.log('组件挂载'));
onUnmounted(() => console.log('组件卸载'));
```

**完全掌握标准：**
- ✅ 能用 `<script setup>` 写组件
- ✅ 能熟用 ref / reactive / computed / watch
- ✅ 能用 v-if / v-for / v-model / @click / :class
- ✅ 知道 ref 和 reactive 的区别和使用场景

---

### 2. 组件通信（半天）

#### 2.1 父传子（props）

```vue
<!-- Parent -->
<UserCard :user="userData" :max="100" />

<!-- UserCard -->
<script setup>
const props = defineProps({
    user: { type: Object, required: true },
    max: { type: Number, default: 50 }
});
console.log(props.user);
</script>
```

#### 2.2 子传父（emit）

```vue
<!-- Child -->
<button @click="onClick">删除</button>
<script setup>
const emit = defineEmits(['delete', 'edit']);
const onClick = () => emit('delete', 123);
</script>

<!-- Parent -->
<UserCard @delete="handleDelete" @edit="handleEdit" />
```

#### 2.3 v-model（双向）

```vue
<!-- Child -->
<input :value="modelValue" @input="$emit('update:modelValue', $event.target.value)" />
<script setup>
defineProps(['modelValue']);
defineEmits(['update:modelValue']);
</script>

<!-- Parent -->
<MyInput v-model="text" />
```

#### 2.4 provide / inject（祖孙跨层）

```js
// 祖先
provide('theme', 'dark');
provide('toggleTheme', () => { });

// 子孙
const theme = inject('theme', 'light');     // 第二参数是默认值
```

#### 2.5 ref（拿子组件实例）

```vue
<MyDialog ref="dialogRef" />
<script setup>
const dialogRef = ref();
const openDialog = () => dialogRef.value.open();
</script>
```

---

### 3. Vue Router 4（半天）

#### 3.1 基础

```js
// router/index.js
import { createRouter, createWebHistory } from 'vue-router';

export const router = createRouter({
    history: createWebHistory(),
    routes: [
        { path: '/login', component: () => import('@/views/Login.vue'), meta: { public: true } },
        {
            path: '/',
            component: () => import('@/layout/Layout.vue'),
            redirect: '/dashboard',
            children: [
                { path: 'dashboard', component: () => import('@/views/Dashboard.vue') },
                { path: 'users', component: () => import('@/views/Users.vue'), meta: { roles: ['admin'] } },
                { path: 'users/:id', component: () => import('@/views/UserDetail.vue') }
            ]
        },
        { path: '/:pathMatch(.*)*', component: () => import('@/views/404.vue') }
    ]
});

// main.js
import { router } from './router';
createApp(App).use(router).mount('#app');
```

#### 3.2 路由组件 / 跳转

```vue
<router-link to="/users">用户</router-link>
<router-link :to="{ path: '/users/1' }">详情</router-link>
<router-view />

<script setup>
import { useRouter, useRoute } from 'vue-router';

const router = useRouter();
const route = useRoute();

router.push('/login');
router.push({ path: '/users/1' });
router.push({ name: 'user', params: { id: 1 }, query: { tab: 'info' } });
router.replace('/login');
router.go(-1);

console.log(route.path, route.params.id, route.query.tab);
</script>
```

#### 3.3 路由守卫（鉴权⭐）

```js
router.beforeEach((to, from, next) => {
    const token = localStorage.getItem('token');
    const userStore = useUserStore();

    // 公开页面直接放行
    if (to.meta.public) return next();

    // 未登录跳登录
    if (!token) return next('/login');

    // 角色校验
    if (to.meta.roles && !to.meta.roles.includes(userStore.role)) {
        return next('/403');
    }

    next();
});
```

#### 3.4 动态路由（菜单从后端拉）

```js
// 登录后
const menus = await api.getMenus();
menus.forEach(m => router.addRoute('layout', {
    path: m.path,
    component: () => import(`@/views/${m.component}.vue`),
    meta: { title: m.title, icon: m.icon }
}));
```

---

### 4. Pinia 状态管理（半天）

#### 4.1 创建 Store

```js
// stores/user.js
import { defineStore } from 'pinia';
import { ref, computed } from 'vue';

// Composition API 风格（推荐⭐）
export const useUserStore = defineStore('user', () => {
    const token = ref(localStorage.getItem('token') || '');
    const userInfo = ref(null);

    const isLogin = computed(() => !!token.value);

    async function login(username, password) {
        const res = await api.login(username, password);
        token.value = res.token;
        localStorage.setItem('token', res.token);
        await fetchUserInfo();
    }

    async function fetchUserInfo() {
        userInfo.value = await api.getUserInfo();
    }

    function logout() {
        token.value = '';
        userInfo.value = null;
        localStorage.removeItem('token');
    }

    return { token, userInfo, isLogin, login, fetchUserInfo, logout };
});
```

#### 4.2 使用

```vue
<script setup>
import { useUserStore } from '@/stores/user';
import { storeToRefs } from 'pinia';

const userStore = useUserStore();

// 解构响应式数据要用 storeToRefs（state、getters）
const { token, isLogin } = storeToRefs(userStore);

// action 可以直接解构
const { login, logout } = userStore;

login('admin', '123456');
</script>
```

#### 4.3 持久化插件

```bash
pnpm add pinia-plugin-persistedstate
```

```js
// main.js
import { createPinia } from 'pinia';
import piniaPersist from 'pinia-plugin-persistedstate';

const pinia = createPinia();
pinia.use(piniaPersist);

// stores/user.js
defineStore('user', { /* ... */ }, {
    persist: true                              // 自动存 localStorage
});
```

---

### 5. Axios 封装（⭐重点）

```js
// utils/request.js
import axios from 'axios';
import { useUserStore } from '@/stores/user';
import { ElMessage, ElMessageBox } from 'element-plus';
import { router } from '@/router';

const request = axios.create({
    baseURL: import.meta.env.VITE_API_BASE || '/api',
    timeout: 10000
});

// 请求拦截
request.interceptors.request.use(
    config => {
        const userStore = useUserStore();
        if (userStore.token) {
            config.headers.Authorization = `Bearer ${userStore.token}`;
        }
        return config;
    },
    error => Promise.reject(error)
);

// 响应拦截
request.interceptors.response.use(
    response => {
        const { code, message, data } = response.data;
        if (code === 200) return data;
        ElMessage.error(message || '请求失败');
        return Promise.reject(new Error(message));
    },
    error => {
        const status = error.response?.status;
        if (status === 401) {
            useUserStore().logout();
            ElMessageBox.confirm('登录已过期，请重新登录', '提示').then(() => {
                router.push('/login');
            });
        } else if (status === 403) {
            ElMessage.error('权限不足');
        } else if (status >= 500) {
            ElMessage.error('服务器异常');
        } else {
            ElMessage.error(error.message);
        }
        return Promise.reject(error);
    }
);

export default request;
```

#### API 模块化

```js
// api/user.js
import request from '@/utils/request';

export const login = (data) => request.post('/users/login', data);
export const getUserInfo = () => request.get('/users/me');
export const listUsers = (params) => request.get('/users', { params });
export const createUser = (data) => request.post('/users', data);
export const updateUser = (id, data) => request.put(`/users/${id}`, data);
export const deleteUser = (id) => request.delete(`/users/${id}`);
```

---

### 6. Element Plus（1 天）

#### 6.1 引入 + 自动按需

```js
// vite.config.js
import AutoImport from 'unplugin-auto-import/vite';
import Components from 'unplugin-vue-components/vite';
import { ElementPlusResolver } from 'unplugin-vue-components/resolvers';

export default {
    plugins: [
        vue(),
        AutoImport({ resolvers: [ElementPlusResolver()] }),
        Components({ resolvers: [ElementPlusResolver()] })
    ]
};
```

#### 6.2 必会组件

```vue
<!-- 表单 -->
<el-form :model="form" :rules="rules" ref="formRef" label-width="80px">
    <el-form-item label="用户名" prop="username">
        <el-input v-model="form.username" placeholder="请输入" />
    </el-form-item>
    <el-form-item label="密码" prop="password">
        <el-input v-model="form.password" type="password" show-password />
    </el-form-item>
    <el-form-item label="角色" prop="role">
        <el-select v-model="form.role">
            <el-option label="管理员" value="admin" />
            <el-option label="普通" value="user" />
        </el-select>
    </el-form-item>
    <el-form-item>
        <el-button type="primary" @click="onSubmit">提交</el-button>
        <el-button @click="onReset">重置</el-button>
    </el-form-item>
</el-form>

<!-- 表格 -->
<el-table :data="users" border stripe v-loading="loading">
    <el-table-column type="selection" width="50" />
    <el-table-column prop="id" label="ID" width="80" />
    <el-table-column prop="name" label="姓名" />
    <el-table-column prop="email" label="邮箱" show-overflow-tooltip />
    <el-table-column label="状态">
        <template #default="{ row }">
            <el-tag :type="row.active ? 'success' : 'info'">
                {{ row.active ? '启用' : '禁用' }}
            </el-tag>
        </template>
    </el-table-column>
    <el-table-column label="操作" width="200" fixed="right">
        <template #default="{ row }">
            <el-button size="small" @click="onEdit(row)">编辑</el-button>
            <el-popconfirm title="确认删除？" @confirm="onDelete(row.id)">
                <template #reference>
                    <el-button size="small" type="danger">删除</el-button>
                </template>
            </el-popconfirm>
        </template>
    </el-table-column>
</el-table>

<!-- 分页 -->
<el-pagination
    v-model:current-page="page"
    v-model:page-size="size"
    :total="total"
    :page-sizes="[10, 20, 50]"
    layout="total, sizes, prev, pager, next, jumper"
    @current-change="loadList"
    @size-change="loadList"
/>

<!-- 弹窗 -->
<el-dialog v-model="dialogVisible" title="编辑用户" width="500">
    <UserForm :data="editing" @success="onSuccess" />
</el-dialog>

<!-- 消息 -->
ElMessage.success('保存成功');
ElMessageBox.confirm('确认删除？', '提示', { type: 'warning' });

<!-- 上传 -->
<el-upload :action="uploadUrl" :headers="uploadHeaders" :on-success="onSuccess">
    <el-button type="primary">点击上传</el-button>
</el-upload>
```

---

### 7. 后台管理布局（半天）

```
┌──────────────────────────────────────────┐
│  顶部导航（用户信息、退出）                  │
├────────┬─────────────────────────────────┤
│        │                                  │
│ 侧边栏  │       内容区（router-view）      │
│ 菜单    │                                  │
│        │                                  │
└────────┴─────────────────────────────────┘
```

```vue
<!-- Layout.vue -->
<template>
    <el-container class="layout">
        <el-aside width="220px">
            <Sidebar />
        </el-aside>
        <el-container>
            <el-header>
                <Header />
            </el-header>
            <el-main>
                <router-view />
            </el-main>
        </el-container>
    </el-container>
</template>
```

---

### 8. 权限控制（⭐重点）

#### 8.1 路由级权限

- 路由 meta 标记 roles
- beforeEach 校验

#### 8.2 按钮级权限

```js
// directives/permission.js
export const permission = {
    mounted(el, binding) {
        const userStore = useUserStore();
        if (!userStore.permissions.includes(binding.value)) {
            el.parentNode?.removeChild(el);
        }
    }
};

// main.js
app.directive('permission', permission);
```

```vue
<el-button v-permission="'user:delete'">删除</el-button>
```

---

## 二、每日学习安排

| 天 | 学习内容 | 上机练习 | 时长 |
| --- | --- | --- | --- |
| **周一** | Vue3 基础 + 模板 + 响应式 | TodoList 基础版 | 5h |
| **周二** | 组件通信 + 生命周期 | 拆分 TodoList 成多组件 | 5h |
| **周三** | Vue Router + 嵌套路由 + 守卫 | 路由 + 登录跳转 | 6h |
| **周四** | Pinia + Axios 封装 | API + Store 整套 | 6h |
| **周五** | Element Plus 表单 + 表格 + 弹窗 | CRUD 页面 | 6h |
| **周六** | 后台布局 + 权限 + 主题 | 完整布局 + 权限路由 | 6h |
| **周日** | 联调微服务后端 + 综合复盘 | 联调 → GitHub | 5h |

---

## 三、本周必做实战项目

### 项目：后台管理系统（联调微服务）

**功能：**
- 登录页（账号密码 + 验证码）
- 主布局（侧边栏 + 顶部 + 标签页）
- 用户管理（CRUD + 角色分配 + 启停）
- 商品管理（CRUD + 图片上传）
- 订单管理（列表 + 详情 + 状态流转）
- 个人中心（修改密码、头像）
- 仪表盘（用 ECharts 简单图表）

**技术要求：**
- ✅ Vue3 + Vite + Pinia + Vue Router + Element Plus + Axios
- ✅ JWT 鉴权 + 401 自动跳转
- ✅ 路由级 + 按钮级权限
- ✅ Axios 拦截器统一错误
- ✅ 联调上周（第 13 周）的微服务后端
- ✅ 部署：Nginx 静态文件 + 反向代理

**验收：**
- ✅ 5 个模块功能完整
- ✅ 登录 / 退出 / 401 流程正常
- ✅ 不同角色看到不同菜单
- ✅ 表格 + 分页 + 搜索 + 弹窗规范
- ✅ README + 截图
- ✅ 提交 GitHub

---

## 四、完全掌握检查清单

- [ ] 能用 `<script setup>` + Composition API 写组件
- [ ] 能用 ref / reactive / computed / watch
- [ ] 4 种父子通信都会（props / emit / v-model / provide-inject）
- [ ] 能配嵌套路由 + 路由守卫
- [ ] 能用 Pinia 管理状态 + 持久化
- [ ] 能封装 axios 拦截器（含 token / 错误处理）
- [ ] 能用 Element Plus 写完整 CRUD 页面
- [ ] 能实现路由级 + 按钮级权限
- [ ] 完成后台管理系统并联调后端 + 提交 GitHub

---

## 五、自测题

**Q1：** ref 和 reactive 的区别？什么时候用哪个？
**答：**
- ref：基本类型 / 对象都行，访问要 .value
- reactive：仅对象，直接访问，**解构会失去响应性**（用 toRefs）
- 推荐：基本类型用 ref，对象/数组也可以用 ref（因为统一）

---

**Q2：** Pinia 和 Vuex 区别？
**答：**
- Pinia 是 Vue3 官方推荐
- 不需要 mutation（直接改 state）
- 完美 TS 支持
- 模块化更简单（每个 store 独立文件）
- 体积更小

---

**Q3：** v-if 和 v-show 区别？
**答：**
- v-if：真删除/创建 DOM，切换开销大
- v-show：用 display:none 控制，切换快
- 频繁切换用 v-show，条件少变用 v-if

---

**Q4：** Composition API 优势？
**答：**
- 逻辑复用更优雅（自定义 hook）
- 类型推导更好
- 同一个功能的代码集中
- Tree-shaking 友好

---

## 六、常见坑

| 坑 | 解决 |
| --- | --- |
| reactive 解构失去响应 | 用 toRefs |
| ref 模板里要 .value 吗 | 模板里自动解包，JS 里要 .value |
| watch 不触发 | 监听 reactive 子属性用函数 `() => state.x` |
| router 跳转后页面不更新 | params 变化要用 watch route |
| Element Plus 中文 | `app.use(ElementPlus, { locale: zhCn })` |
| 跨域 | Vite proxy 或后端 CORS |

---

## 七、推荐资源

- [Vue3 官方文档](https://cn.vuejs.org/)
- [Pinia 文档](https://pinia.vuejs.org/zh/)
- [Element Plus](https://element-plus.org/zh-CN/)
- 视频：尚硅谷 Vue3 + Element Plus 全套
- 项目参考：[vue-element-admin](https://github.com/PanJiaChen/vue-element-admin)、[vue-vben-admin](https://github.com/vbenjs/vue-vben-admin)

---

## 八、本周完成后的"自我画像"

> "我能用 Vue3 + Composition API 写组件。
> 我会用 Pinia + Vue Router + Axios 搭项目。
> 我能用 Element Plus 完成 CRUD 后台管理系统。
> 我已经联调了我的微服务后端，前后端打通。
> 下周开始 React + AI Chat。"

---

## 九、下周预告

第 16 周：**React + Ant Design + AI Chat 页面**——为接入 LLM 做前端准备。
