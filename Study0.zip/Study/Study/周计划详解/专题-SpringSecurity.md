# 专题：Spring Security + OAuth 2.0

> **建议学习时机**：第 8 周（数据库整合）后立刻补，企业项目普遍使用。
>
> **核心定位**：**JDK 自带的 JWT 拦截器是练手版，Spring Security 才是企业级标准**。
>
> **预计投入**：6~8 小时

---

## 一、为什么用 Spring Security

### 自己写 JWT 拦截器的问题

- 安全漏洞容易漏（XSS、CSRF、SQL 注入、密码爆破）
- 没有标准化的角色 / 权限模型
- OAuth 2.0 / OIDC 自己实现等于重新发明轮子
- 不能配合 Spring 生态（Method Security、CORS、CSRF）

### Spring Security 提供

- 认证（Authentication）+ 授权（Authorization）
- 密码加密（BCrypt 等）
- 会话管理
- CSRF / CORS / XSS 防护
- OAuth 2.0 / OIDC / SAML 集成
- 方法级权限（@PreAuthorize）

---

## 二、核心概念（懂这个就懂 80%）

```
HTTP Request
    │
    ▼
[Filter Chain]                              ← 一连串过滤器
    │
    ├─ SecurityContextHolderFilter
    ├─ UsernamePasswordAuthenticationFilter  ← 登录拦截
    ├─ JwtAuthenticationFilter (自定义)       ← JWT 解析
    ├─ ExceptionTranslationFilter
    └─ FilterSecurityInterceptor             ← 权限判断
    │
    ▼
Controller
```

### 关键对象

| 对象 | 含义 |
| --- | --- |
| `Authentication` | 认证信息（who） |
| `GrantedAuthority` | 权限（can do what） |
| `UserDetails` | 用户详情（账号、密码、权限） |
| `UserDetailsService` | 加载用户（DB / LDAP / ...） |
| `PasswordEncoder` | 密码加密 |
| `SecurityContext` | 当前请求的安全上下文 |
| `SecurityFilterChain` | 过滤器链 |

---

## 三、基础配置（SpringBoot 3 + Spring Security 6）

### 3.1 引依赖

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-security</artifactId>
</dependency>
```

### 3.2 默认行为

引入依赖后：
- 所有接口都需要登录
- 自动生成一个用户 `user`，密码在启动日志里
- `/login` 自动提供登录页

### 3.3 自定义配置

```java
@Configuration
@EnableWebSecurity
@EnableMethodSecurity     // 开启方法级权限
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtFilter;

    public SecurityConfig(JwtAuthenticationFilter jwtFilter) {
        this.jwtFilter = jwtFilter;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        return http
            // 关闭 CSRF（JWT 不需要）
            .csrf(AbstractHttpConfigurer::disable)

            // CORS
            .cors(Customizer.withDefaults())

            // 无状态（不用 Session）
            .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))

            // 路径权限
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/api/auth/**", "/swagger-ui/**", "/v3/api-docs/**").permitAll()
                .requestMatchers("/api/admin/**").hasRole("ADMIN")
                .requestMatchers(HttpMethod.GET, "/api/articles/**").permitAll()
                .anyRequest().authenticated()
            )

            // JWT 过滤器（放在 UsernamePasswordAuthenticationFilter 前）
            .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class)

            // 异常处理
            .exceptionHandling(ex -> ex
                .authenticationEntryPoint((req, resp, e) -> {
                    resp.setStatus(401);
                    resp.setContentType("application/json;charset=UTF-8");
                    resp.getWriter().write("{\"code\":401,\"message\":\"未登录\"}");
                })
                .accessDeniedHandler((req, resp, e) -> {
                    resp.setStatus(403);
                    resp.setContentType("application/json;charset=UTF-8");
                    resp.getWriter().write("{\"code\":403,\"message\":\"权限不足\"}");
                })
            )

            .build();
    }
}
```

---

## 四、JWT 整合（核心⭐）

### 4.1 JWT 工具类

```java
@Component
public class JwtUtil {
    @Value("${jwt.secret}")
    private String secret;

    @Value("${jwt.expiration:86400000}")
    private long expiration;

    public String generate(Long userId, String username, Collection<? extends GrantedAuthority> authorities) {
        return Jwts.builder()
            .subject(userId.toString())
            .claim("username", username)
            .claim("authorities", authorities.stream().map(GrantedAuthority::getAuthority).toList())
            .issuedAt(new Date())
            .expiration(new Date(System.currentTimeMillis() + expiration))
            .signWith(Keys.hmacShaKeyFor(secret.getBytes()))
            .compact();
    }

    public Claims parse(String token) {
        return Jwts.parser()
            .verifyWith(Keys.hmacShaKeyFor(secret.getBytes()))
            .build()
            .parseSignedClaims(token)
            .getPayload();
    }
}
```

### 4.2 JWT 过滤器

```java
@Component
@RequiredArgsConstructor
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private final JwtUtil jwtUtil;
    private final UserDetailsService userDetailsService;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws ServletException, IOException {
        String header = request.getHeader("Authorization");
        if (header == null || !header.startsWith("Bearer ")) {
            chain.doFilter(request, response);
            return;
        }
        try {
            String token = header.substring(7);
            Claims claims = jwtUtil.parse(token);
            String username = claims.get("username", String.class);

            if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
                UserDetails user = userDetailsService.loadUserByUsername(username);
                UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken(
                    user, null, user.getAuthorities()
                );
                auth.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                SecurityContextHolder.getContext().setAuthentication(auth);
            }
        } catch (Exception e) {
            // token 无效，继续过滤链，让权限检查决定怎么处理
        }
        chain.doFilter(request, response);
    }
}
```

### 4.3 UserDetailsService 实现

```java
@Service
@RequiredArgsConstructor
public class UserDetailsServiceImpl implements UserDetailsService {

    private final UserMapper userMapper;

    @Override
    public UserDetails loadUserByUsername(String username) {
        User user = userMapper.findByUsername(username);
        if (user == null) throw new UsernameNotFoundException("用户不存在");

        return org.springframework.security.core.userdetails.User.builder()
            .username(user.getUsername())
            .password(user.getPassword())
            .authorities(user.getRoles().stream()
                .map(r -> new SimpleGrantedAuthority("ROLE_" + r))
                .toList())
            .accountExpired(false)
            .accountLocked(!user.isActive())
            .build();
    }
}
```

### 4.4 登录 Controller

```java
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthenticationManager authManager;
    private final JwtUtil jwtUtil;

    @PostMapping("/login")
    public Result<Map<String, String>> login(@RequestBody LoginDTO dto) {
        Authentication auth = authManager.authenticate(
            new UsernamePasswordAuthenticationToken(dto.getUsername(), dto.getPassword())
        );

        UserDetails user = (UserDetails) auth.getPrincipal();
        String token = jwtUtil.generate(
            ((MyUserDetails) user).getId(),
            user.getUsername(),
            user.getAuthorities()
        );

        return Result.success(Map.of("token", token));
    }
}
```

---

## 五、方法级权限（@PreAuthorize）

```java
@RestController
public class AdminController {

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/users/{id}")
    public Result<?> delete(@PathVariable Long id) { ... }

    @PreAuthorize("hasAuthority('user:read') or hasRole('ADMIN')")
    @GetMapping("/users")
    public Result<?> list() { ... }

    @PreAuthorize("#id == authentication.principal.id")
    @PutMapping("/users/{id}")
    public Result<?> update(@PathVariable Long id, @RequestBody UserDTO dto) { ... }
    // 只能改自己

    @PostAuthorize("returnObject.owner == authentication.principal.username")
    @GetMapping("/articles/{id}")
    public Article get(@PathVariable Long id) { ... }
    // 返回后判断（如返回的文章作者必须是当前用户）
}
```

**SpEL 表达式：**
- `hasRole('ADMIN')`：检查角色（自动加 ROLE_ 前缀）
- `hasAuthority('user:read')`：检查权限
- `hasAnyRole('ADMIN', 'MANAGER')`
- `#id == authentication.principal.id`：方法参数 vs 当前用户

---

## 六、获取当前用户

```java
@GetMapping("/me")
public Result<?> me() {
    Authentication auth = SecurityContextHolder.getContext().getAuthentication();
    UserDetails user = (UserDetails) auth.getPrincipal();
    return Result.success(user);
}

// 或用 @AuthenticationPrincipal
@GetMapping("/me")
public Result<?> me(@AuthenticationPrincipal UserDetails user) {
    return Result.success(user);
}
```

---

## 七、CORS 配置

```java
@Bean
public CorsConfigurationSource corsConfigurationSource() {
    CorsConfiguration cfg = new CorsConfiguration();
    cfg.setAllowedOriginPatterns(List.of("*"));
    cfg.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
    cfg.setAllowedHeaders(List.of("*"));
    cfg.setExposedHeaders(List.of("Authorization"));
    cfg.setAllowCredentials(true);
    cfg.setMaxAge(3600L);

    UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
    source.registerCorsConfiguration("/**", cfg);
    return source;
}
```

---

## 八、OAuth 2.0（半天）

### 8.1 OAuth 2.0 是什么

授权框架。让用户用第三方账号登录你的应用（微信 / GitHub / Google）。

### 8.2 4 种授权模式

| 模式 | 适用 |
| --- | --- |
| Authorization Code（最常用） | Web 应用 |
| Implicit（已弃用） | SPA（旧） |
| Password | 自己的应用 |
| Client Credentials | 服务对服务 |

### 8.3 标准 Authorization Code 流程

```
User             Client               GitHub
 │                 │                    │
 │ click "login"   │                    │
 ├────────────────▶│                    │
 │                 │ redirect to oauth  │
 │                 ├───────────────────▶│
 │  authorize?     │                    │
 │◀───────────────────────────────────  │
 │  yes            │                    │
 ├───────────────────────────────────  ▶│
 │                 │  redirect + code   │
 │                 │◀───────────────────│
 │                 │ exchange code      │
 │                 ├───────────────────▶│
 │                 │     access_token   │
 │                 │◀───────────────────│
 │                 │ get user info      │
 │                 ├───────────────────▶│
 │                 │     user info      │
 │                 │◀───────────────────│
 │  login success  │                    │
 │◀────────────────│                    │
```

### 8.4 Spring Security OAuth2 Client（让你的应用接 GitHub 登录）

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-oauth2-client</artifactId>
</dependency>
```

```yaml
spring:
  security:
    oauth2:
      client:
        registration:
          github:
            client-id: ${GITHUB_CLIENT_ID}
            client-secret: ${GITHUB_CLIENT_SECRET}
            scope: read:user, user:email
```

```java
@Bean
public SecurityFilterChain filter(HttpSecurity http) throws Exception {
    return http
        .authorizeHttpRequests(a -> a.anyRequest().authenticated())
        .oauth2Login(Customizer.withDefaults())   // 自动有 /oauth2/authorization/github
        .build();
}

@GetMapping("/me")
public Map<String, Object> me(@AuthenticationPrincipal OAuth2User user) {
    return user.getAttributes();
}
```

访问 `/oauth2/authorization/github` 自动跳转 GitHub 登录。

### 8.5 OAuth2 Resource Server（保护 API）

如果别人的 OAuth 服务器签发 JWT，你的服务作为资源服务器：

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-oauth2-resource-server</artifactId>
</dependency>
```

```yaml
spring:
  security:
    oauth2:
      resourceserver:
        jwt:
          issuer-uri: https://auth.example.com
```

```java
http.oauth2ResourceServer(c -> c.jwt(Customizer.withDefaults()));
```

Spring 自动验证 JWT 签名 + 过期 + iss。

### 8.6 OIDC（OpenID Connect）

OAuth 2.0 + 身份认证。比纯 OAuth 多一个 `id_token`（含用户信息）。

---

## 九、CSRF / XSS / 密码爆破防护

### 9.1 CSRF

Session 模式默认开启，JWT 模式关闭（无状态）。

### 9.2 密码爆破

- 登录失败次数限制（Redis 计数 + 锁定）
- 验证码（图形 / 短信）
- 二次认证（2FA）

```java
@Component
@RequiredArgsConstructor
public class LoginAttemptService {
    private final StringRedisTemplate redis;
    private static final int MAX_ATTEMPTS = 5;

    public void loginFailed(String username) {
        String key = "login:fail:" + username;
        Long count = redis.opsForValue().increment(key);
        if (count == 1) redis.expire(key, 30, TimeUnit.MINUTES);
        if (count >= MAX_ATTEMPTS) {
            redis.opsForValue().set("login:lock:" + username, "1", 30, TimeUnit.MINUTES);
        }
    }

    public boolean isLocked(String username) {
        return redis.hasKey("login:lock:" + username);
    }
}
```

---

## 十、面试要点

### Q1：Spring Security 的核心是什么？
**答：** Filter Chain。每个请求经过一系列过滤器，做认证、授权、CORS、CSRF 等。`SecurityFilterChain` 是入口。

### Q2：JWT 和 Session 哪个好？
**答：**
- Session：服务端存储、易撤销、适合单体
- JWT：无状态、易扩展、适合微服务 / 分布式
- 都不完美：JWT 难主动失效（用 Redis 黑名单补救）

### Q3：@PreAuthorize 和 @Secured 区别？
**答：**
- @Secured：仅支持角色（`@Secured("ROLE_ADMIN")`）
- @PreAuthorize：支持 SpEL（更强大），推荐用

### Q4：OAuth 2.0 vs OIDC？
**答：**
- OAuth 2.0：授权（让别的应用用你的资源）
- OIDC：在 OAuth 之上加身份认证，提供 `id_token`

### Q5：怎么实现"踢人下线"？
**答：**
- Session 模式：直接销毁 session
- JWT 模式：Redis 黑名单（把 token 放 Redis，过滤器检查）

---

## 十一、常见坑

| 坑 | 解决 |
| --- | --- |
| `Could not initialize Spring Security` | 检查 SecurityFilterChain Bean |
| 401 但应该 200 | 检查 permitAll 路径 |
| 跨域失败 | 配置 CorsConfigurationSource + http.cors() |
| Role vs Authority | hasRole 自动加 ROLE_ 前缀 |
| @PreAuthorize 不生效 | 加 @EnableMethodSecurity |
| CSRF 接口报 403 | JWT 模式关闭 csrf |
| 旧版 API 不一致 | Spring Security 6 大改，注意版本 |

---

## 十二、推荐资源

- [Spring Security 文档](https://docs.spring.io/spring-security/reference/)
- [Spring Security 6 迁移指南](https://docs.spring.io/spring-security/reference/migration/index.html)
- [OAuth 2.0 RFC](https://datatracker.ietf.org/doc/html/rfc6749)
- 书：《Spring Security 实战》

---

## 十三、完成判定

- [ ] 能用 Spring Security 6 配置 JWT 鉴权
- [ ] 能实现 UserDetailsService 从 DB 加载
- [ ] 能用 @PreAuthorize 做方法级权限
- [ ] 能配 CORS + CSRF
- [ ] 能用 oauth2Login 接 GitHub 登录
- [ ] 能用 Redis 实现登录失败锁定
- [ ] 把第 9 周项目的手写 JWT 拦截器替换为 Spring Security
